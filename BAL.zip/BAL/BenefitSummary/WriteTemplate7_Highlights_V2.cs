﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using StringTrimmer;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate7_Highlights_V2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        ////public void WriteFieldToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, string selectedColor = "Grey")
        public void WriteFieldToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRCData> BRCList, string ddlBRCSelectedValue, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, string selectedColor = "Grey")
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);


                ////if (ddlBRC.SelectedIndex > 1)
                ////{
                ////    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                ////}
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                            string effective_year = Convert.ToDateTime(effectivedate.ToString()).Year.ToString().Trim();

                            comFunObj.Write_Field_Header(oWordDoc, oWordApp, effective_year, selectedColor);

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client Name1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                    }
                                    if (fieldName.Contains("ELIGIBLITY"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("ELIGIBLITY");
                                    }
                                    if (fieldName.Contains("SUPPLEMENTAL AND VOLUNTARY PLANS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUPPLEMENTAL AND VOLUNTARY PLANS");
                                    }
                                    if (fieldName.Contains("MedicalEffectiveYear"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(effective_year);
                                    }


                                    //if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                                    //{
                                    //    myMergeField.Select();

                                    //    if (Emp.Rows.Count > 0)
                                    //    {

                                    //        oWordApp.Selection.TypeText(Convert.ToString(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()).ToLower());
                                    //    }
                                    //    else
                                    //    {
                                    //        oWordApp.Selection.TypeText(" ");
                                    //    }
                                    //}

                                    //if (Emp.Rows.Count > 0)
                                    //{
                                    //    if (fieldName.Contains("Employee Status"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        if (Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim().Length == 0)
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                    //        }
                                    //    }
                                    //    if (fieldName.Contains("Working"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        if (Emp.Rows[0]["VALUE"].ToString().Trim().Length == 0)
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                    //        }
                                    //    }

                                    //    if (fieldName.Contains("Frequency"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        if (Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim().Length == 0)
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                    //        }
                                    //    }
                                    //    if (fieldName.Contains("unitofmeasure"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        if (Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim().Length == 0)
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                    //        }
                                    //    }
                                    //}
                                    //if (fieldName.Contains("Medical/Eligibility Rule/Waiting Period"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim().Length == 0)
                                    //        {
                                    //            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim_String().ToLower());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim_String().ToLower());
                                    //        }
                                    //    }
                                    //    else
                                    //    {
                                    //        oWordApp.Selection.TypeText(" ");
                                    //    }
                                    //}

                                    ///if (BRCindex > -1)
                                    if (ddlBRCSelectedValue == "YES" && BRCList.Count > 0) // IF BRC Want to Include
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText("BENEFIT RESOURCE CENTER");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        /// <param name="dtPlanContactDetails">DataTable dtPlanContactDetails contain the plan contact information (Optional Parameter)</param>
        public void WriteContactinformationToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string selectedColor = "", DataTable dtPlanContactDetails = null)
        {
            try
            {
                //// Approach 1
                //int count = 9;

                // Approach 2
                int count = 7;

                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                DataRow[] foundRows = null;
                int cnt = 2;

                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;

                int rowCnt = 2;
                foreach (Word.Border border in oWordDoc.Tables[count].Borders)
                {
                    carrier = oWordDoc.Tables[count].Cell(cnt, 1).Range.Text;
                    //description_Policy = oWordDoc.Tables[count].Cell(cnt, 2).Range.Text;
                    website_phone = oWordDoc.Tables[count].Cell(cnt, 2).Range.Text.Replace("\r\r", "\r");
                }

                oWordDoc.Tables[count].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[count].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[count].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[count].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[count].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        //if (k > 1)
                        //{
                        //    oWordDoc.Tables[count].Rows.Add();
                        //}
                        carriername = PlanTable.Rows[i]["Carrier"].ToString();
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        /*
                        //ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                        //oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"].ToString()) + " / " + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());
                        //foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");
                         */

                        var planContactName = (from n in dtPlanContactDetails.AsEnumerable()
                                               where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                               select n.Field<string>("ContactName")).FirstOrDefault();

                        var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                                where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();

                        if (!string.IsNullOrEmpty(planContactName) || !string.IsNullOrEmpty(planContactPhone))
                        {
                            //carriername = PlanTable.Rows[i]["Carrier"].ToString();
                            // plantype = PlanTable.Rows[i]["PlanType"].ToString();
                            ////ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                            oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                            ////oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"].ToString()) + " / " + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());
                            // //foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");
                            oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(planContactName) + "\n" + Convert.ToString(planContactPhone);

                            oWordDoc.Tables[count].Rows.Add();
                            //k++;
                            rowCnt++;
                        }
                    }
                }
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("contactinfo"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                    }
                }
                if (oWordDoc.Tables[count].Rows.Last.Cells[1].Range.Text == "\r\a")
                {
                    oWordDoc.Tables[count].Rows.Last.Delete();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlMedicalNoOfPlan">Dropdownlist ddlMedicalNoOfPlan Object</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataTable PlanTypeSpecific, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlMedicalNoOfPlan, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string selectedColor = "Grey")
        {
            try
            {
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                int count = 1;

                ArrayList arrMedical = new ArrayList();
                ArrayList arrMedicalPlanType = new ArrayList();


                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedical.Add(3, "45");             // Annual Deductible [Individual]
                HashtableMedical.Add(33, "44");            // Annual Deductible [Maximum Per Family]
                HashtableMedical.Add(4, "16");             // Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedical.Add(5, "386");            // Professional [Office Visit]
                HashtableMedical.Add(6, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedical.Add(7, "971");            //Other Services[Complex Radiology]
                // HashtableMedical.Add(6, "295");            // Hospital / Facility[Inpatient Care] 
                HashtableMedical.Add(8, "295");            // Hospital / Facility[Inpatient Care]
                HashtableMedical.Add(99, "52");            // Annual Out of Pocket Maximum (Family)
                HashtableMedical.Add(10, "53");             // Annual Out of Pocket Maximum (Individual)
                #endregion

                string Family_Plan1 = string.Empty;
                string Family_Plan2 = string.Empty;
                string Family_Plan3 = string.Empty;
                string Family_Plan4 = string.Empty;

                string OutOfPocket_Family_Plan1 = string.Empty;
                string OutOfPocket_Family_Plan2 = string.Empty;
                string OutOfPocket_Family_Plan3 = string.Empty;
                string OutOfPocket_Family_Plan4 = string.Empty;


                oWordDoc.Tables[1].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[1].Rows[2].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[1].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[1].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[1].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                // Approach 1
                //oWordDoc.Tables[6].Range.Font.Color = comFunObj.font_color(selectedColor);
                //oWordDoc.Tables[6].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                //oWordDoc.Tables[6].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                //oWordDoc.Tables[6].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[6].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);


                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {

                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            # region MergeField

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Number of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlMedicalNoOfPlan.SelectedItem.Text.Trim());
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Monthly Contribution"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("Offers"))
                                    {
                                        myMergeField.Select();
                                        if (ddlMedicalNoOfPlan.SelectedItem.Text == "2" || ddlMedicalNoOfPlan.SelectedItem.Text == "3")
                                        {
                                            oWordApp.Selection.TypeText("offers a choice between");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("offers");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Med_Plan"))
                                    {
                                        myMergeField.Select();
                                        if (ddlMedicalNoOfPlan.SelectedItem.Text == "2" || ddlMedicalNoOfPlan.SelectedItem.Text == "3")
                                        {
                                            oWordApp.Selection.TypeText("medical plans. You can choose the");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("medical plan, the");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Plan Type" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!arrMedicalPlanType.Contains(PlanTable.Rows[k]["SummaryName"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["SummaryName"].ToString() + " plan ");
                                                arrMedicalPlanType.Add(PlanTable.Rows[k]["SummaryName"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString() + " plan");
                                            arrMedicalPlanType.Add(PlanTable.Rows[k]["SummaryName"].ToString().Trim());
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Carrier Name" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!arrMedical.Contains(PlanTable.Rows[k]["Carrier"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                arrMedical.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                continue;
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            arrMedical.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            continue;
                                        }

                                    }
                                    if (fieldName.Contains("MEDICAL Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("MEDICAL");
                                        continue;
                                    }
                                }
                            }
                            #endregion

                            #region MedicalTable

                            oWordDoc.Tables[1].Cell(2, count + 1).Select();
                            oWordDoc.Tables[1].Cell(2, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            // Approach 1
                            //oWordDoc.Tables[6].Cell(1, count + 1).Select();
                            //oWordDoc.Tables[6].Cell(1, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 33)
                                            {
                                                Family_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan1;
                                            }
                                            if (key == 99)
                                            {
                                                OutOfPocket_Family_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan1;
                                            }

                                            else if (key != 33 && key != 3 && key != 99 && key != 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Family_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan2;
                                            }
                                            if (key == 99)
                                            {
                                                OutOfPocket_Family_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan2;
                                            }
                                            else if (key != 33 && key != 3 && key != 99 && key != 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Family_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan3;
                                            }
                                            if (key == 99)
                                            {
                                                OutOfPocket_Family_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan3;
                                            }
                                            else if (key != 33 && key != 3 && key != 99 && key != 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 4)
                                        {
                                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Family_Plan4 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan4;
                                            }
                                            if (key == 99)
                                            {
                                                OutOfPocket_Family_Plan4 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan4;
                                            }
                                            else if (key != 33 && key != 3 && key != 99 && key != 10)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }
                oWordDoc.Tables[1].Rows[1].Cells.Borders.Enable = 0;
                count = count - 1;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (count > 1)
                        {
                            if (fieldName.Contains("multiplemedical"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("singlemedical"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("  ");
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        public void WriteDentalSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataTable PlanTypeSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                ArrayList Dental_Carrier = new ArrayList();
                ArrayList Dental_PlanType = new ArrayList();
                #region HashtableDental
                Hashtable HashtableDental = new Hashtable();
                HashtableDental.Add(33, "45");     // Annual Deductible[Individual]
                HashtableDental.Add(3, "44");      // Annual Deductible[Family]
                HashtableDental.Add(4, "164");     // Dental Categories[Preventive & Diagnostic Care]
                HashtableDental.Add(5, "64");      // Dental Categories[Basic Restorative Care]
                HashtableDental.Add(6, "336");     // Dental Categories[Major Restorative Care]
                HashtableDental.Add(7, "55");      // Benefit Year Maximum 
                #endregion
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                ConstantValue cv = new ConstantValue();
                string Annual_Deductible_Individual_Plan1 = string.Empty;
                string Annual_Deductible_Individual_Plan2 = string.Empty;
                string Annual_Deductible_Individual_Plan3 = string.Empty;
                string Annual_Deductible_Individual_Plan4 = string.Empty;

                oWordDoc.Tables[3].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[3].Rows[2].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[3].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[3].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[3].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                // Approach 1
                //oWordDoc.Tables[7].Range.Font.Color = comFunObj.font_color(selectedColor);
                //oWordDoc.Tables[7].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                //oWordDoc.Tables[7].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                //oWordDoc.Tables[7].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[7].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);


                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("DENTAL Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("DENTAL");
                                    }

                                    if (fieldName.Contains("Dental Monthly Contribution"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }

                                    if (fieldName.Contains("Dental Carrier Name" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!Dental_Carrier.Contains(PlanTable.Rows[k]["Carrier"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                Dental_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }

                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Dental_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        }
                                        continue;
                                    }
                                }
                            }

                            #endregion
                            oWordDoc.Tables[3].Rows[1].Cells.Borders.Enable = 0;
                            #region DetalTable

                            oWordDoc.Tables[3].Cell(2, count + 1).Select();
                            oWordDoc.Tables[3].Cell(2, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            // Approach 1
                            //oWordDoc.Tables[7].Cell(1, count + 1).Select();
                            //oWordDoc.Tables[7].Cell(1, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            foreach (int key in HashtableDental.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDental[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan1 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan2 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }

                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan3 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }

                                        if (count == 4)
                                        {
                                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan4 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan4 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                int iTotalFields = 0;

                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableSTD
                HashtableSTD.Add(1, "8");       // Elimination Period [Accident]
                HashtableSTD.Add(2, "505");     // Elimination Period [Sickness]
                HashtableSTD.Add(3, "71");      // STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "350");     // STD General Information – Maximum Period of Payment
                #endregion
                string value = string.Empty;

                string Benefit_Percentage = string.Empty;
                string Accident = string.Empty;
                string Sickness = string.Empty;
                string Maximum_Period_Of_Payment = string.Empty;

                string Benefit_Percentage2 = string.Empty;
                string Accident2 = string.Empty;
                string Sickness2 = string.Empty;
                string Maximum_Period_Of_Payment2 = string.Empty;
                string STD_Summary_Plan1 = string.Empty;
                string STD_Summary_Plan2 = string.Empty;
                string STD_Carrier = string.Empty;
                List<string> lstcarrier = new List<string>();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (count == 1)
                            {
                                STD_Summary_Plan1 = PlanTable.Rows[k]["SummaryName"].ToString();
                                comFunObj.GetCarrierList(PlanTable.Rows[k]["Carrier"].ToString(), ref lstcarrier);
                            }
                            if (count == 2)
                            {
                                STD_Summary_Plan2 = PlanTable.Rows[k]["SummaryName"].ToString();
                                comFunObj.GetCarrierList(PlanTable.Rows[k]["Carrier"].ToString(), ref lstcarrier);
                            }
                            #region STDTable

                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {

                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        if (count == 1)
                                        {
                                            switch (key)
                                            {
                                                case 1: Accident = value.Trim_String(); break;
                                                case 2: Sickness = value.Trim_String(); break;
                                                case 3: Benefit_Percentage = value; break;
                                                case 4: if (dr["UOM"].ToString() == "text")
                                                    {
                                                        dr["UOM"] = "";
                                                    }
                                                    else
                                                    {
                                                        Maximum_Period_Of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " " + dr["UOM"].ToString().Trim_String();
                                                    }
                                                    break;

                                            }
                                        }

                                        if (count == 2)
                                        {
                                            switch (key)
                                            {
                                                case 1: Accident2 = value.Trim_String(); break;
                                                case 2: Sickness2 = value.Trim_String(); break;
                                                case 3: Benefit_Percentage2 = value; break;
                                                case 4: if (dr["UOM"].ToString() == "text")
                                                    {
                                                        dr["UOM"] = "";
                                                    }
                                                    else
                                                    {
                                                        Maximum_Period_Of_Payment2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " " + dr["UOM"].ToString().Trim_String();
                                                    }
                                                    break;

                                            }
                                        }

                                        //if (key == 1)
                                        //{
                                        //    Accident = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //}
                                        //else if (key == 2)
                                        //{
                                        //    Sickness = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //}
                                        //else if (key == 3)
                                        //{
                                        //    Benefit_Percentage = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //}
                                        //else if (key == 4)
                                        //{
                                        //    if (dr["UOM"].ToString() == "text")
                                        //    {
                                        //        dr["UOM"] = "";
                                        //    }

                                        //    Maximum_Period_Of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " " + dr["UOM"].ToString().Trim();
                                        //}

                                    }
                                }
                                value = "";
                            }

                            #endregion



                            count++;
                        }
                    }
                }

                if (lstcarrier.Count > 0)
                {
                    foreach (string item in lstcarrier)
                    {
                        if (STD_Carrier.Length == 0)
                        {
                            STD_Carrier = item;
                        }
                        else
                        {
                            STD_Carrier = STD_Carrier + " and " + item;
                        }
                    }
                }
                count = count - 1;
                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        if (count > 0)
                        {
                            if (fieldName.Contains("SHORT TERM DISABILITY INSURANCE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("SHORT TERM DISABILITY INSURANCE");
                                continue;
                            }
                        }

                        if (fieldName.Contains("STD Carrier Name"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());

                            oWordApp.Selection.TypeText(STD_Carrier);
                            continue;
                        }
                        # region summary
                        if (fieldName.Contains("STDSummary1"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());

                            oWordApp.Selection.TypeText(STD_Summary_Plan1);
                            continue;
                        }
                        if (fieldName.Contains("Second_STD_Summary"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());
                            if (!string.IsNullOrEmpty(STD_Summary_Plan2))
                            {
                                oWordApp.Selection.TypeText(STD_Summary_Plan2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                            continue;
                        }

                        # endregion summary

                        #region Elimination Period Accident
                        if (fieldName.Contains("STD Elimination Period Accident"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Accident))
                            {
                                oWordApp.Selection.TypeText(Accident);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_STD_Elimination Period Accident"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Accident2))
                            {
                                oWordApp.Selection.TypeText(Accident2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        #endregion Elimination Period Accident

                        #region STD Elimination Period Sickness
                        if (fieldName.Contains("STD Elimination Period Sickness"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Sickness))
                            {
                                oWordApp.Selection.TypeText(Sickness);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_STD_Elimination Period Sickness"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Sickness2))
                            {
                                oWordApp.Selection.TypeText(Sickness2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        #endregion STD Elimination Period Sickness

                        #region STD Benefit Percentage
                        if (fieldName.Contains("STD Benefit Percentage"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Benefit_Percentage))
                            {
                                oWordApp.Selection.TypeText(Benefit_Percentage);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_STD_Benefit Percentage"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Benefit_Percentage2))
                            {
                                oWordApp.Selection.TypeText(Benefit_Percentage2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        #endregion STD Benefit Percentage

                        #region STD Maximum Period of Payment
                        if (fieldName.Contains("STD Maximum Period of Payment"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Maximum_Period_Of_Payment))
                            {
                                oWordApp.Selection.TypeText(Maximum_Period_Of_Payment);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_STD_Maximum Period of Payment"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Maximum_Period_Of_Payment2))
                            {
                                oWordApp.Selection.TypeText(Maximum_Period_Of_Payment2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        #endregion STD Maximum Period of Payment

                        if (count == 1)
                        {
                            if (fieldName.Contains("STDPlan1"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());

                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                        if (count == 2)
                        {
                            if (fieldName.Contains("STDPlan2"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());

                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                    }


                }
                #endregion

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">LTDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan</param>
        public void WriteLTDSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                Hashtable HashtableLTD = new Hashtable();

                #region HashtableLTD
                HashtableLTD.Add(1, "181");     // Benefits [Elimination Period]
                HashtableLTD.Add(2, "71");      // General Plan Information – Benefit Percentage
                HashtableLTD.Add(3, "374");     // Benefits [Maximum Monthly Benefit]
                HashtableLTD.Add(4, "141");     // Benefits [Definition of Disability]
                HashtableLTD.Add(5, "351");     // Benefits [Maximum Period of Payment]
                ConstantValue cv = new ConstantValue();

                string value = string.Empty;
                string Elimination_Period = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Maximum_Monthly_Benefit = string.Empty;
                string Definition_of_Disability = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;
                string Elimination_Period2 = string.Empty;
                string Benefit_Percentage2 = string.Empty;
                string Maximum_Monthly_Benefit2 = string.Empty;
                string Definition_of_Disability2 = string.Empty;
                string Maximum_Period_of_Payment2 = string.Empty;

                string LTD_Summary_Plan1 = string.Empty;
                string LTD_Summary_Plan2 = string.Empty;
                string LTD_Carrier = string.Empty;
                List<string> lstcarrier = new List<string>();

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (count == 1)
                            {
                                LTD_Summary_Plan1 = PlanTable.Rows[k]["SummaryName"].ToString();
                                comFunObj.GetCarrierList(PlanTable.Rows[k]["Carrier"].ToString(), ref lstcarrier);
                            }
                            if (count == 2)
                            {
                                LTD_Summary_Plan2 = PlanTable.Rows[k]["SummaryName"].ToString();
                                comFunObj.GetCarrierList(PlanTable.Rows[k]["Carrier"].ToString(), ref lstcarrier);
                            }
                            #region LTDTable
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        if (count == 1)
                                        {
                                            switch (key)
                                            {
                                                case 1: Elimination_Period = value.Trim_String(); break;
                                                case 2: Benefit_Percentage = value.Trim_String(); break;
                                                case 3: Maximum_Monthly_Benefit = value.Trim_String(); break;
                                                case 4: Definition_of_Disability = value.Trim_String(); break;
                                                case 5: if (dr["UOM"].ToString() != "text")
                                                    {
                                                        Maximum_Period_of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + " " + dr["UOM"].ToString()).Trim_String();
                                                    }
                                                    else
                                                    {
                                                        Maximum_Period_of_Payment = value.Trim_String();
                                                    }

                                                    break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            switch (key)
                                            {
                                                case 1: Elimination_Period2 = value.Trim_String(); break;
                                                case 2: Benefit_Percentage2 = value.Trim_String(); break;
                                                case 3: Maximum_Monthly_Benefit2 = value.Trim_String(); break;
                                                case 4: Definition_of_Disability2 = value.Trim_String(); break;
                                                case 5: if (dr["UOM"].ToString() != "text")
                                                    {
                                                        Maximum_Period_of_Payment2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + " " + dr["UOM"].ToString()).Trim_String();
                                                    }
                                                    else
                                                    {
                                                        Maximum_Period_of_Payment2 = value.Trim_String();
                                                    }

                                                    break;
                                            }
                                        }
                                    }

                                    //if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    //{
                                    //    if (key == 1)
                                    //    {
                                    //        Elimination_Period = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    //    }
                                    //    if (key == 2)
                                    //    {
                                    //        Benefit_Percentage = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    //    }
                                    //    if (key == 3)
                                    //    {
                                    //        Maximum_Monthly_Benefit = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    //    }
                                    //    if (key == 4)
                                    //    {
                                    //        Definition_of_Disability = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    //    }
                                    //    if (key == 5)
                                    //    {
                                    //        if (dr["UOM"].ToString() != "text")
                                    //        {
                                    //            Maximum_Period_of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + " " + dr["UOM"].ToString()).Trim();
                                    //        }
                                    //        else
                                    //        {
                                    //            Maximum_Period_of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    //        }
                                    //    }


                                }
                                value = "";
                            }

                            #endregion


                            count++;
                        }
                    }
                }
                if (lstcarrier.Count > 0)
                {
                    foreach (string item in lstcarrier)
                    {
                        if (LTD_Carrier.Length == 0)
                        {
                            LTD_Carrier = item;
                        }
                        else
                        {
                            LTD_Carrier = LTD_Carrier + " and " + item;
                        }
                    }
                }
                count = count - 1;

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        if (count > 0)
                        {
                            if (fieldName.Contains("LONG TERM DISABILITY INSURANCE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("LONG TERM DISABILITY INSURANCE");
                                continue;
                            }
                        }


                        if (fieldName.Contains("LTD Carrier Name"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());

                            oWordApp.Selection.TypeText(LTD_Carrier);
                            continue;
                        }

                        # region summary
                        if (fieldName.Contains("LTDSumaary1"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());

                            oWordApp.Selection.TypeText(LTD_Summary_Plan1);
                            continue;
                        }
                        if (fieldName.Contains("Second_LTD_Sumaary"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());
                            if (!string.IsNullOrEmpty(LTD_Summary_Plan2))
                            {
                                oWordApp.Selection.TypeText(LTD_Summary_Plan2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                            continue;
                        }

                        # endregion summary

                        #region Elimination Period
                        if (fieldName.Contains("LTD Elimination Period"))
                        {
                            myMergeField.Select();

                            if (!string.IsNullOrEmpty(Elimination_Period))
                            {
                                oWordApp.Selection.TypeText(Elimination_Period);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_LTD_Elimination Period"))
                        {
                            myMergeField.Select();

                            if (!string.IsNullOrEmpty(Elimination_Period2))
                            {
                                oWordApp.Selection.TypeText(Elimination_Period2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        #endregion Elimination Period

                        #region Benefit Percentage
                        if (fieldName.Contains("LTD  Benefit Percentage"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Benefit_Percentage))
                            {
                                oWordApp.Selection.TypeText(Benefit_Percentage);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_LTD_Benefit Percentage"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Benefit_Percentage2))
                            {
                                oWordApp.Selection.TypeText(Benefit_Percentage2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        #endregion Benefit Percentage

                        #region Maximum Monthly Benefit
                        if (fieldName.Contains("LTD Maximum Monthly Benefit"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Maximum_Monthly_Benefit))
                            {
                                oWordApp.Selection.TypeText(Maximum_Monthly_Benefit);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_LTD_Maximum Monthly Benefit"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Maximum_Monthly_Benefit2))
                            {
                                oWordApp.Selection.TypeText(Maximum_Monthly_Benefit2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        #endregion Maximum Monthly Benefit

                        #region Definition of Disability
                        if (fieldName.Contains("LTD Definition of Disability"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Definition_of_Disability))
                            {
                                oWordApp.Selection.TypeText(Definition_of_Disability);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_LTD_Definition of Disability"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Definition_of_Disability2))
                            {
                                oWordApp.Selection.TypeText(Definition_of_Disability2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        #endregion Definition of Disability

                        #region Maximum Period of Payment
                        if (fieldName.Contains("LTD Maximum Period of Payment"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                            {
                                oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_LTD_Maximum Period of Payment"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Maximum_Period_of_Payment2))
                            {
                                oWordApp.Selection.TypeText(Maximum_Period_of_Payment2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        #endregion Maximum Period of Payment

                        if (count == 1)
                        {
                            if (fieldName.Contains("LTD1"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }

                        }
                        if (count == 2)
                        {
                            if (fieldName.Contains("LTD2"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }

                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        public void WriteVisionBenefitsSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();
                Hashtable HashtableVisionBenefitInNetwork_Col2 = new Hashtable();
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                #region HastableVisionBenefit

                HashtableVisionBenefitInNetwork.Add(2, "195");     // General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(3, "344");     // General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(4, "507");     // Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitInNetwork.Add(5, "208");     // Covered Services – Frames
                HashtableVisionBenefitInNetwork.Add(6, "178");     // Covered Services – Contact Lenses - Elective

                HashtableVisionBenefitInNetwork_Col2.Add(2, "194");     // General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitInNetwork_Col2.Add(4, "309");     // General Plan Information – Benefit Frequency – Lenses
                HashtableVisionBenefitInNetwork_Col2.Add(5, "207");     // General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork_Col2.Add(6, "122");     // General Plan Information – Benefit Frequency – Contacts

                #endregion

                int count = 1;

                ArrayList Vision_Carrier = new ArrayList();
                ConstantValue cv = new ConstantValue();


                oWordDoc.Tables[4].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[4].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[4].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[4].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[4].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                // Approach 1
                //oWordDoc.Tables[8].Range.Font.Color = comFunObj.font_color(selectedColor);
                //oWordDoc.Tables[8].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                //oWordDoc.Tables[8].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                //oWordDoc.Tables[8].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[8].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);


                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VISION Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("VISION");
                                        continue;
                                    }
                                    if (count > 2)
                                    {
                                        if (fieldName.Contains("VisionPlan3And4"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Vision Monthly Contribution"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Carrier Name" + count.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!Vision_Carrier.Contains(PlanTable.Rows[k]["Carrier"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                Vision_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Vision_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        }
                                        continue;
                                    }
                                }
                            }
                            #endregion

                            # region VisionBenefitTable
                            if (count == 1)
                            {
                                oWordDoc.Tables[4].Cell(1, 2).Select();
                                oWordDoc.Tables[4].Cell(1, 2).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }
                            else if (count == 2)
                            {
                                oWordDoc.Tables[4].Cell(1, 3).Select();
                                oWordDoc.Tables[4].Cell(1, 3).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }
                            else if (count == 3)
                            {
                                oWordDoc.Tables[5].Cell(1, 2).Select();
                                oWordDoc.Tables[5].Cell(1, 2).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }
                            else if (count == 4)
                            {
                                oWordDoc.Tables[5].Cell(1, 3).Select();
                                oWordDoc.Tables[5].Cell(1, 3).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }

                            // Approach 1
                            //oWordDoc.Tables[8].Cell(1, count + 1).Select();
                            //oWordDoc.Tables[8].Cell(1, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 2)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 4).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 3)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 4)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 4).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableVisionBenefitInNetwork_Col2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork_Col2[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 2)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 5).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 3)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 4)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 5).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteLifeADDToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, string selectedColor = "", ArrayList GroupTermLifeBenefitColumnIdList = null, ArrayList ADDBenefitColumnIdList = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int iTotalFields = 0;

                int count = 0;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string value = "";
                string value1 = "";


                string LifeAndADnD_Amount1 = "";
                string LifeAndADnD_Amount2 = "";

                string GroupTermLife_Amount1 = "";
                string GroupTermLife_Amount2 = "";

                string ADnD_Amount1 = "";
                string ADnD_Amount2 = "";

                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "186"); //Employee[Overall Maximum]

                #endregion

                string Life_and_ADND_Carrier1 = string.Empty;
                string Life_and_ADND_Carrier2 = string.Empty;
                string GroupTermLife_Carrier1 = string.Empty;
                string GroupTermLife_Carrier2 = string.Empty;
                string ADnD_Carrier1 = string.Empty;
                string ADnD_Carrier2 = string.Empty;

                string LifeAndADnD_SummaryName1 = string.Empty;
                string LifeAndADnD_SummaryName2 = string.Empty;
                string GroupTermLife_SummaryName1 = string.Empty;
                string GroupTermLife_SummaryName2 = string.Empty;
                string ADnD_SummaryName1 = string.Empty;
                string ADnD_SummaryName2 = string.Empty;

                int tableNoLifeADnD = 18;
                int tableNoGroupTermLife = 20;
                int tableNoADnDOnly = 22;

                int LifeCount = 0;
                int GroupTermCount = 0;
                int AddCount = 0;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {

                            #region GroupLifeADDBenifitTable
                            //foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            //{
                            //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            //    {
                            //        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                            //        {
                            //            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                            //        }
                            //        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                            //        {
                            //            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                            //        }
                            //        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                            //        {
                            //            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                            //        }
                            //    }
                            //}

                            if (count == 0)
                            {
                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            LifeAndADnD_Amount1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            GroupTermLife_Amount1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            ADnD_Amount1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                    }
                                }

                                if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                                {
                                    Life_and_ADND_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    LifeAndADnD_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    //if (!string.IsNullOrEmpty(Life_and_ADND_Carrier1))
                                    //{
                                    //    oWordDoc.Tables[tableNoLifeADnD].Cell(1, 1).Range.Text = Life_and_ADND_Carrier1;
                                    //}
                                    //oWordDoc.Tables[tableNoLifeADnD].Cell(2, 1).Range.Text = LifeAndADnD_SummaryName1;
                                    //oWordDoc.Tables[tableNoLifeADnD].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                {
                                    GroupTermLife_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    GroupTermLife_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    //if (!string.IsNullOrEmpty(GroupTermLife_Carrier1))
                                    //{
                                    //    oWordDoc.Tables[tableNoGroupTermLife].Cell(1, 1).Range.Text = GroupTermLife_Carrier1;
                                    //}
                                    //oWordDoc.Tables[tableNoGroupTermLife].Cell(2, 1).Range.Text = GroupTermLife_SummaryName1;
                                    //oWordDoc.Tables[tableNoGroupTermLife].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                {
                                    ADnD_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    ADnD_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    //if (!string.IsNullOrEmpty(ADnD_Carrier1))
                                    //{
                                    //    oWordDoc.Tables[tableNoADnDOnly].Cell(1, 1).Range.Text = ADnD_Carrier1;
                                    //}
                                    //oWordDoc.Tables[tableNoADnDOnly].Cell(2, 1).Range.Text = ADnD_SummaryName1;
                                    //oWordDoc.Tables[tableNoADnDOnly].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                            }
                            else if (count == 1)
                            {

                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            LifeAndADnD_Amount2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            GroupTermLife_Amount2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            ADnD_Amount2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                    }
                                }

                                if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                                {
                                    Life_and_ADND_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    LifeAndADnD_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    //if (!string.IsNullOrEmpty(Life_and_ADND_Carrier2))
                                    //{
                                    //    oWordDoc.Tables[tableNoLifeADnD + 1].Cell(1, 1).Range.Text = Life_and_ADND_Carrier2;
                                    //}
                                    //oWordDoc.Tables[tableNoLifeADnD + 1].Cell(2, 1).Range.Text = LifeAndADnD_SummaryName2;
                                    //oWordDoc.Tables[tableNoLifeADnD + 1].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                {
                                    GroupTermLife_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    GroupTermLife_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    //if (!string.IsNullOrEmpty(GroupTermLife_Carrier2))
                                    //{
                                    //    oWordDoc.Tables[tableNoGroupTermLife + 1].Cell(1, 1).Range.Text = GroupTermLife_Carrier2;
                                    //}
                                    //oWordDoc.Tables[tableNoGroupTermLife + 1].Cell(2, 1).Range.Text = GroupTermLife_SummaryName2;
                                    //oWordDoc.Tables[tableNoGroupTermLife + 1].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                {
                                    ADnD_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    ADnD_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    //if (!string.IsNullOrEmpty(ADnD_Carrier2))
                                    //{
                                    //    oWordDoc.Tables[tableNoADnDOnly + 1].Cell(1, 1).Range.Text = ADnD_Carrier2;
                                    //}
                                    //oWordDoc.Tables[tableNoADnDOnly + 1].Cell(2, 1).Range.Text = ADnD_SummaryName2;
                                    //oWordDoc.Tables[tableNoADnDOnly + 1].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                            }

                            #endregion


                            count++;
                        }
                    }
                    #region merge fields


                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeCount++;
                    }
                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermCount++;
                    }
                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        AddCount++;
                    }

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                            {

                                if (fieldName.Contains("LIFE/AD&D INSURANCE"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    oWordApp.Selection.TypeText("LIFE/AD&D INSURANCE");
                                    continue;
                                }
                                if (LifeCount > 1)
                                {
                                    if (fieldName.Contains("Life_Add_2nd_Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("Life and AD&D Carrier Name2"))
                                    {
                                        myMergeField.Select();
                                        if (Life_and_ADND_Carrier2 == Life_and_ADND_Carrier1)
                                        {
                                            //oWordApp.Selection.TypeText(" ");
                                        }
                                        else
                                        {
                                            Life_and_ADND_Carrier2 = Life_and_ADND_Carrier1 + " and " + Life_and_ADND_Carrier2;
                                            oWordApp.Selection.TypeText(Life_and_ADND_Carrier2);
                                        }
                                        continue;
                                    }
                                }
                                if (fieldName.Contains("Life and AD&D Carrier Name1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Life_and_ADND_Carrier1);
                                    continue;
                                }

                                if (fieldName.Contains("Life and AD&D Benefit Summaries Description1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_SummaryName1);
                                    continue;
                                }
                                if (fieldName.Contains("Life and AD&D Benefit Summaries Description2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_SummaryName2);
                                    continue;
                                }
                                if (fieldName.Contains("Life and AD&D Benefit Amount Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_Amount1);
                                    continue;
                                }
                                if (fieldName.Contains("Life and AD&D Benefit Amount Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_Amount2);
                                    continue;
                                }

                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                            {
                                if (fieldName.Contains("LIFE INSURANCE"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    oWordApp.Selection.TypeText("LIFE INSURANCE");
                                    continue;
                                }
                                if (GroupTermCount > 1)
                                {
                                    if (fieldName.Contains("GroupTermLife_2nd_Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("Group Term Life Carrier Name2"))
                                    {
                                        myMergeField.Select();
                                        if (GroupTermLife_Carrier2 == GroupTermLife_Carrier1)
                                        {
                                            //oWordApp.Selection.TypeText(" ");
                                        }
                                        else
                                        {
                                            GroupTermLife_Carrier2 = GroupTermLife_Carrier1 + " and " + GroupTermLife_Carrier2;
                                            oWordApp.Selection.TypeText(GroupTermLife_Carrier2);
                                        }
                                        continue;
                                    }
                                }
                                if (fieldName.Contains("Group Term Life Carrier Name1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_Carrier1);
                                    continue;
                                }

                                if (fieldName.Contains("Group Term Life Benefit Summaries Description1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_SummaryName1);
                                    continue;
                                }
                                if (fieldName.Contains("Group Term Life Benefit Summaries Description2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_SummaryName2);
                                    continue;
                                }
                                if (fieldName.Contains("Group Term Life Benefit Amount Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_Amount1);
                                    continue;
                                }
                                if (fieldName.Contains("Group Term Life Benefit Amount Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_Amount2);
                                    continue;
                                }
                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                            {

                                if (fieldName.Contains("ADD INSURANCE"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    oWordApp.Selection.TypeText("ADD INSURANCE");
                                    continue;
                                }

                                if (fieldName.Contains("Second_ADD_Carrier Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" and " + ADnD_Carrier2);
                                    continue;
                                }
                                if (fieldName.Contains("ADD Carrier Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_Carrier1);
                                    continue;
                                }

                                if (fieldName.Contains("ADDSummary1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_SummaryName1);
                                    continue;
                                }
                                if (fieldName.Contains("SecondADDSummary"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_SummaryName2);
                                    continue;
                                }

                                if (fieldName.Contains("ADD Benefit Amount Employee"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_Amount1);
                                    continue;
                                }
                                if (fieldName.Contains("SecondADD Benefit Amount Employee"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_Amount2);
                                    continue;
                                }
                                if (fieldName.Contains("ADD1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                }
                                if (AddCount > 1)
                                {
                                    if (fieldName.Contains("ADD2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                            }

                            //if (fieldName.Contains("Beneficiary"))
                            //{
                            //    myMergeField.Select();
                            //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                            //    oWordApp.Selection.TypeText("Beneficiary");
                            //    continue;
                            //}

                        }
                    }
                    #endregion

                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Group Term Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="GroupTermLifeBenefitColumnIdList">GroupTermLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Group Term Life Plan</param>
        public void WriteGroupTermLifeBenifitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList GroupTermLifeBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableGroupTermLifeBenifit = new Hashtable();

                #region HashtableGroupLifeADDBenifit
                HashtableGroupTermLifeBenifit.Add(1, "186");     //Employee [Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(7, "517");     //Spouse[Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(11, "102");    //Child(ren)[Benefit Amount] 

                #endregion

                string Employee_Benefit_Amount = string.Empty;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.GroupTermLifePlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region GroupTermLifeBenifitTable
                            foreach (int key in HashtableGroupTermLifeBenifit.Keys)
                            {
                                Employee_Benefit_Amount = "";
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.GroupTermLifePlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupTermLifeBenifit[key].ToString())
                                    {
                                        Employee_Benefit_Amount = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LIFE INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("LIFE INSURANCE");
                                        continue;
                                    }

                                    if (fieldName.Contains("Group Term Life Carrier Name" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }

                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Group Term Life Benefit Amount Employee" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Employee_Benefit_Amount))
                                        {
                                            oWordApp.Selection.TypeText(Employee_Benefit_Amount);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Group Term Life Benefit Summaries Description" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText((PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ADDBenefitColumnIdList">ADDBenefitColumnIdList contain InNetwork Benefit ColumnId for AD&D Plan</param>
        public void WriteADDBenifitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList ADDBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableADDBenifit = new Hashtable();

                #region HashtableADDBenifit
                HashtableADDBenifit.Add(1, "186");     //Employee [Benefit Amount]

                #endregion

                string Employee_Benefit_Amount = string.Empty;
                string Employee_Benefit_Amount2 = string.Empty;

                string ADD_Summary_Plan1 = string.Empty;
                string ADD_Summary_Plan2 = string.Empty;
                string ADD_Carrier = string.Empty;
                List<string> lstcarrier = new List<string>();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.ADD.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (count == 1)
                            {
                                ADD_Summary_Plan1 = PlanTable.Rows[k]["SummaryName"].ToString();
                                comFunObj.GetCarrierList(PlanTable.Rows[k]["Carrier"].ToString(), ref lstcarrier);
                            }
                            if (count == 2)
                            {
                                ADD_Summary_Plan2 = PlanTable.Rows[k]["SummaryName"].ToString();
                                comFunObj.GetCarrierList(PlanTable.Rows[k]["Carrier"].ToString(), ref lstcarrier);
                            }
                            #region GroupTermLifeBenifitTable

                            foreach (int key in HashtableADDBenifit.Keys)
                            {
                                Employee_Benefit_Amount = "";
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.ADD.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableADDBenifit[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            Employee_Benefit_Amount = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                        if (count == 2)
                                        {
                                            Employee_Benefit_Amount2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        }
                                    }
                                }
                            }
                            #endregion


                            count++;
                        }
                    }
                }


                if (lstcarrier.Count > 0)
                {
                    foreach (string item in lstcarrier)
                    {
                        if (ADD_Carrier.Length == 0)
                        {
                            ADD_Carrier = item;
                        }
                        else
                        {
                            ADD_Carrier = ADD_Carrier + " and " + item;
                        }
                    }
                }
                count = count - 1;
                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        if (count > 0)
                        {
                            if (fieldName.Contains("ADD INSURANCE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("AD&D INSURANCE");
                                continue;
                            }
                        }

                        if (fieldName.Contains("ADD Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ADD_Carrier);
                            continue;
                        }

                        # region summary
                        if (fieldName.Contains("ADDSummary1"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());

                            oWordApp.Selection.TypeText(ADD_Summary_Plan1);
                            continue;
                        }
                        if (fieldName.Contains("Second_ADD_Summary"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());
                            if (!string.IsNullOrEmpty(ADD_Summary_Plan2))
                            {
                                oWordApp.Selection.TypeText(ADD_Summary_Plan2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                            continue;
                        }

                        # endregion summary

                        if (fieldName.Contains("ADD Benefit Amount Employee"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Employee_Benefit_Amount))
                            {
                                oWordApp.Selection.TypeText(Employee_Benefit_Amount);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Second_ADD_Benefit Amount Employee"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Employee_Benefit_Amount2))
                            {
                                oWordApp.Selection.TypeText(Employee_Benefit_Amount2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("ADD1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("");
                        }
                        if (fieldName.Contains("ADD2"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("");
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Wellness Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="WellnessBenefitColumnIdList">WellnessBenefitColumnIdList contain InNetwork Benefit ColumnId for Wellness Plan</param>
        public void WriteWellnessBenifitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList WellnessBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int count = 1;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.Wellness.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("WELLNESS PROGRAM"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("WELLNESS PROGRAM");
                                        continue;
                                    }

                                    if (fieldName.Contains("Wellness Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeADDBenefitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int count = 1;
                string value = string.Empty;
                string volantarycarrier1 = "";
                string volantarycarrier2 = "";

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                #region HashtableVoluntaryLifeADDBenifit
                /*Delete Overall maximum row from all catagory--29/05/2014*/
                //HashtableVoluntaryLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]


                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VOLUNTARY LIFE / AD&D INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (PlanTable.Rows[k]["ProductName"].ToString().Trim().Contains("AD&D"))
                                        {
                                            oWordApp.Selection.TypeText("VOLUNTARY LIFE / AD&D INSURANCE");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("VOLUNTARY LIFE INSURANCE");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Voluntary Life Details"))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[k]["ProductName"].ToString().Trim().Contains("AD&D"))
                                        {
                                            oWordApp.Selection.TypeText("for Voluntary Life and AD&D Insurance");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("for Voluntary Life Insurance");
                                        }
                                        continue;
                                    }

                                    if (count == 1)
                                    {
                                        volantarycarrier1 = (PlanTable.Rows[k]["Carrier"].ToString());
                                    }
                                    else if (count == 2)
                                    {
                                        volantarycarrier2 = PlanTable.Rows[k]["Carrier"].ToString();
                                    }

                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("VOLUNTARY LIFE AD&D Carrier Name1"))
                        {
                            myMergeField.Select();

                            if (!string.IsNullOrEmpty(volantarycarrier1) && string.IsNullOrEmpty(volantarycarrier2))
                            {
                                oWordApp.Selection.TypeText(volantarycarrier1);
                            }
                            else if (string.IsNullOrEmpty(volantarycarrier1) && !string.IsNullOrEmpty(volantarycarrier2))
                            {
                                oWordApp.Selection.TypeText(volantarycarrier2);
                            }
                            else if (!string.IsNullOrEmpty(volantarycarrier1) && !string.IsNullOrEmpty(volantarycarrier2))
                            {
                                if (volantarycarrier1 != volantarycarrier2)
                                {
                                    oWordApp.Selection.TypeText(volantarycarrier1 + " and " + volantarycarrier1);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(volantarycarrier1);
                                }
                            }
                            continue;
                        }

                        //if (fieldName.Contains("VOLUNTARY LIFE AD&D Carrier Name2"))
                        //{
                        //    myMergeField.Select();

                        //    if (count > 1)
                        //    {
                        //        if (volantarycarrier1 != volantarycarrier2)
                        //        {
                        //            oWordApp.Selection.TypeText(" and " + volantarycarrier2);
                        //        }
                        //    }
                        //    else
                        //    {
                        //        oWordApp.Selection.TypeText(volantarycarrier2);
                        //    }
                        //}

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP Plan</param>
        public void WriteEAPSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                Hashtable HashtableEAP = new Hashtable();

                #region HashtableEAP
                HashtableEAP.Add(1, "384"); // Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("EAP Number of Visits"))
                                                {
                                                    myMergeField.Select();
                                                    string number_visit_item = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                                    if (number_visit_item.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item.Trim());
                                                    }
                                                    continue;
                                                }

                                                if (fieldName.Contains("EAP Carrier Name"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                    continue;
                                                }
                                                if (fieldName.Contains("EMPLOYEE ASSISTANCE PROGRAM (EAP)"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText("EMPLOYEE ASSISTANCE PROGRAM (EAP)");
                                                    continue;
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        public void WriteFSASectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataTable PlanTypeSpecific, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int count = 1;
                Hashtable HashtableFSA = new Hashtable();

                DataRow[] foundPlanTypeRows = null;

                #region HashtableFSA
                HashtableFSA.Add(1, "354"); // Administration Services - Medical Spending Accounts - Maximum
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                {
                                                    myMergeField.Select();
                                                    string administration_service_medicalspending = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                    if (administration_service_medicalspending.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(administration_service_medicalspending.Trim());
                                                    }
                                                    continue;
                                                }
                                                if (fieldName.Contains("FLEXIBLE SPENDING ACCOUNTS (FSA)"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText("FLEXIBLE SPENDING ACCOUNTS (FSA)");
                                                    continue;
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="clientName">clientName contain selected client name</param>
        /// <param name="ddlHSAPlanName">ddlHSAPlanName contain selected HSA plan name</param>
        public void WriteHSASectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataTable CarrierSpecific, ArrayList HSABenefitColumnIdList, string clientName, DropDownList ddlHSAPlanName, string selectedColor = "Grey")
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                Hashtable HashtableHSA = new Hashtable();

                #region HashtableHSA
                HashtableHSA.Add(1, "635");     //General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSA.Add(2, "636");     //General Plan Information – Maximum Annual Contribution/Family
                HashtableHSA.Add(3, "640");     //Employer Contributions – Individual
                HashtableHSA.Add(4, "644");     //Employer Contributions – Family

                //HashtableHSABenifit.Add(1, "640");     //Employer Contributions – Individual
                //HashtableHSABenifit.Add(2, "644");     //Employer Contributions – Family
                #endregion

                //string MaxAnnualContribution = "";
                //string MaxAnnualContribution_Family = "";

                string Max_Annual_Contribution_Individual1 = " ";
                string Max_Annual_Contribution_Family1 = " ";
                string Max_Annual_EmployerContribution_Individual1 = " ";
                string Max_Annual_EmployerContribution_Family1 = " ";
                string value = "";

                // IRC
                BPBusiness bp = new BPBusiness();
                DataTable dt_IRC = new DataTable();

                oWordDoc.Tables[2].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[2].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[2].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[2].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[2].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            // Get the renewal year for taking the IRC table detail
                            string renewalDate = Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year);

                            dt_IRC = bp.GetIRCList(renewalDate);

                            foreach (int key in HashtableHSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSA[key].ToString())
                                    {
                                        //if (key == 1)
                                        //{
                                        //    MaxAnnualContribution = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //}
                                        //if (key == 2)
                                        //{
                                        //    MaxAnnualContribution_Family = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //}
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Max_Annual_Contribution_Individual1 = value;
                                                break;
                                            case 2: Max_Annual_Contribution_Family1 = value;
                                                break;
                                            case 3: Max_Annual_EmployerContribution_Individual1 = value;
                                                break;
                                            case 4: Max_Annual_EmployerContribution_Family1 = value;
                                                break;
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[2].Cell(1, 2).Select();
                            //oWordDoc.Tables[2].Cell(1, 2).Range.Text = clientName + " " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year + " PLAN YEAR CONTRIBUTION*";
                            oWordDoc.Tables[2].Cell(1, 2).Range.Text = clientName + " " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).Year + " PLAN YEAR CONTRIBUTION*";  // As Per Lisa we change Renewal date to Effective Date - Amogh

                            oWordDoc.Tables[2].Cell(1, 3).Select();
                            //oWordDoc.Tables[2].Cell(1, 3).Range.Text = "IRS" + " " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year + " CALENDAR YEAR MAXIMUM CONTRIBUTION";
                            oWordDoc.Tables[2].Cell(1, 3).Range.Text = "IRS" + " " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).Year + " CALENDAR YEAR MAXIMUM CONTRIBUTION"; // As Per Lisa we change Renewal date to Effective Date - Amogh

                            oWordDoc.Tables[2].Cell(2, 2).Select();
                            oWordDoc.Tables[2].Cell(2, 2).Range.Text = Max_Annual_EmployerContribution_Individual1; //Employer Contribution Amount for Individual

                            oWordDoc.Tables[2].Cell(3, 2).Select();
                            oWordDoc.Tables[2].Cell(3, 2).Range.Text = Max_Annual_EmployerContribution_Family1;     //Employer Contribution Amount for Family

                            oWordDoc.Tables[2].Cell(2, 3).Select();
                            oWordDoc.Tables[2].Cell(2, 3).Range.Text = Max_Annual_Contribution_Individual1;         //Maximum Annual Amount for Individual

                            oWordDoc.Tables[2].Cell(3, 3).Select();
                            oWordDoc.Tables[2].Cell(3, 3).Range.Text = Max_Annual_Contribution_Family1;             //Maximum Annual Amount for Family

                            for (int j = 0; j < dt_IRC.Rows.Count; j++)
                            {
                                //oWordDoc.Tables[2].Cell(2, 3).Select();
                                //oWordDoc.Tables[2].Cell(2, 3).Range.Text = Convert.ToString(dt_IRC.Rows[j]["EmployeeOnlyCoverage"].ToString()) + ", including employer contribution";

                                //oWordDoc.Tables[2].Cell(3, 3).Select();
                                //oWordDoc.Tables[2].Cell(3, 3).Range.Text = Convert.ToString(dt_IRC.Rows[j]["FamilyCoverage"].ToString()) + ", including employer contribution";

                                oWordDoc.Tables[2].Cell(4, 3).Select();
                                oWordDoc.Tables[2].Cell(4, 3).Range.Text = Convert.ToString(dt_IRC.Rows[j]["EmployeesOver55"].ToString()) + " additional “catch-up” contribution";
                            }

                            count++;
                        }
                    }
                }

                #region merge fields
                int iTotalFields = 0;
                if (ddlHSAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HEALTH SAVINGS ACCOUNT"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HEALTH SAVINGS ACCOUNT");
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlHRAPlanName">DropDownList ddlHRAPlanName Object</param>
        /// /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA Plan</param>
        public void WriteHRASectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlHRAPlanName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                Hashtable HashtableHRA = new Hashtable();
                #region HashtableHRA
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "241"); // Health Reimbursement Account Tier 4 

                #endregion

                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_2 = string.Empty;

                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                foreach (int key in HashtableHRA.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                HRA_Tier_1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                HRA_Tier_2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #region merge fields
                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HEALTH REIMBURSEMENT ACCOUNT"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HEALTH REIMBURSEMENT ACCOUNT");
                                continue;
                            }
                            if (fieldName.Contains("General Plan Information/Health Reimbursement Account Tier 1"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_1))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_1);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("General Plan Information/Health Reimbursement Account Tier 4"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_2))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_2);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Prescription Drugs Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        public void WritePrescriptionDrugsSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataSet ProductDS, DataTable PlanTable, DataTable CarrierSpecific, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, string selectedColor = "Grey")
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();
                HashtablePrescriptionDrugs.Add(1, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");    //Prescription Categories[Non Formulary]
                #endregion

                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    Generic = "";
                    Formulary = "";
                    NonFormulary = "";

                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region PrescriptionDrugsTable

                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = value; break;
                                            case 2: Formulary = value; break;
                                            case 3: NonFormulary = value; break;
                                        }
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Generic))
                            {
                                Generic = Generic + " / ";
                            }
                            if (!string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + " / ";
                            }

                            value = Generic + Formulary + NonFormulary;

                            if (count == 1)
                            {
                                oWordDoc.Tables[1].Cell(9, 2).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[1].Cell(9, 3).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[1].Cell(9, 4).Range.Text = value;
                            }
                            if (count == 4)
                            {
                                oWordDoc.Tables[1].Cell(9, 5).Range.Text = value;
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage, string selectedColor = "Grey")
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                bool flag = false;
                bool flag1 = false;
                oWordDoc.Save();


                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            // Added by Vaibhav and Shravan for Spanish template
                            if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            //else
                            //{
                            //    myMergeField.Delete();
                            //}
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlAnnualLegalNotice.SelectedIndex == 0 && ddlChipNotice.SelectedIndex == 0)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlAnnualLegalNotice.SelectedIndex == 0 && ddlChipNotice.SelectedIndex == 0)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("Annual_Notice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                continue;
                            }
                        }

                        if (fieldName.Equals("OtherProducts"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("\f"); // For Inserting the page break before Annual Legal Notice
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }

                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (flag1 == true)
                                {
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    flag1 = false;
                                }

                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;


                // Call common function to write the contact information page fields
                // COmented by Vaibhav
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true, selectedColor, "Summary Highlight");
                //Added by Vaibhav
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedColor, "Summary Highlight");
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS, string selectedColor = "", DataSet BenefitDS = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int DentalCount = 0;
                int VisionCount = 0;

                DataTable PremiumTableWriteMedical = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteMedical);

                DataTable PremiumTableWriteDental = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteDental);

                DataTable PremiumTableWriteVision = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteVision);

                int premTableMedical1 = 6;
                int dentalTableNo = 7;
                int visionTableNo = 8;
                ArrayList arrContributionID = new ArrayList();
                ArrayList arrContributionID_Vision = new ArrayList();
                int medicalColumnNum = 1;
                int dentalColumnNum = 1;
                int visionColumnNum = 1;
                string strPlan_Contri1 = "";
                string strPlan_Contri2 = "";
                int MedicalTableRowCounter = 2;
                int DentalTableRowCounter = 2;
                int VisionTableRowCounter = 2;
                int contributionId_1 = 0;
                int contributionId_2 = 0;
                int RowCounter = 1;
                string FrequencyMEdical1 = string.Empty;
                DataTable PremiumTable = new DataTable();

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    //DataTable PremiumTable = new DataTable();
                    //int premium_row_counter = 0;

                    //PremiumTable.Columns.Add("Plan", typeof(string));
                    ////PremiumTable.Columns.Add("rateTierID", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    //PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    //PremiumTable.Columns.Add("monthlycost", typeof(string));
                    //PremiumTable.Columns.Add("contributioncost", typeof(string));
                    //PremiumTable.Columns.Add("summaryname", typeof(string));
                    //PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    //PremiumTable.Columns.Add("contributionid", typeof(string));
                    //PremiumTable.Columns.Add("rateid", typeof(string));
                    //PremiumTable.Columns.Add("contributionValueID", typeof(string));
                    //PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    //PremiumTable.Columns.Add("PlanNumber", typeof(string));

                    //for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    //{
                    //    if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                    //    {
                    //        if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()) && ContributionDS.Tables["ContributionValueTable"].Rows[j]["contribution_number"].ToString() == PlanTable.Rows[index]["PlanNumber"].ToString())
                    //        {
                    //            PremiumTable.Rows.Add();
                    //            PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];//Plan Name
                    //            PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();//Rate tier ID
                    //            PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();//Contribution Description(like EE ,Spouse)
                    //            PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();//Contribution values
                    //            PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionValueID"].ToString();//Contribution ValueId
                    //            PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();//Frequency
                    //            PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString();//Contribution Id
                    //            PremiumTable.Rows[premium_row_counter][11] = PlanTable.Rows[index]["PlanNumber"].ToString();
                    //            premium_row_counter++;
                    //        }

                    //        if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId_2"].ToString()) && ContributionDS.Tables["ContributionValueTable"].Rows[j]["contribution_number"].ToString() == PlanTable.Rows[index]["PlanNumber"].ToString())
                    //        {
                    //            PremiumTable.Rows.Add();
                    //            PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];//Plan Name
                    //            PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();//Rate tier ID
                    //            PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();//Contribution Description(like EE ,Spouse)
                    //            PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();//Contribution values
                    //            PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionValueID"].ToString();//Contribution ValueId
                    //            PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();//Frequency
                    //            PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString();//Contribution Id
                    //            PremiumTable.Rows[premium_row_counter][11] = PlanTable.Rows[index]["PlanNumber"].ToString();
                    //            premium_row_counter++;
                    //        }
                    //    }
                    //}

                    #endregion


                    //DataTable dt = new DataTable();

                    //PremiumTable.DefaultView.Sort = "[contributionValueID] asc";
                    //dt = PremiumTable.DefaultView.ToTable(true);

                    //// Commented the "monthlycost != 0" condition on the request of Nicole on 07 April 2015 

                    ////// The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                    ////for (int k = 0; k < dt.Rows.Count; k++)
                    ////{
                    ////    if (Convert.ToDecimal(dt.Rows[k]["monthlycost"]) == 0)
                    ////    {
                    ////        dt.Rows[k].Delete();
                    ////        k = k - 1;
                    ////    }
                    ////}

                    //PremiumTable = dt;

                    PremiumTable.Clear();
                    PremiumTable = comFunObj.CreateContributionPremiumTable(PlanTable, ContributionDS, index);

                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId"].ToString()))
                    {
                        contributionId_1 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId"].ToString());
                    }
                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId_2"].ToString()))
                    {
                        contributionId_2 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId_2"].ToString());
                    }

                    DataTable dt1 = new DataTable();

                    PremiumTable.DefaultView.Sort = "[contributionValueID] asc";
                    //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt1 = PremiumTable.DefaultView.ToTable(true);

                    for (int k = 0; k < dt1.Rows.Count; k++)
                    {
                        if (Convert.ToDecimal(dt1.Rows[k]["monthlycost"]) == 0)
                        {
                            dt1.Rows[k].Delete();
                            k = k - 1;
                        }
                    }

                    PremiumTable = dt1;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        //strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()); ;
                        //if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        //{
                        //    strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        //}

                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim() + " Medical Plan"); ;
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim() + " Medical Plan");
                        }
                        if (index == 0)
                        {
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical1 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }

                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            //// Approach 1
                            //comFunObj.WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }
                        if (index == 1)
                        {
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            //// Approach 1
                            //comFunObj.WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }
                        if (index == 2)
                        {
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            //// Approach 1
                            //comFunObj.WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim() + " Dental Plan"); ;
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim() + " Dental Plan");
                        }
                        if (DentalCount == 0)
                        {
                            comFunObj.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteDental);
                            //// Approach 1
                            //comFunObj.WriteDentalContributionValues(oWordDoc, oWordApp, dentalTableNo, ref dentalColumnNum, PremiumTableWriteDental, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref dentalColumnNum, PremiumTableWriteDental, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }
                        if (DentalCount == 1)
                        {
                            PremiumTableWriteDental.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteDental);
                            //// Approach 1
                            //comFunObj.WriteDentalContributionValues(oWordDoc, oWordApp, dentalTableNo, ref dentalColumnNum, PremiumTableWriteDental, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref dentalColumnNum, PremiumTableWriteDental, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }
                        if (DentalCount == 2)
                        {
                            PremiumTableWriteDental.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, 3, ref PremiumTableWriteDental);
                            //// Approach 1
                            //comFunObj.WriteDentalContributionValues(oWordDoc, oWordApp, dentalTableNo, ref dentalColumnNum, PremiumTableWriteDental, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref dentalColumnNum, PremiumTableWriteDental, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    //columnNum = 1;
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";

                        //strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()); ;
                        //if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        //{
                        //    strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        //}
                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim() + " Vision Plan"); ;
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim() + " Vision Plan");
                        }

                        if (VisionCount == 0)
                        {
                            comFunObj.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteVision);
                            //// Approach 1
                            //comFunObj.WriteVisionContributionValues(oWordDoc, oWordApp, visionTableNo, ref visionColumnNum, PremiumTableWriteVision, 1, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref visionColumnNum, PremiumTableWriteVision, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }
                        if (VisionCount == 1)
                        {
                            PremiumTableWriteVision.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteVision);
                            //// Approach 1
                            //comFunObj.WriteVisionContributionValues(oWordDoc, oWordApp, visionTableNo, ref visionColumnNum, PremiumTableWriteVision, 2, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter);

                            // Approach 2
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref visionColumnNum, PremiumTableWriteVision, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, ref RowCounter, contributionId_1, contributionId_2);
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                // Approach 2
                #region Approach 2

                if (oWordDoc.Tables[premTableMedical1].Rows.Last.Cells[1].Range.Text == "\r\a")
                {
                    oWordDoc.Tables[premTableMedical1].Rows.Last.Delete();
                }
                oWordDoc.Tables[premTableMedical1].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[premTableMedical1].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].PreferredWidth = oWordApp.InchesToPoints(7.65f);

                #endregion

                // Approach 1
                #region Approach 1
                /*
                #region Medical Monthly Premium

                if (PremiumTableWriteMedical != null && PremiumTableWriteMedical.Rows.Count > 0)
                {
                    oWordDoc.Tables[premTableMedical1].Rows.Last.Delete();
                    oWordDoc.Tables[premTableMedical1].Range.Font.Color = comFunObj.font_color(selectedColor);
                    oWordDoc.Tables[premTableMedical1].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    oWordDoc.Tables[premTableMedical1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[premTableMedical1].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                    oWordDoc.Tables[premTableMedical1].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                }

                #endregion

                #region Dental Monthly Premium

                if (PremiumTableWriteDental != null && PremiumTableWriteDental.Rows.Count > 0)
                {
                    oWordDoc.Tables[dentalTableNo].Rows.Last.Delete();
                    oWordDoc.Tables[dentalTableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[dentalTableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                }

                #endregion

                #region Vision Monthly Premium
                arrContributionID.Clear();
                if (PremiumTableWriteVision != null && PremiumTableWriteVision.Rows.Count > 0)
                {
                    oWordDoc.Tables[visionTableNo].Rows.Last.Delete();
                    oWordDoc.Tables[visionTableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                    oWordDoc.Tables[visionTableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    oWordDoc.Tables[visionTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[visionTableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                    oWordDoc.Tables[visionTableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                }

                #endregion
                */
                #endregion Approach 1

                #region Merge Fields
                int iTotalFields1 = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields1++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("MedicalCount"))
                        {
                            myMergeField.Select();
                            if (PremiumTableWriteMedical.Rows.Count > 0)
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("DentalCount"))
                        {
                            myMergeField.Select();
                            if (PremiumTableWriteDental.Rows.Count > 0)
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("MONTHLY"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(FrequencyMEdical1.ToUpper());

                            continue;
                        }
                        if (fieldName.Contains("EMPLOYEE COSTS"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("EMPLOYEE COSTS");

                            continue;
                        }
                        if (fieldName.Contains("VisionCount"))
                        {
                            myMergeField.Select();
                            if (PremiumTableWriteVision.Rows.Count > 0)
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">List<Contact> ContactList Object</param>
        /// <param name="AccountDS">DataSet AccountDS Object as optional parameter</param>
        /// <param name="selectedcolor">string selectedcolor Object as optional parameter</param>
        /// <param name="BenefitStructureDS ">DataSet BenefitStructureDS  Object as optional parameter</param>
        ///public void WriteAdditionalProductsToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null)
        public void WriteAdditionalProductsToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable OfficeTable, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null)
        {
            try
            {
                int iTotalFields = 0;
                DataTable Office = OfficeTable;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                bool is_Patient_Advocacy_Selected = false;
                bool is_Consumer_Driven_Telemedicine_Selected = false;
                bool is_Wellness_Selected = false;
                bool is_Accident_Selected = false;
                bool is_Voluntary_Cancer_Selected = false;
                bool is_Voluntary_Critical_Illness_Selected = false;

                string Patient_Advocacy_CarrierName = string.Empty;
                string Telemedicine_CarrierName = string.Empty;
                string Wellness_CarrierName = string.Empty;

                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        {
                            is_Patient_Advocacy_Selected = true;
                            Patient_Advocacy_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        {
                            is_Consumer_Driven_Telemedicine_Selected = true;
                            Telemedicine_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        {
                            is_Accident_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            is_Voluntary_Cancer_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            is_Voluntary_Critical_Illness_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Wellness)
                        {
                            is_Wellness_Selected = true;
                            Wellness_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                        }
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (is_Patient_Advocacy_Selected == true)
                        {
                            if (fieldName.Contains("HEADING PATIENT ADVOCACY"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("PATIENT ADVOCACY");
                                continue;
                            }

                            if (fieldName.Contains("Patient Advocacy Carrier Name"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(Patient_Advocacy_CarrierName);
                                continue;
                            }

                            if (fieldName.Contains("Common_Wellness"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (is_Consumer_Driven_Telemedicine_Selected == true)
                        {
                            if (fieldName.Contains("HEADING TELEMEDICINE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("TELEMEDICINE");
                                continue;
                            }

                            if (fieldName.Contains("Telemedicine Carrier Name"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Telemedicine_CarrierName);
                                continue;
                            }

                            if (fieldName.Contains("Common_Wellness"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (is_Wellness_Selected == true)
                        {
                            if (fieldName.Contains("HEADING WELLNESS PROGRAM"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WELLNESS PROGRAM");
                                continue;
                            }

                            if (fieldName.Contains("Wellness Carrier Name"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Wellness_CarrierName);
                                continue;
                            }

                            if (fieldName.Contains("Common_Wellness"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEligibilityToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            string EmployeeType = string.Empty;
            string domesticPartner = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                    EmployeeType = Emp.Rows[0]["EmployeeTypes_type"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                //dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType

                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                    //{
                    //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                    //}
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText((EmployeeStatus.Trim() + " " + EmployeeType.Trim() + " " + Working.Trim() + " " + UOM.Trim() + " " + Frequency.Trim()).ToLower());
                        else
                            myMergeField.Delete();
                        continue;
                    }

                    if (fieldName.Contains("Medical/Eligibility Rule/Waiting Period"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period.Trim().ToLower());
                        else
                            myMergeField.Delete();
                        continue;
                    }

                }
            }


        }

    }
}
