﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Drawing;
using System.Configuration;


namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTools4_BenchmarkingAuditReport : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        int Innetwork_Col_No = 5;
        int Outnetwork_Col_No = 6;
        int Column_No = 3;
        //int gCounter = 4;
        //int counter = 3;

        // Get the color flag from the web.config file to check the status of a flag
        // Flag = True (Development and UAT enviornment)
        // Flag = False (Production enviornment)
        bool colorFlag = Convert.ToBoolean(ConfigurationManager.AppSettings["ColorFlagForContractReviewChecklist"].ToString());

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="ddlClient">DropDownList ddlClient for showing client name</param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteMedicalSectionToTools4(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, DropDownList ddlClient, ArrayList MedicalBenefitColumnIdOutNetworkList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM, DataSet AccountDS, int OptionFieldValueiD, DataSet BenefitStructureDS)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                int count = 1;
                ArrayList arrMedical = new ArrayList();

                #region HashtableMedical In Network
                Hashtable HashtableMedical = new Hashtable();
                HashtableMedical.Add(1, "45");      //Annual Deductible[Per Person] - Individual 
                HashtableMedical.Add(2, "44");      //Annual Deductible[Maximum Per Family] - Family
                HashtableMedical.Add(3, "112");     //General Plan Information Coinsurence
                HashtableMedical.Add(4, "53");      //Annual Out-of-Pocket Maximum[Per Person] - Individual 
                HashtableMedical.Add(5, "52");      //Annual Out-of-Pocket Maximum[Maximum Per Family] - Family
                HashtableMedical.Add(6, "386");     //Professional[Office Visit]
                HashtableMedical.Add(7, "16");      //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedical.Add(8, "184");     //Other Services[Emergency Room]
                HashtableMedical.Add(9, "555");     //Other Services[Urgent Care]
                HashtableMedical.Add(10, "168");    //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedical.Add(11, "107");    //Other Services[Chiropractic Services]
                HashtableMedical.Add(12, "295");    //Hospital/Facility[Inpatient Care]
                HashtableMedical.Add(13, "409");    //Hospital/Facility[Outpatient Care]
                HashtableMedical.Add(14, "287");    //Mental Health Benefits; Inpatient; In-Network
                HashtableMedical.Add(15, "407");    //Mental Health Benefits; Outpatient; In-Network
                HashtableMedical.Add(16, "670");    //Substance Abuse; Inpatient Care; Inpatient Hospitalization In-Network
                HashtableMedical.Add(17, "673");    //Substance Abuse; Inpatient Care; Outpatient Care In-Network
                HashtableMedical.Add(18, "971");            //Other Services[Complex Radiology]
                HashtableMedical.Add(19, "414");            //Outpatient Specialist visit
                #endregion

                #region HashtableMedical Out Network
                //Hashtable HashtableMedicalOutNetwork = new Hashtable();
                //HashtableMedicalOutNetwork.Add(1, "45");      //Annual Deductible[Per Person] - Individual 
                //HashtableMedicalOutNetwork.Add(2, "44");      //Annual Deductible[Maximum Per Family] - Family
                //HashtableMedicalOutNetwork.Add(3, "112");     //General Plan Information Coinsurence
                //HashtableMedicalOutNetwork.Add(4, "53");      //Annual Out-of-Pocket Maximum[Per Person] - Individual 
                //HashtableMedicalOutNetwork.Add(5, "52");      //Annual Out-of-Pocket Maximum[Maximum Per Family] - Family
                //HashtableMedicalOutNetwork.Add(6, "386");     //Professional[Office Visit]
                //HashtableMedicalOutNetwork.Add(7, "16");      //Preventive Care - Adult Periodic Exams with Preventive Tests
                //HashtableMedicalOutNetwork.Add(8, "184");     //Other Services[Emergency Room]
                //HashtableMedicalOutNetwork.Add(9, "555");     //Other Services[Urgent Care]
                //HashtableMedicalOutNetwork.Add(10, "168");    //Other Services[Diagnostic X-Ray and Lab Tests]
                //HashtableMedicalOutNetwork.Add(11, "107");    //Other Services[Chiropractic Services]
                //HashtableMedicalOutNetwork.Add(12, "295");    //Hospital/Facility[Inpatient Care]
                //HashtableMedicalOutNetwork.Add(13, "409");    //Hospital/Facility[Outpatient Care]
                //HashtableMedicalOutNetwork.Add(14, "287");    //Mental Health Benefits; Inpatient; In-Network
                //HashtableMedicalOutNetwork.Add(15, "407");    //Mental Health Benefits; Outpatient; In-Network
                //HashtableMedicalOutNetwork.Add(16, "670");    //Substance Abuse; Inpatient Care; Inpatient Hospitalization In-Network
                //HashtableMedicalOutNetwork.Add(17, "673");    //Substance Abuse; Inpatient Care; Outpatient Care In-Network
                //HashtableMedicalOutNetwork.Add(18, "971");            //Other Services[Complex Radiology]
                #endregion

                string value = string.Empty;
                string AnnualDeductible_Individual = string.Empty;
                string AnnualDeductible_Family = string.Empty;
                string OutOfPocketMax_Individual = string.Empty;
                string OutOfPocketMax_Family = string.Empty;
                string domesticPartner = string.Empty;


                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Funding
                string FundingType = "";
                switch (OptionFieldValueiD)
                {
                    case 52403: FundingType = "Self-Insured"; break;
                    case 52401: FundingType = "Fully Insured"; break;
                    case 52400: FundingType = ""; break;
                    default: FundingType = ""; break;
                }

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());

                int k = 0;

                for (k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                    {
                        Excel.Worksheet wkSheet = null;
                        if (count == 1)
                        {
                            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                        }

                        # region Common Field for All Plans
                        //wkSheet.Cells[1, 1] = PlanTable.Rows[k]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                        //if (colorFlag == true)
                        //{
                        //    wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[k]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                        //} 
                        wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                        wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                        //wkSheet.Cells[9, Column_No] = primaryIndustry;
                        if (primaryIndustry.Contains('_'))
                        {
                            wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                        }
                        else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                        wkSheet.Cells[10, Column_No] = PlanTable.Rows[k]["Name"].ToString();
                        wkSheet.Cells[11, Column_No] = PlanTable.Rows[k]["ProductName"].ToString().Split('|')[0];
                        wkSheet.Cells[12, Column_No] = FundingType;
                        for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                        {
                            if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                            {
                                wkSheet.Cells[15, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                break;
                            }
                        }
                        wkSheet.Cells[16, Column_No] = PlanTable.Rows[k]["SummaryName"].ToString();

                        //if (!string.IsNullOrEmpty(PlanTable.Rows[k]["Renewal"].ToString()))
                        //{
                        //    if (Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()) != DateTime.MinValue)
                        //    {
                        //        DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString());
                        //        wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                        //    }
                        //}
                        //else
                        //{
                        //    wkSheet.Cells[4, 2] = "";
                        //}
                        // wkSheet.Cells[5, 2] = PlanTable.Rows[k]["Carrier"].ToString();
                        #endregion

                        #region Eligibility Section
                        //if (EligibilityDS.Tables.Count > 0)
                        //{
                        //    if (EligibilityDS.Tables[0].Rows.Count > 0)
                        //    {
                        //        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim().Length == 0)
                        //        {
                        //            wkSheet.Cells[49, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString();
                        //        }
                        //        else
                        //        {
                        //            wkSheet.Cells[49, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                        //        }

                        //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                        //        if (domesticPartner.Trim().Length == 0)
                        //        {
                        //            wkSheet.Cells[51, Innetwork_Col_No] = domesticPartner;
                        //        }
                        //        else
                        //        {
                        //            wkSheet.Cells[51, Innetwork_Col_No] = domesticPartner;
                        //        }

                        //        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                        //        {
                        //            wkSheet.Cells[50, Innetwork_Col_No] = "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                        //        }
                        //    }
                        //}
                        //wkSheet.Cells[58, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                        //wkSheet.Cells[59, Innetwork_Col_No] = MainAddress;
                        //wkSheet.Cells[48, Innetwork_Col_No] = UOM;
                        #endregion



                        #region MedicalTable

                        #region In Network
                        foreach (int key in HashtableMedical.Keys)
                        {
                            foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            {
                                if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                {
                                    value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    switch (key)
                                    {
                                        case 1: AnnualDeductible_Individual = value; break;
                                        case 2:
                                            if (!string.IsNullOrEmpty(value))
                                            {
                                                AnnualDeductible_Family = " / " + value;
                                            }
                                            else
                                            {
                                                AnnualDeductible_Family = value;
                                            }
                                            break;
                                        case 3: wkSheet.Cells[18, Column_No] = value; break;        // Coinsurance (Percentage)
                                        case 4: OutOfPocketMax_Individual = value; break;

                                        case 5: if (!string.IsNullOrEmpty(value))
                                            {
                                                OutOfPocketMax_Family = " / " + value;
                                            }
                                            else
                                            {
                                                OutOfPocketMax_Family = value;
                                            }
                                            break;
                                        case 6: wkSheet.Cells[19, Column_No] = value; break;        // Office Visit 

                                        // case 7: wkSheet.Cells[19, Innetwork_Col_No] = value; break;        // Preventive Care
                                        case 8: wkSheet.Cells[22, Column_No] = value; break;        // ER Copay & Benefit
                                        case 9: wkSheet.Cells[23, Column_No] = value; break;        // Urgent Care 
                                        //case 10: wkSheet.Cells[22, Innetwork_Col_No] = value; break;       // Outpatient Lab/X-Ray
                                        //case 11: wkSheet.Cells[24, Innetwork_Col_No] = value; break;       // Chiropractic Services
                                        // case 12: wkSheet.Cells[26, Innetwork_Col_No] = value; break;       // CONTRACT FEATURES
                                        //case 13: wkSheet.Cells[27, Innetwork_Col_No] = value; break;       // Outpatient Hospital Services
                                        //case 14: wkSheet.Cells[28, Innetwork_Col_No] = value; break;       // Mental Health Inpatient
                                        //case 15: wkSheet.Cells[29, Innetwork_Col_No] = value; break;       // Mental Health Outpatient
                                        //case 16: wkSheet.Cells[30, Innetwork_Col_No] = value; break;       // Substance Abuse Inpatient
                                        //case 17: wkSheet.Cells[31, Innetwork_Col_No] = value; break;       // Substance Abuse Outpatient
                                        //case 18: wkSheet.Cells[23, Innetwork_Col_No] = value; break;       // Complex Radiology
                                        case 19: wkSheet.Cells[20, Column_No] = value; break;
                                    }
                                }
                            }
                        }

                        //wkSheet.Cells[17, Column_No] = AnnualDeductible_Individual + AnnualDeductible_Family;
                        //wkSheet.Cells[21, Column_No] = OutOfPocketMax_Individual + OutOfPocketMax_Family;
                        wkSheet.Cells[17, Column_No] = AnnualDeductible_Individual;
                        wkSheet.Cells[21, Column_No] = OutOfPocketMax_Individual;
                        #endregion

                        #region Out Of Network
                        //AnnualDeductible_Individual = "";
                        //AnnualDeductible_Family = "";
                        //OutOfPocketMax_Individual = "";
                        //OutOfPocketMax_Family = "";

                        //foreach (int key in HashtableMedicalOutNetwork.Keys)
                        //{
                        //    value = "";

                        //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                        //    {
                        //        if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                        //        {
                        //            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                        //            switch (key)
                        //            {
                        //                case 1: AnnualDeductible_Individual = value; break;
                        //                case 2:
                        //                    if (!string.IsNullOrEmpty(value))
                        //                    {
                        //                        AnnualDeductible_Family = " / " + value;
                        //                    }
                        //                    else
                        //                    {
                        //                        AnnualDeductible_Family = value;
                        //                    }
                        //                    break;
                        //                case 3: wkSheet.Cells[16, Outnetwork_Col_No] = value; break;    // Coinsurance (Percentage)
                        //                case 4: OutOfPocketMax_Individual = value; break;
                        //                case 5:

                        //                    if (!string.IsNullOrEmpty(value))
                        //                    {
                        //                        OutOfPocketMax_Family = " / " + value;
                        //                    }
                        //                    else
                        //                    {
                        //                        OutOfPocketMax_Family = value;
                        //                    }
                        //                    break;
                        //                case 6: wkSheet.Cells[18, Outnetwork_Col_No] = value; break;    // Office Visit 
                        //                case 7: wkSheet.Cells[19, Outnetwork_Col_No] = value; break;    // Preventive Care
                        //                case 8: wkSheet.Cells[20, Outnetwork_Col_No] = value; break;    // ER Copay & Benefit
                        //                case 9: wkSheet.Cells[21, Outnetwork_Col_No] = value; break;    // Urgent Care
                        //                case 10: wkSheet.Cells[22, Outnetwork_Col_No] = value; break;   // Outpatient Lab/X-Ray
                        //                case 11: wkSheet.Cells[24, Outnetwork_Col_No] = value; break;   // Chiropractic Services
                        //                case 12: wkSheet.Cells[26, Outnetwork_Col_No] = value; break;   // CONTRACT FEATURES
                        //                case 13: wkSheet.Cells[27, Outnetwork_Col_No] = value; break;   // Outpatient Hospital Services
                        //                case 14: wkSheet.Cells[28, Outnetwork_Col_No] = value; break;   // Mental Health Inpatient
                        //                case 15: wkSheet.Cells[29, Outnetwork_Col_No] = value; break;   // Mental Health Outpatient
                        //                case 16: wkSheet.Cells[30, Outnetwork_Col_No] = value; break;   // Substance Abuse Inpatient
                        //                case 17: wkSheet.Cells[31, Outnetwork_Col_No] = value; break;   // Substance Abuse Outpatient
                        //                case 18: wkSheet.Cells[23, Outnetwork_Col_No] = value; break;       // Complex Radiology
                        //            }
                        //        }
                        //    }
                        //}
                        //wkSheet.Cells[14, Outnetwork_Col_No] = AnnualDeductible_Individual + AnnualDeductible_Family;
                        //wkSheet.Cells[17, Outnetwork_Col_No] = OutOfPocketMax_Individual + OutOfPocketMax_Family;

                        #endregion

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Prescription Drugs Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        public void WritePrescriptionDrugsSectionToTools4(Excel.Application myExcelApp, DataSet ProductDS, DataTable PlanTable, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string SummaryId, string ProductTypeDescription)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 1;

                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();
                HashtablePrescriptionDrugs.Add(1, "578");   // Deductible[Individual]
                HashtablePrescriptionDrugs.Add(2, "213");   // Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(3, "78");    // Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(4, "84");    // Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(5, "881");   // Prescription Categories[Preferred Specialty]
                #endregion

                //#region HashtablePrescriptionDrugs_OutNetwork
                //Hashtable HashtablePrescriptionDrugs_OutNetwork = new Hashtable();
                //HashtablePrescriptionDrugs_OutNetwork.Add(1, "578");    // Deductible[Individual]
                //HashtablePrescriptionDrugs_OutNetwork.Add(2, "213");    // Prescription Categories[Generic]
                //HashtablePrescriptionDrugs_OutNetwork.Add(3, "78");     // Prescription Categories[Formulary]
                //HashtablePrescriptionDrugs_OutNetwork.Add(4, "84");     // Prescription Categories[Non Formulary]
                //HashtablePrescriptionDrugs_OutNetwork.Add(5, "881");    // Prescription Categories[Preferred Specialty]
                //#endregion

                //#region MailOrder
                //Hashtable HashtableMailOrder = new Hashtable();

                //HashtableMailOrder.Add(1, "211");    // Mail Order[Individual]
                //HashtableMailOrder.Add(2, "76");     // Mail Order[Generic]
                //HashtableMailOrder.Add(3, "82");     // Mail Order[Formulary]
                //HashtableMailOrder.Add(4, "579");    // Mail Order[Non Formulary]
                //HashtableMailOrder.Add(5, "884");    // Mail Order[Preferred Specialty]
                //#endregion

                //#region MailOrder_OutNetwork
                //Hashtable HashtableMailOrder_OutNetwork = new Hashtable();

                //HashtableMailOrder_OutNetwork.Add(1, "211");    // Mail Order[Individual]
                //HashtableMailOrder_OutNetwork.Add(2, "76");     // Mail Order[Generic]
                //HashtableMailOrder_OutNetwork.Add(3, "82");     // Mail Order[Formulary]
                //HashtableMailOrder_OutNetwork.Add(4, "579");    // Mail Order[Non Formulary]
                //HashtableMailOrder_OutNetwork.Add(5, "884");    // Mail Order[Preferred Specialty]
                //#endregion

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region PrescriptionDrugsTable
                            string value = string.Empty;
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            //case 1: wkSheet.Cells[35, Innetwork_Col_No] = value; break;        // Prescription Deductible
                                            case 2: wkSheet.Cells[24, Column_No] = value; break;        // Retail Generic Drugs
                                            case 3: wkSheet.Cells[25, Column_No] = value; break;        // Retail Brand Name (Formulary) Drugs
                                            case 4: wkSheet.Cells[26, Column_No] = value; break;        // Retail Brand Name (Non-Formulary) Drugs
                                            case 5: wkSheet.Cells[27, Column_No] = value; break;        // Prescription Categories[Preferred Specialty]
                                        }
                                    }
                                }
                            }

                            //value = "";
                            //foreach (int key in HashtablePrescriptionDrugs_OutNetwork.Keys)
                            //{
                            //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            //    {
                            //        if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_OutNetwork[key].ToString())
                            //        {
                            //            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                            //            switch (key)
                            //            {
                            //                case 1: wkSheet.Cells[35, Outnetwork_Col_No] = value; break;        // Prescription Deductible
                            //                case 2: wkSheet.Cells[36, Outnetwork_Col_No] = value; break;        // Retail Generic Drugs
                            //                case 3: wkSheet.Cells[37, Outnetwork_Col_No] = value; break;        // Retail Brand Name (Formulary) Drugs
                            //                case 4: wkSheet.Cells[38, Outnetwork_Col_No] = value; break;        // Retail Brand Name (Non-Formulary) Drugs
                            //                case 5: wkSheet.Cells[39, Outnetwork_Col_No] = value; break;        // Prescription Categories[Preferred Specialty]
                            //            }
                            //        }
                            //    }
                            //}
                            #endregion

                            //#region MailOrder_Prescription Drugs
                            //value = "";
                            //foreach (int key in HashtableMailOrder.Keys)
                            //{
                            //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            //    {
                            //        if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                            //        {
                            //            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                            //            switch (key)
                            //            {
                            //                case 1: wkSheet.Cells[41, Innetwork_Col_No] = value; break;        // Prescription Deductible
                            //                case 2: wkSheet.Cells[42, Innetwork_Col_No] = value; break;        // Mail-Order Generic Drugs
                            //                case 3: wkSheet.Cells[43, Innetwork_Col_No] = value; break;        // Mail-Order Brand Name (Formulary) Drugs
                            //                case 4: wkSheet.Cells[40, Innetwork_Col_No] = value; break;        // Mail-Order Brand Name (Non-Formulary) Drugs
                            //                case 5: wkSheet.Cells[44, Innetwork_Col_No] = value; break;        // Prescription Categories[Preferred Specialty]

                            //            }
                            //        }
                            //    }
                            //}

                            //value = "";
                            //foreach (int key in HashtableMailOrder_OutNetwork.Keys)
                            //{
                            //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            //    {
                            //        if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_OutNetwork[key].ToString())
                            //        {
                            //            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                            //            switch (key)
                            //            {
                            //                case 1: wkSheet.Cells[41, Outnetwork_Col_No] = value; break;        // Prescription Deductible
                            //                case 2: wkSheet.Cells[42, Outnetwork_Col_No] = value; break;        // Mail-Order Generic Drugs
                            //                case 3: wkSheet.Cells[43, Outnetwork_Col_No] = value; break;        // Mail-Order Brand Name (Formulary) Drugs
                            //                case 4: wkSheet.Cells[40, Outnetwork_Col_No] = value; break;        // Mail-Order Brand Name (Non-Formulary) Drugs
                            //                case 5: wkSheet.Cells[44, Outnetwork_Col_No] = value; break;        // Prescription Categories[Preferred Specialty]
                            //            }
                            //        }
                            //    }
                            //}

                            //#endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        public void WriteHSAToTools4(Excel.Application myExcelApp, DataSet ProductDS, DataTable PlanTable, DataSet BenefitDS, ArrayList HSABenefitColumnIdList, string SummaryId, string ProductTypeDescription, DropDownList ddlClient, DataSet AccountDS, int OptionFieldValueiD, DataSet BenefitStructureDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableHSA = new Hashtable();
                #region HashtableHSA
                //HashtableHSA.Add(1, "635"); // General Plan Information – Maximum Annual Contribution / Individual
                //HashtableHSA.Add(2, "636"); // General Plan Information – Maximum Annual Contribution / Family

                HashtableHSA.Add(1, "640"); //  Individual
                HashtableHSA.Add(2, "644"); // Family
                #endregion
                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Funding
                string FundingType = "";
                switch (OptionFieldValueiD)
                {
                    case 52403: FundingType = "Self-Insured"; break;
                    case 52401: FundingType = "Fully Insured"; break;
                    case 52400: FundingType = ""; break;
                    default: FundingType = ""; break;
                }

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }
                            # region Common Field for All Plans
                            wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                            wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                            //wkSheet.Cells[9, Column_No] = primaryIndustry;
                            if (primaryIndustry.Contains('_'))
                            {
                                wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                            }
                            else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                            wkSheet.Cells[10, Column_No] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[11, Column_No] = PlanTable.Rows[k]["ProductName"].ToString().Split('|')[0];
                            wkSheet.Cells[12, Column_No] = FundingType;
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                                {
                                    wkSheet.Cells[15, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    break;
                                }
                            }
                            wkSheet.Cells[16, Column_No] = PlanTable.Rows[k]["SummaryName"].ToString(); // Benefit Name                    
                            #endregion
                            #region HSATable
                            string value = string.Empty;
                            foreach (int key in HashtableHSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSA[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[17, Column_No] = value; break;  // General Plan Information – Maximum Annual Contribution / Individual
                                            case 2: wkSheet.Cells[18, Column_No] = value; break;        // General Plan Information – Maximum Annual Contribution / Family  
                                        }
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">HRABenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        public void WriteHRAToTools4(Excel.Application myExcelApp, DataSet ProductDS, DataTable PlanTable, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, string SummaryId, string ProductTypeDescription, DropDownList ddlClient, DataSet AccountDS, int OptionFieldValueiD, DataSet BenefitStructureDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableHRA = new Hashtable();
                #region HashtableHRA
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "241"); // Health Reimbursement Account Tier 4 

                #endregion
                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Funding
                string FundingType = "";
                switch (OptionFieldValueiD)
                {
                    case 52403: FundingType = "Self-Insured"; break;
                    case 52401: FundingType = "Fully Insured"; break;
                    case 52400: FundingType = ""; break;
                    default: FundingType = ""; break;
                }

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }
                            # region Common Field for All Plans
                            wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                            wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                            //wkSheet.Cells[9, Column_No] = primaryIndustry;
                            if (primaryIndustry.Contains('_'))
                            {
                                wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                            }
                            else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                            wkSheet.Cells[10, Column_No] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[11, Column_No] = PlanTable.Rows[k]["ProductName"].ToString().Split('|')[0];
                            wkSheet.Cells[12, Column_No] = FundingType;
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                                {
                                    wkSheet.Cells[15, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    break;
                                }
                            }
                            wkSheet.Cells[16, Column_No] = PlanTable.Rows[k]["SummaryName"].ToString(); // Benefit Name                    
                            #endregion
                            #region HSATable
                            string value = string.Empty;
                            foreach (int key in HashtableHRA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[17, Column_No] = value; break;  // General Plan Information – Maximum Annual Contribution / Individual
                                            case 2: wkSheet.Cells[18, Column_No] = value; break;        // General Plan Information – Maximum Annual Contribution / Family  
                                        }
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan </param>
        /// <param name="ddlClient">DropDownList ddlClient for showing client name</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteLTDSectionToToTools4(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlClient, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM, DataSet AccountDS, DataSet BenefitStructureDS)
        {
            try
            {
                int count = 1;
                string ProductName = "";
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());

                #region HashtableLTD
                HashtableLTD.Add(1, "181");     //General Plan Information – Elimination Period 1
                HashtableLTD.Add(2, "71");      //General Plan Information – Benefit Percentage 2
                HashtableLTD.Add(3, "374");     //General Plan Information – Monthly Benefit Maximum 3
                HashtableLTD.Add(4, "351");     //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(5, "449");     //Benefits[Pre-Existing Condition Limitation]
                HashtableLTD.Add(6, "141");     //Benefits[Definition of Disability] 4
                HashtableLTD.Add(7, "142");     //Definition of Earnings
                HashtableLTD.Add(8, "582");     //Guaranteed Issue
                HashtableLTD.Add(9, "371");     //Minimum Monthly Benefit
                #endregion

                string value = "";
                string Elimination_Period = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit_Maximum = string.Empty;
                string Maximum_Period_Of_Payment = string.Empty;
                string Pre_Existing_Condition = string.Empty;
                string Disability = string.Empty;
                string Defination_Erning = string.Empty;
                string Guaranteed_Issue = string.Empty;
                string renewal = string.Empty;
                string Minimum_Monthly_Benefit = string.Empty;

                for (int rowindex = 0; rowindex < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString())
                        {
                            #region LTD

                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            # region Common Field for All Plans
                            wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                            wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                            //wkSheet.Cells[9, Column_No] = primaryIndustry;
                            if (primaryIndustry.Contains('_'))
                            {
                                wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                            }
                            else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                            wkSheet.Cells[10, Column_No] = PlanTable.Rows[rowindex]["ProductName"].ToString().Split('|')[0]; ;
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                                {
                                    wkSheet.Cells[13, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    break;
                                }
                            }
                            wkSheet.Cells[14, Column_No] = PlanTable.Rows[rowindex]["SummaryName"].ToString(); // Benefit Name                    
                            #endregion

                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                //if (value.Contains("days"))
                                                //{
                                                //    Elimination_Period = value.Trim().Replace("days", "day");
                                                //}
                                                //else
                                                //{
                                                //    Elimination_Period = value.Trim();
                                                //}
                                                //break;
                                                Elimination_Period = value.Trim();
                                                break;
                                            case 2: Benefit_Percentage = value.Trim(); break;
                                            case 3: Monthly_Benefit_Maximum = value.Trim(); break;
                                            case 4: Maximum_Period_Of_Payment = value.Trim() + " " + dr["UOM"].ToString().Trim(); break;
                                            case 5: Pre_Existing_Condition = value.Trim(); break;
                                            case 6: Disability = value.Trim(); break;
                                            case 7: Defination_Erning = value.Trim(); break;
                                            case 8: Guaranteed_Issue = value.Trim(); break;
                                            case 9: Minimum_Monthly_Benefit = value.Trim(); break;
                                        }
                                    }
                                }
                            }

                            /*** This Code is Commented by Amogh - 20/11/2017 b'coz Split(null) generate exception if value is Null   ***/
                            //int z = Convert.ToInt32(Elimination_Period.Split(null)[0]);
                            //if (z > 1)
                            //    wkSheet.Cells[15, Column_No] = Elimination_Period.ToString() + "s";
                            //else
                            //    wkSheet.Cells[15, Column_No] = Elimination_Period.ToString();

                            wkSheet.Cells[15, Column_No] = Convert.ToString(Elimination_Period);

                            //wkSheet.Cells[15, Column_No] = Elimination_Period.ToString();
                            wkSheet.Cells[16, Column_No] = Benefit_Percentage.ToString();
                            wkSheet.Cells[17, Column_No] = Monthly_Benefit_Maximum.ToString();
                            wkSheet.Cells[18, Column_No] = Disability.ToString();

                            //wkSheet.Cells[15, Innetwork_Col_No] = Guaranteed_Issue.ToString();
                            //wkSheet.Cells[17, Innetwork_Col_No] = Maximum_Period_Of_Payment.ToString();
                            //wkSheet.Cells[18, Innetwork_Col_No] = Minimum_Monthly_Benefit.ToString();
                            //wkSheet.Cells[21, Innetwork_Col_No] = Defination_Erning;
                            //wkSheet.Cells[22, Innetwork_Col_No] = Pre_Existing_Condition;

                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        /// <param name="ddlClient">DropDownList ddlClient for showing client name</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteSTDSectionToToTools4(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlClient, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM, DataSet AccountDS, DataSet BenefitStructureDS)
        {
            try
            {
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());

                #region HashtableSTD
                HashtableSTD.Add(1, "181");       //STD General Information – Elimination Period 
                HashtableSTD.Add(2, "142");       //STD General Information – Defination of Erning 
                HashtableSTD.Add(3, "71");       //STD General Plan Information – Benefit Percentage  3
                HashtableSTD.Add(4, "141");     //STD General Information – Defination of Disability 
                HashtableSTD.Add(5, "350");     //STD General Information – Maximum Period of Payment 5
                HashtableSTD.Add(6, "449");     //Benefit Features[Pre-Existing Condition Limitation]
                HashtableSTD.Add(7, "569");     //STD General Information – Weekly Benefit Maximum 4
                HashtableSTD.Add(8, "373");     //Minimum Weekly Benefit
                HashtableSTD.Add(9, "8");       //Elimination Period[Accident] 1
                HashtableSTD.Add(10, "505");    //Elimination Period[Sickness] 2
                #endregion

                string EliminationPeriod = string.Empty;
                string Defination_of_Erning = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Defination_of_Disability = string.Empty;
                string Weekly_Benefit_Maximum = string.Empty;
                string Pre_Existing_Condition_Limitation = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;
                string Minimum_Weekly_Benefit = string.Empty;
                string EliminationPeriod_Accident = string.Empty;
                string EliminationPeriod_Sickness = string.Empty;
                string ProductName = "";
                string renewal = string.Empty;
                string value = "";

                for (int rowindex = 0; rowindex < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString())
                        {
                            #region STD
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            # region Common Field for All Plans
                            wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                            wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                            //wkSheet.Cells[9, Column_No] = primaryIndustry;
                            if (primaryIndustry.Contains('_'))
                            {
                                wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                            }
                            else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                            wkSheet.Cells[10, Column_No] = PlanTable.Rows[rowindex]["ProductName"].ToString().Split('|')[0]; ;
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                                {
                                    wkSheet.Cells[13, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    break;
                                }
                            }
                            wkSheet.Cells[14, Column_No] = PlanTable.Rows[rowindex]["SummaryName"].ToString(); // Benefit Name                    
                            #endregion

                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {

                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                if (value.Contains("days"))
                                                {
                                                    EliminationPeriod = value.Trim().Replace("days", "day");
                                                }
                                                else
                                                {
                                                    EliminationPeriod = value.Trim();
                                                }
                                                break;
                                            case 2: Defination_of_Erning = value.Trim(); break;
                                            case 3: Benefit_Percentage = value.Trim(); break;
                                            case 4: Defination_of_Disability = value.Trim(); break;
                                            case 5: Maximum_Period_of_Payment = value.Trim() + " " + dr["UOM"].ToString().Trim(); break;
                                            case 6: Pre_Existing_Condition_Limitation = value.Trim(); break;
                                            case 7: Weekly_Benefit_Maximum = value.Trim(); break;
                                            case 8: Minimum_Weekly_Benefit = value.Trim(); break;
                                            case 9: EliminationPeriod_Accident = value.Trim(); break;
                                            case 10: if (!string.IsNullOrEmpty(value.Trim()))
                                                {
                                                    // EliminationPeriod_Sickness = " / " + value.Trim();
                                                    EliminationPeriod_Sickness = value.Trim();
                                                }
                                                else
                                                {
                                                    EliminationPeriod_Sickness = value.Trim();
                                                }
                                                break;
                                        }
                                    }
                                }
                            }

                            //wkSheet.Cells[16, Innetwork_Col_No] = Maximum_Period_of_Payment.ToString();


                            wkSheet.Cells[15, Column_No] = EliminationPeriod_Accident;
                            wkSheet.Cells[16, Column_No] = EliminationPeriod_Sickness;
                            wkSheet.Cells[17, Column_No] = Benefit_Percentage.ToString();
                            wkSheet.Cells[18, Column_No] = Weekly_Benefit_Maximum.ToString();
                            wkSheet.Cells[19, Column_No] = Maximum_Period_of_Payment.ToString();
                            //wkSheet.Cells[19, Innetwork_Col_No] = Defination_of_Disability.ToString();
                            //wkSheet.Cells[20, Innetwork_Col_No] = Defination_of_Erning;
                            //wkSheet.Cells[21, Innetwork_Col_No] = Pre_Existing_Condition_Limitation;

                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        public void WriteMonthlyPremiumSectionToTemplate4(Excel.Application myExcelApp, DataSet RateDS, DataSet ContributionDS, DataTable PlanTable, string ProductTypeDescription, int startIndex, int OptionFieldValueiD)
        {
            try
            {
                Excel.Worksheet wkSheet = null;
                int columnNumber = Column_No;
                ArrayList arrRateId = new ArrayList();
                ArrayList arrContributionId = new ArrayList();

                ////Funding
                //string FundingType = "";
                //switch (OptionFieldValueiD)
                //{
                //    case 52403: FundingType = "Self-Insured"; break;
                //    case 52401: FundingType = "Fully Insured"; break;
                //    case 52400: FundingType = ""; break;
                //    default: FundingType = ""; break;
                //}

                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                {
                    Object missing = System.Reflection.Missing.Value;

                    for (int index = startIndex; index < PlanTable.Rows.Count; index++)
                    {
                        #region  BuildTable
                        DataTable PremiumTable = new DataTable();
                        int premium_row_counter = 0;


                        DataTable PremiumTable_Contribution = new DataTable();
                        int premium_Contribution_row_counter = 0;
                        int monthly_premium_row_counter = 0;
                        int premium_row_Number = 0;
                        int rateName_row_Number = 0;
                        int fundingType_rowNo = 0;
                        if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.MedicalPlanType)
                        {
                            monthly_premium_row_counter = 31;
                            premium_row_Number = 32;
                            rateName_row_Number = 30;
                            fundingType_rowNo = 31;
                        }
                        else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.DentalPlanType)
                        {
                            monthly_premium_row_counter = 26;
                            premium_row_Number = 27;
                            rateName_row_Number = 25;
                            fundingType_rowNo = 26;
                        }
                        else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.VisionPlanType)
                        {
                            monthly_premium_row_counter = 23;
                            premium_row_Number = 24;
                            rateName_row_Number = 22;
                            fundingType_rowNo = 23;
                        }
                        int monthly_premium_col_counter = 2;

                        int monthly_Contribution_col_counter = 2;
                        bool header_created = false;
                        int Start = 0;
                        int End = 0;
                        int Interval = 0;

                        PremiumTable.Columns.Add("Plan", typeof(string));
                        //PremiumTable.Columns.Add("rateTierID", typeof(string));
                        PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                        PremiumTable.Columns.Add("rateTier_description", typeof(string));
                        PremiumTable.Columns.Add("monthlycost", typeof(string));
                        PremiumTable.Columns.Add("contributioncost", typeof(string));
                        PremiumTable.Columns.Add("summaryname", typeof(string));
                        PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                        PremiumTable.Columns.Add("contributionid", typeof(string));
                        PremiumTable.Columns.Add("rateid", typeof(string));
                        PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                        PremiumTable.Columns.Add("ageBandIndex", typeof(int));


                        PremiumTable_Contribution.Columns.Add("Plan", typeof(string));
                        //PremiumTable.Columns.Add("rateTierID", typeof(string));
                        PremiumTable_Contribution.Columns.Add("contributionTierID", typeof(Int16));
                        PremiumTable_Contribution.Columns.Add("contributionTier_description", typeof(string));
                        PremiumTable_Contribution.Columns.Add("monthlycost", typeof(string));
                        PremiumTable_Contribution.Columns.Add("contributioncost", typeof(string));
                        PremiumTable_Contribution.Columns.Add("summaryname", typeof(string));
                        PremiumTable_Contribution.Columns.Add("contributionFrequency", typeof(string));
                        PremiumTable_Contribution.Columns.Add("contributionid", typeof(string));
                        PremiumTable_Contribution.Columns.Add("rateid", typeof(string));
                        PremiumTable_Contribution.Columns.Add("contributionFieldValueID", typeof(string));
                        PremiumTable_Contribution.Columns.Add("ageBandIndex", typeof(int));
                        int iTotalFields = 0;

                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "fully insured equivalent") && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_summaryID"].ToString()) == int.Parse(PlanTable.Rows[index]["SummaryID"].ToString()))
                                {
                                    if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                                    {
                                        Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
                                        End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
                                        Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
                                        //  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
                                        if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
                                        {
                                            PremiumTable.Rows.Add();
                                            PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                            //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                            if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                            {
                                                PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                            }
                                            else
                                            {
                                                PremiumTable.Rows[premium_row_counter][1] = 0;
                                            }
                                            PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                            PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                            PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                            PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                            PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                                            premium_row_counter++;
                                        }
                                    }
                                    else
                                    {
                                        PremiumTable.Rows.Add();
                                        PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                        //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                        if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                        {
                                            PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                        }
                                        else
                                        {
                                            PremiumTable.Rows[premium_row_counter][1] = 0;
                                        }
                                        PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                        PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                        PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                        PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                        PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                                        ////for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                        ////{
                                        ////    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                        ////    {
                                        ////        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        ////        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        ////        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        ////        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                        ////        break;
                                        ////    }
                                        ////}
                                        premium_row_counter++;
                                    }
                                }
                            }
                        }

                        #endregion

                        //new change
                        // Boolean flag = false;

                        for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                        {
                            if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                            {
                                if (PlanTable.Rows[index]["SummaryID"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_summaryID"].ToString().Trim())
                                {
                                    // Commented the "ContributionValues_amount != 0" condition on the request of Nicole on 07 April 2015 
                                    //if (Convert.ToDecimal(ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_amount"]) != 0)
                                    //{
                                    //    flag = false;

                                    //for (int i = 0; i < PremiumTable.Rows.Count; i++)
                                    //{
                                    //    if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][11].ToString() == PlanTable.Rows[index]["SummaryID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    //    {
                                    //        flag = true;
                                    //        break;
                                    //    }
                                    //}
                                    //if (flag == false)
                                    //{
                                    double PremiumPercentageValue = 0;
                                    double SalaryPercentageValue = 0;
                                    double.TryParse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_percentOfPremium"].ToString(), out PremiumPercentageValue);
                                    double.TryParse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_percentOfSalary"].ToString(), out SalaryPercentageValue);
                                    if (PremiumPercentageValue == 0 && SalaryPercentageValue == 0)
                                    {
                                        PremiumTable_Contribution.Rows.Add();
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][3] = "";
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contribution"].ToString();

                                        PremiumTable_Contribution.Rows[premium_Contribution_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString(); ;
                                        //break;
                                        premium_Contribution_row_counter++;
                                    }

                                    //}
                                    //}
                                }
                            }
                        }
                        //end change

                        #region AddTable

                        DataTable dt = new DataTable();

                        PremiumTable.DefaultView.Sort = "[rateID] , [rateTierID] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;

                        DataTable dt1 = new DataTable();

                        //  PremiumTable_Contribution.DefaultView.Sort = "[contributionid] , [contributionTierID] asc";
                        dt1 = PremiumTable_Contribution.DefaultView.ToTable(true);
                        PremiumTable_Contribution = dt1;

                        #endregion
                        Int16 recordCnt = 0;
                        #region FillRateTable
                        for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                        {

                            if (!arrRateId.Contains(PremiumTable.Rows[i]["rateid"].ToString()))
                            {
                                monthly_premium_col_counter++;
                                arrRateId.Add(PremiumTable.Rows[i]["rateid"].ToString());

                                var rateDesriptions = (from a in RateDS.Tables["RateTable"].AsEnumerable()
                                                       where a.Field<Int32>("rateID") == Convert.ToInt32(PremiumTable.Rows[i]["rateid"])
                                                       select a.Field<string>("description")).FirstOrDefault();
                                wkSheet.Cells[rateName_row_Number, monthly_premium_col_counter] = rateDesriptions;

                                var rateFundingType = (from a in RateDS.Tables["RateTable"].AsEnumerable()
                                                       where a.Field<Int32>("rateID") == Convert.ToInt32(PremiumTable.Rows[i]["rateid"])
                                                       select a.Field<string>("FundingType")).FirstOrDefault();
                                if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.MedicalPlanType)
                                {
                                    wkSheet.Cells[fundingType_rowNo, monthly_premium_col_counter] = rateFundingType.Replace(@"_", " ");

                                }
                                else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.DentalPlanType)
                                {
                                    wkSheet.Cells[fundingType_rowNo, monthly_premium_col_counter] = rateFundingType.Replace(@"_", " ");

                                }
                                else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.VisionPlanType)
                                {
                                    wkSheet.Cells[fundingType_rowNo, monthly_premium_col_counter] = rateFundingType.Replace(@"_", " ");

                                }
                                //wkSheet.Cells[30, monthly_premium_col_counter] = rateDesriptions;
                            }

                            Microsoft.Office.Interop.Excel.Range oRng = null;
                            int endRowNum = 0;
                            oRng = GetSpecifiedRange("Contributions", wkSheet, premium_row_Number, 100);
                            if (oRng != null)
                            {
                                endRowNum = Convert.ToInt32(((dynamic)oRng).Row);
                            }



                            // monthly_premium_col_counter = 3;
                            for (int m = monthly_premium_row_counter; m < endRowNum; m++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    oRng = GetSpecifiedRange(PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"), wkSheet, premium_row_Number, endRowNum);
                                    if (oRng != null)
                                    {
                                        //monthly_premium_col_counter++;
                                        monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRng).Row) - 1;
                                        wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
                                        wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();

                                    }
                                    else
                                    {
                                        monthly_premium_row_counter++;
                                        monthly_premium_row_counter = endRowNum - 1;
                                        wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
                                        wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();
                                    }
                                    wkSheet.Cells[monthly_premium_row_counter, 1] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                }
                                else
                                {
                                    oRng = GetSpecifiedRange("Employee & " + PremiumTable.Rows[i][2].ToString(), wkSheet, premium_row_Number, endRowNum);
                                    if (oRng != null)
                                    {
                                        // monthly_premium_col_counter++;
                                        monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRng).Row);
                                        wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
                                        wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();
                                    }
                                    else
                                    {
                                        monthly_premium_row_counter++;
                                        monthly_premium_row_counter = endRowNum - 1;
                                        wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
                                        wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();

                                    }
                                    wkSheet.Cells[monthly_premium_row_counter, 1] = "Employee & " + PremiumTable.Rows[i][2].ToString();

                                }
                                break;
                            }

                            recordCnt++;
                            //if (recordCnt != PremiumTable.Rows.Count)
                            //{
                            //    //wkSheet.Rows.Insert(ref missing, ref missing);
                            //}

                            ////  monthly_premium_row_counter++;
                        }

                        #endregion



                        int row_num_contriHeader = 0;
                        #region FillContributionTable

                        Microsoft.Office.Interop.Excel.Range oRngC = null;
                        int endRowNumC = 0;
                        oRngC = GetSpecifiedRange("Contributions", wkSheet, premium_row_Number, wkSheet.Rows.Count);
                        if (oRngC != null)
                        {
                            endRowNumC = Convert.ToInt32(((dynamic)oRngC).Row) + 1;
                        }
                        monthly_premium_row_counter = endRowNumC + 2;
                        for (int i = 0; i < PremiumTable_Contribution.DefaultView.ToTable(true, "contributionFieldValueID").Rows.Count; i++)
                        {


                            if (i == 0)
                            {
                                row_num_contriHeader = endRowNumC;
                            }



                            if (!arrContributionId.Contains(PremiumTable_Contribution.Rows[i]["contributionid"].ToString()))
                            {
                                monthly_Contribution_col_counter++;
                                arrContributionId.Add(PremiumTable_Contribution.Rows[i]["contributionid"].ToString());

                                var ContriDesriptions = (from a in ContributionDS.Tables["contributionTable"].AsEnumerable()
                                                         where a.Field<Int32>("contributionid") == Convert.ToInt32(PremiumTable_Contribution.Rows[i]["contributionid"])
                                                         select a.Field<string>("description")).FirstOrDefault();
                                Color ColumnHeaderColor = Color.FromArgb(0, 112, 192);
                                if (Convert.ToString(PlanTable.Rows[index]["PlanType"]) == "Medical Plan")
                                { ColumnHeaderColor = Color.FromArgb(0, 112, 192); }
                                else if (Convert.ToString(PlanTable.Rows[index]["PlanType"]) == "Dental Plan")
                                { ColumnHeaderColor = Color.FromArgb(192, 80, 77); }
                                if (Convert.ToString(PlanTable.Rows[index]["PlanType"]) == "Vision Plan")
                                { ColumnHeaderColor = Color.FromArgb(245, 150, 70); }


                                wkSheet.Cells[row_num_contriHeader - 1, monthly_Contribution_col_counter].Interior.Color = System.Drawing.ColorTranslator.ToOle(ColumnHeaderColor);
                                //wkSheet.Range[row_num_contriHeader - 1, monthly_Contribution_col_counter].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                                wkSheet.Cells[row_num_contriHeader, monthly_Contribution_col_counter] = ContriDesriptions;
                                wkSheet.Cells[row_num_contriHeader + 1, monthly_Contribution_col_counter] = "Employee";
                                wkSheet.Cells[row_num_contriHeader + 2, monthly_Contribution_col_counter] = Convert.ToString(PremiumTable_Contribution.Rows[i]["contributionFrequency"]).Replace(@"_", " ");
                            }





                            // monthly_premium_col_counter = 3;
                            //for (int m = monthly_premium_row_counter; m < endRowNum; m++)
                            //{
                            if (PremiumTable_Contribution.Rows[i][1].ToString() == "8")
                            {
                                oRngC = GetSpecifiedRange(PremiumTable_Contribution.Rows[i][2].ToString().Replace("EE", "Employee"), wkSheet, row_num_contriHeader + 3, endRowNumC + 25);
                                if (oRngC != null)
                                {
                                    //monthly_premium_col_counter++;
                                    //Commented by Vaibhav 
                                    // monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row) - 1;
                                    int temp_monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row);
                                    wkSheet.Cells[temp_monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
                                    // wkSheet.Cells[monthly_premium_row_counter - 2, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();

                                }
                                else
                                {
                                    monthly_premium_row_counter++;
                                    //monthly_premium_row_counter = endRowNum - 2;
                                    //wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
                                    wkSheet.Cells[monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
                                    //wkSheet.Cells[monthly_premium_row_counter - 2, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
                                    wkSheet.Cells[monthly_premium_row_counter, 1] = PremiumTable_Contribution.Rows[i][2].ToString().Replace("EE", "Employee");
                                }

                            }
                            else
                            {
                                oRngC = GetSpecifiedRange("Employee & " + PremiumTable_Contribution.Rows[i][2].ToString(), wkSheet, row_num_contriHeader + 3, endRowNumC + 25);
                                if (oRngC != null)
                                {
                                    // monthly_premium_col_counter++;
                                    monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row);
                                    wkSheet.Cells[monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
                                }
                                else
                                {
                                    monthly_premium_row_counter++;
                                    //monthly_premium_row_counter = endRowNum - 2;
                                    //wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
                                    wkSheet.Cells[monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();

                                }
                                wkSheet.Cells[monthly_premium_row_counter, 1] = "Employee & " + PremiumTable_Contribution.Rows[i][2].ToString();

                            }
                            // break;
                            //}

                            recordCnt++;
                            //if (recordCnt != PremiumTable.Rows.Count)
                            //{
                            //    //wkSheet.Rows.Insert(ref missing, ref missing);
                            //}

                            ////  monthly_premium_row_counter++;
                        }

                        #endregion
                        break;
                    }
                }
                //oWordDoc.Tables[PremiumTable_counter].Delete();
                //PremiumTable_counter = PremiumTable_counter - 1;
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        ////public void WriteMonthlyPremiumSectionToTemplate4(Excel.Application myExcelApp, DataSet RateDS, DataSet ContributionDS, DataTable PlanTable, string ProductTypeDescription, int startIndex, int OptionFieldValueiD)
        ////{
        ////    try
        ////    {
        ////        Excel.Worksheet wkSheet = null;
        ////        int columnNumber = Column_No;
        ////        ArrayList arrRateId = new ArrayList();
        ////        ArrayList arrContributionId = new ArrayList();

        ////        ////Funding
        ////        //string FundingType = "";
        ////        //switch (OptionFieldValueiD)
        ////        //{
        ////        //    case 52403: FundingType = "Self-Insured"; break;
        ////        //    case 52401: FundingType = "Fully Insured"; break;
        ////        //    case 52400: FundingType = ""; break;
        ////        //    default: FundingType = ""; break;
        ////        //}

        ////        wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
        ////        {
        ////            Object missing = System.Reflection.Missing.Value;

        ////            for (int index = startIndex; index < PlanTable.Rows.Count; index++)
        ////            {
        ////                #region  BuildTable
        ////                DataTable PremiumTable = new DataTable();
        ////                int premium_row_counter = 0;


        ////                DataTable PremiumTable_Contribution = new DataTable();
        ////                int premium_Contribution_row_counter = 0;
        ////                int monthly_premium_row_counter = 0;
        ////                int premium_row_Number = 0;
        ////                int rateName_row_Number = 0;
        ////                int fundingType_rowNo = 0;
        ////                if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.MedicalPlanType)
        ////                {
        ////                    monthly_premium_row_counter = 31;
        ////                    premium_row_Number = 32;
        ////                    rateName_row_Number = 30;
        ////                    fundingType_rowNo = 31;
        ////                }
        ////                else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.DentalPlanType)
        ////                {
        ////                    monthly_premium_row_counter = 26;
        ////                    premium_row_Number = 27;
        ////                    rateName_row_Number = 25;
        ////                    fundingType_rowNo = 26;
        ////                }
        ////                else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.VisionPlanType)
        ////                {
        ////                    monthly_premium_row_counter = 23;
        ////                    premium_row_Number = 24;
        ////                    rateName_row_Number = 22;
        ////                    fundingType_rowNo = 23;
        ////                }
        ////                int monthly_premium_col_counter = 2;

        ////                int monthly_Contribution_col_counter = 2;
        ////                bool header_created = false;
        ////                int Start = 0;
        ////                int End = 0;
        ////                int Interval = 0;

        ////                PremiumTable.Columns.Add("Plan", typeof(string));
        ////                //PremiumTable.Columns.Add("rateTierID", typeof(string));
        ////                PremiumTable.Columns.Add("rateTierID", typeof(Int16));
        ////                PremiumTable.Columns.Add("rateTier_description", typeof(string));
        ////                PremiumTable.Columns.Add("monthlycost", typeof(string));
        ////                PremiumTable.Columns.Add("contributioncost", typeof(string));
        ////                PremiumTable.Columns.Add("summaryname", typeof(string));
        ////                PremiumTable.Columns.Add("contributionFrequency", typeof(string));
        ////                PremiumTable.Columns.Add("contributionid", typeof(string));
        ////                PremiumTable.Columns.Add("rateid", typeof(string));
        ////                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
        ////                PremiumTable.Columns.Add("ageBandIndex", typeof(int));


        ////                PremiumTable_Contribution.Columns.Add("Plan", typeof(string));
        ////                //PremiumTable.Columns.Add("rateTierID", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("contributionTierID", typeof(Int16));
        ////                PremiumTable_Contribution.Columns.Add("contributionTier_description", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("monthlycost", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("contributioncost", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("summaryname", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("contributionFrequency", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("contributionid", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("rateid", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("contributionFieldValueID", typeof(string));
        ////                PremiumTable_Contribution.Columns.Add("ageBandIndex", typeof(int));
        ////                int iTotalFields = 0;

        ////                for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
        ////                {
        ////                    if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
        ////                    {
        ////                        if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "fully insured equivalent") && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_summaryID"].ToString()) == int.Parse(PlanTable.Rows[index]["SummaryID"].ToString()))
        ////                        {
        ////                            if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
        ////                            {
        ////                                Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
        ////                                End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
        ////                                Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
        ////                                //  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
        ////                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
        ////                                {
        ////                                    PremiumTable.Rows.Add();
        ////                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        ////                                    //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        ////                                    if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        ////                                    {
        ////                                        PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        ////                                    }
        ////                                    else
        ////                                    {
        ////                                        PremiumTable.Rows[premium_row_counter][1] = 0;
        ////                                    }
        ////                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        ////                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        ////                                    PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        ////                                    PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        ////                                    PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        ////                                    premium_row_counter++;
        ////                                }
        ////                            }
        ////                            else
        ////                            {
        ////                                PremiumTable.Rows.Add();
        ////                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        ////                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        ////                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        ////                                {
        ////                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        ////                                }
        ////                                else
        ////                                {
        ////                                    PremiumTable.Rows[premium_row_counter][1] = 0;
        ////                                }
        ////                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        ////                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        ////                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        ////                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        ////                                PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        ////                                ////for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        ////                                ////{
        ////                                ////    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        ////                                ////    {
        ////                                ////        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        ////                                ////        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        ////                                ////        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        ////                                ////        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
        ////                                ////        break;
        ////                                ////    }
        ////                                ////}
        ////                                premium_row_counter++;
        ////                            }
        ////                        }
        ////                    }
        ////                }

        ////                #endregion

        ////                //new change
        ////                // Boolean flag = false;

        ////                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        ////                {
        ////                    if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
        ////                    {
        ////                        if (PlanTable.Rows[index]["SummaryID"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_summaryID"].ToString().Trim())
        ////                        {
        ////                            // Commented the "ContributionValues_amount != 0" condition on the request of Nicole on 07 April 2015 
        ////                            //if (Convert.ToDecimal(ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_amount"]) != 0)
        ////                            //{
        ////                            //    flag = false;

        ////                            //for (int i = 0; i < PremiumTable.Rows.Count; i++)
        ////                            //{
        ////                            //    if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][11].ToString() == PlanTable.Rows[index]["SummaryID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        ////                            //    {
        ////                            //        flag = true;
        ////                            //        break;
        ////                            //    }
        ////                            //}
        ////                            //if (flag == false)
        ////                            //{
        ////                            PremiumTable_Contribution.Rows.Add();
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][3] = "";
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contribution"].ToString();

        ////                            PremiumTable_Contribution.Rows[premium_Contribution_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString(); ;
        ////                            //break;
        ////                            premium_Contribution_row_counter++;
        ////                            //}
        ////                            //}
        ////                        }
        ////                    }
        ////                }
        ////                //end change

        ////                #region AddTable

        ////                DataTable dt = new DataTable();

        ////                PremiumTable.DefaultView.Sort = "[rateID] , [rateTierID] asc";
        ////                dt = PremiumTable.DefaultView.ToTable(true);
        ////                PremiumTable = dt;

        ////                DataTable dt1 = new DataTable();

        ////                //  PremiumTable_Contribution.DefaultView.Sort = "[contributionid] , [contributionTierID] asc";
        ////                dt1 = PremiumTable_Contribution.DefaultView.ToTable(true);
        ////                PremiumTable_Contribution = dt1;

        ////                #endregion
        ////                Int16 recordCnt = 0;
        ////                #region FillRateTable
        ////                for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        ////                {

        ////                    if (!arrRateId.Contains(PremiumTable.Rows[i]["rateid"].ToString()))
        ////                    {
        ////                        monthly_premium_col_counter++;
        ////                        arrRateId.Add(PremiumTable.Rows[i]["rateid"].ToString());

        ////                        var rateDesriptions = (from a in RateDS.Tables["RateTable"].AsEnumerable()
        ////                                               where a.Field<Int32>("rateID") == Convert.ToInt32(PremiumTable.Rows[i]["rateid"])
        ////                                               select a.Field<string>("description")).FirstOrDefault();
        ////                        wkSheet.Cells[rateName_row_Number, monthly_premium_col_counter] = rateDesriptions;

        ////                        var rateFundingType = (from a in RateDS.Tables["RateTable"].AsEnumerable()
        ////                                               where a.Field<Int32>("rateID") == Convert.ToInt32(PremiumTable.Rows[i]["rateid"])
        ////                                               select a.Field<string>("FundingType")).FirstOrDefault();
        ////                        if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.MedicalPlanType)
        ////                        {
        ////                            wkSheet.Cells[fundingType_rowNo, monthly_premium_col_counter] = rateFundingType.Replace(@"_", " ");

        ////                        }
        ////                        else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.DentalPlanType)
        ////                        {
        ////                            wkSheet.Cells[fundingType_rowNo, monthly_premium_col_counter] = rateFundingType.Replace(@"_", " ");

        ////                        }
        ////                        else if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == cv.VisionPlanType)
        ////                        {
        ////                            wkSheet.Cells[fundingType_rowNo, monthly_premium_col_counter] = rateFundingType.Replace(@"_", " ");

        ////                        }
        ////                        //wkSheet.Cells[30, monthly_premium_col_counter] = rateDesriptions;
        ////                    }

        ////                    Microsoft.Office.Interop.Excel.Range oRng = null;
        ////                    int endRowNum = 0;
        ////                    oRng = GetSpecifiedRange("Contributions", wkSheet, premium_row_Number, 100);
        ////                    if (oRng != null)
        ////                    {
        ////                        endRowNum = Convert.ToInt32(((dynamic)oRng).Row);
        ////                    }



        ////                    // monthly_premium_col_counter = 3;
        ////                    for (int m = monthly_premium_row_counter; m < endRowNum; m++)
        ////                    {
        ////                        if (PremiumTable.Rows[i][1].ToString() == "8")
        ////                        {
        ////                            oRng = GetSpecifiedRange(PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"), wkSheet, premium_row_Number, endRowNum);
        ////                            if (oRng != null)
        ////                            {
        ////                                //monthly_premium_col_counter++;
        ////                                monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRng).Row) - 1;
        ////                                wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
        ////                                wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();

        ////                            }
        ////                            else
        ////                            {
        ////                                monthly_premium_row_counter++;
        ////                                monthly_premium_row_counter = endRowNum - 1;
        ////                                wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
        ////                                wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();
        ////                            }
        ////                            wkSheet.Cells[monthly_premium_row_counter, 1] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
        ////                        }
        ////                        else
        ////                        {
        ////                            oRng = GetSpecifiedRange("Employee & " + PremiumTable.Rows[i][2].ToString(), wkSheet, premium_row_Number, endRowNum);
        ////                            if (oRng != null)
        ////                            {
        ////                                // monthly_premium_col_counter++;
        ////                                monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRng).Row);
        ////                                wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
        ////                                wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();
        ////                            }
        ////                            else
        ////                            {
        ////                                monthly_premium_row_counter++;
        ////                                monthly_premium_row_counter = endRowNum - 1;
        ////                                wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
        ////                                wkSheet.Cells[monthly_premium_row_counter, monthly_premium_col_counter] = "$" + PremiumTable.Rows[i][3].ToString();

        ////                            }
        ////                            wkSheet.Cells[monthly_premium_row_counter, 1] = "Employee & " + PremiumTable.Rows[i][2].ToString();

        ////                        }
        ////                        break;
        ////                    }

        ////                    recordCnt++;
        ////                    //if (recordCnt != PremiumTable.Rows.Count)
        ////                    //{
        ////                    //    //wkSheet.Rows.Insert(ref missing, ref missing);
        ////                    //}

        ////                    ////  monthly_premium_row_counter++;
        ////                }

        ////                #endregion



        ////                int row_num_contriHeader = 0;
        ////                #region FillContributionTable

        ////                Microsoft.Office.Interop.Excel.Range oRngC = null;
        ////                int endRowNumC = 0;
        ////                oRngC = GetSpecifiedRange("Contributions", wkSheet, premium_row_Number, wkSheet.Rows.Count);
        ////                if (oRngC != null)
        ////                {
        ////                    endRowNumC = Convert.ToInt32(((dynamic)oRngC).Row) + 1;
        ////                }
        ////                monthly_premium_row_counter = endRowNumC + 2;
        ////                for (int i = 0; i < PremiumTable_Contribution.DefaultView.ToTable(true, "contributionFieldValueID").Rows.Count; i++)
        ////                {


        ////                    if (i == 0)
        ////                    {
        ////                        row_num_contriHeader = endRowNumC;
        ////                    }



        ////                    if (!arrContributionId.Contains(PremiumTable_Contribution.Rows[i]["contributionid"].ToString()))
        ////                    {
        ////                        monthly_Contribution_col_counter++;
        ////                        arrContributionId.Add(PremiumTable_Contribution.Rows[i]["contributionid"].ToString());

        ////                        var ContriDesriptions = (from a in ContributionDS.Tables["contributionTable"].AsEnumerable()
        ////                                                 where a.Field<Int32>("contributionid") == Convert.ToInt32(PremiumTable_Contribution.Rows[i]["contributionid"])
        ////                                                 select a.Field<string>("description")).FirstOrDefault();
        ////                        Color ColumnHeaderColor = Color.FromArgb(0, 112, 192);
        ////                        if (Convert.ToString(PlanTable.Rows[index]["PlanType"]) == "Medical Plan")
        ////                        { ColumnHeaderColor = Color.FromArgb(0, 112, 192); }
        ////                        else if (Convert.ToString(PlanTable.Rows[index]["PlanType"]) == "Dental Plan")
        ////                        { ColumnHeaderColor = Color.FromArgb(192, 80, 77); }
        ////                        if (Convert.ToString(PlanTable.Rows[index]["PlanType"]) == "Vision Plan")
        ////                        { ColumnHeaderColor = Color.FromArgb(245, 150, 70); }


        ////                        wkSheet.Cells[row_num_contriHeader - 1, monthly_Contribution_col_counter].Interior.Color = System.Drawing.ColorTranslator.ToOle(ColumnHeaderColor);
        ////                        //wkSheet.Range[row_num_contriHeader - 1, monthly_Contribution_col_counter].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
        ////                        wkSheet.Cells[row_num_contriHeader, monthly_Contribution_col_counter] = ContriDesriptions;
        ////                        wkSheet.Cells[row_num_contriHeader + 1, monthly_Contribution_col_counter] = "Employee";
        ////                        wkSheet.Cells[row_num_contriHeader + 2, monthly_Contribution_col_counter] = Convert.ToString(PremiumTable_Contribution.Rows[i]["contributionFrequency"]).Replace(@"_", " ");
        ////                    }





        ////                    // monthly_premium_col_counter = 3;
        ////                    //for (int m = monthly_premium_row_counter; m < endRowNum; m++)
        ////                    //{
        ////                    if (PremiumTable_Contribution.Rows[i][1].ToString() == "8")
        ////                    {
        ////                        oRngC = GetSpecifiedRange(PremiumTable_Contribution.Rows[i][2].ToString().Replace("EE", "Employee"), wkSheet, row_num_contriHeader + 3, endRowNumC + 25);
        ////                        if (oRngC != null)
        ////                        {
        ////                            //monthly_premium_col_counter++;
        ////                            monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row) - 1;
        ////                            wkSheet.Cells[monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
        ////                            // wkSheet.Cells[monthly_premium_row_counter - 2, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();

        ////                        }
        ////                        else
        ////                        {
        ////                            monthly_premium_row_counter++;
        ////                            //monthly_premium_row_counter = endRowNum - 2;
        ////                            //wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
        ////                            wkSheet.Cells[monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
        ////                            //wkSheet.Cells[monthly_premium_row_counter - 2, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
        ////                        }
        ////                        wkSheet.Cells[monthly_premium_row_counter, 1] = PremiumTable_Contribution.Rows[i][2].ToString().Replace("EE", "Employee");
        ////                    }
        ////                    else
        ////                    {
        ////                        oRngC = GetSpecifiedRange("Employee & " + PremiumTable_Contribution.Rows[i][2].ToString(), wkSheet, row_num_contriHeader + 3, endRowNumC + 25);
        ////                        if (oRngC != null)
        ////                        {
        ////                            // monthly_premium_col_counter++;
        ////                            monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row);
        ////                            wkSheet.Cells[monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();
        ////                        }
        ////                        else
        ////                        {
        ////                            monthly_premium_row_counter++;
        ////                            //monthly_premium_row_counter = endRowNum - 2;
        ////                            //wkSheet.Rows[monthly_premium_row_counter].EntireRow.Insert();
        ////                            wkSheet.Cells[monthly_premium_row_counter, monthly_Contribution_col_counter] = "$" + PremiumTable_Contribution.Rows[i][4].ToString();

        ////                        }
        ////                        wkSheet.Cells[monthly_premium_row_counter, 1] = "Employee & " + PremiumTable_Contribution.Rows[i][2].ToString();

        ////                    }
        ////                    // break;
        ////                    //}

        ////                    recordCnt++;
        ////                    //if (recordCnt != PremiumTable.Rows.Count)
        ////                    //{
        ////                    //    //wkSheet.Rows.Insert(ref missing, ref missing);
        ////                    //}

        ////                    ////  monthly_premium_row_counter++;
        ////                }

        ////                #endregion
        ////                break;
        ////            }
        ////        }
        ////        //oWordDoc.Tables[PremiumTable_counter].Delete();
        ////        //PremiumTable_counter = PremiumTable_counter - 1;
        ////    }

        ////    catch (Exception ex)
        ////    {
        ////        //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
        ////        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        ////        Response.Redirect("~/view/ErrorNotification.aspx");
        ////    }
        ////}


        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlClient">DropDownList to show client name for selected item</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="DentalBenefitColumnIdOutNetworkList">DentalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteDentalSectionToTools4(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlClient, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM, DataSet AccountDS, int OptionFieldValueiD, DataSet BenefitStructureDS)
        {
            try
            {
                #region HashtableDental In Network
                Hashtable HashtableDental = new Hashtable();
                HashtableDental.Add(1, "45");   //Annual Deductible[Individual]
                HashtableDental.Add(2, "44");   //Annual Deductible[Family]
                HashtableDental.Add(3, "566");  //Annual Deductible[Deductible waived for Preventive]
                HashtableDental.Add(4, "55");   //Benefit Year Maximum 
                HashtableDental.Add(5, "164");  //Dental Categories[Preventive & Diagnostic Care]
                HashtableDental.Add(6, "64");   //Dental Categories[Basic Restorative Care]
                HashtableDental.Add(7, "336");  //Dental Categories[Major Restorative Care]
                HashtableDental.Add(8, "392");  //Orthodontia[Benefits]
                HashtableDental.Add(9, "314");  //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDental.Add(10, "190");  //Endodontic Treatment
                HashtableDental.Add(11, "419");  //Periodontic Treatment
                #endregion

                #region HashtableDental Out Network
                //Hashtable HashtableDentalOutNetwork = new Hashtable();
                //HashtableDentalOutNetwork.Add(1, "45");   //Annual Deductible[Individual]
                //HashtableDentalOutNetwork.Add(2, "44");   //Annual Deductible[Family]
                //HashtableDentalOutNetwork.Add(3, "566");  //Annual Deductible[Deductible waived for Preventive]
                //HashtableDentalOutNetwork.Add(4, "55");   //Benefit Year Maximum 
                //HashtableDentalOutNetwork.Add(5, "164");  //Dental Categories[Preventive & Diagnostic Care]
                //HashtableDentalOutNetwork.Add(6, "64");   //Dental Categories[Basic Restorative Care]
                //HashtableDentalOutNetwork.Add(7, "336");  //Dental Categories[Major Restorative Care]
                //HashtableDentalOutNetwork.Add(8, "392");  //Orthodontia[Benefits]
                //HashtableDentalOutNetwork.Add(9, "314");  //Orthodontia[Lifetime Orthodontia Maximum]
                //HashtableDentalOutNetwork.Add(10, "190");  //Endodontic Treatment
                //HashtableDentalOutNetwork.Add(11, "419");  //Periodontic Treatment
                #endregion

                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                string AnnualDeductible_Induvidual = string.Empty;
                string AnnualDeductible_Family = string.Empty;
                string domesticPartner = string.Empty;

                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Funding
                string FundingType = "";
                switch (OptionFieldValueiD)
                {
                    case 52403: FundingType = "Self-Insured"; break;
                    case 52401: FundingType = "Fully Insured"; break;
                    case 52400: FundingType = ""; break;
                    default: FundingType = ""; break;
                }

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans
                            wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                            wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                            //wkSheet.Cells[9, Column_No] = primaryIndustry;
                            if (primaryIndustry.Contains('_'))
                            {
                                wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                            }
                            else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                            wkSheet.Cells[10, Column_No] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[11, Column_No] = PlanTable.Rows[k]["ProductName"].ToString().Split('|')[0];
                            wkSheet.Cells[12, Column_No] = FundingType;
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                                {
                                    wkSheet.Cells[15, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    break;
                                }
                            }
                            wkSheet.Cells[16, Column_No] = PlanTable.Rows[k]["SummaryName"].ToString();
                            //wkSheet.Cells[1, 1] = PlanTable.Rows[k]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                            //if (colorFlag == true)
                            //{
                            //    wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[k]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                            //}
                            //wkSheet.Cells[13, 1] = PlanTable.Rows[k]["Name"].ToString();
                            //wkSheet.Cells[3, 2] = ddlClient.SelectedItem.Text.ToString();
                            //if (!string.IsNullOrEmpty(PlanTable.Rows[k]["Renewal"].ToString()))
                            //{
                            //    if (Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()) != DateTime.MinValue)
                            //    {
                            //        DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString());
                            //        wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                            //    }
                            //}
                            //else
                            //{
                            //    wkSheet.Cells[4, 2] = "";
                            //}
                            //wkSheet.Cells[5, 2] = PlanTable.Rows[k]["Carrier"].ToString();
                            #endregion

                            #region Eligibility Section
                            ////wkSheet.Cells[27, Innetwork_Col_No] = UOM;

                            ////if (EligibilityDS.Tables.Count > 0)
                            ////{
                            ////    if (EligibilityDS.Tables[0].Rows.Count > 0)
                            ////    {
                            ////        wkSheet.Cells[28, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                            ////        wkSheet.Cells[29, Innetwork_Col_No] = "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();

                            ////        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                            ////        wkSheet.Cells[30, Innetwork_Col_No] = domesticPartner;
                            ////    }
                            ////}
                            ////wkSheet.Cells[37, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                            ////wkSheet.Cells[38, Innetwork_Col_No] = MainAddress;

                            #endregion


                            #region DetalTable In Network

                            foreach (int key in HashtableDental.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDental[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 1: AnnualDeductible_Induvidual = value; break;
                                            //case 2: if (!string.IsNullOrEmpty(value))
                                            //    {
                                            //        AnnualDeductible_Family = " / " + value;
                                            //    }
                                            //    else
                                            //    {
                                            //        AnnualDeductible_Family = value;
                                            //    }
                                            //    break;
                                            //case 3: wkSheet.Cells[15, Column_No] = value; break;
                                            case 4: wkSheet.Cells[18, Column_No] = value; break;
                                            case 5: wkSheet.Cells[19, Column_No] = value; break;
                                            case 6: wkSheet.Cells[20, Column_No] = value; break;
                                            case 7: wkSheet.Cells[21, Column_No] = value; break;
                                            case 8: wkSheet.Cells[22, Column_No] = value; break;
                                            //case 9: wkSheet.Cells[21, Column_No] = value; break;
                                            //case 10: wkSheet.Cells[22, Column_No] = value; break;
                                            //case 11: wkSheet.Cells[23, Column_No] = value; break;
                                        }
                                    }
                                }
                            }

                            //wkSheet.Cells[14, Innetwork_Col_No] = AnnualDeductible_Induvidual + AnnualDeductible_Family;
                            wkSheet.Cells[17, Column_No] = AnnualDeductible_Induvidual;

                            #endregion

                            #region DetalTable Out Network
                            //AnnualDeductible_Induvidual = "";
                            //AnnualDeductible_Family = "";
                            //foreach (int key in HashtableDentalOutNetwork.Keys)
                            //{
                            //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            //    {
                            //        if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && DentalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalOutNetwork[key].ToString())
                            //        {
                            //            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                            //            switch (key)
                            //            {
                            //                case 1: AnnualDeductible_Induvidual = value; break;
                            //                case 2:
                            //                    if (!string.IsNullOrEmpty(value))
                            //                    {
                            //                        AnnualDeductible_Family = " / " + value;
                            //                    }
                            //                    else { AnnualDeductible_Family = value; }
                            //                    break;

                            //                case 3: wkSheet.Cells[15, Outnetwork_Col_No] = value; break;
                            //                case 4: wkSheet.Cells[16, Outnetwork_Col_No] = value; break;
                            //                case 5: wkSheet.Cells[17, Outnetwork_Col_No] = value; break;
                            //                case 6: wkSheet.Cells[18, Outnetwork_Col_No] = value; break;
                            //                case 7: wkSheet.Cells[19, Outnetwork_Col_No] = value; break;
                            //                case 8: wkSheet.Cells[20, Outnetwork_Col_No] = value; break;
                            //                case 9: wkSheet.Cells[21, Outnetwork_Col_No] = value; break;
                            //                case 10: wkSheet.Cells[22, Outnetwork_Col_No] = value; break;
                            //                case 11: wkSheet.Cells[23, Outnetwork_Col_No] = value; break;
                            //            }
                            //        }
                            //    }
                            //}

                            //wkSheet.Cells[14, Outnetwork_Col_No] = AnnualDeductible_Induvidual + AnnualDeductible_Family;


                            #endregion
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlClient">DropDownList to show client name for selected item</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="VisionBenefitColumnIdOutNetworkList">VisionBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteVisionSectionToTools4(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlClient, ArrayList VisionBenefitColumnIdList, ArrayList VisionBenefitColumnIdOutNetworkList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM, DataSet AccountDS, int OptionFieldValueiD, DataSet BenefitStructureDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitInNetwork.Add(1, "195");      //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(2, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(3, "194");      //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitInNetwork.Add(4, "309");      //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitInNetwork.Add(5, "207");      //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork.Add(6, "122");      //General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefitInNetwork.Add(7, "507");      //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitInNetwork.Add(8, "73");       //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefitInNetwork.Add(9, "553");      //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitInNetwork.Add(10, "311");     //Covered Services – Lenses – Lenticular Lens
                HashtableVisionBenefitInNetwork.Add(11, "356");     //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefitInNetwork.Add(12, "178");     //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefitInNetwork.Add(13, "208");     //Covered Services – Frames


                ArrayList arrVisionBenefitInNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                {
                    arrVisionBenefitInNetwork.Add(key);
                }

                arrVisionBenefitInNetwork.Sort();
                arrVisionBenefitInNetwork.Reverse();
                #endregion

                //Hashtable HashtableVisionBenefitOutNetwork = new Hashtable();

                #region HastableVisionBenefit
                //HashtableVisionBenefitOutNetwork.Add(1, "195");      //General Plan Information – Copay – Examination Deductible
                //HashtableVisionBenefitOutNetwork.Add(2, "344");      //General Plan Information – Copay – Material Deductible
                //HashtableVisionBenefitOutNetwork.Add(3, "194");      //General Plan Information – Benefit Frequency – Examination
                //HashtableVisionBenefitOutNetwork.Add(4, "309");      //General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefitOutNetwork.Add(5, "207");      //General Plan Information – Benefit Frequency – Frames
                //HashtableVisionBenefitOutNetwork.Add(6, "122");      //General Plan Information – Benefit Frequency – Contacts
                //HashtableVisionBenefitOutNetwork.Add(7, "507");      //Covered Services – Lenses – Single Vision Lens
                //HashtableVisionBenefitOutNetwork.Add(8, "73");       //Covered Services – Lenses – Bifocal Lens
                //HashtableVisionBenefitOutNetwork.Add(9, "553");      //Covered Services – Lenses – Trifocal Lens
                //HashtableVisionBenefitOutNetwork.Add(10, "311");     //Covered Services – Lenses – Lenticular Lens
                //HashtableVisionBenefitOutNetwork.Add(11, "356");     //Covered Services – Contact Lenses – Medically Necessary
                //HashtableVisionBenefitOutNetwork.Add(12, "178");     //Covered Services – Contact Lenses - Elective
                //HashtableVisionBenefitOutNetwork.Add(13, "208");     //Covered Services – Frames

                //ArrayList arrVisionBenefitOutNetwork = new ArrayList();
                //foreach (int key in HashtableVisionBenefitOutNetwork.Keys)
                //{
                //    arrVisionBenefitOutNetwork.Add(key);
                //}

                //arrVisionBenefitOutNetwork.Sort();
                //arrVisionBenefitOutNetwork.Reverse();
                #endregion

                int count = 1;
                string value = "";
                string domesticPartner = string.Empty;
                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Funding
                string FundingType = "";
                switch (OptionFieldValueiD)
                {
                    case 52403: FundingType = "Self-Insured"; break;
                    case 52401: FundingType = "Fully Insured"; break;
                    case 52400: FundingType = ""; break;
                    default: FundingType = ""; break;
                }

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());

                for (int rowindex = 0; rowindex < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;

                            # region VisionBenefitTable

                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans

                            wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                            wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                            //wkSheet.Cells[9, Column_No] = primaryIndustry;
                            if (primaryIndustry.Contains('_'))
                            {
                                wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                            }
                            else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                            wkSheet.Cells[10, Column_No] = PlanTable.Rows[rowindex]["ProductName"].ToString().Split('|')[0];
                            wkSheet.Cells[11, Column_No] = FundingType;
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                                {
                                    wkSheet.Cells[14, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    break;
                                }
                            }
                            wkSheet.Cells[15, Column_No] = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            //wkSheet.Cells[1, 1] = PlanTable.Rows[rowindex]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                            //if (colorFlag == true)
                            //{
                            //    wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[rowindex]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                            //}
                            //wkSheet.Cells[13, 1] = PlanTable.Rows[rowindex]["Name"].ToString();
                            //wkSheet.Cells[3, 2] = ddlClient.SelectedItem.Text.ToString();
                            //if (!string.IsNullOrEmpty(PlanTable.Rows[rowindex]["Renewal"].ToString()))
                            //{
                            //    if (Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString()) != DateTime.MinValue)
                            //    {
                            //        DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString());
                            //        wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                            //    }
                            //}
                            //else
                            //{
                            //    wkSheet.Cells[4, 2] = "";
                            //}
                            //wkSheet.Cells[5, 2] = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            #endregion

                            #region Eligibility Section
                            //wkSheet.Cells[29, Innetwork_Col_No] = UOM;

                            //if (EligibilityDS.Tables.Count > 0)
                            //{
                            //    if (EligibilityDS.Tables[0].Rows.Count > 0)
                            //    {
                            //        wkSheet.Cells[30, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                            //        wkSheet.Cells[31, Innetwork_Col_No] = "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();

                            //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                            //        wkSheet.Cells[32, Innetwork_Col_No] = domesticPartner;
                            //    }
                            //}
                            //wkSheet.Cells[39, Innetwork_Col_No] = PlanTable.Rows[rowindex]["PolicyNumber"].ToString();
                            //wkSheet.Cells[40, Innetwork_Col_No] = MainAddress;
                            #endregion


                            foreach (int key in arrVisionBenefitInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 1: wkSheet.Cells[16, Column_No] = value; break; // Examination Copay
                                                //case 2: wkSheet.Cells[16, Innetwork_Col_No] = value; break; // Materials Copay
                                                case 3: wkSheet.Cells[17, Column_No] = value; break; // Frequency of Examinations	Exam Benefit (in/out)
                                                case 4: wkSheet.Cells[18, Column_No] = value; break; // Frequency of Lenses 	
                                                case 5: wkSheet.Cells[19, Column_No] = value; break; // Frequency of Frames 	
                                                //case 6: wkSheet.Cells[20, Innetwork_Col_No] = value; break; // Frequency of Contacts 	
                                                //case 7: wkSheet.Cells[21, Innetwork_Col_No] = value; break; // Single Vision Lens	
                                                //case 8: wkSheet.Cells[22, Innetwork_Col_No] = value; break; // Bifocal Lens	
                                                //case 9: wkSheet.Cells[23, Innetwork_Col_No] = value; break; // Trifocal Lens	
                                                //case 10: wkSheet.Cells[24, Innetwork_Col_No] = value; break; // Lenticular 	
                                                //case 11: wkSheet.Cells[25, Innetwork_Col_No] = value; break; // Contact Lenses - Medically Necessary	
                                                //case 12: wkSheet.Cells[26, Innetwork_Col_No] = value; break; // Contact Lenses - Elective	
                                                //case 13: wkSheet.Cells[27, Innetwork_Col_No] = value; break; // Frames	
                                            }
                                        }
                                    }
                                }
                            }

                            //foreach (int key in arrVisionBenefitOutNetwork)
                            //{
                            //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            //    {
                            //        if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitOutNetwork[key].ToString())
                            //        {
                            //            if (count == 1)
                            //            {
                            //                value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                            //                switch (key)
                            //                {
                            //                    case 1: wkSheet.Cells[15, Outnetwork_Col_No] = value; break; // Examination Copay
                            //                    case 2: wkSheet.Cells[16, Outnetwork_Col_No] = value; break; // Materials Copay
                            //                    case 3: wkSheet.Cells[17, Outnetwork_Col_No] = value; break; // Frequency of Examinations	Exam Benefit (in/out)
                            //                    case 4: wkSheet.Cells[18, Outnetwork_Col_No] = value; break; // Frequency of Lenses 	
                            //                    case 5: wkSheet.Cells[19, Outnetwork_Col_No] = value; break; // Frequency of Frames 	
                            //                    case 6: wkSheet.Cells[20, Outnetwork_Col_No] = value; break; // Frequency of Contacts 	
                            //                    case 7: wkSheet.Cells[21, Outnetwork_Col_No] = value; break; // Single Vision Lens	
                            //                    case 8: wkSheet.Cells[22, Outnetwork_Col_No] = value; break; // Bifocal Lens	
                            //                    case 9: wkSheet.Cells[23, Outnetwork_Col_No] = value; break; // Trifocal Lens	
                            //                    case 10: wkSheet.Cells[24, Outnetwork_Col_No] = value; break; // Lenticular 	
                            //                    case 11: wkSheet.Cells[25, Outnetwork_Col_No] = value; break; // Contact Lenses - Medically Necessary	
                            //                    case 12: wkSheet.Cells[26, Outnetwork_Col_No] = value; break; // Contact Lenses - Elective	
                            //                    case 13: wkSheet.Cells[27, Outnetwork_Col_No] = value; break; // Frames	
                            //                }
                            //            }
                            //        }
                            //    }
                            //}
                            #endregion
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlClient">DropDownList ddlClient is used to show selected client name.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteLifeADDBenifitToTools4(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlClient, ArrayList LifeADDBenefitColumnIdList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM, DataSet AccountDS, DataSet BenefitStructureDS, int lICount, int gTCount)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int count = 1;
                string value = string.Empty;
                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                string domesticPartner = string.Empty;

                #region HashtableGroupLifeADDBenifit
                HashtableGroupLifeADDBenifit.Add(1, "186");  //Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(2, "188");  //Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(3, "187");  //Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(4, "19");   //Reduction of Benefits Schedule; Age 64 or Younger
                HashtableGroupLifeADDBenifit.Add(5, "2");    //age 65 - 69
                HashtableGroupLifeADDBenifit.Add(6, "3");    //age 70 - 74
                HashtableGroupLifeADDBenifit.Add(7, "4");    //age 75 - 79
                HashtableGroupLifeADDBenifit.Add(8, "5");    //age 80 - 84
                HashtableGroupLifeADDBenifit.Add(9, "22");   //Reduction of Benefits Schedule; Age 85 and Older
                HashtableGroupLifeADDBenifit.Add(10, "517"); //Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(11, "519"); //Spouse[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(12, "518"); //Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(13, "102"); //Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(14, "104"); //Child(ren)[Overall Maximum] 
                HashtableGroupLifeADDBenifit.Add(15, "103"); //Child(ren)[Guarantee Issue Amount]

                #endregion

                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());
                var FTEDate = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<DateTime>("groupAccountInfo_numberOfFTEsAsOf");
                string Num_Of_FTE_Date = (FTEDate.First()).ToString("d");

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());


                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans
                            wkSheet.Cells[7, Column_No] = ddlClient.SelectedItem.Text.ToString();
                            wkSheet.Cells[8, Column_No] = Num_Of_FTE + " as of " + Num_Of_FTE_Date;
                            //wkSheet.Cells[9, Column_No] = primaryIndustry;
                            if (primaryIndustry.Contains('_'))
                            {
                                wkSheet.Cells[9, Column_No] = primaryIndustry.Replace(@"_", " ");
                            }
                            else { wkSheet.Cells[9, Column_No] = primaryIndustry; }
                            wkSheet.Cells[10, Column_No] = (PlanTable.Rows[k]["ProductName"].ToString().Split('|')[0]).Replace("&amp;", "&");
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["ProductID"]) == Convert.ToInt32(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][5]))
                                {
                                    wkSheet.Cells[13, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    break;
                                }
                            }
                            string str = Convert.ToString(PlanTable.Rows[k]["SummaryName"]).Replace("&amp;", "&");
                            wkSheet.Cells[14, Column_No] = str;
                            if (str.Contains("&#39;"))
                                wkSheet.Cells[14, Column_No] = str.Replace("&#39;", "'");
                            #endregion

                            #region Eligibility section
                            //wkSheet.Cells[32, Innetwork_Col_No] = UOM;

                            //if (EligibilityDS.Tables.Count > 0)
                            //{
                            //    if (EligibilityDS.Tables[0].Rows.Count > 0)
                            //    {
                            //        wkSheet.Cells[33, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                            //        wkSheet.Cells[34, Innetwork_Col_No] = "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();

                            //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                            //        wkSheet.Cells[35, Innetwork_Col_No] = domesticPartner;
                            //    }
                            //}
                            //wkSheet.Cells[42, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                            //wkSheet.Cells[43, Innetwork_Col_No] = MainAddress;
                            #endregion

                            //if (lICount > 0)
                            //{
                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        //if (PlanTable.Rows[k]["Name"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                        //{
                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[15, Column_No] = value; break; // Benefit Amount - Employee	
                                            case 2: wkSheet.Cells[17, Column_No] = value; break; // Guarantee Issue Amount - Employee
                                            case 3: wkSheet.Cells[16, Column_No] = value; break; // Benefit Maximum - Employee	
                                        }
                                        //for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                                        //{
                                        //    if (j == 0)
                                        //    {
                                        //        wkSheet.Cells[13, Column_No] = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                        //    }
                                        //    else
                                        //        break;
                                        //}
                                        //wkSheet.Cells[14, Column_No] = Convert.ToString(PlanTable.Rows[k]["SummaryName"]).Replace("&amp;", "&");
                                        //Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                                        //}
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlClient">DropDownList ddlClient is used to show selected client name.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteVoluntaryLifeToTools3(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlClient, ArrayList VoluntaryLifeBenefitColumnIdList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 1;
                string value = string.Empty;
                string domesticPartner = string.Empty;
                Hashtable HashtableVoluntaryLife = new Hashtable();

                /*Delete Overall maximum row from all catagory--29/05/2014*/
                HashtableVoluntaryLife.Add(1, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLife.Add(2, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLife.Add(3, "187");//Employee[Guarantee Issue Amount]4
                HashtableVoluntaryLife.Add(4, "19");//Age 64 or Younger
                HashtableVoluntaryLife.Add(5, "2");//age--
                HashtableVoluntaryLife.Add(6, "3");//age
                HashtableVoluntaryLife.Add(7, "4");//age
                HashtableVoluntaryLife.Add(8, "5");//age
                HashtableVoluntaryLife.Add(9, "22");//Age 85 and Older
                HashtableVoluntaryLife.Add(10, "516");//Spouse[Benefit Amount]6
                HashtableVoluntaryLife.Add(11, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLife.Add(12, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLife.Add(13, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLife.Add(14, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLife.Add(15, "103"); //Child(ren)[Guarantee Issue Amount]

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLife.ToLower())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;

                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans
                            wkSheet.Cells[1, 1] = PlanTable.Rows[k]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                            if (colorFlag == true)
                            {
                                wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[k]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                            }
                            wkSheet.Cells[13, 1] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[3, 2] = ddlClient.SelectedItem.Text.ToString();
                            if (!string.IsNullOrEmpty(PlanTable.Rows[k]["Renewal"].ToString()))
                            {
                                if (Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()) != DateTime.MinValue)
                                {
                                    DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString());
                                    wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                                }
                            }
                            else
                            {
                                wkSheet.Cells[4, 2] = "";
                            }
                            wkSheet.Cells[5, 2] = PlanTable.Rows[k]["Carrier"].ToString();

                            #region Eligibility Section
                            wkSheet.Cells[32, Innetwork_Col_No] = UOM;

                            if (EligibilityDS.Tables.Count > 0)
                            {
                                if (EligibilityDS.Tables[0].Rows.Count > 0)
                                {
                                    wkSheet.Cells[33, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                                    wkSheet.Cells[34, Innetwork_Col_No] = "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();

                                    domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                    wkSheet.Cells[35, Innetwork_Col_No] = domesticPartner;
                                }
                            }

                            wkSheet.Cells[42, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                            wkSheet.Cells[43, Innetwork_Col_No] = MainAddress;

                            #endregion
                            #endregion

                            foreach (int key in HashtableVoluntaryLife.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLife.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLife[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[14, Innetwork_Col_No] = value; break;//Employee [Benefit Amount]
                                            case 2: wkSheet.Cells[15, Innetwork_Col_No] = value; break;//Employee[Overall Maximum]
                                            case 3: wkSheet.Cells[16, Innetwork_Col_No] = value; break;//Guarantee Issue Amount - Employee	
                                            case 4: wkSheet.Cells[18, Innetwork_Col_No] = value; break;//Age 64 or  Younger	
                                            case 5: wkSheet.Cells[19, Innetwork_Col_No] = value; break;//65-69	
                                            case 6: wkSheet.Cells[20, Innetwork_Col_No] = value; break;//70-74	
                                            case 7: wkSheet.Cells[21, Innetwork_Col_No] = value; break;//75-79	
                                            case 8: wkSheet.Cells[22, Innetwork_Col_No] = value; break;//80-84	
                                            case 9: wkSheet.Cells[23, Innetwork_Col_No] = value; break;//Age 85 and Older	
                                            case 10: wkSheet.Cells[25, Innetwork_Col_No] = value; break;//Spouse Life Benefit	
                                            case 11: wkSheet.Cells[26, Innetwork_Col_No] = value; break;//Spouse Life Benefit Maximum	
                                            case 12: wkSheet.Cells[27, Innetwork_Col_No] = value; break;//Spouse Life Benefit Guarantee Issue Amount	
                                            case 13: wkSheet.Cells[28, Innetwork_Col_No] = value; break;//Child(ren) Life Benefit
                                            case 14: wkSheet.Cells[29, Innetwork_Col_No] = value; break;//Child(ren) Life Benefit Maximum	
                                            case 15: wkSheet.Cells[30, Innetwork_Col_No] = value; break;//Child(ren) Life Benefit Guarantee Issue Amount
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life ADD Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlClient">DropDownList ddlClient is used to show selected client name.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteVoluntaryLifeADDToTools3(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlClient, ArrayList VoluntaryLifeBenefitColumnIdList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 1;
                string value = string.Empty;
                string domesticPartner = string.Empty;
                Hashtable HashtableVoluntaryLife = new Hashtable();

                /*Delete Overall maximum row from all catagory--29/05/2014*/
                HashtableVoluntaryLife.Add(1, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLife.Add(2, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLife.Add(3, "187");//Employee[Guarantee Issue Amount]4
                HashtableVoluntaryLife.Add(4, "516");//Spouse[Benefit Amount]6
                HashtableVoluntaryLife.Add(5, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLife.Add(6, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLife.Add(7, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLife.Add(8, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLife.Add(9, "103"); //Child(ren)[Guarantee Issue Amount]

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADD.ToLower())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;

                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans
                            wkSheet.Cells[1, 1] = PlanTable.Rows[k]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                            if (colorFlag == true)
                            {
                                wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[k]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                            }
                            wkSheet.Cells[13, 1] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[3, 2] = ddlClient.SelectedItem.Text.ToString();
                            if (!string.IsNullOrEmpty(PlanTable.Rows[k]["Renewal"].ToString()))
                            {
                                if (Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()) != DateTime.MinValue)
                                {
                                    DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString());
                                    wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                                }
                            }
                            else
                            {
                                wkSheet.Cells[4, 2] = "";
                            }
                            wkSheet.Cells[5, 2] = PlanTable.Rows[k]["Carrier"].ToString();

                            #region Eligibility Section
                            wkSheet.Cells[25, Innetwork_Col_No] = UOM;

                            if (EligibilityDS.Tables.Count > 0)
                            {
                                if (EligibilityDS.Tables[0].Rows.Count > 0)
                                {
                                    wkSheet.Cells[26, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                                    wkSheet.Cells[27, Innetwork_Col_No] = "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();

                                    domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                    wkSheet.Cells[28, Innetwork_Col_No] = domesticPartner;
                                }
                            }
                            wkSheet.Cells[35, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                            wkSheet.Cells[36, Innetwork_Col_No] = MainAddress;

                            #endregion



                            #endregion

                            foreach (int key in HashtableVoluntaryLife.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADD.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLife[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[14, Innetwork_Col_No] = value; break;//Employee [Benefit Amount]
                                            case 2: wkSheet.Cells[15, Innetwork_Col_No] = value; break;//Employee[Overall Maximum]
                                            case 3: wkSheet.Cells[16, Innetwork_Col_No] = value; break;//Guarantee Issue Amount - Employee	
                                            case 4: wkSheet.Cells[18, Innetwork_Col_No] = value; break;//Spouse Life Benefit	
                                            case 5: wkSheet.Cells[19, Innetwork_Col_No] = value; break;//Spouse Life Benefit Maximum	
                                            case 6: wkSheet.Cells[20, Innetwork_Col_No] = value; break;//Spouse Life Benefit Guarantee Issue Amount	
                                            case 7: wkSheet.Cells[21, Innetwork_Col_No] = value; break;//Child(ren) Life Benefit
                                            case 8: wkSheet.Cells[22, Innetwork_Col_No] = value; break;//Child(ren) Life Benefit Maximum	
                                            case 9: wkSheet.Cells[23, Innetwork_Col_No] = value; break;//Child(ren) Life Benefit Guarantee Issue Amount
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        /// <param name="ddlClient">DropDownList ddlClient is used to show selected client name.</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteFSASectionToTools3(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, DropDownList ddlClient, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                int count = 1;
                Hashtable HashtableFSA = new Hashtable();

                #region HashtableFSA
                HashtableFSA.Add(1, "451");//Premium Only Plan
                HashtableFSA.Add(2, "355");//Administration Services-Medical Spending Accounts - Minimum
                HashtableFSA.Add(3, "354");//Administration Services-Medical Spending Accounts - Maximum
                HashtableFSA.Add(4, "151");//Administration Services – Dependent Care Accounts-Minimum
                HashtableFSA.Add(5, "150");//Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(6, "489");//Administration Services – Run Out Period

                #endregion

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;

                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans
                            wkSheet.Cells[1, 1] = PlanTable.Rows[k]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                            if (colorFlag == true)
                            {
                                wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[k]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                            }
                            wkSheet.Cells[13, 1] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[3, 2] = ddlClient.SelectedItem.Text.ToString();
                            if (!string.IsNullOrEmpty(PlanTable.Rows[k]["Renewal"].ToString()))
                            {
                                if (Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()) != DateTime.MinValue)
                                {
                                    DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString());
                                    wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                                }
                            }
                            else
                            {
                                wkSheet.Cells[4, 2] = "";
                            }
                            wkSheet.Cells[5, 2] = PlanTable.Rows[k]["Carrier"].ToString();

                            wkSheet.Cells[28, Innetwork_Col_No] = UOM;

                            if (EligibilityDS.Tables.Count > 0)
                            {
                                if (EligibilityDS.Tables[0].Rows.Count > 0)
                                {
                                    wkSheet.Cells[29, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                                }
                            }

                            wkSheet.Cells[33, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                            wkSheet.Cells[34, Innetwork_Col_No] = MainAddress;
                            #endregion

                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[14, Innetwork_Col_No] = value; break;//Premium Only	
                                            case 2: wkSheet.Cells[15, Innetwork_Col_No] = value; break;//Medical Spending Account Minimum	Exam Copay
                                            case 3: wkSheet.Cells[16, Innetwork_Col_No] = value; break;//Medical Spending Accounts - Maximum	Exam Benefit (in/out)
                                            case 4: wkSheet.Cells[17, Innetwork_Col_No] = value; break;//Dependent Care Account Minimum	
                                            case 5: wkSheet.Cells[18, Innetwork_Col_No] = value; break;//Dependent Care Account Maximum	
                                            case 6: wkSheet.Cells[19, Innetwork_Col_No] = value; break;//Run Out Period	
                                        }

                                        #endregion
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Group Term Life AD&D Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlClient">DropDownList ddlClient is used to show selected client name.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteGroupTermLifeToTools3(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlClient, ArrayList LifeADDBenefitColumnIdList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                string domesticPartner = string.Empty;

                #region HashtableGroupLifeADDBenifit
                HashtableGroupLifeADDBenifit.Add(1, "186");  //Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(2, "188");  //Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(3, "187");  //Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(4, "19");   //Reduction of Benefits Schedule; Age 64 or Younger
                HashtableGroupLifeADDBenifit.Add(5, "2");    //age
                HashtableGroupLifeADDBenifit.Add(6, "3");    //age
                HashtableGroupLifeADDBenifit.Add(7, "4");    //age
                HashtableGroupLifeADDBenifit.Add(8, "5");    //age
                HashtableGroupLifeADDBenifit.Add(9, "22");   //Reduction of Benefits Schedule; Age 85 and Older
                HashtableGroupLifeADDBenifit.Add(10, "517"); //Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(11, "519"); //Spouse[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(12, "518"); //Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(13, "102"); //Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(14, "104"); //Child(ren)[Overall Maximum] 
                HashtableGroupLifeADDBenifit.Add(15, "103"); //Child(ren)[Guarantee Issue Amount]

                #endregion

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.GroupTermLifePlanType.ToLower())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans
                            wkSheet.Cells[1, 1] = PlanTable.Rows[k]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                            if (colorFlag == true)
                            {
                                wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[k]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                            }
                            wkSheet.Cells[13, 1] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[3, 2] = ddlClient.SelectedItem.Text.ToString();
                            if (!string.IsNullOrEmpty(PlanTable.Rows[k]["Renewal"].ToString()))
                            {
                                if (Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()) != DateTime.MinValue)
                                {
                                    DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString());
                                    wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                                }
                            }
                            else
                            {
                                wkSheet.Cells[4, 2] = "";
                            }
                            wkSheet.Cells[5, 2] = PlanTable.Rows[k]["Carrier"].ToString();

                            wkSheet.Cells[32, Innetwork_Col_No] = UOM;

                            if (EligibilityDS.Tables.Count > 0)
                            {
                                if (EligibilityDS.Tables[0].Rows.Count > 0)
                                {
                                    wkSheet.Cells[33, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                                    wkSheet.Cells[34, Innetwork_Col_No] = "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();

                                    domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                    wkSheet.Cells[35, Innetwork_Col_No] = domesticPartner;
                                }
                            }

                            wkSheet.Cells[42, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                            wkSheet.Cells[43, Innetwork_Col_No] = MainAddress;
                            #endregion

                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.GroupTermLifePlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[14, Innetwork_Col_No] = value; break; // Benefit Amount - Employee	
                                            case 2: wkSheet.Cells[15, Innetwork_Col_No] = value; break; // Benefit Maximum - Employee	
                                            case 3: wkSheet.Cells[16, Innetwork_Col_No] = value; break; // Guarantee Issue Amount - Employee	
                                            case 4: wkSheet.Cells[18, Innetwork_Col_No] = value; break; // Age 64 or  Younger	
                                            case 5: wkSheet.Cells[19, Innetwork_Col_No] = value; break; // 65-69	
                                            case 6: wkSheet.Cells[20, Innetwork_Col_No] = value; break; // 70-74	
                                            case 7: wkSheet.Cells[21, Innetwork_Col_No] = value; break; // 75-79	
                                            case 8: wkSheet.Cells[22, Innetwork_Col_No] = value; break; // 80-84	
                                            case 9: wkSheet.Cells[23, Innetwork_Col_No] = value; break; // Age 85 and Older	
                                            case 10: wkSheet.Cells[25, Innetwork_Col_No] = value; break; // Spouse Life Benefit	
                                            case 11: wkSheet.Cells[26, Innetwork_Col_No] = value; break; // Spouse Life Benefit Maximum	
                                            case 12: wkSheet.Cells[27, Innetwork_Col_No] = value; break; // Spouse Life Benefit Guarantee Issue Amount	
                                            case 13: wkSheet.Cells[28, Innetwork_Col_No] = value; break; // Child(ren) Life Benefit
                                            case 14: wkSheet.Cells[29, Innetwork_Col_No] = value; break; // Child(ren) Life Benefit Maximum	
                                            case 15: wkSheet.Cells[30, Innetwork_Col_No] = value; break; // Child(ren) Life Benefit Guarantee Issue Amount
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write AD&D Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlClient">DropDownList ddlClient is used to show selected client name.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteADDToTools3(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlClient, ArrayList LifeADDBenefitColumnIdList, string SummaryId, string ProductTypeDescription, DataSet EligibilityDS, string MainAddress, string UOM)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableADDBenifit = new Hashtable();
                string domesticPartner = string.Empty;

                #region HashtableADDBenifit
                HashtableADDBenifit.Add(1, "186");  //Employee [Benefit Amount]
                HashtableADDBenifit.Add(2, "19");   //Reduction of Benefits Schedule; Age 64 or Younger
                HashtableADDBenifit.Add(3, "2");    //age 65 - 69
                HashtableADDBenifit.Add(4, "3");    //age 70 - 74
                HashtableADDBenifit.Add(5, "4");    //age 75 - 79
                HashtableADDBenifit.Add(6, "5");    //age 80 - 84
                HashtableADDBenifit.Add(7, "22");   //Reduction of Benefits Schedule; Age 85 and Older

                #endregion

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.ADD.ToLower())
                    {
                        if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                        {
                            Excel.Worksheet wkSheet = null;
                            if (count == 1)
                            {
                                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
                            }

                            #region Common Part In All Plans
                            wkSheet.Cells[1, 1] = PlanTable.Rows[k]["Name"].ToString() + " CONTRACT/BOOKLET REVIEW CHECKLIST";
                            if (colorFlag == true)
                            {
                                wkSheet.Cells[1, 1].Characters[1, PlanTable.Rows[k]["Name"].ToString().Length].Font.Color = Color.FromArgb(0, 176, 80);
                            }
                            wkSheet.Cells[13, 1] = PlanTable.Rows[k]["Name"].ToString();
                            wkSheet.Cells[3, 2] = ddlClient.SelectedItem.Text.ToString();
                            if (!string.IsNullOrEmpty(PlanTable.Rows[k]["Renewal"].ToString()))
                            {
                                if (Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()) != DateTime.MinValue)
                                {
                                    DateTime renewdate = Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString());
                                    wkSheet.Cells[4, 2] = renewdate.ToString("MM/dd/yyyy");
                                }
                            }
                            else
                            {
                                wkSheet.Cells[4, 2] = "";
                            }
                            wkSheet.Cells[5, 2] = PlanTable.Rows[k]["Carrier"].ToString();

                            wkSheet.Cells[23, Innetwork_Col_No] = UOM;

                            if (EligibilityDS.Tables.Count > 0)
                            {
                                if (EligibilityDS.Tables[0].Rows.Count > 0)
                                {
                                    wkSheet.Cells[24, Innetwork_Col_No] = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim();
                                    //wkSheet.Cells[34, Innetwork_Col_No]= "Unmarried children up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();

                                    //domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                    //wkSheet.Cells[35, Innetwork_Col_No]= domesticPartner;
                                }
                            }

                            wkSheet.Cells[31, Innetwork_Col_No] = PlanTable.Rows[k]["PolicyNumber"].ToString();
                            wkSheet.Cells[32, Innetwork_Col_No] = MainAddress;
                            #endregion

                            foreach (int key in HashtableADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.ADD.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (key)
                                        {
                                            case 1: wkSheet.Cells[14, Innetwork_Col_No] = value; break; // Benefit Amount - Employee	
                                            case 2: wkSheet.Cells[16, Innetwork_Col_No] = value; break; // Age 64 or  Younger	
                                            case 3: wkSheet.Cells[17, Innetwork_Col_No] = value; break; // 65-69	
                                            case 4: wkSheet.Cells[18, Innetwork_Col_No] = value; break; // 70-74	
                                            case 5: wkSheet.Cells[19, Innetwork_Col_No] = value; break; // 75-79	
                                            case 6: wkSheet.Cells[20, Innetwork_Col_No] = value; break; // 80-84	
                                            case 7: wkSheet.Cells[21, Innetwork_Col_No] = value; break; // Age 85 and Older	
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void SearchText()
        {
            //string File_name = "D:\\test.xlsx";
            //Microsoft.Office.Interop.Excel.Application oXL = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook oWB;
            //Microsoft.Office.Interop.Excel.Worksheet oSheet;
            try
            {
                //object missing = System.Reflection.Missing.Value;
                //oWB = oXL.Workbooks.Open(File_name, missing, missing, missing, missing,
                //    missing, missing, missing, missing, missing, missing,
                //    missing, missing, missing, missing);
                //oSheet = (Microsoft.Office.Interop.Excel.Worksheet)oWB.Worksheets[1];
                //Microsoft.Office.Interop.Excel.Range oRng = GetSpecifiedRange("test", oSheet);
                //if (oRng != null)
                //{
                //    MessageBox.Show("Text found, position is Row:" + oRng.Row + " and column:" + oRng.Column);
                //}
                //else
                //{
                //    MessageBox.Show("Text is not found");
                //}
                //oWB.Close(false, missing, missing);

                //oSheet = null;
                //oWB = null;
                //oXL.Quit();
            }
            catch (Exception ex)
            {

            }
        }


        private Microsoft.Office.Interop.Excel.Range GetSpecifiedRange(string matchStr, Microsoft.Office.Interop.Excel.Worksheet objWs, int startRange, int EndRange)
        {
            object missing = System.Reflection.Missing.Value;
            Microsoft.Office.Interop.Excel.Range currentFind = null;
            Microsoft.Office.Interop.Excel.Range firstFind = null;
            currentFind = objWs.get_Range("A" + startRange, "AM" + EndRange).Find(matchStr, missing,
                           Microsoft.Office.Interop.Excel.XlFindLookIn.xlValues,
                           Microsoft.Office.Interop.Excel.XlLookAt.xlWhole,
                           Microsoft.Office.Interop.Excel.XlSearchOrder.xlByRows,
                           Microsoft.Office.Interop.Excel.XlSearchDirection.xlNext, false, missing, missing);
            return currentFind;
        }
    }
}