﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using System.Drawing;
using StringTrimmer;
using Microsoft.Office.Core;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using Microsoft.Office.Interop.Word;

namespace BenefitPointSummaryPortal.BAL.Finance
{
    public class ComboInvoiceCommissionSplit
    {
          BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        #region common functions
        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_Field_Header(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Client Name"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                continue;
                            }
                        }
                    }
                }
            }

        }

        public void AddDropDownToComboReport(Word.Document oWordDoc, int rowValue, int tableNumber)
        {
            Word.Range range2 = oWordDoc.Tables[tableNumber].Cell(rowValue, 3).Range;
            // oWordDoc.Tables[tableNumber].Cell(rowValue, 2).Range.Font.Size = 9;
            //  oWordDoc.Tables[tableNumber].Cell(rowValue, 2).Range.Font.Name = "calibri";
            range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
            foreach (Word.ContentControl dropdown in range2.ContentControls)
            {
                dropdown.DropdownListEntries.Clear();
                dropdown.DropdownListEntries.Add("Select", "Select", 1);
                dropdown.DropdownListEntries.Add("Email", "first", 2);
                dropdown.DropdownListEntries.Add("Mail", "second", 3);

            }
        }
        #endregion

        public void WriteCommissionSplitInformationToComboReport(Word.Document oWordDoc, Word.Application oWordApp, DataSet AccountDS, DataSet AccountTeamMemberDS, string CommissionSplitDate, int Rows)
        {
            string SalesLead_FirstName = string.Empty;
            string SalesLead_LastName = string.Empty;
            #region For Address and Phone Number - Team Members
            if (AccountDS != null)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }
                    }
                }
            }

            if (Rows > 0)
            {
                for (int i = 1; i < Rows; i++)
                {
                    oWordDoc.Tables[8].Rows.Add();
                }
                oWordDoc.Tables[12].Rows[1].Range.Copy();
                for (int k = 1; k < Rows; k++)
                {
                    oWordDoc.Tables[12].Rows[1].Range.Paste();
                }
            }

            #region MergeField

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Primary Sales Lead"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                        {
                            oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }
                    if (fieldName.Contains("CommissionSpliDate"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                        {
                            oWordApp.Selection.TypeText(CommissionSplitDate);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                }
            }
            #endregion

            #endregion

        }

        public void WriteCommissionSplitPlanInformationToComboReport(Word.Document oWordDoc, Word.Application oWordApp, DataTable CommissionSplitPlanInfo)
        {
            int RowNum = 2;
            Color rowsColor_4 = Color.FromArgb(242, 242, 242);
            int rgb_Rows4 = ColorTranslator.ToOle(rowsColor_4);
            Word.WdColor wdColor_rows4 = (Word.WdColor)rgb_Rows4;
            for (int k = 1; k < CommissionSplitPlanInfo.Rows.Count; k++)
            {
                oWordDoc.Tables[10].Rows.Add();
            }

           
            foreach (DataRow dr in CommissionSplitPlanInfo.Rows)
            {
                string PlanType = Convert.ToString(dr["Name"]).ToString();
                string CarrierName = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                string PolicyNumber = Convert.ToString(dr["PolicyNumber"]);
                oWordDoc.Tables[10].Cell(RowNum, 1).Select();
                oWordDoc.Tables[10].Cell(RowNum, 1).Range.Text = PlanType;
                oWordDoc.Tables[10].Cell(RowNum, 2).Range.Text = CarrierName;
                oWordDoc.Tables[10].Cell(RowNum, 3).Range.Text = PolicyNumber;

                if (RowNum % 2 == 0)
                    oWordDoc.Tables[10].Rows[RowNum].Shading.BackgroundPatternColor = wdColor_rows4;
                RowNum++;

            }
        }

        public void WriteContactInformationToComboTemplate(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact)
        {
            #region Header Information
            Write_Field_Header(oWordDoc, oWordApp, ddlClient);
            #endregion
            #region Main Address Row
            string MainAddress = "";
            MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
            #endregion
            #region Write Table of Account Contacts
            string name = string.Empty;
            string email = string.Empty;
            int clmCnt = 1;
            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    oWordDoc.Tables[1].Rows[2].Range.Copy();
                    for (int row = 1; row < arrAcctContact.Count; row++)
                    {
                        oWordDoc.Tables[1].Rows[oWordDoc.Tables[1].Rows.Count].Range.Paste();
                    }

                    for (int row = 0; row < arrAcctContact.Count; row++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[row].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].Name != null)
                                {
                                    oWordDoc.Tables[1].Cell(row + 2, 1).Range.Fields[1].Select();
                                    oWordApp.Selection.TypeText(ContactList[i].Name);
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(row + 2, 1).Range.Fields[1].Delete();
                                }

                                if (ContactList[i].Email != null)
                                {
                                    oWordDoc.Tables[1].Cell(row + 2, 2).Range.Fields[1].Select();
                                    oWordApp.Selection.TypeText(ContactList[i].Email);
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(row + 2, 2).Range.Fields[1].Delete();
                                }

                                clmCnt++;
                            }
                        }
                    }
                }
                else
                {
                    oWordDoc.Tables[1].Cell(2, 1).Range.Fields[1].Delete();
                    oWordDoc.Tables[1].Cell(2, 2).Range.Fields[1].Delete();
                }
            }

            #endregion
            #region MergeField
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Sysdate"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                        continue;
                    }

                    if (fieldName.Contains("Main Address"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(MainAddress))
                        {
                            oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }
                }
            }
            #endregion
        }

        public void WriteOfficeAndServiceTeamInformationToComboReport(Word.Document oWordDoc, Word.Application oWordApp, DataSet AccountDS, DataSet AccountTeamMemberDS, string Office_Regions)
        {
            #region For Address and Phone Number - Team Members
            string ServiceLead_FirstName = string.Empty;
            string ServiceLead_LastName = string.Empty;
            string SalesLead_FirstName = string.Empty;
            string SalesLead_LastName = string.Empty;

            if (AccountDS != null)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }
                    }
                }

            }
            #endregion
            #region MergeField
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Service Team"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(Office_Regions.Trim());
                        continue;
                    }


                    if (fieldName.Contains("Primary Service Lead Name"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                        {
                            oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("Primary Sales Lead Name"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                        {
                            oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }
                }
            }
            #endregion
        }

        public void Write_Invoiceinfo_PolicyInfoToComboReport(Word.Document oWordDoc, Word.Application oWordApp, List<Carrier> carrierList, DataTable PlanInfoTable, DataSet ProductDS)
        {
            #region Plan Writing
            string planType = string.Empty;
            string policyNo = String.Empty;
            string renewalDate = string.Empty;
            string effectiveDate = String.Empty;
            string carrier = String.Empty;
            string commissionfee = String.Empty;
            string frequency = String.Empty;
            Int32 billingCarrierID = 0;
            string billingCarrierName = String.Empty;
            int clmCnt = 1;
            foreach (DataRow dr in PlanInfoTable.Rows)
            {
                planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                policyNo = Convert.ToString(dr["PolicyNumber"]);
                carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                renewalDate = Convert.ToString(dr["Renewal"]);
                renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                effectiveDate = Convert.ToString(dr["Effective"]);
                effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
            }

            for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
            {
                commissionfee = "$" + Convert.ToString(ProductDS.Tables[1].Rows[k][38]);
                frequency = Convert.ToString(ProductDS.Tables[1].Rows[k][39]).Replace("_", " ");
                billingCarrierID = Convert.ToInt32(ProductDS.Tables[1].Rows[k]["billingCarrierID"]);
                billingCarrierName = Convert.ToString((from cc in carrierList
                                                       where cc.CarrierId == billingCarrierID
                                                       select cc.CarrierName).FirstOrDefault());
            }

            #endregion
            #region MergeField
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();


                    if (fieldName.Contains("Renewal Date"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(renewalDate))
                        {
                            oWordApp.Selection.TypeText(renewalDate);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("Effective Date"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(effectiveDate))
                        {
                            oWordApp.Selection.TypeText(effectiveDate);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("PlanType"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(Convert.ToString(planType)))
                        {
                            oWordApp.Selection.TypeText(Convert.ToString(planType));
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("PolicyNumber"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(Convert.ToString(policyNo)))
                        {
                            oWordApp.Selection.TypeText(Convert.ToString(policyNo));
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("CarrierName"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(carrier))
                        {
                            oWordApp.Selection.TypeText(carrier);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("BillingName"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(billingCarrierName))
                        {
                            oWordApp.Selection.TypeText(billingCarrierName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }


                }
            }
            #endregion
        }

        public void Write_InvoiceDetails_ServiceFeeToComboReport(Word.Document oWordDoc, Word.Application oWordApp, DataSet ProductDS)
        {
            #region Invoice information fro service fee
            int clmCnt = 1;
            string EstimationCommissionServiceFee = string.Empty;
            string CommsionPeriodType = string.Empty;
            if (ProductDS != null)
            {
                if (ProductDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < ProductDS.Tables[1].Rows.Count; j++)
                    {

                        if (clmCnt > 1)
                        {
                            oWordDoc.Tables[4].Rows.Add();
                        }

                        /// is any condition need to check here 
                        /// 

                        EstimationCommissionServiceFee = Convert.ToString(ProductDS.Tables[1].Rows[j]["additionalProductInfo_estimatedCommission "]);
                       // oWordDoc.Tables[4].Cell(j + 1, 2).Range.Text = EstimationCommissionServiceFee; -- Commented by Vaibhav
                        oWordDoc.Tables[4].Cell(j + 1, 2).Range.Fields[1].Select();
                        if (EstimationCommissionServiceFee != null && EstimationCommissionServiceFee.Trim() != string.Empty)
                            oWordApp.Selection.TypeText("$" + EstimationCommissionServiceFee);
                        else
                            oWordDoc.Tables[4].Cell(j + 1, 2).Range.Fields[1].Delete();

                        CommsionPeriodType = Convert.ToString(ProductDS.Tables[1].Rows[j]["additionalProductInfo_commissionPeriodType"]).Replace("_", " ");
                       // oWordDoc.Tables[4].Cell(j + 1, 3).Range.Text = CommsionPeriodType; -- Commented by Vaibhav
                        oWordDoc.Tables[4].Cell(j + 1, 3).Range.Fields[1].Select();
                        if (CommsionPeriodType != null && CommsionPeriodType.Trim() != string.Empty)
                            oWordApp.Selection.TypeText(CommsionPeriodType);
                        else
                            oWordDoc.Tables[4].Cell(j + 1, 3).Range.Fields[1].Delete();

                        clmCnt++;


                    }
                }

            }

            #endregion
        }

        public void Write_InvoiceDetails_BillClientandRemit_CommToComboReport(Word.Document oWordDoc, Word.Application oWordApp, DataSet ProductDS)
        {
            #region Invoice information fro service fee
            int clmCnt = 1;
            string PremiumPaymentFrequencyBill = String.Empty;
            if (ProductDS != null)
            {
                if (ProductDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < ProductDS.Tables[1].Rows.Count; j++)
                    {
                        if (clmCnt > 1)
                        {
                            oWordDoc.Tables[5].Rows.Add();
                        }

                        /// is any condition need to check here 
                        /// 

                        PremiumPaymentFrequencyBill = Convert.ToString(ProductDS.Tables[1].Rows[j]["premiumPaymentFrequency"]).Replace("_", " ");
                        //oWordDoc.Tables[5].Cell(j + 1, 3).Range.Text = PremiumPaymentFrequencyBill; -- Commented by Vaibhav
                        oWordDoc.Tables[5].Cell(j + 1, 3).Range.Fields[1].Select();
                        if (PremiumPaymentFrequencyBill != null && PremiumPaymentFrequencyBill.Trim() != string.Empty)
                            oWordApp.Selection.TypeText(PremiumPaymentFrequencyBill);
                        else
                            oWordDoc.Tables[5].Cell(j + 1, 3).Range.Fields[1].Delete();

                        clmCnt++;

                    }
                }

            }

            #endregion
        }

        public void Write_InvoiceDetails_ThirdPartyServiceToComboReport(Word.Document oWordDoc, Word.Application oWordApp, DataSet ProductDS)
        {
            #region Invoice information fro service fee
            int clmCnt = 1;
            string PremiumPaymentFrequencyThirdParty = String.Empty;
            if (ProductDS != null)
            {
                if (ProductDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < ProductDS.Tables[1].Rows.Count; j++)
                    {
                        if (clmCnt > 1)
                        {
                            oWordDoc.Tables[6].Rows.Add();
                        }

                        /// is any condition need to check here 
                        /// 

                        PremiumPaymentFrequencyThirdParty = Convert.ToString(ProductDS.Tables[1].Rows[j]["PremiumPaymentFrequency"]).Replace("_", " ");;
                      //  oWordDoc.Tables[6].Cell(j + 1, 3).Range.Text = PremiumPaymentFrequencyThirdParty;Commented by Vaibhavs
                        oWordDoc.Tables[6].Cell(j + 1, 3).Range.Fields[1].Select();
                        if (PremiumPaymentFrequencyThirdParty != null && PremiumPaymentFrequencyThirdParty.Trim() != string.Empty)
                            oWordApp.Selection.TypeText(PremiumPaymentFrequencyThirdParty);
                        else
                            oWordDoc.Tables[6].Cell(j + 1, 3).Range.Fields[1].Delete();

                        clmCnt++;
                    }
                }

            }

            #endregion
        }

        public void DeleteBookmarks(Word.Document oWordDoc, Word.Application oWordApp, string name)
        {
            int cnt = 1;
            bool IsFound = false;
            //bkmSplitPlans
            foreach (Bookmark item in oWordApp.ActiveDocument.Bookmarks)
            {
                if (item.Name == name)
                {
                    item.Range.Delete();
                    continue;
                }

            }

        }

    }
}