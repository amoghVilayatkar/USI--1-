﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class Rate
    {
        #region Variable
        private int _rateId;
        private string _description;
         #endregion
        #region Properties
        /// <summary>
        /// Get and Set RateId
        /// </summary>
        
        public int RateId
        {
            get
            {
                return _rateId;
            }
            set
            {
                _rateId = value;
            }
        }
        /// <summary>
        /// Get and Set RateDescription
        /// </summary>
        public string RateDescription
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        #endregion
    }
}