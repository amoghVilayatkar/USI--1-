﻿using System;
using Microsoft.Reporting.WebForms;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Reflection;


namespace BenefitPointSummaryPortal.View
{
    public partial class BRC_MultiYearUtilization_SSRS : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();

        CommonFunctionsBS commnObj = new CommonFunctionsBS();
        protected void Page_Load(object sender, EventArgs e)
        {
            ////string Activity = "BRC Multi-Year Utilization";
            ////string Activity_Group = "BRC";
            //DisableUnwantedExportFormat(rptViewer, "PDF");
            div_footer.Controls.Add(commnObj.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                TitleSpan.InnerText = "BRC Multi-Year Utilization";
                rptViewer.ProcessingMode = ProcessingMode.Remote;
                ServerReport serverReport = rptViewer.ServerReport;
                rptViewer.ProcessingMode = ProcessingMode.Remote;
                serverReport.ReportServerUrl = new Uri("http://reports.qa.usii.com/reportserver");
                //serverReport.ReportServerUrl = new Uri("http://reports.usii.com/Reportserver"); // Production Version
                serverReport.ReportPath = "/CRM BRC/BRC_Year_Over_Year_Utilization";
                //rptViewer.ServerReport.GetParameters();
                //rptViewer.ShowParameterPrompts = true;
                //rptViewer.ServerReport.SetParameters(Param);
                string Activity = string.Empty;
                string Activity_Group = string.Empty;
                Activity = "Multi-Year Utilization";
                Activity_Group = "Reports";
                string AdditionalCrtieriaOption_1 = string.Empty; // string.Empty;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                rptViewer.ServerReport.Refresh();
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, "", "");
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, "", "", Convert.ToString(Session["DeliverableCategory"]), "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
            }
        }
    }
}