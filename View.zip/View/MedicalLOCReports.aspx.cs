﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using BenefitPointSummaryPortal.BAL.AnalysisTemplate;

namespace BenefitPointSummaryPortal.View
{
    public partial class MedicalLOCReports : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        string SessionId = "";
        DataSet AccountDS = new DataSet();
        DataSet AccountTeamMemberDS = new DataSet();
        WriteMedicalLOCTemplates wr = new WriteMedicalLOCTemplates();
        IList<string> SfSheet = new List<string>() { "Medical SL Detail", "Medical Factors", "Medical Admin Detail", "Medical Benefit Alternatives", "Medical Notes", "TPA Notes" };

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        private static string Activity = "";
        private static string Activity_Group = "";

        protected void Page_Load(object sender, EventArgs e)
        {


            try
            {
                if (Session["Summary"] == "MedicalLOCTemplates")
                {
                    Page.MaintainScrollPositionOnPostBack = true;
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                    div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                    if (!IsPostBack)
                    {
                        mvMedicalLOC.ActiveViewIndex = 0;
                        SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                        SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                        Session["SessionId"] = SessionId;
                        objCommFun.GetUserDetails();
                        ddlcontents.SelectedValue = "ClientDetails"; ;
                        ddlcontents_SelectedIndexChanged(null, null);
                        Activity_Group = "Analytics";
                        Activity = TitleSpan.InnerText;
                        Session["DeliverableCategory"] = "Analytics";
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlcontents_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlOrientation.SelectedIndex = 0;
            txtAnalysisRenewalDate.Text = "";
            rdlAncillaryAnalysisPlanStatus.SelectedIndex = 0;
            switch (ddlcontents.SelectedValue)
            {
                case "ClientDetails":
                    txtLetterDecription.Text = "For existing USI clients. Provides medical line of coverage benefit and rate illustrations populated with client data. Current and renewal benefits are populated with data as stated in BenefitPoint. Not all benefits will populate; empty cells are benefits not housed in BenefitPoint or not entered for that client. Rates, enrollment, and some benefits must be manually entered. Contribution and benefit alternative illustrations are included. Templates are fully editable in Excel.";
                    txtLetterDecription.Visible = true;
                    tblClientDetails.Style.Add("display", "");
                    spnClientDescription.InnerText = "Indicate which BenefitPoint client you would like to create an Analysis for.";
                    tblAnalysisDetails.Style.Add("display", "");
                    trRenewalDate.Style.Add("display", "");
                    trPlanStaus.Style.Add("display", "");
                    gvMedicalAnalysisPlans.Columns[1].Visible = true;
                    gvMedicalAnalysisPlans.Columns[2].Visible = true;
                    gvMedicalAnalysisPlans.Columns[4].Visible = true;
                    break;
                case "Unpopulated":
                    txtLetterDecription.Text = "For clients not yet in BenefitPoint. Provides medical line of coverage benefit and rate illustrations with contributions and benefit alternatives. All entries for benefits, rates, and enrollment must be manually entered. Templates are fully editable in Excel.";
                    txtLetterDecription.Visible = true;
                    tblClientDetails.Style.Add("display", "none");
                    trPlanStaus.Style.Add("display", "none");
                    gvMedicalAnalysisPlans.Columns[1].Visible = false;
                    gvMedicalAnalysisPlans.Columns[2].Visible = false;
                    gvMedicalAnalysisPlans.Columns[4].Visible = false;
                    tblAnalysisDetails.Style.Add("display", "");
                    trRenewalDate.Style.Add("display", "none");
                    spnClientDescription.InnerText = "";
                    break;
                default:
                    gvMedicalAnalysisPlans.Columns[1].Visible = true;
                    gvMedicalAnalysisPlans.Columns[2].Visible = true;
                    gvMedicalAnalysisPlans.Columns[4].Visible = true;
                    txtLetterDecription.Text = "";
                    txtLetterDecription.Visible = false;
                    tblClientDetails.Style.Add("display", "none");
                    tblAnalysisDetails.Style.Add("display", "none");
                    trRenewalDate.Style.Add("display", "none");
                    trPlanStaus.Style.Add("display", "none");
                    spnClientDescription.InnerText = "";
                    break;

            }
            txtsearch.Text = "";
            rdlClient.SelectedIndex = 0;
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlClient_SelectedIndexChanged(null, null);
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["PlanList"] = new List<Plan>();
            Session["ProductDS"] = null;
            BindAnalysisGridView();
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ddlcontents.SelectedValue = "0";
            ResetForm();
        }
        protected void gvMedicalAnalysisPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            DropDownList ddlTemplateType = e.Row.FindControl("ddlTemplateType") as DropDownList;
            if (ddlTemplateType != null)
            {
                HiddenField hdnEnableRow = e.Row.FindControl("hdnEnableRow") as HiddenField;

                ddlTemplateType.DataSource = wr.TemplateTypeList;
                ddlTemplateType.DataBind();
                ddlTemplateType.Items.Insert(0, new ListItem("Select", "Select"));

                DropDownList ddlPlan1 = e.Row.FindControl("ddlPlan1") as DropDownList;
                DropDownList ddlPlan2 = e.Row.FindControl("ddlPlan2") as DropDownList;
                DropDownList ddlPlan3 = e.Row.FindControl("ddlPlan3") as DropDownList;
                DropDownList ddlHRAHSA = e.Row.FindControl("ddlHRAHSA") as DropDownList;

                ddlPlan1.Items.Insert(0, new ListItem("Select", "Select"));
                ddlPlan2.Items.Insert(0, new ListItem("Select", "Select"));
                ddlPlan3.Items.Insert(0, new ListItem("Select", "Select"));
                ddlHRAHSA.Items.Insert(0, new ListItem("Select", "Select"));

                DropDownList ddlBenefitSummary1 = e.Row.FindControl("ddlBenefitSummary1") as DropDownList;
                DropDownList ddlBenefitSummary2 = e.Row.FindControl("ddlBenefitSummary2") as DropDownList;
                DropDownList ddlBenefitSummary3 = e.Row.FindControl("ddlBenefitSummary3") as DropDownList;
                DropDownList ddlBenefitSummaryHRAHSA = e.Row.FindControl("ddlBenefitSummaryHRAHSA") as DropDownList;

                ddlBenefitSummary1.Items.Insert(0, new ListItem("Select", "Select"));
                ddlBenefitSummary2.Items.Insert(0, new ListItem("Select", "Select"));
                ddlBenefitSummary3.Items.Insert(0, new ListItem("Select", "Select"));
                ddlBenefitSummaryHRAHSA.Items.Insert(0, new ListItem("Select", "Select"));

                DropDownList ddlTierFactor = e.Row.FindControl("ddlTierFactor") as DropDownList;
                ddlTierFactor.Items.Insert(0, new ListItem("Select", "Select"));

                DropDownList ddlFEI = e.Row.FindControl("ddlFEI") as DropDownList;
                ddlFEI.SelectedValue = "Select";

                if (e.Row.RowIndex > 0)
                {
                    ddlPlan1.Enabled = false;
                    ddlPlan2.Enabled = false;
                    ddlPlan3.Enabled = false;
                    ddlBenefitSummary1.Enabled = false;
                    ddlBenefitSummary2.Enabled = false;
                    ddlBenefitSummary3.Enabled = false;
                    ddlTierFactor.Enabled = false;
                    ddlFEI.Enabled = false;
                    hdnEnableRow.Value = false.ToString();
                }
            }
        }
        protected void rdlAncillaryAnalysisPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvMedicalAnalysisPlans.DataSource = null;
            gvMedicalAnalysisPlans.DataBind();
            BindAnalysisGridView();
        }
        protected void gvMedicalAnalysisPlans_TemplateTypeChanged(object sender, EventArgs e)
        {
            DropDownList ddlSender = sender as DropDownList;
            gvMedicalAnalysisPlans.HeaderRow.Cells[3].Text = "Tier/Factor";

            if (ddlSender != null)
            {
                string ddlSenderClientID = ddlSender.ClientID;
                string[] IdParts = ddlSenderClientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
                int PlanTier = wr.GetPlanTier(ddlSender.SelectedValue);

                DropDownList ddlFEI = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlFEI") as DropDownList;
                ddlFEI.SelectedValue = "Select";

                DropDownList ddlTierFactor = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlTierFactor") as DropDownList;
                List<string> lstTierFactor = GetTierFactor(ddlSender.SelectedValue);
                ddlTierFactor.Items.Clear();
                ddlTierFactor.DataSource = lstTierFactor;
                ddlTierFactor.DataBind();
                ddlTierFactor.Items.Insert(0, new ListItem("Select", "Select"));
                ddlTierFactor.Enabled = false;



                if (ddlSender.SelectedValue.ToLower().StartsWith("sf"))
                {
                    gvMedicalAnalysisPlans.Columns[4].Visible = true;
                    gvMedicalAnalysisPlans.HeaderRow.Cells[3].Text = "Self-Funded Rates & Factors";
                }
                else if (ddlSender.SelectedValue.ToLower().StartsWith("fi"))
                {
                    gvMedicalAnalysisPlans.Columns[4].Visible = false;
                    gvMedicalAnalysisPlans.HeaderRow.Cells[3].Text = "Fully Insured Premium Rate Tier";
                }
                else
                {
                    gvMedicalAnalysisPlans.Columns[4].Visible = true;
                }
                if (ddlcontents.SelectedValue == "Unpopulated")
                {
                    gvMedicalAnalysisPlans.Columns[4].Visible = false;
                    ddlTierFactor.Enabled = true;
                    ddlFEI.Enabled = true;
                    return;
                }

                HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnPlanTier") as HiddenField;
                hdnPlanTier.Value = PlanTier.ToString();

                HiddenField hdnBenefitSummary1 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummary1") as HiddenField;
                HiddenField hdnBenefitSummary2 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummary2") as HiddenField;
                HiddenField hdnBenefitSummary3 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummary3") as HiddenField;

                hdnBenefitSummary1.Value = "0";
                hdnBenefitSummary2.Value = "0";
                hdnBenefitSummary3.Value = "0";

                HiddenField hdnEnableRow = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnEnableRow") as HiddenField;
                hdnEnableRow.Value = ddlSender.SelectedValue == "Select" ? "false" : "true";
                List<Plan> lstMedicalTemplateTypePlans = GetMedicalTemplateTypePlans(ddlSender.SelectedValue);

                DropDownList ddlPlan1 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlPlan1") as DropDownList;
                ddlPlan1.Items.Clear();
                ddlPlan1.DataSource = lstMedicalTemplateTypePlans;
                ddlPlan1.DataBind();

                DropDownList ddlPlan2 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlPlan2") as DropDownList;
                ddlPlan2.Items.Clear();
                ddlPlan2.DataSource = lstMedicalTemplateTypePlans;
                ddlPlan2.DataBind();

                DropDownList ddlPlan3 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlPlan3") as DropDownList;
                ddlPlan3.Items.Clear();
                ddlPlan3.DataSource = lstMedicalTemplateTypePlans;
                ddlPlan3.DataBind();

                List<Plan> lstHRAHSAPlans = GetHRAHSATemplateTypePlans(ddlSender.SelectedValue);
                DropDownList ddlHRAHSA = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlHRAHSA") as DropDownList;
                ddlHRAHSA.Items.Clear();
                ddlHRAHSA.DataSource = lstHRAHSAPlans;
                ddlHRAHSA.DataBind();

                ddlPlan1.Items.Insert(0, new ListItem("Select", "Select"));
                ddlPlan2.Items.Insert(0, new ListItem("Select", "Select"));
                ddlPlan3.Items.Insert(0, new ListItem("Select", "Select"));
                ddlHRAHSA.Items.Insert(0, new ListItem("Select", "Select"));


                if (ddlSender.SelectedValue != "Select" && lstHRAHSAPlans.Count == 0)
                {
                    ddlHRAHSA.Items[0].Text = "No Plans Available";
                    ddlHRAHSA.Enabled = false;
                }
                if (lstHRAHSAPlans.Count > 0)
                {
                    ddlHRAHSA.Enabled = true;
                    if (lstHRAHSAPlans.Count == 1)
                    {
                        ddlHRAHSA.SelectedValue = lstHRAHSAPlans.FirstOrDefault().ProductId.ToString();
                    }
                }


                switch (PlanTier)
                {
                    case 1:
                        ddlPlan1.Visible = true;
                        ddlPlan2.Visible = false;
                        ddlPlan3.Visible = false;
                        if (ddlSender.SelectedValue != "Select" && lstMedicalTemplateTypePlans.Count == 0)
                        {
                            ddlPlan1.Items[0].Text = "No Plans Available";
                        }
                        if (lstMedicalTemplateTypePlans.Count > 0)
                        {
                            ddlPlan1.Enabled = true;
                            if (lstMedicalTemplateTypePlans.Count == 1)
                            {
                                ddlPlan1.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                            }
                        }
                        break;
                    case 2:
                        ddlPlan1.Visible = true;
                        ddlPlan2.Visible = true;
                        ddlPlan3.Visible = false;
                        //If no plans availale then displat "No Plans Available"
                        if (ddlSender.SelectedValue != "Select" && lstMedicalTemplateTypePlans.Count == 0)
                        {
                            ddlPlan1.Items[0].Text = "No Plans Available";
                            ddlPlan2.Items[0].Text = "No Plans Available";
                            ddlPlan2.Visible = false;
                        }
                        if (lstMedicalTemplateTypePlans.Count > 0)
                        {
                            ddlPlan1.Enabled = true;
                            ddlPlan2.Enabled = true;
                            //If only one plan availale then first dropdown of plan should show plan selected and second should display "Insufficient Plans Available"
                            if (lstMedicalTemplateTypePlans.Count == 1)
                            {
                                ddlPlan1.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                                List<BenefitSummarydata> lstBenefitSummaries = GetBenefitSummaries(int.Parse(ddlPlan1.SelectedValue));
                                if (lstBenefitSummaries.Count <= 0)
                                {
                                    ddlPlan2.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan2.Enabled = false;
                                }
                                else if (lstBenefitSummaries.Count() == 1)
                                {
                                    ddlPlan2.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan2.Enabled = false;
                                    hdnBenefitSummary1.Value = lstBenefitSummaries.First().BenefitsummmaryId.ToString();
                                }
                                else
                                {
                                    ddlPlan2.SelectedValue = ddlPlan1.SelectedValue;
                                    hdnBenefitSummary1.Value = lstBenefitSummaries.First().BenefitsummmaryId.ToString();
                                    hdnBenefitSummary2.Value = lstBenefitSummaries.Skip(1).First().BenefitsummmaryId.ToString();
                                }
                            }
                        }
                        break;
                    case 3:
                        ddlPlan1.Visible = true;
                        ddlPlan2.Visible = true;
                        ddlPlan3.Visible = true;
                        //If no plans availale then displat "No Plans Available"
                        if (ddlSender.SelectedValue != "Select" && lstMedicalTemplateTypePlans.Count == 0)
                        {
                            ddlPlan1.Items[0].Text = "No Plans Available";
                            ddlPlan2.Items[0].Text = "No Plans Available";
                            ddlPlan3.Items[0].Text = "No Plans Available";
                            ddlPlan2.Visible = false;
                            ddlPlan3.Visible = false;
                        }
                        if (lstMedicalTemplateTypePlans.Count > 0)
                        {
                            ddlPlan1.Enabled = true;
                            ddlPlan2.Enabled = true;
                            ddlPlan3.Enabled = true;
                            //If only one plan availale then first dropdown of plan should show plan selected and second should display "Insufficient Plans Available"
                            if (lstMedicalTemplateTypePlans.Count == 1)
                            {
                                ddlPlan1.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                                List<BenefitSummarydata> lstBenefitSummaries = GetBenefitSummaries(int.Parse(ddlPlan1.SelectedValue));
                                if (lstBenefitSummaries.Count() <= 0)
                                {
                                    ddlPlan1.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan2.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan3.Items[0].Text = "Insufficient Plans/Summaries Available";

                                    ddlPlan1.Enabled = false;
                                    ddlPlan2.Enabled = false;
                                    ddlPlan3.Enabled = false;
                                }
                                else if (lstBenefitSummaries.Count() == 1)
                                {
                                    hdnBenefitSummary1.Value = lstBenefitSummaries.First().BenefitsummmaryId.ToString();
                                    ddlPlan2.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan3.Items[0].Text = "Insufficient Plans/Summaries Available";

                                    ddlPlan2.Enabled = false;
                                    ddlPlan3.Enabled = false;
                                }
                                else if (lstBenefitSummaries.Count() == 2)
                                {
                                    hdnBenefitSummary1.Value = lstBenefitSummaries.First().BenefitsummmaryId.ToString();
                                    hdnBenefitSummary2.Value = lstBenefitSummaries.Skip(1).First().BenefitsummmaryId.ToString();
                                    ddlPlan2.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                                    ddlPlan3.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan3.Enabled = false;
                                }
                                else
                                {
                                    hdnBenefitSummary1.Value = lstBenefitSummaries.First().BenefitsummmaryId.ToString();
                                    hdnBenefitSummary2.Value = lstBenefitSummaries.Skip(1).First().BenefitsummmaryId.ToString();
                                    hdnBenefitSummary3.Value = lstBenefitSummaries.Skip(2).First().BenefitsummmaryId.ToString();
                                    ddlPlan2.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                                    ddlPlan3.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                                }
                            }
                            else if (lstMedicalTemplateTypePlans.Count == 2)
                            {
                                //ddlPlan1.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                                //ddlPlan2.SelectedValue = lstMedicalTemplateTypePlans.Skip(1).FirstOrDefault().ProductId.ToString();

                                List<BenefitSummarydata> lstBenefitSummary1 = GetBenefitSummaries(lstMedicalTemplateTypePlans.First().ProductId);
                                List<BenefitSummarydata> lstBenefitSummary2 = GetBenefitSummaries(lstMedicalTemplateTypePlans.Skip(1).First().ProductId);
                                List<BenefitSummarydata> AllBenefitSummaries = lstBenefitSummary1.Union(lstBenefitSummary2).ToList();

                                if (AllBenefitSummaries.Count <= 0)
                                {
                                    ddlPlan1.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan2.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan3.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan1.Enabled = false;
                                    ddlPlan2.Enabled = false;
                                    ddlPlan3.Enabled = false;
                                }
                                else if (AllBenefitSummaries.Count == 1)
                                {
                                    ddlPlan1.SelectedValue = AllBenefitSummaries.First().ProductId.ToString();
                                    hdnBenefitSummary1.Value = AllBenefitSummaries.First().BenefitsummmaryId.ToString();
                                    ddlPlan2.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan3.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan2.Enabled = false;
                                    ddlPlan3.Enabled = false;
                                }
                                else if (AllBenefitSummaries.Count == 2)
                                {
                                    ddlPlan1.SelectedValue = AllBenefitSummaries.First().ProductId.ToString();
                                    ddlPlan2.SelectedValue = AllBenefitSummaries.Skip(1).First().ProductId.ToString();

                                    hdnBenefitSummary1.Value = AllBenefitSummaries.First().BenefitsummmaryId.ToString();
                                    hdnBenefitSummary2.Value = AllBenefitSummaries.Skip(1).First().BenefitsummmaryId.ToString();

                                    ddlPlan3.Items[0].Text = "Insufficient Plans/Summaries Available";
                                    ddlPlan3.Enabled = false;
                                }
                                //else
                                //{
                                //    List<int> ProductIds = AllBenefitSummaries.Select(r => r.ProductId).Distinct().ToList();

                                //    if (ProductIds.Count == 1)
                                //    {
                                //        ddlPlan1.SelectedValue = ProductIds.First().ToString();
                                //        ddlPlan2.SelectedValue = ProductIds.First().ToString();
                                //        ddlPlan3.SelectedValue = ProductIds.First().ToString();

                                //        hdnBenefitSummary1.Value = AllBenefitSummaries.First().BenefitsummmaryId.ToString();
                                //        hdnBenefitSummary2.Value = AllBenefitSummaries.Skip(1).First().BenefitsummmaryId.ToString();
                                //        hdnBenefitSummary3.Value = AllBenefitSummaries.Skip(2).First().BenefitsummmaryId.ToString();
                                //    }
                                //    else if (ProductIds.Count == 2)
                                //    {
                                //        ddlPlan1.SelectedValue = ProductIds.First().ToString();
                                //        List<BenefitSummarydata> b1 = AllBenefitSummaries.Where(r => r.ProductId == int.Parse(ddlPlan1.SelectedValue)).ToList();
                                //        if (b1.Count == 1)
                                //        {
                                //            hdnBenefitSummary1.Value = b1.First().BenefitsummmaryId.ToString();
                                //        }
                                //        else if (b1.Count > 1)
                                //        {
                                //            hdnBenefitSummary1.Value = b1.First().BenefitsummmaryId.ToString();
                                //            hdnBenefitSummary2.Value = b1.Skip(1).First().BenefitsummmaryId.ToString();
                                //            ddlPlan2.SelectedValue = ProductIds.First().ToString();
                                //        }
                                //        List<BenefitSummarydata> b2 = AllBenefitSummaries.Where(r => r.ProductId == ProductIds.Skip(1).First()).ToList();
                                //        if (hdnBenefitSummary2.Value == "0")
                                //        {
                                //            ddlPlan2.SelectedValue = ProductIds.Skip(1).First().ToString();
                                //            ddlPlan3.SelectedValue = ProductIds.Skip(1).First().ToString();

                                //            hdnBenefitSummary2.Value = b2.First().BenefitsummmaryId.ToString();
                                //            hdnBenefitSummary3.Value = b2.Skip(1).First().BenefitsummmaryId.ToString();
                                //        }
                                //        else
                                //        {
                                //            ddlPlan3.SelectedValue = ProductIds.Skip(1).First().ToString();
                                //            hdnBenefitSummary3.Value = b2.First().BenefitsummmaryId.ToString();
                                //        }
                                //    }
                                //}
                            }
                            else if (lstMedicalTemplateTypePlans.Count == 3)
                            {
                                //ddlPlan1.SelectedValue = lstMedicalTemplateTypePlans.FirstOrDefault().ProductId.ToString();
                                //ddlPlan2.SelectedValue = lstMedicalTemplateTypePlans.Skip(1).FirstOrDefault().ProductId.ToString();
                                //ddlPlan3.SelectedValue = lstMedicalTemplateTypePlans.Skip(2).FirstOrDefault().ProductId.ToString();
                            }
                        }
                        break;
                    default:
                        ddlPlan1.Visible = true;
                        ddlPlan2.Visible = false;
                        ddlPlan3.Visible = false;
                        break;
                }


                gvMedicalAnalysisPlans_Plan1Changed(ddlPlan1, null);
                gvMedicalAnalysisPlans_Plan2Changed(ddlPlan2, null);
                gvMedicalAnalysisPlans_Plan3Changed(ddlPlan3, null);
                gvMedicalAnalysisPlans_HRAHSAChanged(ddlHRAHSA, null);
            }
        }
        protected void gvMedicalAnalysisPlans_Plan1Changed(object sender, EventArgs e)
        {
            DropDownList ddlPlan1 = sender as DropDownList;
            string[] IdParts = ddlPlan1.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            DropDownList ddlBenefitSummary1 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary1") as DropDownList;
            ddlBenefitSummary1.Items.Clear();
            ddlBenefitSummary1.Items.Insert(0, new ListItem("Select", "Select"));
            ddlBenefitSummary1.AppendDataBoundItems = true;
            HiddenField hdnBenefitSummary1 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummary1") as HiddenField;
            if (!ddlPlan1.SelectedValue.ToLower().Equals("select"))
            {
                ddlBenefitSummary1.Enabled = true;
                string ddlSenderClientID = ddlPlan1.ClientID;
                List<BenefitSummarydata> BenefitSummaries = GetBenefitSummaries(int.Parse(ddlPlan1.SelectedValue));
                ddlBenefitSummary1.DataSource = BenefitSummaries;
                ddlBenefitSummary1.DataBind();

                if (BenefitSummaries.Count == 0)
                {
                    ddlBenefitSummary1.Items[0].Text = "No Summaries Available";
                    ddlBenefitSummary1.Enabled = false;
                }
                else if (BenefitSummaries.Count == 1)
                {
                    ddlBenefitSummary1.SelectedValue = BenefitSummaries.First().BenefitsummmaryId.ToString();
                }

                if (hdnBenefitSummary1.Value != "0")
                {
                    ddlBenefitSummary1.SelectedValue = hdnBenefitSummary1.Value;
                }
            }
            else
            {
                ddlBenefitSummary1.Enabled = false;
            }
            HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnPlanTier") as HiddenField;
            int PlanTier = int.Parse(hdnPlanTier.Value);
            switch (PlanTier)
            {
                case 1:
                    ddlBenefitSummary1.Visible = true;
                    break;
                case 2:
                    ddlBenefitSummary1.Visible = true;
                    break;
                case 3:
                    ddlBenefitSummary1.Visible = true;
                    break;
                default:
                    ddlBenefitSummary1.Visible = true;
                    break;
            }
            hdnBenefitSummary1.Value = "0";
            gvMedicalAnalysisPlans_BenefitSummary1(ddlBenefitSummary1, null);
        }
        protected void gvMedicalAnalysisPlans_Plan2Changed(object sender, EventArgs e)
        {
            DropDownList ddlPlan2 = sender as DropDownList;
            string[] IdParts = ddlPlan2.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            DropDownList ddlBenefitSummary2 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary2") as DropDownList;
            ddlBenefitSummary2.Items.Clear();
            ddlBenefitSummary2.Items.Insert(0, new ListItem("Select", "Select"));
            ddlBenefitSummary2.AppendDataBoundItems = true;

            HiddenField hdnBenefitSummary2 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummary2") as HiddenField;

            if (!ddlPlan2.SelectedValue.ToLower().Equals("select"))
            {
                ddlBenefitSummary2.Enabled = true;
                string ddlSenderClientID = ddlPlan2.ClientID;
                List<BenefitSummarydata> BenefitSummaries = GetBenefitSummaries(int.Parse(ddlPlan2.SelectedValue));
                ddlBenefitSummary2.DataSource = BenefitSummaries;
                ddlBenefitSummary2.DataBind();
                if (BenefitSummaries.Count == 0)
                {
                    ddlBenefitSummary2.Enabled = false;
                    ddlBenefitSummary2.Items[0].Text = "No Summaries Available";
                }
                else if (BenefitSummaries.Count == 1)
                {
                    ddlBenefitSummary2.SelectedValue = BenefitSummaries.First().BenefitsummmaryId.ToString();
                }

                if (hdnBenefitSummary2.Value != "0")
                    ddlBenefitSummary2.SelectedValue = hdnBenefitSummary2.Value;
            }
            else
            {
                ddlBenefitSummary2.Enabled = false;
            }
            if (ddlPlan2.SelectedItem.Text.ToLower() == "no plans available")
            {
                ddlBenefitSummary2.Visible = false;
                return;
            }

            HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnPlanTier") as HiddenField;
            int PlanTier = int.Parse(hdnPlanTier.Value);
            switch (PlanTier)
            {
                case 1:
                    ddlBenefitSummary2.Visible = false;
                    break;
                case 2:
                    ddlBenefitSummary2.Visible = true;
                    break;
                case 3:
                    ddlBenefitSummary2.Visible = true;
                    break;
                default:
                    ddlBenefitSummary2.Visible = false;
                    break;
            }
            hdnBenefitSummary2.Value = "0";

        }
        protected void gvMedicalAnalysisPlans_Plan3Changed(object sender, EventArgs e)
        {
            DropDownList ddlPlan3 = sender as DropDownList;
            string[] IdParts = ddlPlan3.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            DropDownList ddlBenefitSummary3 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary3") as DropDownList;
            ddlBenefitSummary3.Items.Clear();
            ddlBenefitSummary3.Items.Insert(0, new ListItem("Select", "Select"));
            ddlBenefitSummary3.AppendDataBoundItems = true;

            HiddenField hdnBenefitSummary3 = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummary3") as HiddenField;
            if (!ddlPlan3.SelectedValue.ToLower().Equals("select"))
            {
                ddlBenefitSummary3.Enabled = true;
                string ddlSenderClientID = ddlPlan3.ClientID;
                List<BenefitSummarydata> BenefitSummaries = GetBenefitSummaries(int.Parse(ddlPlan3.SelectedValue));
                ddlBenefitSummary3.DataSource = BenefitSummaries;
                ddlBenefitSummary3.DataBind();
                if (BenefitSummaries.Count == 0)
                {
                    ddlBenefitSummary3.Enabled = false;
                    ddlBenefitSummary3.Items[0].Text = "No Summaries Available";
                }
                else if (BenefitSummaries.Count == 1)
                {
                    ddlBenefitSummary3.SelectedValue = BenefitSummaries.First().BenefitsummmaryId.ToString();
                }

                if (hdnBenefitSummary3.Value != "0")
                    ddlBenefitSummary3.SelectedValue = hdnBenefitSummary3.Value;
            }
            else
            {
                ddlBenefitSummary3.Enabled = false;
            }
            if (ddlPlan3.SelectedItem.Text.ToLower() == "no plans available")
            {
                ddlBenefitSummary3.Visible = false;
                return;
            }
            HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("hdnPlanTier") as HiddenField;
            int PlanTier = int.Parse(hdnPlanTier.Value);
            switch (PlanTier)
            {
                case 1:
                    ddlBenefitSummary3.Visible = false;
                    break;
                case 2:
                    ddlBenefitSummary3.Visible = false;
                    break;
                case 3:
                    ddlBenefitSummary3.Visible = true;
                    break;
                default:
                    ddlBenefitSummary3.Visible = false;
                    break;
            }
            hdnBenefitSummary3.Value = "0";
        }
        protected void gvMedicalAnalysisPlans_BenefitSummary1(object sender, EventArgs e)
        {
            DropDownList ddlSender = sender as DropDownList;
            string ddlSenderClientID = ddlSender.ClientID;
            string[] IdParts = ddlSenderClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            DropDownList ddlTierFactor = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlTierFactor") as DropDownList;
            ddlTierFactor.SelectedIndex = 0;
            gvMedicalAnalysisPlans_TierFactor(ddlTierFactor, null);
            if (ddlcontents.SelectedValue == "Unpopulated")
            {
                ddlTierFactor.Enabled = false;
            }
            else
            {
                if (!ddlSender.SelectedItem.Text.ToLower().Equals("select"))
                {
                    ddlTierFactor.Enabled = true;
                }
                else
                {
                    ddlTierFactor.Enabled = false;
                }
            }

        }
        protected void gvMedicalAnalysisPlans_TierFactor(object sender, EventArgs e)
        {
            DropDownList ddlSender = sender as DropDownList;
            string ddlSenderClientID = ddlSender.ClientID;
            string[] IdParts = ddlSenderClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            DropDownList ddlFEI = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlFEI") as DropDownList;
            ddlFEI.SelectedValue = "Select";
            if (!ddlSender.SelectedItem.Text.ToLower().Equals("select"))
            {
                ddlFEI.Enabled = true;
            }
            else
            {
                ddlFEI.Enabled = false;
            }
        }
        protected void gvMedicalAnalysisPlans_HRAHSAChanged(object sender, EventArgs e)
        {
            DropDownList ddlHRAHSA = sender as DropDownList;
            string[] IdParts = ddlHRAHSA.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            DropDownList ddlBenefitSummaryHRAHSA = gvMedicalAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryHRAHSA") as DropDownList;
            ddlBenefitSummaryHRAHSA.Items.Clear();
            ddlBenefitSummaryHRAHSA.Items.Insert(0, new ListItem("Select", "Select"));
            ddlBenefitSummaryHRAHSA.AppendDataBoundItems = true;
            if (!ddlHRAHSA.SelectedValue.ToLower().Equals("select"))
            {
                ddlBenefitSummaryHRAHSA.Enabled = true;
                string ddlSenderClientID = ddlHRAHSA.ClientID;
                List<BenefitSummarydata> BenefitSummaries = GetBenefitSummaries(int.Parse(ddlHRAHSA.SelectedValue));
                ddlBenefitSummaryHRAHSA.DataSource = BenefitSummaries;
                ddlBenefitSummaryHRAHSA.DataBind();

                if (BenefitSummaries.Count == 0)
                {
                    ddlBenefitSummaryHRAHSA.Items[0].Text = "No Summaries Available";
                    ddlBenefitSummaryHRAHSA.Enabled = false;
                }
                else if (BenefitSummaries.Count == 1)
                {
                    ddlBenefitSummaryHRAHSA.SelectedValue = BenefitSummaries.First().BenefitsummmaryId.ToString();
                }
            }
            else
            {
                ddlBenefitSummaryHRAHSA.Enabled = false;
            }

        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                if (ValidateForm())
                {
                    CreateMedicalLOCReport();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private void ResetForm()
        {
            ddlcontents.SelectedValue = "0";
            ddlOrientation.SelectedValue = "Select";
            Session["PlanList"] = new List<Plan>();
            ddlcontents_SelectedIndexChanged(null, null);
        }
        private void BindAnalysisGridView()
        {
            Session["PlanList"] = new List<Plan>();
            Session["ProductDS"] = null;
            LoadPlans();
            DataTable dtblTemp = CreateMedicalLOCDataTable();
            gvMedicalAnalysisPlans.DataSource = null;
            gvMedicalAnalysisPlans.DataBind();
            for (int i = 1; i <= 1; i++)
            {
                DataRow dr = dtblTemp.NewRow();
                dtblTemp.Rows.Add(dr);
            }
            gvMedicalAnalysisPlans.DataSource = dtblTemp;
            gvMedicalAnalysisPlans.DataBind();


        }
        private DataTable CreateMedicalLOCDataTable()
        {
            DataTable dtLOCData = new DataTable();
            dtLOCData.Columns.Add(new DataColumn("RowNum"));
            dtLOCData.Columns.Add(new DataColumn("TemplateType"));
            dtLOCData.Columns.Add(new DataColumn("PlanType"));
            dtLOCData.Columns.Add(new DataColumn("PlanName"));
            dtLOCData.Columns.Add(new DataColumn("ProductID"));
            dtLOCData.Columns.Add(new DataColumn("SelectedBenefitSummary"));
            dtLOCData.Columns.Add(new DataColumn("SummaryId"));
            dtLOCData.Columns.Add(new DataColumn("CarrierName"));
            dtLOCData.Columns.Add(new DataColumn("IsHRAorHSA"));
            return dtLOCData;
        }
        private void LoadPlans()
        {
            List<Plan> PlanList = new List<Plan>();
            DataTable dtblPlan = CreatePlanInfoTable();
            List<Plan> TempPlan = new List<Plan>();
            SessionId = Session["SessionId"].ToString();
            if (ddlClient.SelectedIndex > 0)
            {
                TempPlan = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId, "MedicalLOCTemplate");

                if (rdlAncillaryAnalysisPlanStatus.SelectedIndex == 0)
                {
                    TempPlan = TempPlan.Where(p => p.RenewalDate > System.DateTime.Now && p.ProductStatus == p.ProductStatusCurrent).ToList();
                }

                TempPlan = (from p in TempPlan
                            orderby p.ProductTypeDescription, p.ProductName, p.CarrierName, p.RenewalDate ascending
                            select p).ToList();

                foreach (Plan objPlan in TempPlan)
                {
                    if (WriteMedicalLOCTemplates.Medical_PlanIDs.Contains(objPlan.ProductTypeId) || WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(objPlan.ProductTypeId) || WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(objPlan.ProductTypeId) || WriteMedicalLOCTemplates.StopLoss_PlanIDs.Contains(objPlan.ProductTypeId))
                    {
                        PlanList.Add(objPlan);
                        DataRow drNewRow = dtblPlan.NewRow();
                        drNewRow["Carrier"] = objPlan.CarrierName;
                        drNewRow["Name"] = objPlan.ProductName;
                        drNewRow["Effective"] = objPlan.EffectiveDate.ToString("MM/dd/yy");
                        drNewRow["Renewal"] = objPlan.RenewalDate.ToString("MM/dd/yy"); ;
                        drNewRow["PolicyNumber"] = objPlan.PolicyNumber;
                        drNewRow["ProductId"] = objPlan.ProductId;
                        drNewRow["ProductName"] = objPlan.ProductName;
                        drNewRow["ProductTypeId"] = objPlan.ProductTypeId;
                        drNewRow["PlanType"] = objPlan.ProductTypeDescription;
                        drNewRow["SummaryName"] = objPlan.SummaryName;
                        drNewRow["SummaryId"] = objPlan.SummaryID;
                        drNewRow["PlanNumber"] = objPlan.PolicyNumber;
                        dtblPlan.Rows.Add(drNewRow);
                    }
                }
            }
            Session["PlanList"] = PlanList;
            Session["PlanTable"] = dtblPlan;
        }
        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryId", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
        private List<Plan> GetMedicalTemplateTypePlans(string TemplateTypeName)
        {
            List<Plan> TemplateTypePlanList = new List<Plan>();
            List<Plan> PlanList = Session["PlanList"] as List<Plan>;
            if (PlanList != null)
            {
                WriteMedicalLOCTemplates.TemplateType TemplateType = WriteMedicalLOCTemplates.TemplateType.None;
                TemplateType = wr.ConvertToTemplateType(TemplateTypeName);
                switch (TemplateType)
                {
                    case WriteMedicalLOCTemplates.TemplateType.FI_Single:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("fi")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Dual:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("fi")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Triple:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("fi")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Single:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("sf")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Dual:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("sf")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Triple:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("sf")).ToList();
                        break;
                }
            }

            TemplateTypePlanList = TemplateTypePlanList.Where(p => WriteMedicalLOCTemplates.Medical_PlanIDs.Contains(p.ProductTypeId)).ToList();
            return TemplateTypePlanList;
        }
        private List<Plan> GetHRAHSATemplateTypePlans(string TemplateTypeName)
        {
            List<Plan> TemplateTypePlanList = new List<Plan>();
            List<Plan> PlanList = Session["PlanList"] as List<Plan>;
            if (PlanList != null)
            {
                WriteMedicalLOCTemplates.TemplateType TemplateType = WriteMedicalLOCTemplates.TemplateType.None;
                TemplateType = wr.ConvertToTemplateType(TemplateTypeName);
                switch (TemplateType)
                {
                    case WriteMedicalLOCTemplates.TemplateType.FI_Single:
                        TemplateTypePlanList = PlanList.Where(p => WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(p.ProductTypeId) || WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(p.ProductTypeId)).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Dual:
                        TemplateTypePlanList = PlanList.Where(p => WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(p.ProductTypeId) || WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(p.ProductTypeId)).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Triple:
                        TemplateTypePlanList = PlanList.Where(p => WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(p.ProductTypeId) || WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(p.ProductTypeId)).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Single:
                        TemplateTypePlanList = PlanList.Where(p => WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(p.ProductTypeId) || WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(p.ProductTypeId)).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Dual:
                        TemplateTypePlanList = PlanList.Where(p => WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(p.ProductTypeId) || WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(p.ProductTypeId)).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Triple:
                        TemplateTypePlanList = PlanList.Where(p => WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(p.ProductTypeId) || WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(p.ProductTypeId)).ToList();
                        break;
                }
            }


            return TemplateTypePlanList;
        }
        private List<Plan> GetStopLossTemplateTypePlans(string TemplateTypeName)
        {
            List<Plan> TemplateTypePlanList = new List<Plan>();
            List<Plan> PlanList = Session["PlanList"] as List<Plan>;
            if (PlanList != null)
            {
                WriteMedicalLOCTemplates.TemplateType TemplateType = WriteMedicalLOCTemplates.TemplateType.None;
                TemplateType = wr.ConvertToTemplateType(TemplateTypeName);
                switch (TemplateType)
                {
                    case WriteMedicalLOCTemplates.TemplateType.FI_Single:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("fi")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Dual:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("fi")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Triple:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("fi")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Single:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("sf")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Dual:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("sf")).ToList();
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Triple:
                        TemplateTypePlanList = PlanList.Where(p => p.UsiProductName.ToLower().StartsWith("sf")).ToList();
                        break;
                }
            }

            TemplateTypePlanList = TemplateTypePlanList.Where(p => WriteMedicalLOCTemplates.StopLoss_PlanIDs.Contains(p.ProductTypeId)).ToList();
            return TemplateTypePlanList;
        }
        private List<string> GetTierFactor(string TemplateTypeName)
        {
            List<string> lstTierFactor = new List<string>();
            WriteMedicalLOCTemplates.TemplateType TemplateType = WriteMedicalLOCTemplates.TemplateType.None;
            TemplateType = wr.ConvertToTemplateType(TemplateTypeName);
            switch (TemplateType)
            {
                case WriteMedicalLOCTemplates.TemplateType.FI_Single:
                    lstTierFactor = new List<string>() { "2 Tier", "3 Tier", "4 Tier" };
                    break;
                case WriteMedicalLOCTemplates.TemplateType.FI_Dual:
                    lstTierFactor = new List<string>() { "2 Tier", "3 Tier", "4 Tier" };
                    break;
                case WriteMedicalLOCTemplates.TemplateType.FI_Triple:
                    lstTierFactor = new List<string>() { "2 Tier", "3 Tier", "4 Tier" };
                    break;
                case WriteMedicalLOCTemplates.TemplateType.SF_Single:
                    lstTierFactor = new List<string>() { "Composite", "2 Tier", "4 Tier" };
                    break;
                case WriteMedicalLOCTemplates.TemplateType.SF_Dual:
                    lstTierFactor = new List<string>() { "Composite", "2 Tier", "4 Tier" };
                    break;
                case WriteMedicalLOCTemplates.TemplateType.SF_Triple:
                    lstTierFactor = new List<string>() { "Composite", "2 Tier", "4 Tier" };
                    break;
            }
            return lstTierFactor;
        }
        private List<BenefitSummarydata> GetBenefitSummaries(int ProductId)
        {
            List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            try
            {
                if (ddlClient.SelectedIndex != 0)
                {
                    SessionId = Session["SessionId"].ToString();
                    BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), ProductId, SessionId);
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return BenefitSummaryList;
        }
        private bool ValidateForm()
        {
            if (ddlcontents.SelectedValue == "ClientDetails")
            {
                if (ddlOrientation.SelectedIndex == 0 || ddlOrientation.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Orientation.')</script>");
                    ddlOrientation.Focus();
                    return false;
                }
                if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                    ddlClient.Focus();
                    return false;
                }
                if (txtAnalysisRenewalDate.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Renewal Date.')</script>");
                    txtAnalysisRenewalDate.Focus();
                    return false;
                }
                if (!IsValidDate(txtAnalysisRenewalDate.Text.Trim()))
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Renewal Date. Date format should be MM/DD/YYYY')</script>", false);
                    txtAnalysisRenewalDate.Focus();
                    return false;
                }

                DropDownList ddlTemplateType = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTemplateType") as DropDownList;
                DropDownList ddlPlan1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan1") as DropDownList;
                DropDownList ddlPlan2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan2") as DropDownList;
                DropDownList ddlPlan3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan3") as DropDownList;
                DropDownList ddlHRAHSA = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlHRAHSA") as DropDownList;
                HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[0].FindControl("hdnPlanTier") as HiddenField;

                DropDownList ddlBenefitSummary1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary1") as DropDownList;
                DropDownList ddlBenefitSummary2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary2") as DropDownList;
                DropDownList ddlBenefitSummary3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary3") as DropDownList;
                DropDownList ddlBenefitSummaryHRAHSA = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummaryHRAHSA") as DropDownList;
                DropDownList ddlTierFactor = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTierFactor") as DropDownList;
                DropDownList ddlFEI = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlFEI") as DropDownList;

                if (ddlTemplateType.SelectedValue == "Select")
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Template Type.')</script>");
                    ddlTemplateType.Focus();
                    return false;
                }
                if (ddlPlan1.SelectedValue == "Select")
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Plan.')</script>");
                    ddlPlan1.Focus();
                    return false;
                }
                if (ddlBenefitSummary1.SelectedValue == "Select")
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Benefit Summary.')</script>");
                    ddlBenefitSummary1.Focus();
                    return false;
                }
                if (int.Parse(hdnPlanTier.Value) == 2 || int.Parse(hdnPlanTier.Value) == 3)
                {
                    if (ddlPlan2.SelectedValue != "Select")
                    {
                        if (ddlBenefitSummary2.SelectedValue == "Select")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Benefit Summary for Dual Plan.')</script>");
                            ddlBenefitSummary2.Focus();
                            return false;
                        }
                    }
                }
                if (int.Parse(hdnPlanTier.Value) == 3)
                {
                    if (ddlPlan3.SelectedValue != "Select")
                    {
                        if (ddlBenefitSummary3.SelectedValue == "Select")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Benefit Summary for Triple Plan.')</script>");
                            ddlBenefitSummary3.Focus();
                            return false;
                        }
                    }
                }

                // Validate Duplicate plans or benefit Summaries
                if (!ValidateDuplicatePlanBenefitSummarySelected())
                    return false;

                if (ddlHRAHSA.SelectedValue != "Select")
                {
                    if (ddlBenefitSummaryHRAHSA.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Benefit Summary for HSA/HRA.')</script>");
                        ddlBenefitSummaryHRAHSA.Focus();
                        return false;
                    }
                }
                if (ddlTierFactor.SelectedValue == "Select")
                {
                    if (ddlTemplateType.SelectedValue.ToLower().StartsWith("fi"))
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Fully Insured Premium Rate Tier.')</script>");
                    }
                    else if (ddlTemplateType.SelectedValue.ToLower().StartsWith("sf"))
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Self-Funded Rates & Factors.')</script>");
                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Tier/Factor.')</script>");
                    }

                    ddlTierFactor.Focus();
                    return false;
                }

                if (ddlTemplateType.SelectedValue.ToLower().StartsWith("sf"))
                {
                    if (ddlFEI.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select FIE.')</script>");
                        ddlFEI.Focus();
                        return false;
                    }
                }
            }
            if (ddlcontents.SelectedValue == "Unpopulated")
            {
                if (ddlOrientation.SelectedIndex == 0 || ddlOrientation.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Orientation.')</script>");
                    ddlOrientation.Focus();
                    return false;
                }
                DropDownList ddlTemplateType = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTemplateType") as DropDownList;
                DropDownList ddlTierFactor = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTierFactor") as DropDownList;
                DropDownList ddlFEI = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlFEI") as DropDownList;
                if (ddlTemplateType.SelectedValue == "Select")
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Template Type.')</script>");
                    ddlTemplateType.Focus();
                    return false;
                }
                if (ddlTierFactor.SelectedValue == "Select")
                {
                    if (ddlTemplateType.SelectedValue.ToLower().StartsWith("fi"))
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Fully Insured Premium Rate Tier.')</script>");
                    }
                    else if (ddlTemplateType.SelectedValue.ToLower().StartsWith("sf"))
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Self-Funded Rates & Factors.')</script>");
                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Tier/Factor.')</script>");
                    }

                    ddlTierFactor.Focus();
                    return false;
                }
            }
            return true;
        }
        private bool IsValidDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }
        private void CreateMedicalLOCReport()
        {
            try
            {
                if (ddlcontents.SelectedValue == "ClientDetails")
                {
                    sd.BuildAccountTable();
                    sd.BuildEmployeeTypesTable();
                    AccountDS = sd.GetAccountDetail_AccountProfileSummeryDetails(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    DropDownList ddlTemplateType = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTemplateType") as DropDownList;
                    if (ddlTemplateType.SelectedValue.ToLower().StartsWith("fi"))
                    {
                        Process_FITemplates();
                    }
                    if (ddlTemplateType.SelectedValue.ToLower().StartsWith("sf"))
                    {
                        Process_SFTemplates();
                    }

                    #region ------- Code for Add Activity Log --------
                    List<Contact> ContactList = new List<Contact>();
                    ///string TemplateType = Convert.ToString((DropDownList)gvMedicalAnalysisPlans.FindControl("ddlTemplateType"));
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    string AdditionalCrtieriaOption_1 = ddlOrientation.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DictDepartment = sd.getDepartmentDetails();
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                }
                if (ddlcontents.SelectedValue == "Unpopulated")
                {
                    Download_Unpopulated();
                    string AdditionalCrtieriaOption_1 = ddlOrientation.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private void Download_Unpopulated()
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;

            DropDownList ddlTemplateType = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTemplateType") as DropDownList;
            DropDownList ddlTierFactor = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTierFactor") as DropDownList;
            string myPath = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/Unpopulated/");
            string TemplateTypeName = ddlTemplateType.SelectedValue;
            string TierFactorName = ddlTierFactor.SelectedValue;
            WriteMedicalLOCTemplates.TemplateType TemplateType = WriteMedicalLOCTemplates.TemplateType.None;
            TemplateType = wr.ConvertToTemplateType(TemplateTypeName);
            if (ddlOrientation.SelectedValue == "Landscape")
            {
                switch (TemplateType)
                {
                    case WriteMedicalLOCTemplates.TemplateType.FI_Single:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "FI_Single_Plan_2Tier_Land.xlsx";
                        if (TierFactorName == "3 Tier")
                            myPath = myPath + "FI_Single_Plan_3Tier_Land.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "FI_Single_Plan_4Tier_Land.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Dual:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "FI_Dual_Plan_2Tier_Land.xlsx";
                        if (TierFactorName == "3 Tier")
                            myPath = myPath + "FI_Dual_Plan_3Tier_Land.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "FI_Dual_Plan_4Tier_Land.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Triple:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "FI_Triple_Plan_2Tier_Land.xlsx";
                        if (TierFactorName == "3 Tier")
                            myPath = myPath + "FI_Triple_Plan_3Tier_Land.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "FI_Triple_Plan_4Tier_Land.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Single:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "SF_Single_Plan_2Tier_Land.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "SF_Single_Plan_4Tier_Land.xlsx";
                        if (TierFactorName == "Composite")
                            myPath = myPath + "SF_Single_Plan_Composite_Land.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Dual:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "SF_Dual_Plan_2Tier_Land.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "SF_Dual_Plan_4Tier_Land.xlsx";
                        if (TierFactorName == "Composite")
                            myPath = myPath + "SF_Dual_Plan_Composite_Land.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Triple:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "SF_Triple_Plan_2Tier_Land.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "SF_Triple_Plan_4Tier_Land.xlsx";
                        if (TierFactorName == "Composite")
                            myPath = myPath + "SF_Triple_Plan_Composite_Land.xlsx";
                        break;
                }
            }
            if (ddlOrientation.SelectedValue == "Portrait")
            {
                switch (TemplateType)
                {
                    case WriteMedicalLOCTemplates.TemplateType.FI_Single:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "FI_Single_Plan_2Tier_Port.xlsx";
                        if (TierFactorName == "3 Tier")
                            myPath = myPath + "FI_Single_Plan_3Tier_Port.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "FI_Single_Plan_4Tier_Port.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Dual:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "FI_Dual_Plan_2Tier_Port.xlsx";
                        if (TierFactorName == "3 Tier")
                            myPath = myPath + "FI_Dual_Plan_3Tier_Port.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "FI_Dual_Plan_4Tier_Port.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.FI_Triple:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "FI_Triple_Plan_2Tier_Port.xlsx";
                        if (TierFactorName == "3 Tier")
                            myPath = myPath + "FI_Triple_Plan_3Tier_Port.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "FI_Triple_Plan_4Tier_Port.xlsx";
                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Single:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "SF_Single_Plan_2Tier_Port.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "SF_Single_Plan_4Tier_Port.xlsx";
                        if (TierFactorName == "Composite")
                            myPath = myPath + "SF_Single_Plan_Composite_Port.xlsx";
                        break;

                    case WriteMedicalLOCTemplates.TemplateType.SF_Dual:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "SF_Dual_Plan_2Tier_Port.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "SF_Dual_Plan_4Tier_Port.xlsx";
                        if (TierFactorName == "Composite")
                            myPath = myPath + "SF_Dual_Plan_Composite_port.xlsx";

                        break;
                    case WriteMedicalLOCTemplates.TemplateType.SF_Triple:
                        if (TierFactorName == "2 Tier")
                            myPath = myPath + "SF_Triple_Plan_2Tier_Port.xlsx";
                        if (TierFactorName == "4 Tier")
                            myPath = myPath + "SF_Triple_Plan_4Tier_Port.xlsx";
                        if (TierFactorName == "Composite")
                            myPath = myPath + "SF_Triple_Plan_Composite_Port.xlsx";
                        break;
                }
            }
            string savefilename = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/Unpopulated/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

            if (!Directory.Exists(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/Unpopulated/Downloaded/")))
            {
                Directory.CreateDirectory(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/Unpopulated/Downloaded/"));
            }
            // myPath = Server.MapPath(myPath);


            File.Copy(myPath, savefilename, true);
            DownloadFileNew_ExcelFormat(savefilename.ToString());
        }
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool ValidateDuplicatePlanBenefitSummarySelected()
        {
            DropDownList ddlPlan1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan1") as DropDownList;
            DropDownList ddlPlan2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan2") as DropDownList;
            DropDownList ddlPlan3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan3") as DropDownList;
            HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[0].FindControl("hdnPlanTier") as HiddenField;

            DropDownList ddlBenefitSummary1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary1") as DropDownList;
            DropDownList ddlBenefitSummary2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary2") as DropDownList;
            DropDownList ddlBenefitSummary3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary3") as DropDownList;


            if (hdnPlanTier.Value == "2")
            {
                if (ddlPlan2.SelectedValue != "Select")
                {
                    if (ddlPlan1.SelectedValue == ddlPlan2.SelectedValue)
                    {
                        if (ddlBenefitSummary1.SelectedValue == ddlBenefitSummary2.SelectedValue)
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('You have selected identical Benefit Summaries. Please select unique Benefit Summary for each Plan')</script>");
                            ddlBenefitSummary2.Focus();
                            return false;
                        }
                    }
                }
            }
            if (hdnPlanTier.Value == "3")
            {
                if (ddlPlan2.SelectedValue != "Select")
                {
                    if (ddlPlan1.SelectedValue == ddlPlan2.SelectedValue)
                    {
                        if (ddlBenefitSummary1.SelectedValue == ddlBenefitSummary2.SelectedValue)
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('You have selected identical Benefit Summaries. Please select unique Benefit Summary for each Plan')</script>");
                            ddlBenefitSummary2.Focus();
                            return false;
                        }
                    }
                    if (ddlPlan3.SelectedValue != "Select")
                    {
                        if (ddlPlan2.SelectedValue == ddlPlan3.SelectedValue)
                        {
                            if (ddlBenefitSummary2.SelectedValue == ddlBenefitSummary3.SelectedValue)
                            {
                                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('You have selected identical Benefit Summaries. Please select unique Benefit Summary for each Plan')</script>");
                                ddlBenefitSummary3.Focus();
                                return false;
                            }
                        }
                    }
                }
                if (ddlPlan3.SelectedValue != "Select")
                {
                    if (ddlPlan1.SelectedValue == ddlPlan3.SelectedValue)
                    {
                        if (ddlBenefitSummary1.SelectedValue == ddlBenefitSummary3.SelectedValue)
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('You have selected indentical Benefit Summaries. Please select unique Benefit Summary for each Plan')</script>");
                            ddlBenefitSummary3.Focus();
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        private void Process_FITemplates()
        {
            DropDownList ddlTemplateType = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTemplateType") as DropDownList;
            DropDownList ddlPlan1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan1") as DropDownList;
            DropDownList ddlPlan2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan2") as DropDownList;
            DropDownList ddlPlan3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan3") as DropDownList;
            DropDownList ddlHRAHSA = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlHRAHSA") as DropDownList;
            DropDownList ddlStopLoss = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlStopLoss") as DropDownList;
            HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[0].FindControl("hdnPlanTier") as HiddenField;

            DropDownList ddlBenefitSummary1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary1") as DropDownList;
            DropDownList ddlBenefitSummary2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary2") as DropDownList;
            DropDownList ddlBenefitSummary3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary3") as DropDownList;
            DropDownList ddlBenefitSummaryHRAHSA = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummaryHRAHSA") as DropDownList;
            DropDownList ddlBenefitSummaryStopLoss = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummaryStopLoss") as DropDownList;
            DropDownList ddlTierFactor = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTierFactor") as DropDownList;
            DropDownList ddlFEI = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlFEI") as DropDownList;

            DataTable dtblAnalysisPlan = CreateMedicalLOCDataTable();
            List<Plan> lstTempPlan = Session["PlanList"] as List<Plan>;
            int ProductId = 0;
            int BenefitSummaryId = 0;
            int.TryParse(ddlPlan1.SelectedValue, out ProductId);
            int.TryParse(ddlBenefitSummary1.SelectedValue, out BenefitSummaryId);
            Plan SelectedPlan1 = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();

            //First Row Plan
            DataRow dr1 = dtblAnalysisPlan.NewRow();
            dr1["RowNum"] = 1;
            dr1["TemplateType"] = ddlTemplateType.SelectedValue;
            dr1["PlanType"] = SelectedPlan1 != null ? SelectedPlan1.ProductTypeDescription : "";
            dr1["PlanName"] = SelectedPlan1 != null ? SelectedPlan1.UsiProductName : "";
            dr1["ProductID"] = ProductId;
            dr1["SelectedBenefitSummary"] = ddlBenefitSummary1.SelectedItem.Text;
            dr1["SummaryId"] = BenefitSummaryId;
            dr1["CarrierName"] = SelectedPlan1 != null ? SelectedPlan1.CarrierName : "";
            dr1["IsHRAorHSA"] = "NONE";

            dtblAnalysisPlan.Rows.Add(dr1);

            if (hdnPlanTier.Value == "2" || hdnPlanTier.Value == "3")
            {
                ProductId = 0;
                BenefitSummaryId = 0;
                int.TryParse(ddlPlan2.SelectedValue, out ProductId);
                int.TryParse(ddlBenefitSummary2.SelectedValue, out BenefitSummaryId);
                Plan SelectedPlan2 = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();
                DataRow dr2 = dtblAnalysisPlan.NewRow();
                dr2["RowNum"] = 2;
                dr2["TemplateType"] = ddlTemplateType.SelectedValue;
                dr2["PlanType"] = "";
                dr2["PlanName"] = "";
                dr2["ProductID"] = ProductId;
                dr2["SelectedBenefitSummary"] = "";
                dr2["SummaryId"] = BenefitSummaryId;
                dr2["CarrierName"] = "";
                dr2["IsHRAorHSA"] = "NONE";
                if (ddlPlan2.SelectedValue != "Select")
                {
                    dr2["TemplateType"] = ddlTemplateType.SelectedValue;
                    dr2["PlanType"] = SelectedPlan2 != null ? SelectedPlan2.ProductTypeDescription : "";
                    dr2["PlanName"] = SelectedPlan2 != null ? SelectedPlan2.UsiProductName : "";
                    dr2["ProductID"] = ProductId;
                    dr2["SelectedBenefitSummary"] = ddlBenefitSummary2.SelectedItem.Text;
                    dr2["SummaryId"] = BenefitSummaryId;
                    dr2["CarrierName"] = SelectedPlan2 != null ? SelectedPlan2.CarrierName : "";

                }
                dtblAnalysisPlan.Rows.Add(dr2);
            }
            if (hdnPlanTier.Value == "3")
            {
                ProductId = 0;
                BenefitSummaryId = 0;
                int.TryParse(ddlPlan3.SelectedValue, out ProductId);
                int.TryParse(ddlBenefitSummary3.SelectedValue, out BenefitSummaryId);
                Plan SelectedPlan3 = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();
                DataRow dr3 = dtblAnalysisPlan.NewRow();
                dr3["RowNum"] = 3;
                dr3["TemplateType"] = ddlTemplateType.SelectedValue;
                dr3["PlanType"] = "";
                dr3["PlanName"] = "";
                dr3["ProductID"] = ProductId;
                dr3["SelectedBenefitSummary"] = "";
                dr3["SummaryId"] = BenefitSummaryId;
                dr3["CarrierName"] = "";
                dr3["IsHRAorHSA"] = "NONE";
                if (ddlPlan2.SelectedValue != "Select")
                {
                    dr3["TemplateType"] = ddlTemplateType.SelectedValue;
                    dr3["PlanType"] = SelectedPlan3 != null ? SelectedPlan3.ProductTypeDescription : "";
                    dr3["PlanName"] = SelectedPlan3 != null ? SelectedPlan3.UsiProductName : "";
                    dr3["ProductID"] = ProductId;
                    dr3["SelectedBenefitSummary"] = ddlBenefitSummary3.SelectedItem.Text;
                    dr3["SummaryId"] = BenefitSummaryId;
                    dr3["CarrierName"] = SelectedPlan3 != null ? SelectedPlan3.CarrierName : "";

                }
                dtblAnalysisPlan.Rows.Add(dr3);
            }

            if (ddlBenefitSummaryHRAHSA.SelectedValue != "Select")
            {
                ProductId = 0;
                BenefitSummaryId = 0;
                int.TryParse(ddlHRAHSA.SelectedValue, out ProductId);
                int.TryParse(ddlBenefitSummaryHRAHSA.SelectedValue, out BenefitSummaryId);
                Plan SelectedHRAHSAPlan = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();

                DataRow drHRAHSA = dtblAnalysisPlan.NewRow();
                drHRAHSA["RowNum"] = 3;
                drHRAHSA["TemplateType"] = ddlTemplateType.SelectedValue;
                drHRAHSA["PlanType"] = SelectedHRAHSAPlan != null ? SelectedHRAHSAPlan.ProductTypeDescription : "";
                drHRAHSA["PlanName"] = SelectedHRAHSAPlan != null ? SelectedHRAHSAPlan.UsiProductName : "";
                drHRAHSA["ProductID"] = ProductId;
                drHRAHSA["SelectedBenefitSummary"] = ddlBenefitSummaryHRAHSA.SelectedItem.Text;
                drHRAHSA["SummaryId"] = BenefitSummaryId;
                drHRAHSA["CarrierName"] = SelectedHRAHSAPlan != null ? SelectedHRAHSAPlan.CarrierName : "";
                drHRAHSA["IsHRAorHSA"] = WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(SelectedHRAHSAPlan.ProductTypeId) ? "HRA" : WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(SelectedHRAHSAPlan.ProductTypeId) ? "HSA" : "NONE";
                dtblAnalysisPlan.Rows.Add(drHRAHSA);
            }


            sd.BuildBenefitSummaryTable();
            DataSet BenefitDS = sd.GetBenefitSummary_V2(dtblAnalysisPlan, SessionId);
            WriteMedicalLOCTemplates.TemplateType TemplateType = wr.ConvertToTemplateType(ddlTemplateType.SelectedValue);
            switch (TemplateType)
            {
                case WriteMedicalLOCTemplates.TemplateType.FI_Single:
                    Download_FI_SingleTemplates(BenefitDS, dtblAnalysisPlan, ddlTierFactor.SelectedValue);
                    break;
                case WriteMedicalLOCTemplates.TemplateType.FI_Dual:
                    Download_FI_DualTemplates(BenefitDS, dtblAnalysisPlan, ddlTierFactor.SelectedValue);
                    break;
                case WriteMedicalLOCTemplates.TemplateType.FI_Triple:
                    Download_FI_TripleTemplates(BenefitDS, dtblAnalysisPlan, ddlTierFactor.SelectedValue);
                    break;
            }
        }
        private void Process_SFTemplates()
        {
            DropDownList ddlTemplateType = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTemplateType") as DropDownList;
            DropDownList ddlPlan1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan1") as DropDownList;
            DropDownList ddlPlan2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan2") as DropDownList;
            DropDownList ddlPlan3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlPlan3") as DropDownList;
            DropDownList ddlHRAHSA = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlHRAHSA") as DropDownList;
            DropDownList ddlStopLoss = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlStopLoss") as DropDownList;
            HiddenField hdnPlanTier = gvMedicalAnalysisPlans.Rows[0].FindControl("hdnPlanTier") as HiddenField;

            DropDownList ddlBenefitSummary1 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary1") as DropDownList;
            DropDownList ddlBenefitSummary2 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary2") as DropDownList;
            DropDownList ddlBenefitSummary3 = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummary3") as DropDownList;
            DropDownList ddlBenefitSummaryHRAHSA = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummaryHRAHSA") as DropDownList;
            DropDownList ddlBenefitSummaryStopLoss = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlBenefitSummaryStopLoss") as DropDownList;
            DropDownList ddlTierFactor = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlTierFactor") as DropDownList;
            DropDownList ddlFEI = gvMedicalAnalysisPlans.Rows[0].FindControl("ddlFEI") as DropDownList;

            DataTable dtblAnalysisPlan = CreateMedicalLOCDataTable();
            List<Plan> lstTempPlan = Session["PlanList"] as List<Plan>;
            int ProductId = 0;
            int BenefitSummaryId = 0;
            int.TryParse(ddlPlan1.SelectedValue, out ProductId);
            int.TryParse(ddlBenefitSummary1.SelectedValue, out BenefitSummaryId);
            Plan SelectedPlan1 = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();

            //First Row Plan
            DataRow dr1 = dtblAnalysisPlan.NewRow();
            dr1["RowNum"] = 1;
            dr1["TemplateType"] = ddlTemplateType.SelectedValue;
            dr1["PlanType"] = SelectedPlan1 != null ? SelectedPlan1.ProductTypeDescription : "";
            dr1["PlanName"] = SelectedPlan1 != null ? SelectedPlan1.UsiProductName : "";
            dr1["ProductID"] = ProductId;
            dr1["SelectedBenefitSummary"] = ddlBenefitSummary1.SelectedItem.Text;
            dr1["SummaryId"] = BenefitSummaryId;
            dr1["CarrierName"] = SelectedPlan1 != null ? SelectedPlan1.CarrierName : "";
            dr1["IsHRAorHSA"] = "NONE";
            dtblAnalysisPlan.Rows.Add(dr1);

            if (hdnPlanTier.Value == "2" || hdnPlanTier.Value == "3")
            {
                ProductId = 0;
                BenefitSummaryId = 0;
                int.TryParse(ddlPlan2.SelectedValue, out ProductId);
                int.TryParse(ddlBenefitSummary2.SelectedValue, out BenefitSummaryId);
                Plan SelectedPlan2 = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();
                DataRow dr2 = dtblAnalysisPlan.NewRow();
                dr2["RowNum"] = 2;
                dr2["TemplateType"] = ddlTemplateType.SelectedValue;
                dr2["PlanType"] = "";
                dr2["PlanName"] = "";
                dr2["ProductID"] = ProductId;
                dr2["SelectedBenefitSummary"] = "";
                dr2["SummaryId"] = BenefitSummaryId;
                dr2["CarrierName"] = "";
                dr2["IsHRAorHSA"] = "NONE";
                if (ddlPlan2.SelectedValue != "Select")
                {
                    dr2["TemplateType"] = ddlTemplateType.SelectedValue;
                    dr2["PlanType"] = SelectedPlan2 != null ? SelectedPlan2.ProductTypeDescription : "";
                    dr2["PlanName"] = SelectedPlan2 != null ? SelectedPlan2.UsiProductName : "";
                    dr2["ProductID"] = ProductId;
                    dr2["SelectedBenefitSummary"] = ddlBenefitSummary2.SelectedItem.Text;
                    dr2["SummaryId"] = BenefitSummaryId;
                    dr2["CarrierName"] = SelectedPlan2 != null ? SelectedPlan2.CarrierName : "";

                }
                dtblAnalysisPlan.Rows.Add(dr2);
            }
            if (hdnPlanTier.Value == "3")
            {
                ProductId = 0;
                BenefitSummaryId = 0;
                int.TryParse(ddlPlan3.SelectedValue, out ProductId);
                int.TryParse(ddlBenefitSummary3.SelectedValue, out BenefitSummaryId);
                Plan SelectedPlan3 = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();
                DataRow dr3 = dtblAnalysisPlan.NewRow();
                dr3["RowNum"] = 3;
                dr3["TemplateType"] = ddlTemplateType.SelectedValue;
                dr3["PlanType"] = "";
                dr3["PlanName"] = "";
                dr3["ProductID"] = ProductId;
                dr3["SelectedBenefitSummary"] = "";
                dr3["SummaryId"] = BenefitSummaryId;
                dr3["CarrierName"] = "";
                dr3["IsHRAorHSA"] = "NONE";
                if (ddlPlan2.SelectedValue != "Select")
                {
                    dr3["TemplateType"] = ddlTemplateType.SelectedValue;
                    dr3["PlanType"] = SelectedPlan3 != null ? SelectedPlan3.ProductTypeDescription : "";
                    dr3["PlanName"] = SelectedPlan3 != null ? SelectedPlan3.UsiProductName : "";
                    dr3["ProductID"] = ProductId;
                    dr3["SelectedBenefitSummary"] = ddlBenefitSummary3.SelectedItem.Text;
                    dr3["SummaryId"] = BenefitSummaryId;
                    dr3["CarrierName"] = SelectedPlan3 != null ? SelectedPlan3.CarrierName : "";

                }
                dtblAnalysisPlan.Rows.Add(dr3);
            }

            if (ddlBenefitSummaryHRAHSA.SelectedValue != "Select")
            {
                ProductId = 0;
                BenefitSummaryId = 0;
                int.TryParse(ddlHRAHSA.SelectedValue, out ProductId);
                int.TryParse(ddlBenefitSummaryHRAHSA.SelectedValue, out BenefitSummaryId);
                Plan SelectedHRAHSAPlan = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();

                DataRow drHRAHSA = dtblAnalysisPlan.NewRow();
                drHRAHSA["RowNum"] = 3;
                drHRAHSA["TemplateType"] = ddlTemplateType.SelectedValue;
                drHRAHSA["PlanType"] = SelectedHRAHSAPlan != null ? SelectedHRAHSAPlan.ProductTypeDescription : "";
                drHRAHSA["PlanName"] = ddlHRAHSA.SelectedItem.Text;
                drHRAHSA["ProductID"] = ProductId;
                drHRAHSA["SelectedBenefitSummary"] = ddlBenefitSummaryHRAHSA.SelectedItem.Text;
                drHRAHSA["SummaryId"] = BenefitSummaryId;
                drHRAHSA["CarrierName"] = SelectedHRAHSAPlan != null ? SelectedHRAHSAPlan.CarrierName : "";
                drHRAHSA["IsHRAorHSA"] = WriteMedicalLOCTemplates.HRA_PlanIDs.Contains(SelectedHRAHSAPlan.ProductTypeId) ? "HRA" : WriteMedicalLOCTemplates.HSA_PlanIDs.Contains(SelectedHRAHSAPlan.ProductTypeId) ? "HSA" : "NONE";
                dtblAnalysisPlan.Rows.Add(drHRAHSA);
            }

            sd.BuildBenefitSummaryTable();
            DataSet BenefitDS = sd.GetBenefitSummary_V2(dtblAnalysisPlan, SessionId);
            WriteMedicalLOCTemplates.TemplateType TemplateType = wr.ConvertToTemplateType(ddlTemplateType.SelectedValue);
            switch (TemplateType)
            {
                case WriteMedicalLOCTemplates.TemplateType.SF_Single:
                    Download_SF_SingleTemplates(BenefitDS, dtblAnalysisPlan, ddlTierFactor.SelectedValue, ddlFEI.SelectedValue);
                    break;
                case WriteMedicalLOCTemplates.TemplateType.SF_Dual:
                    Download_SF_DualTemplates(BenefitDS, dtblAnalysisPlan, ddlTierFactor.SelectedValue, ddlFEI.SelectedValue);
                    break;
                case WriteMedicalLOCTemplates.TemplateType.SF_Triple:
                    Download_SF_TripleTemplates(BenefitDS, dtblAnalysisPlan, ddlTierFactor.SelectedValue, ddlFEI.SelectedValue);
                    break;
            }
        }
        public void Download_FI_SingleTemplates(DataSet BenefitDS, DataTable dtblAnalysisPlan, string TierFactor)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/");
                myExcelApp.DisplayAlerts = false;

                object savefilename = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/"));
                }
                string SheetName = string.Empty;
                DateTime dtRenewalDate = GetDate(txtAnalysisRenewalDate.Text.Trim());
                DataRow drHRAHSA = dtblAnalysisPlan.Select("IsHRAorHSA <> 'NONE'").FirstOrDefault();
                if (ddlOrientation.SelectedValue == "Landscape")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "FI_Single_Plan2Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 39, 40 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                    }
                    if (TierFactor == "3 Tier")
                    {
                        myPath = myPath + "FI_Single_Plan3Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 15, 40, 41 };
                        wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "FI_Single_Plan4Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 43, 44 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                    }
                }
                else if (ddlOrientation.SelectedValue == "Portrait")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "FI_Single_Plan2Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        IList<int> HRAorHSARows = new List<int>() { 15, 38, 39 };
                        wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                    }
                    if (TierFactor == "3 Tier")
                    {
                        myPath = myPath + "FI_Single_Plan3Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 15, 40, 41 };
                        wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "FI_Single_Plan4Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 43, 44 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                    }
                }


                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());


                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public void Download_FI_DualTemplates(DataSet BenefitDS, DataTable dtblAnalysisPlan, string TierFactor)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/");
                myExcelApp.DisplayAlerts = false;

                object savefilename = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/"));
                }
                string SheetName = string.Empty;
                DateTime dtRenewalDate = GetDate(txtAnalysisRenewalDate.Text.Trim());
                DataRow drHRAHSA = dtblAnalysisPlan.Select("IsHRAorHSA <> 'NONE'").FirstOrDefault();
                if (ddlOrientation.SelectedValue == "Landscape")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "FI_Dual_Plan2Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 39, 40 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                        }
                    }
                    if (TierFactor == "3 Tier")
                    {
                        myPath = myPath + "FI_Dual_Plan3Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 41, 42 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                        }
                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "FI_Dual_Plan4Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 43, 44 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                        }
                    }
                }
                else if (ddlOrientation.SelectedValue == "Portrait")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "FI_Dual_Plan2Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 39, 40 };

                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                        }
                    }
                    if (TierFactor == "3 Tier")
                    {
                        myPath = myPath + "FI_Dual_Plan3Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 41, 42 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                        }
                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "FI_Dual_Plan4Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 43, 44 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                        }
                    }
                }


                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());


                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void Download_FI_TripleTemplates(DataSet BenefitDS, DataTable dtblAnalysisPlan, string TierFactor)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/");
                myExcelApp.DisplayAlerts = false;

                object savefilename = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/"));
                }
                string SheetName = string.Empty;
                DateTime dtRenewalDate = GetDate(txtAnalysisRenewalDate.Text.Trim());
                DataRow drHRAHSA = dtblAnalysisPlan.Select("IsHRAorHSA <> 'NONE'").FirstOrDefault();

                if (ddlOrientation.SelectedValue == "Landscape")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "FI_Triple_Plan2Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 39, 40 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7, 2);
                        }
                        if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8, 2);
                        }
                    }
                    if (TierFactor == "3 Tier")
                    {
                        myPath = myPath + "FI_Triple_Plan3Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 41, 42 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7, 2);
                        }
                        if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8, 2);
                        }
                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "FI_Triple_Plan4Tier_Land.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 43, 44 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7, 2);
                        }
                        if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8, 2);
                        }
                    }
                }
                else if (ddlOrientation.SelectedValue == "Portrait")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "FI_Triple_Plan2Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        IList<int> HRAorHSARows = new List<int>() { 16, 39, 40 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7, 2);
                        }
                        if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8, 2);
                        }
                    }
                    if (TierFactor == "3 Tier")
                    {
                        myPath = myPath + "FI_Triple_Plan3Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 41, 42 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7, 2);
                        }
                        if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8, 2);
                        }

                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "FI_Triple_Plan4Tier_Port.xlsx";
                        SheetName = "Medical";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        IList<int> HRAorHSARows = new List<int>() { 16, 43, 44 };
                        wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                        if (drHRAHSA != null)
                            wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                        else
                            wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                        if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7, 2);
                        }
                        if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                        {
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8, 2);
                        }

                    }
                }


                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());


                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public void Download_SF_SingleTemplates(DataSet BenefitDS, DataTable dtblAnalysisPlan, string TierFactor, string FieTier)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/");
                myExcelApp.DisplayAlerts = false;

                object savefilename = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/"));
                }
                string SheetName = string.Empty;
                DateTime dtRenewalDate = GetDate(txtAnalysisRenewalDate.Text.Trim());
                DataRow drHRAHSA = dtblAnalysisPlan.Select("IsHRAorHSA <> 'NONE'").FirstOrDefault();

                #region Landscape
                if (ddlOrientation.SelectedValue == "Landscape")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "SF_Single_Plan2Tier_Land.xlsx";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }
                    if (TierFactor == "Composite")
                    {
                        myPath = myPath + "SF_Single_PlanCompositeFactor_Land.xlsx";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }

                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "SF_Single_Plan4Tier_Land.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }
                    }
                }
                #endregion
                #region Potrait
                else if (ddlOrientation.SelectedValue == "Portrait")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "SF_Single_Plan2Tier_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }

                    }
                    if (TierFactor == "Composite")
                    {
                        myPath = myPath + "SF_Single_PlanCompositeFactor_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }

                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "SF_Single_Plan4Tier_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 4);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 4, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }
                #endregion
                }


                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());


                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void Download_SF_DualTemplates(DataSet BenefitDS, DataTable dtblAnalysisPlan, string TierFactor, string FieTier)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/");
                myExcelApp.DisplayAlerts = false;

                object savefilename = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/"));
                }
                string SheetName = string.Empty;
                DateTime dtRenewalDate = GetDate(txtAnalysisRenewalDate.Text.Trim());
                DataRow drHRAHSA = dtblAnalysisPlan.Select("IsHRAorHSA <> 'NONE'").FirstOrDefault();

                #region Landscape
                if (ddlOrientation.SelectedValue == "Landscape")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "SF_Dual_Plan2Tier_Land.xlsx";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 37, 38 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }
                    if (TierFactor == "Composite")
                    {

                        myPath = myPath + "SF_Dual_PlanCompositeFactor_Land.xlsx";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 37, 38 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }
                    if (TierFactor == "4 Tier")
                    {

                        myPath = myPath + "SF_Dual_Plan4Tier_Land.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 37, 38 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }

                    }
                }
                #endregion
                #region Potrait
                else if (ddlOrientation.SelectedValue == "Portrait")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "SF_Dual_Plan2Tier_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };

                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 37, 38 };

                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }

                    }
                    if (TierFactor == "Composite")
                    {
                        myPath = myPath + "SF_Dual_PlanCompositeFactor_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };

                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 37, 38 };

                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }

                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }

                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "SF_Dual_Plan4Tier_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };

                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 37, 38 };

                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 38, 39 };
                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 5);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 5, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);
                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 6);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6);
                            }
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }
                #endregion

                }

                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());


                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void Download_SF_TripleTemplates(DataSet BenefitDS, DataTable dtblAnalysisPlan, string TierFactor, string FieTier)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/");
                myExcelApp.DisplayAlerts = false;

                object savefilename = Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/MedicalLOC/Documents/Templates/ClientDetails/Downloads/"));
                }
                string SheetName = string.Empty;
                DateTime dtRenewalDate = GetDate(txtAnalysisRenewalDate.Text.Trim());
                DataRow drHRAHSA = dtblAnalysisPlan.Select("IsHRAorHSA <> 'NONE'").FirstOrDefault();
                #region Landscape
                if (ddlOrientation.SelectedValue == "Landscape")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "SF_Triple_Plan2Tier_Land.xlsx";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);



                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };

                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };

                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }

                    if (TierFactor == "Composite")
                    {
                        myPath = myPath + "SF_Triple_PlanCompositeFactor_Land.xlsx";
                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);



                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };

                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {


                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };

                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }
                    }
                    if (TierFactor == "4 Tier")
                    {


                        myPath = myPath + "SF_Triple_Plan4Tier_Land.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;
                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };

                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }

                    }
                }
                #endregion
                #region Potrait
                else if (ddlOrientation.SelectedValue == "Portrait")
                {
                    if (TierFactor == "2 Tier")
                    {
                        myPath = myPath + "SF_Triple_Plan2Tier_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };

                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };

                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }

                    }
                    if (TierFactor == "Composite")
                    {
                        myPath = myPath + "SF_Triple_PlanCompositeFactor_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 16, 36, 37 };
                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V1(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }

                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };

                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }

                    }
                    if (TierFactor == "4 Tier")
                    {
                        myPath = myPath + "SF_Triple_Plan4Tier_Port.xlsx";

                        myWorkbook = myExcelApp.Workbooks.Open(myPath);
                        myWorksheet = myWorkbook.ActiveSheet;

                        myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        if (FieTier == "2 Tier")
                        {
                            IList<int> HRAorHSARows = new List<int>() { 15, 35, 36 };

                            SheetName = "Medical FIE 2-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 2-Tier");
                            SfSheet.Add("Contributions 2-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                        if (FieTier == "3 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 36, 37 };
                            SheetName = "Medical FIE 3-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 3-Tier");
                            SfSheet.Add("Contributions 3-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);
                        }
                        if (FieTier == "4 Tier")
                        {

                            IList<int> HRAorHSARows = new List<int>() { 15, 37, 38 };

                            SheetName = "Medical FIE 4-Tier";
                            wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[0]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[0]["PlanName"].ToString(), dtblAnalysisPlan.Rows[0]["PlanType"].ToString(), dtblAnalysisPlan.Rows[0]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[0]["SummaryId"].ToString()), 6);
                            if (drHRAHSA != null)
                                wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 6, 2);
                            else
                                wr.DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetName, HRAorHSARows);

                            if (int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[1]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[1]["PlanName"].ToString(), dtblAnalysisPlan.Rows[1]["PlanType"].ToString(), dtblAnalysisPlan.Rows[1]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[1]["SummaryId"].ToString()), 7);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 7);
                            }
                            if (int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()) > 0)
                            {
                                wr.WriteMedicalBenefits_V2(myExcelApp, myWorkbook, SheetName, dtblAnalysisPlan.Rows[2]["CarrierName"].ToString(), ddlClient.SelectedItem.Text, dtblAnalysisPlan.Rows[2]["PlanName"].ToString(), dtblAnalysisPlan.Rows[2]["PlanType"].ToString(), dtblAnalysisPlan.Rows[2]["SelectedBenefitSummary"].ToString(), dtRenewalDate, BenefitDS, int.Parse(dtblAnalysisPlan.Rows[2]["SummaryId"].ToString()), 8);
                                if (drHRAHSA != null)
                                    wr.WriteHRAHSA(myExcelApp, myWorkbook, SheetName, BenefitDS, int.Parse(drHRAHSA["SummaryId"].ToString()), drHRAHSA["IsHRAorHSA"].ToString(), HRAorHSARows, 8);
                            }
                            SfSheet.Add("Medical FIE 4-Tier");
                            SfSheet.Add("Contributions 4-Tier");
                            wr.WriteMedicalBenefit_Fields(myExcelApp, myWorkbook, "Medical SL Detail", ddlClient.SelectedItem.Text, dtRenewalDate, SfSheet);

                        }
                    }
                #endregion

                }

                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());


                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}