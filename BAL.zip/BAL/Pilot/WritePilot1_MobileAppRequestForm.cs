﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;
using System.IO;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;

namespace BenefitPointSummaryPortal.BAL.Pilot
{
    public class WritePilot1_MobileAppRequestForm : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        //Added by Vaibhav for Mobile App 2 Report
        Hashtable htblPlanMobileAppPlanType = new Hashtable();
        //Added by Vaibhav for Mobile App 2 Report
        public WritePilot1_MobileAppRequestForm()
        {
            htblPlanMobileAppPlanType[5500] = "Accident";
            htblPlanMobileAppPlanType[270] = "AD&D Insurance";
            htblPlanMobileAppPlanType[320] = "Additional Plans";
            htblPlanMobileAppPlanType[1400] = "Cancer";
            htblPlanMobileAppPlanType[1160] = "Critical Illness";
            htblPlanMobileAppPlanType[210] = "Dental";
            htblPlanMobileAppPlanType[190] = "Dental";
            htblPlanMobileAppPlanType[200] = "Dental";
            htblPlanMobileAppPlanType[180] = "Dental";
            htblPlanMobileAppPlanType[310] = "EAP";
            htblPlanMobileAppPlanType[330] = "Flexible Spending Account";
            htblPlanMobileAppPlanType[1114] = "Group Legal";
            htblPlanMobileAppPlanType[178] = "Health Reimbursement Account";
            htblPlanMobileAppPlanType[5060] = "Hospitalization";
            htblPlanMobileAppPlanType[179] = "HSA";
            htblPlanMobileAppPlanType[3090] = "Identity Theft";
            htblPlanMobileAppPlanType[240] = "Life and AD&D";
            htblPlanMobileAppPlanType[250] = "Life Insurance";
            htblPlanMobileAppPlanType[1150] = "Life Insurance";
            htblPlanMobileAppPlanType[1230] = "Life Insurance";
            htblPlanMobileAppPlanType[1890] = "Long Term Care";
            htblPlanMobileAppPlanType[1115] = "Long Term Care";
            htblPlanMobileAppPlanType[300] = "Long Term Disability";
            htblPlanMobileAppPlanType[150] = "Medical";
            htblPlanMobileAppPlanType[160] = "Medical";
            htblPlanMobileAppPlanType[100] = "Medical";
            htblPlanMobileAppPlanType[170] = "Medical";
            htblPlanMobileAppPlanType[130] = "Medical";
            htblPlanMobileAppPlanType[140] = "Medical";
            htblPlanMobileAppPlanType[110] = "Medical";
            htblPlanMobileAppPlanType[120] = "Medical";
            htblPlanMobileAppPlanType[5825] = "Medical";
            htblPlanMobileAppPlanType[5340] = "Onsite Medical Clinic";
            htblPlanMobileAppPlanType[1720] = "Parking & Transit";
            htblPlanMobileAppPlanType[5460] = "Patient Advocacy";
            htblPlanMobileAppPlanType[1790] = "Patient Advocacy";
            htblPlanMobileAppPlanType[1480] = "Pet Insurance";
            htblPlanMobileAppPlanType[173] = "Prescription Drugs";
            htblPlanMobileAppPlanType[340] = "Retirement Plans";
            htblPlanMobileAppPlanType[294] = "Short Term Disability";
            htblPlanMobileAppPlanType[290] = "Short Term Disability";
            htblPlanMobileAppPlanType[230] = "Vision Insurance";
            htblPlanMobileAppPlanType[280] = "Vol AD&D";
            htblPlanMobileAppPlanType[260] = "Vol Life Insurance";
            htblPlanMobileAppPlanType[317] = "Wellness Program";

        }

        public void WriteFieldToPilot1_MobileAppRequestForm(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable PlanTable, string Office_Region)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();

                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;
                string SalesLead_EMail = string.Empty;
                string SalesLead_WorkPhone = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_EMail = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string AnalyticalSupport_FirstName = string.Empty;
                string AnalyticalSupport_LastName = string.Empty;
                string AnalyticalSupport_EMail = string.Empty;
                string AnalyticalSupport_WorkPhone = string.Empty;
                
                string website = string.Empty;
                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Required_5500 = string.Empty;
                string Broker_Of_Record = string.Empty;
                string Primary_Industry = string.Empty;
                string Num_Of_FTE = string.Empty;
                string Num_Of_FTE_AS_Of = string.Empty;
                string Num_Of_FTEquivalents = string.Empty;
                string Num_Of_FTEquivalents_AS_Of = string.Empty;
                string Num_Of_Retiree = string.Empty;
                string Num_Of_Retiree_As_Of = string.Empty;
                string BRC_Status = string.Empty;
                string BRC_Date_Implemented = string.Empty;

                List<string> MedicalPlanTypeList = new List<string>();

                MedicalPlanTypeList.Add("100");
                MedicalPlanTypeList.Add("110");
                MedicalPlanTypeList.Add("120");
                MedicalPlanTypeList.Add("130");
                MedicalPlanTypeList.Add("140");
                MedicalPlanTypeList.Add("150");
                MedicalPlanTypeList.Add("160");
                MedicalPlanTypeList.Add("170");
                MedicalPlanTypeList.Add("1116");


                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {


                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_website"])))
                                    {
                                        website = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_website"]);
                                    }
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }


                                }
                            }


                        }
                    }


                }

                #endregion


                #region MergeField
                string effectiveDate = string.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                        break;
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }
                        if (fieldName.Contains("USI_Office"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Office_Region.Trim());
                            continue;
                        }
                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }



                        if (fieldName.Contains("Primary Sales Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        //if (fieldName.Contains("Primary Sales Lead Email"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(SalesLead_EMail))
                        //    {
                        //        oWordApp.Selection.TypeText(SalesLead_EMail);
                        //    }
                        //    else
                        //    {
                        //        oWordApp.Selection.TypeText(" ");
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Primary Sales Lead Phone"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(SalesLead_WorkPhone))
                        //    {
                        //        oWordApp.Selection.TypeText(SalesLead_WorkPhone);
                        //    }
                        //    else
                        //    {
                        //        oWordApp.Selection.TypeText(" ");
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        //if (fieldName.Contains("Primary Service Lead Email"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(ServiceLead_EMail))
                        //    {
                        //        oWordApp.Selection.TypeText(ServiceLead_EMail);
                        //    }
                        //    else
                        //    {
                        //        oWordApp.Selection.TypeText(" ");
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Primary Service Lead Phone"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                        //    {
                        //        oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                        //    }
                        //    else
                        //    {
                        //        oWordApp.Selection.TypeText(" ");
                        //    }
                        //    continue;
                        //}


                    }
                }
                #endregion

                #region Write Table of Account Contacts
                Tools_Constant tc = new Tools_Constant();
                string accountInfo = string.Empty;
                int clmCnt = 2;
                string name = string.Empty;
                string title = string.Empty;
                string email = string.Empty;
                string phoneNumber = string.Empty;
                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    //clmCnt++;
                                    if (clmCnt > 1)
                                    {
                                        oWordDoc.Tables[5].Rows.Add();
                                    }
                                    if (clmCnt >= 1)
                                    {
                                        if (ContactList[i].Name != null)
                                        {
                                            name = ContactList[i].Name;
                                        }
                                        else
                                        {
                                            name = " ";
                                        }

                                        if (ContactList[i].Title != null)
                                        {
                                            title = ContactList[i].Title;
                                        }
                                        else
                                        {
                                            title = " ";
                                        }

                                        if (ContactList[i].Email != null)
                                        {
                                            email = ContactList[i].Email;
                                        }
                                        else
                                        {
                                            email = " ";
                                        }

                                        if (ContactList[i].Phone.Count > 0)
                                        {
                                            phoneNumber = ContactList[i].Phone[0];
                                        }
                                        else
                                        {
                                            phoneNumber = " ";
                                        }
                                        oWordDoc.Tables[5].Cell(clmCnt, 1).Range.Text = name;
                                        oWordDoc.Tables[5].Cell(clmCnt, 2).Range.Text = title;
                                        oWordDoc.Tables[5].Cell(clmCnt, 3).Range.Text = phoneNumber;
                                        oWordDoc.Tables[5].Cell(clmCnt, 4).Range.Text = email;
                                        oWordDoc.Tables[5].Cell(clmCnt, 5).Range.Text = website;
                                        clmCnt++;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion

                #region Write Table of PLans
                ArrayList PlanTypeList = new ArrayList();
                ArrayList CarrerNameList = new ArrayList();
                ArrayList PolicyNumberlist = new ArrayList();
                ArrayList effectiveList = new ArrayList();
                ArrayList RenewalList = new ArrayList();
                ArrayList Benefit_DescList = new ArrayList();
                ArrayList ContributionMethodList = new ArrayList();
                ArrayList FundingTypeList = new ArrayList();
                ArrayList NumberOfEmpList = new ArrayList();
                #region Plan Infor Code
                int rowCnt = 6;
                int m = 2;
                string PlanType = "";
                string FundingType = "";
                string Benefit_Desc = "";
                int tblPlanNo = 8;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    PlanType = dr["Name"].ToString().Replace("\r", "").Replace("\a", "").Trim();
                    //PlanTypeList.Add(PlanType);
                    CarrerNameList.Add(dr["Carrier"].ToString().Trim());
                    PolicyNumberlist.Add(dr["PolicyNumber"].ToString().Trim());
                    //effectiveList.Add(dr["Effective"].ToString().Trim());
                    //RenewalList.Add(dr["Renewal"].ToString().Trim());
                    //ContributionMethodList.Add(contributionMethod);
                    // FundingTypeList.Add(FundingType);
                    //Benefit_DescList.Add(Benefit_Desc);
                    //Benefit_DescList.Clear();
                    //NumberOfEmpList.Add(NoofELGEmployee);
                    if (rowCnt > 6)
                    {
                        oWordDoc.Tables[tblPlanNo].Rows.Add();
                        oWordDoc.Tables[tblPlanNo].Rows.Add();
                        oWordDoc.Tables[tblPlanNo].Rows.Add();
                        oWordDoc.Tables[tblPlanNo].Rows.Add();
                        oWordDoc.Tables[tblPlanNo].Rows.Add();
                        oWordDoc.Tables[tblPlanNo].Rows.Add();
                        oWordDoc.Tables[tblPlanNo].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineStyle = Word.WdLineStyle.wdLineStyleSingle;
                    }
                    oWordDoc.Tables[tblPlanNo].Cell(m, 1).Range.Text = dr["Name"].ToString().Trim();

                    oWordDoc.Tables[tblPlanNo].Cell(m, 2).Range.Text = "Carrier Name:";
                    oWordDoc.Tables[tblPlanNo].Cell(m, 2).Range.Bold = 1;
                    oWordDoc.Tables[tblPlanNo].Cell(m + 1, 2).Range.Text = dr["Carrier"].ToString().Trim();
                    oWordDoc.Tables[tblPlanNo].Cell(m + 3, 2).Range.Text = "Policy Number:";
                    oWordDoc.Tables[tblPlanNo].Cell(m + 3, 2).Range.Bold = 1;
                    oWordDoc.Tables[tblPlanNo].Cell(m + 4, 2).Range.Text = dr["PolicyNumber"].ToString().Trim();
                    CallRowDropDown(oWordDoc, m);
                    CallRowDropDown(oWordDoc, m + 1);
                    CallRowDropDown(oWordDoc, m + 2);
                    CallRowDropDown(oWordDoc, m + 3);
                    CallRowDropDown(oWordDoc, m + 4);
                    CallRowDropDown(oWordDoc, m + 5);
                    m = m + 6;
                    rowCnt++;
                }
                #endregion

                #region Code for Merging the rows
                #region Code for  Row color
                /*For Row color */

                Color rowsColor_6 = Color.FromArgb(217, 226, 243);
                int rgb_Rows6 = ColorTranslator.ToOle(rowsColor_6);
                Word.WdColor wdColor_rows6 = (Word.WdColor)rgb_Rows6;

                int cnt = 2;
                for (int rowNum = 2; rowNum <= oWordDoc.Tables[tblPlanNo].Rows.Count; rowNum++)
                {
                    if (cnt <= rowNum)
                    {
                        oWordDoc.Tables[tblPlanNo].Rows[cnt].Range.Shading.BackgroundPatternColor = wdColor_rows6;
                        oWordDoc.Tables[tblPlanNo].Rows[cnt + 1].Range.Shading.BackgroundPatternColor = wdColor_rows6;
                        oWordDoc.Tables[tblPlanNo].Rows[cnt + 2].Range.Shading.BackgroundPatternColor = wdColor_rows6;
                        oWordDoc.Tables[tblPlanNo].Rows[cnt + 3].Range.Shading.BackgroundPatternColor = wdColor_rows6;
                        oWordDoc.Tables[tblPlanNo].Rows[cnt + 4].Range.Shading.BackgroundPatternColor = wdColor_rows6;
                        oWordDoc.Tables[tblPlanNo].Rows[cnt + 5].Range.Shading.BackgroundPatternColor = wdColor_rows6;
                        // to skip next 6 rows...
                        rowNum = rowNum + 11;
                        cnt = rowNum + 1;
                    }
                }
                #endregion
                #region Code for First Coloumn Merging
                int rowCntVar = oWordDoc.Tables[tblPlanNo].Rows.Count;
                /*For First Coloumn*/
                for (int rowNum = 2; rowNum <= oWordDoc.Tables[tblPlanNo].Rows.Count; rowNum++)
                {
                    if (rowNum % 6 == 0)
                    {
                        oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1, 1).Merge(oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 1, 1));
                        oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 1, 1).Merge(oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 2, 1));
                        oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 2, 1).Merge(oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 3, 1));
                        oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 3, 1).Merge(oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 4, 1));
                        oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 4, 1).Merge(oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 5, 1));
                    }
                }
                #endregion
                #region Code for Second Coloumn Merging
                /*For Second Coloumn*/
                for (int rowNum = 2; rowNum <= rowCntVar; rowNum++)
                {
                    if (rowNum % 3 == 0)
                    {
                        oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1, 2).Merge(oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 1, 2));
                        oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 1, 2).Merge(oWordDoc.Tables[tblPlanNo].Cell(rowNum + 1 - 2, 2));

                    }
                    rowCntVar = oWordDoc.Tables[tblPlanNo].Rows.Count;
                }
                #endregion
                #endregion

                oWordDoc.Tables[9].Delete();
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void CallRowDropDown(Word.Document oWordDoc, int i)
        {
            Range range = oWordDoc.Tables[8].Cell(i, 3).Range;
            range.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range);
            foreach (Word.ContentControl drpdown in range.ContentControls)
            {
                drpdown.DropdownListEntries.Clear();
               
                drpdown.DropdownListEntries.Add("Phone", "first", 1);
                drpdown.DropdownListEntries.Add("E-mail", "second", 2);
                drpdown.DropdownListEntries.Add("Website", "third", 3);
                Marshal.ReleaseComObject(drpdown);
            }
        }
        #region Added by Vaibhav for New Development Request - Mobile App Form v2
        public void Write_RequestDetails_VideoAttachment_DetailsToMobileApp_V2(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataSet AccountTeamMemberDS, string Office_Regions, string IncludeBrainshark, string BrainsharkName, string BrainsharkLink, string IncldeDocument)
        {
            object missing = System.Type.Missing;
            Write_Field_Header(oWordDoc, oWordApp, ddlClient);
            #region For Address and Phone Number - Team Members
            string ServiceLead_FirstName = string.Empty;
            string ServiceLead_LastName = string.Empty;
            string SalesLead_FirstName = string.Empty;
            string SalesLead_LastName = string.Empty;

            if (AccountDS != null)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }
                    }

                }

            }
            #endregion

            #region Brainshark Link

            if (IncludeBrainshark.ToLower() == "yes")
            {
                oWordDoc.Tables[5].Cell(1, 2).Range.Text = "Yes";
                oWordDoc.Tables[5].Cell(1, 3).Range.Text = BrainsharkName;
                if (BrainsharkLink.Trim() != string.Empty)
                {
                    Microsoft.Office.Interop.Word.Hyperlinks Links = oWordDoc.Hyperlinks;
                    Range UrlRange = oWordDoc.Tables[5].Cell(1, 4).Range;
                    object linkAddr = BrainsharkLink;
                    Microsoft.Office.Interop.Word.Hyperlink myLink = Links.Add(UrlRange, ref linkAddr, ref missing);
                    myLink.Range.Font.Name = "Calibri (Body)";
                    myLink.Range.Font.Size = 10f;
                }
            }
            else
            {
                oWordDoc.Tables[5].Cell(1, 2).Range.Text = "No";
            }

            if (IncldeDocument.ToLower() == "yes")
            {
                oWordDoc.Tables[6].Cell(1, 2).Range.Text = "Yes";
            }
            else
            {
                oWordDoc.Tables[6].Cell(1, 2).Range.Text = "No";
            }


            #endregion

            #region MergeField
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Primary Service Lead Name"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                        {
                            oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("Office"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(Office_Regions);
                        continue;
                    }
                    if (fieldName.Contains("ClientName"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                        continue;
                    }
                    if (fieldName.Contains("Primary Sales Lead Name"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                        {
                            oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("Sysdate"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                        continue;
                    }
                }
            }
            #endregion
        }

        public void Write_SelectedVideos_V2(Word.Document oWordDoc, Word.Application oWordApp, DataTable dtblVideos)
        {
            object missing = System.Type.Missing;
            if (dtblVideos.Rows.Count > 0)
            {
                oWordDoc.Tables[4].Rows[2].Range.Copy();
                if (dtblVideos.Rows.Count > 1)
                {
                    for (int row = 1; row < dtblVideos.Rows.Count; row++)
                    {
                        oWordDoc.Tables[4].Rows[oWordDoc.Tables[4].Rows.Count].Range.Paste();
                    }

                }
                int tableRow = 2;
                for (int row = 0; row < dtblVideos.Rows.Count; row++)
                {
                    oWordDoc.Tables[4].Cell(tableRow, 1).Range.Text = dtblVideos.Rows[row]["VideoName"].ToString();
                    oWordDoc.Tables[4].Cell(tableRow, 2).Range.Text = dtblVideos.Rows[row]["VideoLocationName"].ToString();
                    oWordDoc.Tables[4].Cell(tableRow, 3).Range.Text = dtblVideos.Rows[row]["Language"].ToString();
                    if (dtblVideos.Rows[row]["URL"].ToString().Trim() != string.Empty)
                    {
                        Range urlRange = oWordDoc.Tables[4].Cell(tableRow, 4).Range;
                        //Add URL of Video
                        Microsoft.Office.Interop.Word.Hyperlinks Links = oWordDoc.Hyperlinks;
                        object linkAddr = dtblVideos.Rows[row]["URL"].ToString();
                        Microsoft.Office.Interop.Word.Hyperlink myLink = Links.Add(urlRange, ref linkAddr, ref missing);
                        myLink.Range.Font.Name = "Calibri (Body)";
                        myLink.Range.Font.Size = 10f;
                    }
                    tableRow++;
                }
            }
        }

        public void Write_PlansProductDetails_V2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable PlanTable)
        {
            object missing = System.Type.Missing;
            oWordDoc.Bookmarks[1].Range.Copy();
            for (int i = 1; i < PlanInfoTable.Rows.Count; i++)
            {
                oWordDoc.Bookmarks[1].Range.Fields[oWordDoc.Bookmarks[1].Range.Fields.Count].Select();
                oWordApp.Selection.Paste();
            }

            int tableStartCount = 7;
            foreach (DataRow dr in PlanInfoTable.Rows)
            {
                string PlanType = Convert.ToString(dr["Name"]).Replace("&amp;", "&"); ;
                string CarrierName = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                string PolicyNumber = Convert.ToString(dr["PolicyNumber"]);
                string MobileAppPlanType = string.Empty;

                if (htblPlanMobileAppPlanType.ContainsKey(int.Parse(dr["ProductTypeId"].ToString())))
                {
                    MobileAppPlanType = htblPlanMobileAppPlanType[int.Parse(dr["ProductTypeId"].ToString())].ToString();
                }


                if (!string.IsNullOrEmpty(PlanType))
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 1).Range.Fields[1].Select();
                    oWordApp.Selection.TypeText(PlanType); ;
                }
                else
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 1).Range.Fields[1].Delete();
                }

                if (!string.IsNullOrEmpty(MobileAppPlanType))
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 2).Range.Fields[1].Select();
                    oWordApp.Selection.TypeText(MobileAppPlanType); ;
                }
                else
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 2).Range.Fields[1].Delete();
                }

                if (!string.IsNullOrEmpty(CarrierName))
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 3).Range.Fields[1].Select();
                    oWordApp.Selection.TypeText(CarrierName);
                }
                else
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 3).Range.Fields[1].Delete();
                }

                if (!string.IsNullOrEmpty(PolicyNumber))
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 4).Range.Fields[1].Select();
                    oWordApp.Selection.TypeText(PolicyNumber);
                }
                else
                {
                    oWordDoc.Tables[tableStartCount].Cell(1, 4).Range.Fields[1].Delete();
                }




                tableStartCount++;
            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("pqr"))
                    {
                        myMergeField.Delete();
                        continue;
                    }
                }
            }
        }

        public void Write_ResourceDetails_V2(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, ArrayList arrAcctContact)
        {
            #region Write Table of Account Contacts
            string name = string.Empty;
            string email = string.Empty;
            int clmCnt = 1;
            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    oWordDoc.Tables[3].Rows[4].Range.Copy();
                    for (int row = 1; row < arrAcctContact.Count; row++)
                    {
                        oWordDoc.Tables[3].Rows[oWordDoc.Tables[3].Rows.Count].Range.Paste();
                    }

                    for (int row = 0; row < arrAcctContact.Count; row++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[row].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].Name != null)
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 1).Range.Fields[1].Select();
                                    oWordApp.Selection.TypeText(ContactList[i].Name);
                                }
                                else
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 1).Range.Fields[1].Delete();
                                }

                                if (ContactList[i].Title != null && ContactList[i].Title != string.Empty)
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 2).Range.Fields[1].Select();
                                    oWordApp.Selection.TypeText(ContactList[i].Title);
                                }
                                else
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 2).Range.Fields[1].Delete();
                                }

                                if (ContactList[i].Phone != null && ContactList[i].Phone.Count() > 0)
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 3).Range.Fields[1].Select();
                                    oWordApp.Selection.TypeText(ContactList[i].Phone[0].Trim());
                                }
                                else
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 3).Range.Fields[1].Delete();
                                }

                                if (ContactList[i].Email != null)
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 4).Range.Fields[1].Select();
                                    oWordApp.Selection.TypeText(ContactList[i].Email);
                                }
                                else
                                {
                                    oWordDoc.Tables[3].Cell(row + 4, 4).Range.Fields[1].Delete();
                                }

                                clmCnt++;
                            }
                        }
                    }
                }
                else
                {
                    oWordDoc.Tables[3].Cell(4, 1).Range.Fields[1].Delete();
                    oWordDoc.Tables[3].Cell(4, 2).Range.Fields[1].Delete();
                    oWordDoc.Tables[3].Cell(4, 3).Range.Fields[1].Delete();
                    oWordDoc.Tables[3].Cell(4, 4).Range.Fields[1].Delete();
                }
            }
            else
            {
                oWordDoc.Tables[3].Cell(4, 1).Range.Fields[1].Delete();
                oWordDoc.Tables[3].Cell(4, 2).Range.Fields[1].Delete();
                oWordDoc.Tables[3].Cell(4, 3).Range.Fields[1].Delete();
                oWordDoc.Tables[3].Cell(4, 4).Range.Fields[1].Delete();
            }

            #endregion
        }

        public void Write_Field_Header(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("ClientName"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                continue;
                            }
                        }
                    }
                }
            }

        }

        public void Write_ClientProfileDetails_V2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable PlanTable)
        {
            List<string> MedicalPlanTypeList = new List<string>();

            MedicalPlanTypeList.Add("100");
            MedicalPlanTypeList.Add("110");
            MedicalPlanTypeList.Add("120");
            MedicalPlanTypeList.Add("130");
            MedicalPlanTypeList.Add("140");
            MedicalPlanTypeList.Add("150");
            MedicalPlanTypeList.Add("160");
            MedicalPlanTypeList.Add("170");
            MedicalPlanTypeList.Add("1116");
            string effectiveDate = string.Empty;
            string renewalDate = string.Empty;
            if (PlanInfoTable.Rows.Count > 0)
            {
                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());

                        renewalDate = Convert.ToString(dr["Renewal"]);
                        renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                        break;
                    }
                }

                #region MergeField
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("EffectiveDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate) || !string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("RenewalDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate) || !string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion

            }

        }

        #endregion
    }
}