﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using BenefitPointSummaryPortal.DAL;

namespace BenefitPointSummaryPortal.BAL.OfficeAddress
{
    public class OfficeAddressOperations
    {
        DBHelper DB_helper = new DBHelper();
        /// <summary>
        /// Delete Office address Details from datadase BPPortal by id .
        /// </summary>
        /// <returns>Office name</returns>
        public bool DeleteOfficeAddressDetails(int srNo)
        {
            bool IsSuccess = false;
            try
            {
                // IsActive = false;                
                string flag = "Delete";
                SqlParameter[] parameters = { new SqlParameter("@SRNo ", SqlDbType.NVarChar), new SqlParameter("@op ", SqlDbType.NVarChar) };
                parameters[0].Value = srNo;
                parameters[1].Value = flag;
                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteOfficeAddressDetails", parameters);
                IsSuccess = bool.Parse(dtblResult.Rows[0]["IsSuccess"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return IsSuccess;
        }

        public DataTable SearchOfficeAddress(string Region, string City, string State)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@BPRegion", SqlDbType.NVarChar, 500), new SqlParameter("@City", SqlDbType.NVarChar, 500), new SqlParameter("@State", SqlDbType.NVarChar, 500) };
                parameters[0].Value = Region;
                parameters[1].Value = City;
                parameters[2].Value = State;
                DataTable dtblOfficeAddress = DB_helper.ExecProcedure("GetSearchOfficeAddressDetailsData", parameters);
                return dtblOfficeAddress;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        public bool InsertUpdateOfficeAddressDetails(int SRNo, int DivNo, string BPRegion, string BPOfficeName, string DivisionName, string OfficStreetAdd, string City, string State, string Zip, string OfficPhoneNo, string OfficFaxNo)
        {
            bool IsSuccess = false;
            try
            {
                string flag = "Insert";
                if (SRNo > 0)
                    flag = "Update";
                SqlParameter[] parameters = { 
                                                new SqlParameter("@DIVNO ", SqlDbType.Int), 
                                                new SqlParameter("@BPRegion ", SqlDbType.NVarChar), 
                                                new SqlParameter("@BPOfficeName", SqlDbType.NVarChar), 
                                                new SqlParameter("@DivName", SqlDbType.NVarChar), 
                                                new SqlParameter("@OffStreetAdd", SqlDbType.NVarChar), 
                                                new SqlParameter("@City", SqlDbType.NVarChar), 
                                                new SqlParameter("@State", SqlDbType.NVarChar), 
                                                new SqlParameter("@Zip", SqlDbType.NVarChar), 
                                                new SqlParameter("@OffPhoneNumber", SqlDbType.NVarChar), 
                                                new SqlParameter("@OfficeFaxNumber ", SqlDbType.NVarChar), 
                                                new SqlParameter("@op ", SqlDbType.NVarChar), 
                                                new SqlParameter("@SRNo ", SqlDbType.Int)
                                                
                                            
                 
                                            };
                if (DivNo == 0)
                {
                    parameters[0].Value = DBNull.Value;
                }
                else
                    parameters[0].Value = DivNo;

                parameters[1].Value = BPRegion;
                parameters[2].Value = BPOfficeName;
                parameters[3].Value = DivisionName;
                parameters[4].Value = OfficStreetAdd;
                parameters[5].Value = City;
                parameters[6].Value = State;
                parameters[7].Value = Zip;
                parameters[8].Value = OfficPhoneNo;
                parameters[9].Value = OfficFaxNo;
                parameters[10].Value = flag;
                parameters[11].Value = SRNo;

                //DB_helper.ExecProc("InsertOfficeAddressDetails", parameters);
                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteOfficeAddressDetails", parameters);
                IsSuccess = bool.Parse(dtblResult.Rows[0]["IsSuccess"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return IsSuccess;
        }

        public DataTable GetOfficeAddressById(int srNo)
        {
            DataTable dtbl = new DataTable();
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@srNo ", SqlDbType.NVarChar) };
                parameters[0].Value = srNo;
                dtbl = DB_helper.ExecProcedure("GetOfficeAddressDetailsDatabyId", parameters);//("select Office_name from dbo.BROKER_OFFICE");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtbl;
        }

        public DataTable GetOfficeStateCities(string State)
        {
            DataTable dtblCities = new DataTable();
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@State", SqlDbType.NVarChar, 100) };
                parameters[0].Value = State;
                dtblCities = DB_helper.ExecProcedure("Proc_GetStateCity", parameters);//("select Office_City using selected state from dbo.USIOfficeAddressListing");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblCities;
        }
    }
}