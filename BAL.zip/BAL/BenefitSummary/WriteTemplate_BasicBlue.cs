﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_BasicBlue : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        static Dictionary<string, Dictionary<string, string>> AllBookmarks = new Dictionary<string, Dictionary<string, string>>();

        List<int> Medical_BenefitColumn_Level1 = new List<int>() { 100, 101, 103, 106, 108, 111, 112, 114 };
        List<int> Medical_BenefitColumn_Level2 = new List<int>() { 113, 109, 107, 104, 102 };
        List<int> Medical_BenefitColumn_Level3 = new List<int>() { 105, 110 };

        List<int> Dental_BenefitColumn_Level3 = new List<int>() { 120 };
        List<int> Dental_BenefitColumn_Level2 = new List<int>() { 119, 117 };
        List<int> Dental_BenefitColumn_Level1 = new List<int>() { 115, 116, 118, 121 };
        List<string> listPlan = new List<string>();
        List<int> lstPlanTier = new List<int>();
        bool IsSTDExists = false;
        bool IsIsLTDExists = false;
        public void WriteMedicalSectionToTemplateBasicBlue_v1(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DropDownList ddlClient, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet EligibilityDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            lstPlanTier.Clear();
            listPlan.Add("Medical");
            List<int> SkippedRowIndexes = new List<int>() { 3, 7, 10, 13, 16, 23, 26, 29 };
            List<int> PharmacySkippedRowIndex = new List<int>() { 1, 2, 7 };
            getBookmarks();

            string Renewaldate = string.Empty;
            string Effectivedate = string.Empty;
            DataTable Emp = new DataTable();
            Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();


            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }
            int TablesUsed = 1;
            int CurrentColumnIndex = 2;
            int CurrentTableIndex = 3;
            int WriteCount = 0;
            int ColumnIncreament = 0;
            int RemainingBenefitCount = 3;
            int HeaderColumnIndex = 2;
            List<int> Contributions = new List<int>();
            string strAllCarriers = "";
            string FirstRenewalDate = string.Empty;
            string FirstEffectiveDate = string.Empty;
            string GlobalCarrier = string.Empty;
            float PharmacyFullTableWidth = 0;
            float PharmacyTableAttributeColumnsWidth = 0;
            float MedicalFullTableWidth = 0;
            float MedicalTableAttributeColumnsWidth = 0;

            foreach (string PlanTypeDescription in dictMap.Keys)
            {
                if (PlanTypeDescription == "Medical PPO")
                {
                    if (AllBookmarks["Medical"].ContainsKey("MedicalPPODescription1"))      //MedicalHMODescription1  MedicalPPODescription1
                    {
                        AllBookmarks["Medical"].Remove("MedicalPPODescription1");
                    }
                }
                else if (PlanTypeDescription == "Medical HMO")
                {
                    if (AllBookmarks["Medical"].ContainsKey("MedicalHMODescription1"))      //MedicalHMODescription1  MedicalPPODescription1
                    {
                        AllBookmarks["Medical"].Remove("MedicalHMODescription1");
                    }
                }

                foreach (int key in dictMap[PlanTypeDescription].Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    Renewaldate = drPlanRow["Renewal"].ToString();
                    Effectivedate = drPlanRow["Effective"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();
                    GlobalCarrier = Carrier;
                    if (string.IsNullOrEmpty(FirstRenewalDate))
                    {
                        FirstRenewalDate = Renewaldate;
                        FirstEffectiveDate = Effectivedate;
                    }

                    List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                    int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        lstPlanTier.Add(PlanTier);
                        WriteCount++;
                        RemainingBenefitCount--;

                        switch (PlanTier)
                        {
                            case 1:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 3, int.MaxValue, SkippedRowIndexes);
                                //Pharmacy Table
                                MergeTableColumns(oWordDoc, CurrentTableIndex + 1, CurrentColumnIndex, CurrentColumnIndex + 2, 1, int.MaxValue, PharmacySkippedRowIndex);
                                ColumnIncreament = 1;
                                break;
                            case 2:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 3, int.MaxValue, SkippedRowIndexes);
                                //Pharmacy Table
                                MergeTableColumns(oWordDoc, CurrentTableIndex + 1, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 1, int.MaxValue, PharmacySkippedRowIndex);
                                ColumnIncreament = 2;
                                break;
                            case 3:
                                ColumnIncreament = 3;
                                break;
                        }
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                        string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                        string AnnualDeductibleFamily = "";
                        string OfficeVisitExam = "";
                        string AttributeValue = "";
                        oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                        string strFieldText = "a " + ProduTypeDescription + " through " + Carrier;

                        if (string.IsNullOrEmpty(strAllCarriers))
                            strAllCarriers = strFieldText;
                        else
                        {
                            if (!strAllCarriers.Contains(strFieldText))
                                strAllCarriers = strAllCarriers + ", " + strFieldText;
                        }


                        #region Write Benifit Attribute
                        #region Benefits Coverage

                        #region Annual Deductible Individual - 4
                        //In Network
                        DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkIndividual != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                            int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkIndividual["benefitColumnID"].ToString());
                            string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                            oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex).Range.Text = ColumnNameLevel1;
                        }

                        oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                                int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkIndividual["benefitColumnID"].ToString());
                                string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                                oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 1).Range.Text = ColumnNameLevel2;
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Individual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                                    int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3Individual["benefitColumnID"].ToString());
                                    string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                    oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 2).Range.Text = ColumnNameLevel3;
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }

                        }
                        // Out Network

                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Family - 5
                        //In Network
                        DataRow drBenefitValues_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkFamily != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                            AnnualDeductibleFamily = AttributeValue;
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Family != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Family);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Coinsurance - 6
                        //In Network
                        DataRow drBenefitValues_InNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkCoinsurance != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkCoinsurance);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkCoinsurance != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkCoinsurance);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Coinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Coinsurance != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Coinsurance);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Maximum Pocket Individual - 8
                        //In Network
                        DataRow drBenefitValues_InNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPockIndividual != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPockIndividual);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPockIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPockIndividual);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Individual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Maximum Pocket Family - 9
                        //In Network
                        DataRow drBenefitValues_InNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPockFamily != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPockFamily);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPockFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPockFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3PockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3PockFamily != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PockFamily);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit -Primary Care -11
                        DataRow drBenefitValues_InNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPhysicalOfficePrimaryCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficePrimaryCare);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPhysicalOfficePrimaryCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficePrimaryCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3PhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3PhysicalOfficePrimaryCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PhysicalOfficePrimaryCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit -Specialty Care - 12
                        //In Network
                        DataRow drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Leve3PhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Leve3PhysicalOfficeSpecialtyCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3PhysicalOfficeSpecialtyCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit - Preventive Adult Periodic Exams - 14
                        //In Network
                        DataRow drBenefitValues_InNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPreventiveAdultPeriodicExams != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPreventiveAdultPeriodicExams);
                            OfficeVisitExam = AttributeValue;
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPreventiveAdultPeriodicExams != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveAdultPeriodicExams);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3PreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3PreventiveAdultPeriodicExams != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PreventiveAdultPeriodicExams);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit - Preventive Well-Child Care - 15
                        //InNetwork
                        DataRow drBenefitValues_InNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPreventiveWellChildCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPreventiveWellChildCare);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPreventiveWellChildCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveWellChildCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Leve3PreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Leve3PreventiveWellChildCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3PreventiveWellChildCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - X-ray and Lab Tests = 17
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticXrayLabTest != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticXrayLabTest);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticXrayLabTest != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticXrayLabTest);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_level3DisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_level3DisgnisticXrayLabTest != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_level3DisgnisticXrayLabTest);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Complex Radiology = 18
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticComplexRadiology != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticComplexRadiology);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticComplexRadiology != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticComplexRadiology);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_level3DisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_level3DisgnisticComplexRadiology != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_level3DisgnisticComplexRadiology);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Urgent Care Facility - 19
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - EmergencyRoom - 20
                        //InNetwork
                        DataRow drBenefitValues_InNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkEmrgRoomFacilityCharge != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkEmrgRoomFacilityCharge);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkEmrgRoomFacilityCharge != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkEmrgRoomFacilityCharge);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Leve3EmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Leve3EmrgRoomFacilityCharge != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3EmrgRoomFacilityCharge);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Inpatient Facility Charges - 21
                        //InNetwork
                        DataRow drBenefitValues_InNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkInpatientFacilityCharges != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkInpatientFacilityCharges);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkInpatientFacilityCharges != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkInpatientFacilityCharges);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3InpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3InpatientFacilityCharges != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3InpatientFacilityCharges);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Outpatient Facility and Surgical Charges- 22
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutpatientFacilityandSurgicalCharges != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientFacilityandSurgicalCharges);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Mental Health - Inpatient - 24
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalHealthInpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthInpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalHealthInpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthInpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3MentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3MentalHealthInpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalHealthInpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mental Health - Inpatient - 25
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalHealthOutpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthOutpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalHealthOutpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthOutpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValuesLevel3MentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValuesLevel3MentalHealthOutpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValuesLevel3MentalHealthOutpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Substance Abuse - Inpatient - 27
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalSubAbuseInpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseInpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalSubAbuseInpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseInpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3MentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3MentalSubAbuseInpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseInpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Substance Abuse - Outpatient - 28
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalSubAbuseOutpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseOutpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalSubAbuseOutpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseOutpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3MentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3MentalSubAbuseOutpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseOutpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Other Services - Chiropractic - 30
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOtherServiceChiropractic != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOtherServiceChiropractic);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOtherServiceChiropractic != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOtherServiceChiropractic);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OtherServiceChiropractic != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OtherServiceChiropractic);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion
                        #endregion
                        #endregion
                        #region PharmacySesion

                        #region Retail Pharmacy (30 Day Supply)- Generic (Tier 1)- 3
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutpatientGenericFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientGenericFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(3, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutpatientGenericFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientGenericFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(3, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutpatientGenericFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientGenericFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(3, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Retail Pharmacy (30 Day Supply)- Preferred (Tier 2)- 4
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(4, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(4, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Retail Pharmacy (30 Day Supply)- Non-Preferred (Tier 3)- 5
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutNonPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutNonPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutpatientNonPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientNonPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(5, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutpatientNonPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientNonPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(5, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Retail Pharmacy (30 Day Supply)- Preferred Specialty (Tier 4)- 6
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutPreferredSpecialtyFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredSpecialtyFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(6, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(6, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_LEVEL3OutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_LEVEL3OutPreferredSpecialtyFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_LEVEL3OutPreferredSpecialtyFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(6, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }

                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Generic (Tier 1)- 8
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderGenericFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderGenericFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderGenericFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderGenericFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(8, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderGenericFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderGenericFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(8, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Preferred (Tier 2)- 9
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(9, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(9, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Non-Preferred (Tier 3)- 10
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderNonPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderNonPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(10, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(10, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderNonPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderNonPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(10, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Preferred Specialty (Tier 4)- 11
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex + 1].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex + 1].Cell(11, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex + 1].Cell(11, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #endregion

                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedicalBenefit" + WriteCount, SummaryName);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedicaPlanType" + WriteCount, ProduTypeDescription);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedicalCarrier" + WriteCount, Carrier);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedAnnualDedFamily" + WriteCount, AnnualDeductibleFamily);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedOfficeVisitExam" + WriteCount, OfficeVisitExam);

                        CurrentColumnIndex += ColumnIncreament;
                        HeaderColumnIndex += 1;
                        List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                        WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 2, Carrier, SummaryName, ContributionCollection, ContributionDS);

                        string bookmark = "MedicalPlanTables" + CurrentTableIndex.ToString();     // MedicalPlanTables1, MedicalPlanTables2 etc....
                        if (AllBookmarks["Medical"].ContainsKey(bookmark))
                        {
                            AllBookmarks["Medical"].Remove(bookmark);
                        }

                        string ForntPagebookmark = "FrontPageMedPlan" + WriteCount.ToString();     // MedicalPlanTables1, MedicalPlanTables2 etc....
                        if (AllBookmarks["Medical"].ContainsKey(ForntPagebookmark))
                        {
                            AllBookmarks["Medical"].Remove(ForntPagebookmark);
                        }

                        if (AllBookmarks["Medical"].ContainsKey("MedicalPlanTables" + TablesUsed))      //MedicalHMODescription1  MedicalPPODescription1
                        {
                            AllBookmarks["Medical"].Remove("MedicalPlanTables" + TablesUsed);
                        }
                        MedicalFullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                        MedicalTableAttributeColumnsWidth = MedicalFullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;

                        PharmacyFullTableWidth = oWordDoc.Tables[CurrentTableIndex + 1].Cell(2, 1).Width;
                        PharmacyTableAttributeColumnsWidth = PharmacyFullTableWidth - oWordDoc.Tables[CurrentTableIndex + 1].Cell(3, 1).Width;

                        if (WriteCount % 3 == 0)
                        {
                            AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, MedicalTableAttributeColumnsWidth);//409.5f
                            AdjustCellWidth(oWordDoc, CurrentTableIndex + 1, lstPlanTier, PharmacySkippedRowIndex, PharmacyTableAttributeColumnsWidth);
                            oWordDoc.Tables[CurrentTableIndex + 2].Rows[2].Delete();

                            CurrentColumnIndex = 2;
                            HeaderColumnIndex = 2;
                            CurrentTableIndex += 3;
                            RemainingBenefitCount = 3;
                            TablesUsed += 1;
                            lstPlanTier.Clear();
                        }
                    }

                }

            }

            if (RemainingBenefitCount != 3)
            {
                int BodyMergeStartIndex = CurrentColumnIndex - 1;
                int BodyMergeEndIndex = BodyMergeStartIndex + (RemainingBenefitCount * 3);
                int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                // Benefits
                MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippedRowIndexes);
                //Pharmacy
                MergeTableColumns(oWordDoc, CurrentTableIndex + 1, BodyMergeStartIndex, BodyMergeEndIndex, 1, int.MaxValue, PharmacySkippedRowIndex);
                oWordDoc.Tables[CurrentTableIndex + 2].Rows[2].Delete();
                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, MedicalTableAttributeColumnsWidth);//409.5f
                AdjustCellWidth(oWordDoc, CurrentTableIndex + 1, lstPlanTier, PharmacySkippedRowIndex, PharmacyTableAttributeColumnsWidth);
            }
            if (WriteCount == 1)    //MedicalSinglePlanDescription  MedicalMultiplePlanDescription 
            {
                if (AllBookmarks["Medical"].ContainsKey("MedicalSinglePlanDescription"))      //MedicalHMODescription1  MedicalPPODescription1
                {
                    AllBookmarks["Medical"].Remove("MedicalSinglePlanDescription");
                }
            }
            else
            {
                if (AllBookmarks["Medical"].ContainsKey("MedicalMultiplePlanDescription"))      //MedicalHMODescription1  MedicalPPODescription1
                {
                    AllBookmarks["Medical"].Remove("MedicalMultiplePlanDescription");
                }
            }

            #region MergeField

            int iTotalFields = 0;
            strAllCarriers = strAllCarriers.TrimEnd(',');
            if (WriteCount > 1 && strAllCarriers.Contains(","))
            {
                int lastIndex = strAllCarriers.LastIndexOf(',');
                strAllCarriers = (strAllCarriers.Substring(0, lastIndex) + " and " + strAllCarriers.Substring(lastIndex + 1));
            }
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("First Medical Effective Date"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText((Convert.ToDateTime(FirstEffectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(FirstEffectiveDate.ToString()).Year.ToString()).Trim());
                        continue;
                    }
                    if (fieldName.Contains("Renewal Date"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText((Convert.ToDateTime(FirstRenewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(FirstRenewalDate.ToString()).Year.ToString()).Trim());
                        continue;
                    }

                    if (fieldName.Contains("Number_of_Medical_Plans_Selected")) //LTD Benefit Summary Name
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(WriteCount.ToString());
                        continue;
                    }

                    if (fieldName.Contains("Medical_Plan_Types_text")) //LTD Benefit Summary Name
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(strAllCarriers.ToString());
                        continue;
                    }
                    if (fieldName.Contains("Client_Name_1")) //LTD Benefit Summary Name
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                    if (fieldName.Contains("Carrier_Name_1")) //LTD Benefit Summary Name
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(GlobalCarrier);
                        continue;
                    }
                }
            }
            #endregion
        }

        private void AdjustCellWidth(Word.Document oWordDoc, int TableIndex, List<int> planTierCount, List<int> SkippedRowIndexes, float TableWidth)
        {
            int colCount = oWordDoc.Tables[TableIndex].Columns.Count;
            double CellWidth = TableWidth / planTierCount.Count;
            int CurrentCellStartIndex = 2;
            int CurrentCellEndIndex = 2;
            for (int i = 1; i <= planTierCount.Count; i++)
            {
                CurrentCellStartIndex = CurrentCellEndIndex;
                CurrentCellEndIndex = CurrentCellEndIndex + planTierCount[i - 1];
                if (SkippedRowIndexes != null)
                {
                    if (!SkippedRowIndexes.Contains(1))
                        oWordDoc.Tables[TableIndex].Rows[1].Cells[i + 1].Width = (float)CellWidth;
                }
                else
                {
                    oWordDoc.Tables[TableIndex].Rows[1].Cells[i + 1].Width = (float)CellWidth;
                }
                float InnerCellWisth = (float)(CellWidth / planTierCount[i - 1]);
                for (int Row = 2; Row <= oWordDoc.Tables[TableIndex].Rows.Count; Row++)
                {
                    int TempCellIndex = CurrentCellStartIndex;
                    while (TempCellIndex < CurrentCellEndIndex)
                    {
                        if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                        {
                            if (!SkippedRowIndexes.Contains(Row))
                            {
                                oWordDoc.Tables[TableIndex].Rows[Row].Cells[TempCellIndex].Width = InnerCellWisth;
                            }
                        }
                        else
                        {
                            oWordDoc.Tables[TableIndex].Rows[Row].Cells[TempCellIndex].Width = InnerCellWisth;
                        }
                        TempCellIndex++;
                    }
                }
            }
        }

        public void WriteDentalSectionToTemplateBasicBlue_v1(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            lstPlanTier.Clear();
            listPlan.Add("Dental");
            List<int> SkippeRowSpan = new List<int>() { 3, 7, 12 };
            string Renewaldate = string.Empty;
            string Effectivedate = string.Empty;

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            string strAllCarriers = "";


            foreach (object item in DentalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in DentalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int TablesUsed = 1;
            int CurrentColumnIndex = 2;
            int CurrentTableIndex = 9;
            int WriteCount = 0;
            int ColumnIncreament = 0;
            int RemainingBenefitCount = 3;
            int HeaderColumnIndex = 2;
            List<int> Contributions = new List<int>();
            float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
            float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;
            foreach (string PlanTypeDescription in dictMap.Keys)
            {
                foreach (int key in dictMap[PlanTypeDescription].Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    Renewaldate = drPlanRow["Renewal"].ToString();
                    Effectivedate = drPlanRow["Effective"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();
                    List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                    int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);
                    lstPlanTier.Add(PlanTier);

                    if (string.IsNullOrEmpty(strAllCarriers))
                        strAllCarriers = Carrier;
                    else
                    {
                        if (!strAllCarriers.Contains(Carrier))
                            strAllCarriers = strAllCarriers + ", " + Carrier;
                    }

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        WriteCount++;
                        RemainingBenefitCount--;

                        switch (PlanTier)
                        {
                            case 1:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 3, int.MaxValue, SkippeRowSpan);
                                ColumnIncreament = 1;
                                break;
                            case 2:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 3, int.MaxValue, SkippeRowSpan);
                                ColumnIncreament = 2;
                                break;
                            case 3:
                                ColumnIncreament = 3;
                                break;
                        }
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                        string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                        string AttributeValue = "";
                        oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                        #region Benefits Coverage

                        #region Annual Deductible Individual - 4
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalIndividual != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalIndividual);
                            int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkDentalIndividual["benefitColumnID"].ToString());
                            string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                            oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex).Range.Text = ColumnNameLevel1;
                        }

                        oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        // Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalIndividual);
                                int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkDentalIndividual["benefitColumnID"].ToString());
                                string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                                oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 1).Range.Text = ColumnNameLevel2;
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalIndividual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalIndividual);
                                    int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3DentalIndividual["benefitColumnID"].ToString());
                                    string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                    oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 2).Range.Text = ColumnNameLevel3;
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Family - 5
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalFamily != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalFamily);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDenatlFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDenatlFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DenatlFamily != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DenatlFamily);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Waived for Preventive Care - 6
                        //In Network
                        DataRow drBenefitValues_InNetworkDenatlCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDenatlCoinsurance != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDenatlCoinsurance);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalCoinsurance != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalCoinsurance);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalCoinsurance != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalCoinsurance);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Per Person/Family (indicate calendar/benefit year) - 8
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalAnnualPlanMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalAnnualPlanMaximum);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalAnnualPlanMaximum != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalAnnualPlanMaximum);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalAnnualPlanMaximum != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalAnnualPlanMaximum);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Preventive - 9
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalPreventive != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalPreventive);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalPreventive != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalPreventive);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalPreventive != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalPreventive);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Basic Services – Basic -10
                        DataRow drBenefitValues_InNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalBasicServices != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalBasicServices);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalBasicServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalBasicServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalBasicServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalBasicServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Major Services – Major - 11
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalMajorServices != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalMajorServices);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalMajorServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalMajorServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalMajorServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalMajorServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Orthodontia-Orthodontia Services / Orthodontia - 13
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalOrthodontiaServices != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontiaServices);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalOrthodontiaServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontiaServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalOrthodontiaServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontiaServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Orthodontia Services / Adults (and covered full-time students - 14
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalOrthodontia != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontia);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalOrthodontia != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontia);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalOrthodontia != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontia);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Orthodontia Services / Dependent Children 15
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalDependentChildren != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalDependentChildren);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalDependentChildren != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalDependentChildren);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalDependentChildren != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalDependentChildren);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region General Plan Information – Lifetime Orthodontial Plan Maximum -16
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalLifetimeOrthodontia != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalLifetimeOrthodontia);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalLifetimeOrthodontia != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalLifetimeOrthodontia);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalLifetimeOrthodontia != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalLifetimeOrthodontia);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region General Plan Information – Waiting Period - 17
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #endregion

                        CurrentColumnIndex += ColumnIncreament;
                        HeaderColumnIndex += 1;
                        List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                        WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1, Carrier, SummaryName, ContributionCollection, ContributionDS);

                        if (AllBookmarks["Dental"].ContainsKey("DentalPlanTables" + TablesUsed))
                        {
                            AllBookmarks["Dental"].Remove("DentalPlanTables" + TablesUsed);
                        }
                        if (WriteCount % 3 == 0)
                        {
                            AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippeRowSpan, TableAttributeColumnsWidth);
                            oWordDoc.Tables[CurrentTableIndex + 1].Rows[2].Delete();
                            CurrentColumnIndex = 2;
                            HeaderColumnIndex = 2;
                            CurrentTableIndex += 2;
                            RemainingBenefitCount = 3;
                            TablesUsed += 1;
                        }
                    }
                }
            }

            strAllCarriers = strAllCarriers.TrimEnd(',');
            if (WriteCount > 1 && strAllCarriers.Contains(","))
            {
                int lastIndex = strAllCarriers.LastIndexOf(',');
                strAllCarriers = (strAllCarriers.Substring(0, lastIndex) + " and" + strAllCarriers.Substring(lastIndex + 1));
            }
            if (RemainingBenefitCount != 3)
            {
                int BodyMergeStartIndex = CurrentColumnIndex - 1;
                int BodyMergeEndIndex = BodyMergeStartIndex + (RemainingBenefitCount * 3);
                int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                // Benefits
                MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippeRowSpan);
                oWordDoc.Tables[CurrentTableIndex + 1].Rows[2].Delete();
                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippeRowSpan, TableAttributeColumnsWidth);
            }
            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Dental Carrier Name"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(strAllCarriers);
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteVisionSectionToTemplateBasicBlue_v1(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            List<int> SkippedRowIndexes = new List<int>() { 3, 6, 10, 12, 15, 17 };

            lstPlanTier.Clear();
            listPlan.Add("Vision");
            string Renewaldate = string.Empty;
            string Effectivedate = string.Empty;

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();


            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int TablesUsed = 1;
            int CurrentColumnIndex = 2;
            int CurrentTableIndex = 13;
            int WriteCount = 0;
            int ColumnIncreament = 1;
            int RemainingBenefitCount = 3;
            int HeaderColumnIndex = 2;
            List<int> Contributions = new List<int>();
            foreach (string PlanTypeDescription in dictMap.Keys)
            {
                foreach (int key in dictMap[PlanTypeDescription].Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    Renewaldate = drPlanRow["Renewal"].ToString();
                    Effectivedate = drPlanRow["Effective"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();
                    List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];


                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        WriteCount++;
                        RemainingBenefitCount--;
                        lstPlanTier.Add(1);
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                        string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                        string AttributeValue = "";
                        oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                        #region Benefit Coverage-Copay-Routine Exam-4
                        //InNetwork
                        DataRow drBenefitValues_CopayRoutineExamFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CopayRoutineExamFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineExamFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Copay-Routine Materials-5
                        //InNetwork
                        DataRow drBenefitValues_CopayRoutineMaterialsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CopayRoutineMaterialsFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineMaterialsFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Lenses-Single Vision Lenses-7
                        //InNetwork
                        DataRow drBenefitValues_LensesSingleVisionFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 507 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_LensesSingleVisionFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_LensesSingleVisionFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(7, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Lenses-Bifocal Lenses-8
                        //InNetwork
                        DataRow drBenefitValues_LensesBifocalFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 73 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_LensesBifocalFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_LensesBifocalFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Lenses-Trifocal Lens-9
                        //InNetwork
                        DataRow drBenefitValues_LensesTrifocalFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 553 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_LensesTrifocalFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_LensesTrifocalFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Frames-Retail Equivalent-Frames-11
                        //InNetwork
                        DataRow drBenefitValues_CoveredServicesFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 208 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CoveredServicesFramesFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredServicesFramesFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Contact Lenses-Necessary / Prescribed-Frames-Contact Lenses-13
                        //InNetwork
                        DataRow drBenefitValues_CoveredServicesContactLensesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 356 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CoveredServicesContactLensesFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredServicesContactLensesFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Contact Lenses-Necessary / Prescribed-Frames-Elective-14
                        //InNetwork
                        DataRow drBenefitValues_CoveredServicesElectiveFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CoveredServicesElectiveFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredServicesElectiveFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Other Services Laser Corrective Surgery-Corrective Vision Services-16
                        //InNetwork
                        DataRow drBenefitValues_CoveredLaserCorrectiveSurgeryFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 133 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CoveredLaserCorrectiveSurgeryFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredLaserCorrectiveSurgeryFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Frequency-Routine Exams-18
                        //InNetwork
                        DataRow drBenefitValues_GeneralPlanInformationExamsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 194 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_GeneralPlanInformationExamsFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationExamsFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Frequency-Routine Lenses-19
                        //InNetwork
                        DataRow drBenefitValues_GeneralPlanInformationLensesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_GeneralPlanInformationLensesFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationLensesFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Frequency-Routine Frames-20
                        //InNetwork
                        DataRow drBenefitValues_GeneralPlanInformationFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_GeneralPlanInformationFramesFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationFramesFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Frequency-Routine Contacts-21
                        //InNetwork
                        DataRow drBenefitValues_GeneralPlanInformationContactsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_GeneralPlanInformationContactsFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationContactsFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        CurrentColumnIndex += ColumnIncreament;
                        HeaderColumnIndex += 1;
                        List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                        WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1, Carrier, SummaryName, ContributionCollection, ContributionDS);

                        if (AllBookmarks["Vision"].ContainsKey("VisionPlanTables" + TablesUsed))
                        {
                            AllBookmarks["Vision"].Remove("VisionPlanTables" + TablesUsed);
                        }

                        float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                        float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;

                        if (WriteCount % 3 == 0)
                        {
                            AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
                            oWordDoc.Tables[CurrentTableIndex + 1].Rows[2].Delete();
                            CurrentColumnIndex = 2;
                            HeaderColumnIndex = 2;
                            CurrentTableIndex += 2;
                            RemainingBenefitCount = 3;
                        }
                    }
                }
            }
            if (RemainingBenefitCount != 3)
            {
                float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;

                int BodyMergeStartIndex = CurrentColumnIndex - 1;
                int BodyMergeEndIndex = BodyMergeStartIndex + RemainingBenefitCount;
                int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                // Benefits
                MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, SkippedRowIndexes);
                MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippedRowIndexes);
                oWordDoc.Tables[CurrentTableIndex + 1].Rows[2].Delete();
                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
            }
            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Vision_ClientName_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteHSASectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Health Savings Account (HSA)");
            int PlanCount = 0;
            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                }

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("HSA_Carrier_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                        if (fieldName.Contains("HSA_Policy_Number_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(PolicyNumber);
                            continue;
                        }
                    }
                }

                #endregion
            }
        }
        public void WriteHRASectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Health Reimbursement Account (HRA)");
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string HRA_Tier_1 = string.Empty;
            string HRA_Tier_2 = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    DataRow drBenefitValues_HRA_Tier_1 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 238 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_HRA_Tier_1 != null)
                    {
                        HRA_Tier_1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_HRA_Tier_1);
                    }
                    DataRow drBenefitValues_HRA_Tier_2 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 239 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_HRA_Tier_2 != null)
                    {
                        HRA_Tier_2 = comFunObj.GetBenefitFormattedValue(drBenefitValues_HRA_Tier_2);
                    }
                }

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("HRA_Carrier_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                        if (fieldName.Contains("HRA_Policy_Number_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(PolicyNumber);
                            continue;
                        }
                        if (fieldName.Contains("Client_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }

                        if (fieldName.Contains("HRA Tier One"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(HRA_Tier_1))
                            {
                                oWordApp.Selection.TypeText(HRA_Tier_1);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("HRA Tier Two"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(HRA_Tier_2))
                            {
                                oWordApp.Selection.TypeText(HRA_Tier_2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }

                #endregion
            }
        }
        public void WriteFSASectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Flexible Spending Account (FSA)");
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string administration_service_medicalspending = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    DataRow drBenefitValues_medicalspending = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 354 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_medicalspending != null)
                    {
                        administration_service_medicalspending = comFunObj.GetBenefitFormattedValue(drBenefitValues_medicalspending);
                    }
                }

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("FSA_Carrier_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                        if (fieldName.Contains("FSA_Policy_Number_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(PolicyNumber);
                            continue;
                        }
                        if (fieldName.Contains("Client_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }

                        if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(administration_service_medicalspending))
                            {
                                oWordApp.Selection.TypeText(administration_service_medicalspending);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }

                #endregion
            }
        }
        public void WriteLifeADnDSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Life and AD&D");

            #region Mark written tables by removing from "AllBookmarks"

            int noOfPlans = dictMap.Count;
            string bookmark = string.Empty;

            foreach (int ProductId in dictMap.Keys)
            {
                if (noOfPlans == 1)
                {
                    if (dictMap[ProductId].Count == 1)
                    {
                        if (AllBookmarks["Life and AD&D"].ContainsKey("LifeandADDPlan1"))
                        {
                            AllBookmarks["Life and AD&D"].Remove("LifeandADDPlan1");
                        }
                    }
                    if (dictMap[ProductId].Count == 2)
                    {
                        if (AllBookmarks["Life and AD&D"].ContainsKey("LifeandADDPlan1"))
                        {
                            AllBookmarks["Life and AD&D"].Remove("LifeandADDPlan1");
                        }

                        if (AllBookmarks["Life and AD&D"].ContainsKey("LifeandADDPlan2"))
                        {
                            AllBookmarks["Life and AD&D"].Remove("LifeandADDPlan2");
                        }
                    }
                }
                else if (noOfPlans == 2)
                {
                    if (AllBookmarks["Life and AD&D"].ContainsKey("LifeandADDPlan1"))
                    {
                        AllBookmarks["Life and AD&D"].Remove("LifeandADDPlan1");
                    }

                    if (AllBookmarks["Life and AD&D"].ContainsKey("LifeandADDPlan2"))
                    {
                        AllBookmarks["Life and AD&D"].Remove("LifeandADDPlan2");
                    }
                }
            }
            #endregion

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string Benefit_Amount_Employee_1 = string.Empty;
            string Benefit_Amount_Employee_2 = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    if (PlanCount > 1)
                    {
                        BenefitSummaryCount = 2;
                    }
                    else
                    {
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                    }
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    DataRow drBenefitValues_Benefit_Amount_Employee_1 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Benefit_Amount_Employee_1 != null)
                    {
                        Benefit_Amount_Employee_1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Employee_1);
                    }
                    DataRow drBenefitValues_Benefit_Amount_Employee_2 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Benefit_Amount_Employee_2 != null)
                    {
                        Benefit_Amount_Employee_2 = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Employee_2);
                    }

                    #region MergeField

                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Life_and_AD&D_Carrier_Name_" + BenefitSummaryCount))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Carrier))
                                {
                                    oWordApp.Selection.TypeText(Carrier);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("Life_and_AD&D_Policy_Number_" + BenefitSummaryCount))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(PolicyNumber))
                                {
                                    oWordApp.Selection.TypeText(PolicyNumber);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("Life_and_AD&D_Benefit_Amount_Employee_1"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Benefit_Amount_Employee_1))
                                {
                                    oWordApp.Selection.TypeText(Benefit_Amount_Employee_1);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("Life_and_AD&D_Benefit_Amount_Employee_2"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Benefit_Amount_Employee_2))
                                {
                                    oWordApp.Selection.TypeText(Benefit_Amount_Employee_2);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                    }
                }

                    #endregion
            }
        }
        public void WriteVolunteryLifeSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string Benefit_Amount_Employee = string.Empty;
            string Benefit_Amount_Spouse = string.Empty;
            string Benefit_Amount_Child = string.Empty;
            string planType = string.Empty;
            int noOfValCount = 0;

            int MedicalPlanCount = dictMap.Keys.Count;
            bool IsVolLifeExists = false;
            bool IsVolADDExists = false;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;
                string PolicyNumber = "";

                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();
                string bookmark = string.Empty;


                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    if (drPlanRow["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                    {
                        IsVolLifeExists = true;
                        //isVolLife_Selected = true;
                        planType = cv.VoluntaryLifeADDLOC.ToLower().Trim().ToLower();
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        DataRow drBenefitValues_Benefit_Amount_Employee = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Amount_Employee != null)
                        {
                            Benefit_Amount_Employee = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Employee);
                        }
                        DataRow drBenefitValues_Benefit_Amount_Spouse = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 516 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Amount_Spouse != null)
                        {
                            Benefit_Amount_Spouse = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Spouse);
                        }
                        DataRow drBenefitValues_Benefit_Amount_Child = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 106 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Amount_Child != null)
                        {
                            Benefit_Amount_Child = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Child);
                        }
                        #region MergeField

                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Equals("Vol_Life_Carrier_Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Carrier);
                                    continue;
                                }
                                if (fieldName.Equals("Vol_Life_Policy_Number"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(PolicyNumber);
                                    continue;
                                }

                                if (fieldName.Equals("Vol_Life_Benefit_Amount_Employee"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Amount_Employee))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Amount_Employee);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Equals("Vol_Life_Benefit_Amount_Spouse"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Amount_Spouse))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Amount_Spouse);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Equals("Vol_Life_Benefit_mount_Child"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Amount_Child))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Amount_Child);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                            }
                        }

                        #endregion

                    }
                    if (drPlanRow["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                    {
                        IsVolADDExists = true;
                        //isVolADnD_Selected = true;
                        planType = cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower().Trim().ToLower();
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        DataRow drBenefitValues_Benefit_Amount_Employee = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Amount_Employee != null)
                        {
                            Benefit_Amount_Employee = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Employee);
                        }
                        DataRow drBenefitValues_Benefit_Amount_Spouse = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 516 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Amount_Spouse != null)
                        {
                            Benefit_Amount_Spouse = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Spouse);
                        }
                        DataRow drBenefitValues_Benefit_Amount_Child = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 106 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Amount_Child != null)
                        {
                            Benefit_Amount_Child = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Amount_Child);
                        }

                        #region MergeField

                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Equals("Vol_AD&D_Carrier_Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Carrier);
                                    continue;
                                }
                                if (fieldName.Equals("Vol_AD&D_Policy_Number"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(PolicyNumber);
                                    continue;
                                }

                                if (fieldName.Equals("Vol_ADD_Benefit_Amount"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Amount_Employee))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Amount_Employee);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Equals("Vol_ADD_Benefit_Amount_Spouse"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Amount_Spouse))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Amount_Spouse);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Equals("Vol_ADD_Benefit_Amount_Child"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Amount_Child))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Amount_Child);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                            }
                        }

                        #endregion
                    }
                }
            }
            string Title = string.Empty;
            if (IsVolLifeExists == true && IsVolADDExists == true)
            {
                Title = "Voluntary Life and AD&D";
                listPlan.Add("Voluntary Life and AD&D");
                if (AllBookmarks["Voluntary Life"].ContainsKey("VoluntaryLifeDescription1"))
                {
                    AllBookmarks["Voluntary Life"].Remove("VoluntaryLifeDescription1");
                }
            }
            else if (IsVolLifeExists == true && IsVolADDExists == false)
            {
                listPlan.Add("Voluntary Life");
                Title = "Voluntary Life";
                if (AllBookmarks["Voluntary Life"].ContainsKey("VoluntaryLifeDescription1"))
                {
                    AllBookmarks["Voluntary Life"].Remove("VoluntaryLifeDescription1");
                }
            }
            else if (IsVolLifeExists == false && IsVolADDExists == true)
            {
                listPlan.Add("Voluntary AD&D");
                if (AllBookmarks["Voluntary Life"].ContainsKey("VoluntaryLifeDescription2"))
                {
                    AllBookmarks["Voluntary Life"].Remove("VoluntaryLifeDescription2");
                }
            }

            #region MergeField



            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("VolLifeSectionTitle"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(Title);
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteShortTermDisabilityDSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Short Term Disability");
            IsSTDExists = true;
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string STDBenefitPercentage = string.Empty;
            string STDWeeklyBenefitMaximum = string.Empty;
            string STDEliminationPeriod = string.Empty;
            string STDMaximumPeriodofPayment = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    string AttributeValue = "";
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    #region Elimination Period

                    DataRow drBenefitValues_EliminationPeriod = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_EliminationPeriod != null)
                    {
                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_EliminationPeriod);
                    }
                    STDEliminationPeriod = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Percentage

                    DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_BenefitPercentage != null)
                    {
                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                    }
                    STDBenefitPercentage = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Maximum Weekly Benefit

                    DataRow drBenefitValues_MaximumWeeklyBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_MaximumWeeklyBenefit != null)
                    {
                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_MaximumWeeklyBenefit);
                    }
                    STDWeeklyBenefitMaximum = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Maximum Period of Payment

                    DataRow drBenefitValues_MaximumPeriodPayment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_MaximumPeriodPayment != null)
                    {
                        ///AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_MaximumPeriodPayment);
                        if (drBenefitValues_MaximumPeriodPayment["UOM"].ToString() == "text")
                        {
                            drBenefitValues_MaximumPeriodPayment["UOM"] = "";
                        }
                        AttributeValue = (comFunObj.GetBenefitFormattedValue(drBenefitValues_MaximumPeriodPayment) + " " + drBenefitValues_MaximumPeriodPayment["UOM"].ToString().Trim().Replace("_", " ")).Trim();
                    }
                    STDMaximumPeriodofPayment = AttributeValue;
                    AttributeValue = "";

                    
                    #endregion
                }

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("STD_Carrie_Name_" + PlanCount) || fieldName.Contains("STDCarrierName1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }

                        if (fieldName.Contains("STD_Policy_Number_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(PolicyNumber);
                            continue;
                        }
                        if (fieldName.Contains("STDBenefitPercentage1"))
                        {
                            myMergeField.Select();
                            if (STDBenefitPercentage == "")
                            {
                                STDBenefitPercentage = " ";
                            }
                            oWordApp.Selection.TypeText(STDBenefitPercentage);
                            continue;
                        }
                        if (fieldName.Contains("STDWeeklyBenefitMaximum1"))
                        {
                            myMergeField.Select();
                            if (STDWeeklyBenefitMaximum == "")
                            {
                                STDWeeklyBenefitMaximum = " ";
                            }
                            oWordApp.Selection.TypeText(STDWeeklyBenefitMaximum);
                            continue;
                        }
                        if (fieldName.Contains("STDEliminationPeriod1"))
                        {
                            myMergeField.Select();
                            if (STDEliminationPeriod == "")
                            {
                                STDEliminationPeriod = " ";
                            }
                            oWordApp.Selection.TypeText(STDEliminationPeriod);
                            continue;
                        }
                        if (fieldName.Contains("STDMaximumPeriodofPayment1"))
                        {
                            myMergeField.Select();
                            if (STDMaximumPeriodofPayment == "")
                            {
                                STDMaximumPeriodofPayment = " ";
                            }
                            oWordApp.Selection.TypeText(STDMaximumPeriodofPayment);
                            continue;
                        }

                    }
                }

                #endregion
            }
        }
        public void WriteLongTermDisabilityDSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Long Term Disability");
            IsIsLTDExists = true;
            #region Mark written tables by removing from "AllBookmarks"

            int noOfPlans = dictMap.Count;
            string bookmark = string.Empty;

            foreach (int ProductId in dictMap.Keys)
            {
                if (noOfPlans == 1)
                {
                    if (dictMap[ProductId].Count == 1)
                    {
                        if (AllBookmarks["LTD"].ContainsKey("LTDPlan1"))
                        {
                            AllBookmarks["LTD"].Remove("LTDPlan1");
                        }
                    }
                    if (dictMap[ProductId].Count == 2)
                    {
                        if (AllBookmarks["LTD"].ContainsKey("LTDPlan1"))
                        {
                            AllBookmarks["LTD"].Remove("LTDPlan1");
                        }

                        if (AllBookmarks["LTD"].ContainsKey("LTDPlan2"))
                        {
                            AllBookmarks["LTD"].Remove("LTDPlan2");
                        }
                    }
                }
                else if (noOfPlans == 2)
                {
                    if (AllBookmarks["LTD"].ContainsKey("LTDPlan1"))
                    {
                        AllBookmarks["LTD"].Remove("LTDPlan1");
                    }

                    if (AllBookmarks["LTD"].ContainsKey("LTDPlan2"))
                    {
                        AllBookmarks["LTD"].Remove("LTDPlan2");
                    }
                }
            }


            /*
             * 
             * if(HMOplan)
             * 
             if (AllBookmarks["Medical"].ContainsKey("MedicalHMODescription1"))
                {
                    AllBookmarks["Medical"].Remove("MedicalHMODescription1");
                }
             * if(PPOplan)
             * 
             if (AllBookmarks["Medical"].ContainsKey("MedicalHMODescription1"))
                {
                    AllBookmarks["Medical"].Remove("MedicalHMODescription1");
                }
             * 
             */

            /* 
             foreach(i,plans)
             * {
             * if(hmo)
             * if (AllBookmarks["Medical"].ContainsKey("MedicalHMODescription"+i))
                {
                    AllBookmarks["Medical"].Remove("MedicalHMODescription"+i);
                }
             * }
             
             */
            #endregion

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string Elimination_Period = string.Empty;
            string Elimination_Period_Sickness = string.Empty;
            string Monthly_Benefit = string.Empty;
            string Maximum_Period_of_Payment = string.Empty;
            string Summary_Name = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    if (PlanCount > 1)
                    {
                        BenefitSummaryCount = 2;
                    }
                    else
                    {
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                    }

                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                    Summary_Name = drPlanBenefitRow["SummaryName"].ToString();

                    DataRow drBenefitValues_Elimination_Period = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Elimination_Period != null)
                    {
                        Elimination_Period = comFunObj.GetBenefitFormattedValue(drBenefitValues_Elimination_Period);
                    }

                    DataRow drBenefitValues_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Benefit != null)
                    {
                        Monthly_Benefit = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit);
                    }
                    DataRow drBenefitValues_Period_of_Payment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 141 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Period_of_Payment != null)
                    {
                        Maximum_Period_of_Payment = comFunObj.GetBenefitFormattedValue(drBenefitValues_Period_of_Payment);
                    }

                    #region MergeField

                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("LTD_Carrier_Name_" + BenefitSummaryCount))  //LTD Carrier Name
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Carrier);
                                continue;
                            }
                            if (fieldName.Contains("LTD_Policy_Number_" + BenefitSummaryCount)) //LTD Policy Number
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(PolicyNumber);
                                continue;
                            }
                            if (fieldName.Contains("LTD_Benefit_Summary_Name_" + BenefitSummaryCount)) //LTD Benefit Summary Name
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Summary_Name);
                                continue;
                            }

                            if (fieldName.Contains("Elimination_Period_" + BenefitSummaryCount))  //Elimination Period
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Elimination_Period))
                                {
                                    oWordApp.Selection.TypeText(Elimination_Period);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("Elimination_Period_" + BenefitSummaryCount))  //Elimination Period
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Elimination_Period))
                                {
                                    oWordApp.Selection.TypeText(Elimination_Period);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("Maximum_Monthly_Benefit_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Monthly_Benefit))
                                {
                                    oWordApp.Selection.TypeText(Monthly_Benefit);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("Maximum_Monthly_Benefit_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Monthly_Benefit))
                                {
                                    oWordApp.Selection.TypeText(Monthly_Benefit);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }


                            if (fieldName.Contains("Maximum_Period_of_Payment_" + BenefitSummaryCount)) //Maximum Period of Payment
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                {
                                    oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("Maximum_Period_of_Payment_" + BenefitSummaryCount)) //Maximum Period of Payment
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                {
                                    oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                    }
                }

                    #endregion
            }
        }
        public void WriteEAPSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Employee Assistance Plan");
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("EAP_Carrier_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                        if (fieldName.Contains("Company_Name_" + PlanCount))  //Company Name
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                    }
                }

                #endregion
            }
        }
        public void WriteAdditionalProductToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanInfoTable)
        {
            string Telemedicine_Carrier_Name = string.Empty;
            string Telemedicine_Client_Name_1 = string.Empty;

            string PAP_Carrier_Name_1 = string.Empty;
            if (PlanInfoTable != null)
            {
                for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                {
                    if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                    {
                        PAP_Carrier_Name_1 = PlanInfoTable.Rows[k]["Carrier"].ToString();

                        listPlan.Add("Patient Advocacy Program");
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                    {
                        Telemedicine_Carrier_Name = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        listPlan.Add("Telemedicine");
                    }
                }
            }
            listPlan.Add("Worksite Programs");
            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Telemedicine_Carrier_Name_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(Telemedicine_Carrier_Name);
                        continue;
                    }
                    if (fieldName.Contains("PAP_Carrier_Name_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(PAP_Carrier_Name_1);
                        continue;
                    }
                    if (fieldName.Contains("Telemedicine_Client_Name_1"))  //Client Name
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteContactinformationToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string selectedColor, bool isBRCSelected, List<BRCData> BRCList, string ddlBRCSelectedValue, DataTable dtPlanContactDetails = null)
        {
            listPlan.Add("Employee Benefit Contacts");
            //int count = PremiumTable_counter + 1;
            int count = 29;

            int k = 1;
            string carriername = "";
            string plantype = "";
            string ProductTypeDesc = "";
            List<string> lstUniquePlanTypeCarrier = new List<string>();
            string carrier = string.Empty;
            string website_phone = string.Empty;
            int BRCindex = 0;
            int rowCnt = 2;

            for (int i = 0; i < PlanTable.Rows.Count; i++)
            {
                carriername = PlanTable.Rows[i]["Carrier"].ToString();
                plantype = PlanTable.Rows[i]["PlanType"].ToString();
                ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();

                string lstUniquePlanTypeCarrierItem = carriername + "|" + ProductTypeDesc;

                if (!lstUniquePlanTypeCarrier.Contains(lstUniquePlanTypeCarrierItem))
                {
                    lstUniquePlanTypeCarrier.Add(lstUniquePlanTypeCarrierItem);
                    if (rowCnt > 2)
                    {
                        oWordDoc.Tables[count].Rows.Add();
                    }
                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                    oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"].ToString());
                    oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = Convert.ToString(PlanTable.Rows[i]["SummaryName"].ToString()) + "\n" + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());

                    var planContactFirstName = (from n in dtPlanContactDetails.AsEnumerable()
                                                where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                    var planContactLastName = (from n in dtPlanContactDetails.AsEnumerable()
                                               where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                               select n.Field<string>("Contact_LastName")).FirstOrDefault();

                    var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                            where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                            select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();


                    oWordDoc.Tables[count].Cell(rowCnt, 4).Range.Text = Convert.ToString(planContactFirstName) + "  " + Convert.ToString(planContactLastName) + "\n" + Convert.ToString(planContactPhone);
                    rowCnt++;
                }
            }
            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();


                    if (fieldName.Contains("Carrier_Name_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(carriername);
                        continue;
                    }
                    //if (fieldName.Contains("BRC_Hours")) 
                    //{
                    //    myMergeField.Select();
                    //    oWordApp.Selection.TypeText(ClientName);
                    //    continue;
                    //}
                    if (fieldName.Contains("BRC_Hours"))
                    {
                        myMergeField.Select();

                        if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                        {
                            myMergeField.Delete();
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                        }
                        continue;
                    }
                    if (fieldName.Contains("BRC_Phone_Number"))
                    {
                        myMergeField.Select();

                        if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                        {
                            myMergeField.Delete();
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                        }
                        continue;
                    }
                    if (fieldName.Contains("BRC_EMAIL"))
                    {
                        myMergeField.Select();

                        if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                        {
                            myMergeField.Delete();
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                        }
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteNoticeSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlLifeADD, DropDownList ddlVoluntaryADD, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage, string selectedColor = "")
        {

            int iTotalFields = 0;
            int index = -1;
            Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);

            bool flag = false;
            bool flag_MarketPlace = false;
            if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
            {
                index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
            }
            if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
            {
                flag = true;
            }
            if (ddlChipNotice.SelectedIndex == 0 && ddlAnnualLegalNotice.SelectedIndex == 0 && ddlMarketplaceCoverage.SelectedIndex >= 1)
            {
                flag_MarketPlace = true;
            }
            bool flag1 = false;

            # region MergeField
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Equals("CHIPNotice"))
                    {
                        if (ddlChipNotice.SelectedIndex == 1)
                        {
                            myMergeField.Delete();
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();
                            r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                            if (flag == false)
                            {
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                            }
                            else if (flag == true)
                            {
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                //r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                            }

                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                            continue;
                        }
                        //adde by Vaibhav for spanish template
                        else if (ddlChipNotice.SelectedIndex == 2)
                        {
                            myMergeField.Delete();
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();
                            r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                            if (flag == false)
                            {
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                            }
                            else if (flag == true)
                            {
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                // r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                            }

                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                            continue;
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                    }

                    if (fieldName.Contains("MARKETPLACE COVERAGE"))
                    {
                        if (ddlMarketplaceCoverage.SelectedIndex == 1)
                        {
                            myMergeField.Delete();
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();

                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                            if (flag_MarketPlace == true)
                            {
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                //  r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                            }
                            r.InsertBreak(Word.WdBreakType.wdPageBreak);
                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options_EnrolmentGuide.doc"), missing, true, missing, missing);
                        }
                        //Added by Vaibhav to add Spanish templte
                        else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                        {
                            myMergeField.Delete();
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();

                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                            if (flag_MarketPlace == true)
                            {
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                // r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                            }
                            r.InsertBreak(Word.WdBreakType.wdPageBreak);
                            //r.PageSetup.RightMargin = 150f;
                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Equals("Annual_Notice"))
                    {
                        if (ddlAnnualLegalNotice.SelectedIndex == 1)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            Word.Range r = oWordDoc.Range();

                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                            r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);

                            // r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)

                            continue;
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                    }
                    if (fieldName.Equals("LegalChipCommon"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(" ");
                        continue;
                    }
                    if (fieldName.Equals("OtherProducts"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText("\f"); // For Inserting the page break before Annual Legal Notice
                        oWordApp.Selection.TypeText(" ");
                        continue;
                    }

                    if (fieldName.Equals("AnnualLeagalNotice"))
                    {
                        if (ddlAnnualLegalNotice.SelectedIndex == 1)
                        {
                            myMergeField.Delete();
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();

                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                            if (flag1 == true)
                            {
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                flag1 = false;
                            }

                            comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }

                        oWordDoc.Save();
                    }
                }
            }
            #endregion
            iTotalFields = 0;
            comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedColor);

        }
        public void WriteContribution(Word.Document oWordDoc, Word.Application oWordApp, int ContributionTableIndex, string CarrierName, string SummaryName, List<int> ContributionCollection, DataSet ContributionDS)
        {
            DataTable dtblContributionValues = ContributionDS.Tables["ContributionValueTable"].Copy();
            for (int i = 0; i < dtblContributionValues.Rows.Count; i++)
            {
                double PremiumPercentageValue = 0;
                double SalaryPercentageValue = 0;
                double.TryParse(dtblContributionValues.Rows[i]["contributionValues_percentOfPremium"].ToString(), out PremiumPercentageValue);
                double.TryParse(dtblContributionValues.Rows[i]["contributionValues_percentOfSalary"].ToString(), out SalaryPercentageValue);
                if (PremiumPercentageValue > 0 || SalaryPercentageValue > 0)
                {
                    dtblContributionValues.Rows[i].Delete();
                }
            }

            int WriteCounter = 0;
            foreach (int ContId in ContributionCollection)
            {
                DataRow[] Contributions = dtblContributionValues.Select("ContributionValues_Contribution = " + ContId);
                List<int> UniqueRateTierIds = new List<int>();
                if (Contributions.Count() > 0)
                {
                    foreach (DataRow ContributionItem in Contributions)
                    {
                        if (!UniqueRateTierIds.Contains(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString())))
                        {
                            UniqueRateTierIds.Add(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString()));
                        }
                    }
                    if (UniqueRateTierIds.Count() > 0)
                    {
                        oWordDoc.Tables[ContributionTableIndex].Rows[oWordDoc.Tables[ContributionTableIndex].Rows.Count].Range.Copy();
                        if (WriteCounter == 0)
                            WriteCounter = oWordDoc.Tables[ContributionTableIndex].Rows.Count + 1;
                        for (int a = 0; a <= UniqueRateTierIds.Count(); a++)
                        {
                            oWordDoc.Tables[ContributionTableIndex].Rows[oWordDoc.Tables[ContributionTableIndex].Rows.Count].Range.Paste();
                        }
                        oWordDoc.Tables[ContributionTableIndex].Cell(WriteCounter, 1).Range.Text = "";


                        /****** WE COMMENTED THIS CODE AS PER NICOLE REQUIREMENT Basic Blue - Issue #10 - Contribution Table description change
                         * oWordDoc.Tables[ContributionTableIndex].Cell(WriteCounter, 2).Range.Text = CarrierName + "-" + SummaryName + "-" + Contributions[0]["description"].ToString();
                        */
                        oWordDoc.Tables[ContributionTableIndex].Cell(WriteCounter, 2).Range.Text = Contributions[0]["description"].ToString();

                        MergeTableColumns(oWordDoc, ContributionTableIndex, 1, 2, WriteCounter, WriteCounter, null);
                        int rgb_font = ColorTranslator.ToOle(Color.FromArgb(217, 217, 217));
                        Word.WdColor wdColor_font = (Word.WdColor)rgb_font;
                        oWordDoc.Tables[ContributionTableIndex].Cell(WriteCounter, 1).Range.Shading.BackgroundPatternColor = wdColor_font;

                        if (WriteCounter == 3)
                        {
                            oWordDoc.Tables[ContributionTableIndex].Cell(1, 1).Range.Text = "Employee Contributions (" + Contributions[0]["contributionFrequency"].ToString().Replace("_", " ").Replace("or","per") + ")";

                        }
                        WriteCounter++;
                        foreach (DataRow ContributionItem in Contributions)
                        {
                            if (UniqueRateTierIds.Contains(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString())))
                            {
                                UniqueRateTierIds.Remove(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString()));
                                oWordDoc.Tables[ContributionTableIndex].Cell(WriteCounter, 1).Range.Text = ContributionItem["contributionDescriptionWithEEIncluded"].ToString().Replace("EE", "Employee");
                                oWordDoc.Tables[ContributionTableIndex].Cell(WriteCounter, 2).Range.Text = "$" + comFunObj.GetBenefitFormattedValue_Contribtion(ContributionItem["contributionValues_amount"].ToString());
                                WriteCounter++;
                            }


                        }
                    }
                }

            }
        }
        public void WriteAccountContact(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, List<Contact> ContactList, ArrayList arrAcctContact)
        {
            string ClientContact_Name = string.Empty;
            string PhoneNumber = string.Empty;
            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].Name != null)
                                {
                                    ClientContact_Name = ContactList[i].Name;
                                }
                                else
                                {
                                    ClientContact_Name = " ";
                                }
                                if (ContactList[i].Phone.Count > 0)
                                {
                                    PhoneNumber = ContactList[i].Phone[0];
                                }
                                else
                                {
                                    PhoneNumber = " ";
                                }
                            }
                        }
                    }
                }
            }
            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Contact_Name"))
                    {
                        myMergeField.Select();
                        if (ClientContact_Name != string.Empty)
                            oWordApp.Selection.TypeText(ClientContact_Name);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Client_Contact_Ph_Number"))
                    {
                        myMergeField.Select();
                        if (PhoneNumber != string.Empty)
                            oWordApp.Selection.TypeText(PhoneNumber);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                }
            }
        }

        public void WriteMedicalSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DropDownList ddlClient, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet EligibilityDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Medical");
            List<int> SkippedRowIndexes = new List<int>() { 3, 7, 10, 13, 16, 23, 26, 29 };
            List<int> PharmacySkippedRowIndex = new List<int>() { 7 };
            getBookmarks();

            #region Mark written tables by removing from "AllBookmarks"

            string PlanType_Description = string.Empty;

            int noOfTables = dictMap.Count;
            string bookmark = string.Empty;
            string ForntPagebookmark = string.Empty;

            for (int i = 1; i <= noOfTables; i++)
            {
                bookmark = "MedicalPlanTables" + i.ToString();     // MedicalPlanTables1, MedicalPlanTables2 etc....
                if (AllBookmarks["Medical"].ContainsKey(bookmark))
                {
                    AllBookmarks["Medical"].Remove(bookmark);
                }
            }
            for (int i = 1; i <= noOfTables; i++)
            {
                ForntPagebookmark = "FrontPageMedPlan" + i.ToString();     // MedicalPlanTables1, MedicalPlanTables2 etc....
                if (AllBookmarks["Medical"].ContainsKey(ForntPagebookmark))
                {
                    AllBookmarks["Medical"].Remove(ForntPagebookmark);
                }
            }

            foreach (int plan in dictMap.Keys)
            {
                DataRow drPlanType = PlanTable.Select("ProductId = " + plan).FirstOrDefault();
                PlanType_Description = drPlanType["ProductTypeDescription"].ToString();

                if (PlanType_Description == "Medical PPO")
                {
                    bookmark = "MedicalPPODescription1";

                    if (AllBookmarks["Medical"].ContainsKey(bookmark))      //MedicalHMODescription1  MedicalPPODescription1
                    {
                        AllBookmarks["Medical"].Remove(bookmark);
                    }
                }
                else if (PlanType_Description == "Medical HMO")
                {
                    bookmark = "MedicalHMODescription1";

                    if (AllBookmarks["Medical"].ContainsKey(bookmark))      //MedicalHMODescription1  MedicalPPODescription1
                    {
                        AllBookmarks["Medical"].Remove(bookmark);
                    }
                }
                if (dictMap.Count == 1)    //MedicalSinglePlanDescription  MedicalMultiplePlanDescription 
                {
                    bookmark = "MedicalSinglePlanDescription";

                    if (AllBookmarks["Medical"].ContainsKey(bookmark))      //MedicalHMODescription1  MedicalPPODescription1
                    {
                        AllBookmarks["Medical"].Remove(bookmark);
                    }
                }
                else
                {
                    bookmark = "MedicalMultiplePlanDescription";

                    if (AllBookmarks["Medical"].ContainsKey(bookmark))      //MedicalHMODescription1  MedicalPPODescription1
                    {
                        AllBookmarks["Medical"].Remove(bookmark);
                    }

                }
            }
            #endregion

            int BenefitCoverageTableIndex = 1;
            int ContrbutionTableIndex = 2;
            int PharmacyTableIndex = 3;
            string Renewaldate = string.Empty;
            string Effectivedate = string.Empty;
            DataTable Emp = new DataTable();

            Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();

            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            int SelectedPlanType = 0;
            int TotalBenefitSummeries = 0;
            // Write for each disctinct plan selected
            foreach (int key in dictMap.Keys)
            {
                SelectedPlanType = dictMap.Count;
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                Renewaldate = drPlanRow["Renewal"].ToString();
                Effectivedate = drPlanRow["Effective"].ToString();
                string Carrier = drPlanRow["Carrier"].ToString();
                PlanCount = PlanCount + 1;
                List<int> BenefitSummarries = dictMap[key];
                int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);
                int InNetworkColumnIndex = 0;
                int IncreamentCount = 0;

                switch (PlanTier)
                {
                    case 1:
                        InNetworkColumnIndex = 2;
                        IncreamentCount = 1;

                        //Benefit Table Header
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 2, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 5, 2, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 6, 2, 2, null);

                        //Benefit Table Body
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 3, int.MaxValue, SkippedRowIndexes);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 5, 3, int.MaxValue, SkippedRowIndexes);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 6, 3, int.MaxValue, SkippedRowIndexes);


                        //Pharmacy Table Header
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 2, 4, 1, 2, null);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 5, 1, 2, null);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 4, 6, 1, 2, null);

                        //Pharmacy Table Body
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 2, 4, 3, int.MaxValue, PharmacySkippedRowIndex);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 5, 3, int.MaxValue, PharmacySkippedRowIndex);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 4, 6, 3, int.MaxValue, PharmacySkippedRowIndex);

                        break;
                    case 2:
                        InNetworkColumnIndex = 2;
                        IncreamentCount = 2;

                        //Table Header
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 2, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 6, 2, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 8, 2, 2, null);

                        //Table Body
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 3, int.MaxValue, SkippedRowIndexes);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 6, 3, int.MaxValue, SkippedRowIndexes);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 8, 3, int.MaxValue, SkippedRowIndexes);


                        //Table Header
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 4, 1, 2, null);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 5, 6, 1, 2, null);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 7, 8, 1, 2, null);

                        //Pharmacy Table Body
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 4, 3, int.MaxValue, PharmacySkippedRowIndex);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 5, 6, 3, int.MaxValue, PharmacySkippedRowIndex);
                        MergeTableColumns(oWordDoc, PharmacyTableIndex, 7, 8, 3, int.MaxValue, PharmacySkippedRowIndex);
                        break;
                    case 3:
                        InNetworkColumnIndex = 2;
                        IncreamentCount = 3;
                        break;
                }
                int SummaryCount = 0;
                // Write for each Benefit Summary selected
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    SummaryCount = SummaryCount + 1;
                    string AttributeValue = "";

                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                    string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                    string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                    string AnnualDeductibleFamily = "";
                    string OfficeVisitExam = "";
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, SummaryCount + 1).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                    #region Benefits Coverage

                    #region Annual Deductible Individual - 4
                    //In Network
                    DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkIndividual != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                        int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkIndividual["benefitColumnID"].ToString());
                        string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(2, InNetworkColumnIndex).Range.Text = ColumnNameLevel1;
                    }

                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(4, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkIndividual != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                            int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkIndividual["benefitColumnID"].ToString());
                            string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(2, InNetworkColumnIndex + 1).Range.Text = ColumnNameLevel2;
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(4, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3Individual != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                                int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3Individual["benefitColumnID"].ToString());
                                string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                oWordDoc.Tables[BenefitCoverageTableIndex].Cell(2, InNetworkColumnIndex + 2).Range.Text = ColumnNameLevel3;
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(4, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }

                    }
                    // Out Network

                    AttributeValue = "";
                    #endregion

                    #region Annual Deductible Family - 5
                    //In Network
                    DataRow drBenefitValues_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkFamily != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                        AnnualDeductibleFamily = AttributeValue;
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(5, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkFamily != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(5, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3Family != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3Family);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(5, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Annual Deductible Coinsurance - 6
                    //In Network
                    DataRow drBenefitValues_InNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkCoinsurance != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkCoinsurance);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(6, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkCoinsurance != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkCoinsurance);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(6, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3Coinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3Coinsurance != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3Coinsurance);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(6, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Maximum Pocket Individual - 8
                    //In Network
                    DataRow drBenefitValues_InNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkPockIndividual != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkPockIndividual);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(8, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkPockIndividual != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkPockIndividual);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(8, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3Individual != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(8, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }

                    AttributeValue = "";
                    #endregion

                    #region Maximum Pocket Family - 9
                    //In Network
                    DataRow drBenefitValues_InNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkPockFamily != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkPockFamily);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(9, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkPockFamily != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkPockFamily);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(9, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3PockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3PockFamily != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3PockFamily);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(9, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Physical Office Visit -Primary Care -11
                    DataRow drBenefitValues_InNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkPhysicalOfficePrimaryCare != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficePrimaryCare);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(11, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkPhysicalOfficePrimaryCare != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficePrimaryCare);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(11, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3PhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3PhysicalOfficePrimaryCare != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3PhysicalOfficePrimaryCare);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(11, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Physical Office Visit -Specialty Care - 12
                    //In Network
                    DataRow drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(12, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(12, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Leve3PhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Leve3PhysicalOfficeSpecialtyCare != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Leve3PhysicalOfficeSpecialtyCare);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(12, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Physical Office Visit - Preventive Adult Periodic Exams - 14
                    //In Network
                    DataRow drBenefitValues_InNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare);
                        OfficeVisitExam = AttributeValue;
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(14, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkPreventiveAdultPeriodicExams != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveAdultPeriodicExams);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(14, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3PreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3PreventiveAdultPeriodicExams != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3PreventiveAdultPeriodicExams);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(14, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Physical Office Visit - Preventive Well-Child Care - 15
                    //InNetwork
                    DataRow drBenefitValues_InNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkPreventiveWellChildCare != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkPreventiveWellChildCare);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(15, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkPreventiveWellChildCare != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveWellChildCare);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(15, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Leve3PreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Leve3PreventiveWellChildCare != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Leve3PreventiveWellChildCare);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(15, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Dignistic Services - X-ray and Lab Tests = 17
                    //InNetwork
                    DataRow drBenefitValues_InNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDisgnisticXrayLabTest != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticXrayLabTest);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(17, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDisgnisticXrayLabTest != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticXrayLabTest);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(17, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_level3DisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_level3DisgnisticXrayLabTest != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_level3DisgnisticXrayLabTest);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(17, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Dignistic Services - Complex Radiology = 18
                    //InNetwork
                    DataRow drBenefitValues_InNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDisgnisticComplexRadiology != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticComplexRadiology);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(18, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDisgnisticComplexRadiology != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticComplexRadiology);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(18, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_level3DisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_level3DisgnisticComplexRadiology != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_level3DisgnisticComplexRadiology);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(18, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Dignistic Services - Urgent Care Facility - 19
                    //InNetwork
                    DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(19, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(19, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(19, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Dignistic Services - EmergencyRoom - 20
                    //InNetwork
                    DataRow drBenefitValues_InNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkEmrgRoomFacilityCharge != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkEmrgRoomFacilityCharge);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(20, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkEmrgRoomFacilityCharge != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkEmrgRoomFacilityCharge);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(20, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Leve3EmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Leve3EmrgRoomFacilityCharge != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Leve3EmrgRoomFacilityCharge);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(20, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Dignistic Services - Inpatient Facility Charges - 21
                    //InNetwork
                    DataRow drBenefitValues_InNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkInpatientFacilityCharges != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkInpatientFacilityCharges);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(21, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkInpatientFacilityCharges != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkInpatientFacilityCharges);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(21, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3InpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3InpatientFacilityCharges != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3InpatientFacilityCharges);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(21, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Dignistic Services - Outpatient Facility and Surgical Charges- 22
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(22, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(22, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OutpatientFacilityandSurgicalCharges != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutpatientFacilityandSurgicalCharges);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(22, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }

                    AttributeValue = "";
                    #endregion

                    #region Mental Health - Inpatient - 24
                    //InNetwork
                    DataRow drBenefitValues_InNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkMentalHealthInpatient != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthInpatient);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(24, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkMentalHealthInpatient != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthInpatient);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(24, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3MentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3MentalHealthInpatient != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3MentalHealthInpatient);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(24, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Mental Health - Inpatient - 25
                    //InNetwork
                    DataRow drBenefitValues_InNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkMentalHealthOutpatient != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthOutpatient);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(25, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkMentalHealthOutpatient != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthOutpatient);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(25, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValuesLevel3MentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValuesLevel3MentalHealthOutpatient != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValuesLevel3MentalHealthOutpatient);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(25, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }

                    AttributeValue = "";
                    #endregion

                    #region Substance Abuse - Inpatient - 27
                    //InNetwork
                    DataRow drBenefitValues_InNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 669 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkMentalSubAbuseInpatient != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseInpatient);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(27, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 669 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkMentalSubAbuseInpatient != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseInpatient);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(27, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3MentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 669 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3MentalSubAbuseInpatient != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseInpatient);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(27, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Substance Abuse - Outpatient - 28
                    //InNetwork
                    DataRow drBenefitValues_InNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 672 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkMentalSubAbuseOutpatient != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseOutpatient);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(28, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 672 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkMentalSubAbuseOutpatient != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseOutpatient);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(28, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        DataRow drBenefitValues_Level3MentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 672 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                        if (drBenefitValues_Level3MentalSubAbuseOutpatient != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseOutpatient);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(28, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                        AttributeValue = "";
                    }
                    AttributeValue = "";
                    #endregion

                    #region Other Services - Chiropractic - 30
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOtherServiceChiropractic != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOtherServiceChiropractic);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(30, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOtherServiceChiropractic != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOtherServiceChiropractic);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(30, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OtherServiceChiropractic != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OtherServiceChiropractic);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(30, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion
                    #endregion

                    #region PharmacySesion

                    #region Retail Pharmacy (30 Day Supply)- Generic (Tier 1)- 3
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutpatientGenericFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientGenericFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(3, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutpatientGenericFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientGenericFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(3, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        DataRow drBenefitValues_Level3OutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                        if (drBenefitValues_Level3OutpatientGenericFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutpatientGenericFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(3, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                        AttributeValue = "";
                    }
                    AttributeValue = "";
                    #endregion

                    #region Retail Pharmacy (30 Day Supply)- Preferred (Tier 2)- 4
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutPreferredFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(4, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutPreferredFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(4, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OutPreferredFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutPreferredFacility);
                            }
                            oWordDoc.Tables[PharmacyTableIndex].Cell(4, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Retail Pharmacy (30 Day Supply)- Non-Preferred (Tier 3)- 5
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutNonPreferredFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutNonPreferredFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(5, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutpatientNonPreferredFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientNonPreferredFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(5, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OutpatientNonPreferredFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutpatientNonPreferredFacility);
                            }
                            oWordDoc.Tables[PharmacyTableIndex].Cell(5, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Retail Pharmacy (30 Day Supply)- Preferred Specialty (Tier 4)- 6
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutPreferredSpecialtyFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredSpecialtyFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(6, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutPreferredSpecialtyFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredSpecialtyFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(6, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_LEVEL3OutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_LEVEL3OutPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_LEVEL3OutPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[PharmacyTableIndex].Cell(6, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }

                    }
                    AttributeValue = "";
                    #endregion

                    #region Mail Order Pharmacy (90 Day Supply)- Generic (Tier 1)- 8
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutMailOrderGenericFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderGenericFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(8, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutMailOrderGenericFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderGenericFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(8, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OutMailOrderGenericFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderGenericFacility);
                            }
                            oWordDoc.Tables[PharmacyTableIndex].Cell(8, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Mail Order Pharmacy (90 Day Supply)- Preferred (Tier 2)- 9
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutMailOrderPreferredFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(9, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutMailOrderPreferredFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(9, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OutMailOrderPreferredFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredFacility);
                            }
                            oWordDoc.Tables[PharmacyTableIndex].Cell(9, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Mail Order Pharmacy (90 Day Supply)- Non-Preferred (Tier 3)- 10
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutMailOrderNonPreferredFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderNonPreferredFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(10, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(10, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OutMailOrderNonPreferredFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderNonPreferredFacility);
                            }
                            oWordDoc.Tables[PharmacyTableIndex].Cell(10, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Mail Order Pharmacy (90 Day Supply)- Preferred Specialty (Tier 4)- 11
                    //InNetwork
                    DataRow drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility);
                    }
                    oWordDoc.Tables[PharmacyTableIndex].Cell(11, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility);
                        }
                        oWordDoc.Tables[PharmacyTableIndex].Cell(11, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[PharmacyTableIndex].Cell(11, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #endregion

                    if (SummaryCount == 1)
                    {
                        TotalBenefitSummeries = TotalBenefitSummeries + 1;
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedicalBenefit" + TotalBenefitSummeries, SummaryName);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedicaPlanType" + TotalBenefitSummeries, ProduTypeDescription);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedicalCarrier" + TotalBenefitSummeries, Carrier);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedAnnualDedFamily" + TotalBenefitSummeries, AnnualDeductibleFamily);
                        WriteToMergeField(oWordDoc, oWordApp, "FrontPageMedOfficeVisitExam" + TotalBenefitSummeries, OfficeVisitExam);

                    }
                    InNetworkColumnIndex = InNetworkColumnIndex + IncreamentCount;
                }

                switch (SummaryCount)
                {
                    case 1:
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 1, 1, null);
                        switch (PlanTier)
                        {
                            case 1:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 3, int.MaxValue, SkippedRowIndexes);

                                //Pharmacy Table Header
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 2, 4, 1, 2, null);
                                //Pharmacy Table Body
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 2, 4, 3, int.MaxValue, PharmacySkippedRowIndex);
                                break;
                            case 2:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 7, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 7, 3, int.MaxValue, SkippedRowIndexes);

                                //Pharmacy Table Header
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 7, 1, 2, null);
                                //Pharmacy Table Body
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 7, 3, int.MaxValue, PharmacySkippedRowIndex);
                                break;
                            case 3:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 10, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 10, 3, int.MaxValue, SkippedRowIndexes);

                                //Pharmacy Table Header
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 4, 10, 1, 2, null);
                                //Pharmacy Table Body
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 4, 10, 3, int.MaxValue, PharmacySkippedRowIndex);
                                break;
                        }
                        break;
                    case 2:
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 1, 1, null);
                        switch (PlanTier)
                        {
                            case 1:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 3, int.MaxValue, SkippedRowIndexes);

                                //Pharmacy Table Header
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 4, 1, 2, null);
                                //Pharmacy Table Body
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 3, 4, 3, int.MaxValue, PharmacySkippedRowIndex);
                                break;
                            case 2:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 7, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 7, 3, int.MaxValue, SkippedRowIndexes);

                                //Pharmacy Table Header
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 5, 7, 1, 2, null);
                                //Pharmacy Table Body
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 5, 7, 3, int.MaxValue, PharmacySkippedRowIndex);
                                break;
                            case 3:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 10, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 10, 3, int.MaxValue, SkippedRowIndexes);

                                //Pharmacy Table Header
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 7, 10, 1, 2, null);
                                //Pharmacy Table Body
                                MergeTableColumns(oWordDoc, PharmacyTableIndex, 7, 10, 3, int.MaxValue, PharmacySkippedRowIndex);
                                break;
                        }
                        break;
                }

                oWordDoc.Tables[BenefitCoverageTableIndex].Columns.DistributeWidth();
                BenefitCoverageTableIndex = BenefitCoverageTableIndex + 3;
                ContrbutionTableIndex = ContrbutionTableIndex + 3;
                PharmacyTableIndex = PharmacyTableIndex + 3;

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("First Medical Effective Date"))
                        {
                            myMergeField.Select();

                            oWordApp.Selection.TypeText((Convert.ToDateTime(Renewaldate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(Renewaldate.ToString()).Year.ToString()).Trim());
                            continue;
                        }
                        if (fieldName.Contains("Renewal Date"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText((Convert.ToDateTime(Effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(Effectivedate.ToString()).Year.ToString()).Trim());
                            continue;
                        }

                        if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                        {
                            myMergeField.Select();

                            if (Emp.Rows.Count > 0)
                            {
                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }

                        if (fieldName.Contains("Medical Plan Waiting Period"))
                        {
                            myMergeField.Select();
                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                            {
                                if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().ToLower().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }


                        if (fieldName.Contains("Client_Name_" + PlanCount))  //LTD Carrier Name
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                        if (fieldName.Contains("Carrier_Name_" + PlanCount))  //LTD Carrier Name
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }

                        if (fieldName.Contains("Medical_Plan_Type_" + PlanCount)) //LTD Benefit Summary Name
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(PlanTypeDescription);
                            continue;
                        }
                        if (fieldName.Contains("Number_of_Medical_Plans_Selected")) //LTD Benefit Summary Name
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(SelectedPlanType.ToString());
                            continue;
                        }
                    }
                }
                #endregion

            }

        }
        public void WriteDentalSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Dental");
            List<int> SkippeRowSpan = new List<int>() { 1, 3, 7, 12 };
            int BenefitCoverageTableIndex = 19;
            int ContrbutionTableIndex = 20;
            //int PharmacyTableIndex = 3;

            #region Mark written tables by removing from "AllBookmarks"

            int noOfTables = dictMap.Count;
            string bookmark = string.Empty;

            for (int i = 1; i <= noOfTables; i++)
            {
                bookmark = "DentalPlanTables" + i.ToString();     // DentalPlanTables1, DentalPlanTables2 etc....
                if (AllBookmarks["Dental"].ContainsKey(bookmark))
                {
                    AllBookmarks["Dental"].Remove(bookmark);
                }
            }

            #endregion

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in DentalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in DentalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            int DentalPlanCount = dictMap.Keys.Count;
            string strAllCarriers = "";
            // Write for each disctinct plan selected
            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                string Carrier = drPlanRow["Carrier"].ToString();
                if (string.IsNullOrEmpty(strAllCarriers))
                    strAllCarriers = Carrier;
                else
                    strAllCarriers = strAllCarriers + "," + Carrier;

                PlanCount = PlanCount + 1;
                List<int> BenefitSummarries = dictMap[key];
                int InNetworkColumnIndex = 0;
                int IncreamentCount = 0;

                int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);

                switch (PlanTier)
                {
                    case 1:
                        InNetworkColumnIndex = 2;
                        IncreamentCount = 1;

                        //Benefit Table Header
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 2, 2, null); // Merge the benefit summery column
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 5, 2, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 6, 2, 2, null);

                        //Benefit Table Body
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 3, int.MaxValue, SkippeRowSpan);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 5, 3, int.MaxValue, SkippeRowSpan);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 6, 3, int.MaxValue, SkippeRowSpan);
                        break;
                    case 2:
                        InNetworkColumnIndex = 2;
                        IncreamentCount = 2;

                        //Table Header
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 2, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 6, 2, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 8, 2, 2, null);

                        //Table Body
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 3, int.MaxValue, SkippeRowSpan);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 6, 3, int.MaxValue, SkippeRowSpan);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 8, 3, int.MaxValue, SkippeRowSpan);
                        break;
                    case 3:
                        InNetworkColumnIndex = 2;
                        IncreamentCount = 3;
                        break;
                }


                int BenefitSummaryCount = 0;
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    string AttributeValue = "";
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                    string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount + 1).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                    #region Benefits Coverage

                    #region Annual Deductible Individual - 4
                    //In Network
                    DataRow drBenefitValues_InNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalIndividual != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalIndividual);
                        int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkDentalIndividual["benefitColumnID"].ToString());
                        string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(2, InNetworkColumnIndex).Range.Text = ColumnNameLevel1;
                    }

                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(4, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    // Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalIndividual != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalIndividual);
                            int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkDentalIndividual["benefitColumnID"].ToString());
                            string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(2, InNetworkColumnIndex + 1).Range.Text = ColumnNameLevel2;
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(4, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalIndividual != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalIndividual);
                                int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3DentalIndividual["benefitColumnID"].ToString());
                                string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                oWordDoc.Tables[BenefitCoverageTableIndex].Cell(2, InNetworkColumnIndex + 2).Range.Text = ColumnNameLevel3;
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(4, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Annual Deductible Family - 5
                    //In Network
                    DataRow drBenefitValues_InNetworkDentalFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalFamily != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalFamily);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(5, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDenatlFamily != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDenatlFamily);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(5, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DenatlFamily != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DenatlFamily);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(5, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }

                    AttributeValue = "";
                    #endregion

                    #region Annual Deductible Waived for Preventive Care - 6
                    //In Network
                    DataRow drBenefitValues_InNetworkDenatlCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDenatlCoinsurance != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDenatlCoinsurance);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(6, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalCoinsurance != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalCoinsurance);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(6, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalCoinsurance != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalCoinsurance);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(6, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Per Person/Family (indicate calendar/benefit year) - 8
                    //In Network
                    DataRow drBenefitValues_InNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalAnnualPlanMaximum != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalAnnualPlanMaximum);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(8, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalAnnualPlanMaximum != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalAnnualPlanMaximum);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(8, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalAnnualPlanMaximum != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalAnnualPlanMaximum);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(8, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Preventive - 9
                    //In Network
                    DataRow drBenefitValues_InNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalPreventive != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalPreventive);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(9, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalPreventive != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalPreventive);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(9, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalPreventive != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalPreventive);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(9, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Basic Services – Basic -10
                    DataRow drBenefitValues_InNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalBasicServices != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalBasicServices);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(10, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalBasicServices != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalBasicServices);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(10, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalBasicServices != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalBasicServices);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(10, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Major Services – Major - 11
                    //In Network
                    DataRow drBenefitValues_InNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalMajorServices != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalMajorServices);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(11, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalMajorServices != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalMajorServices);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(11, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalMajorServices != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalMajorServices);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(11, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Orthodontia-Orthodontia Services / Orthodontia - 13
                    //In Network
                    DataRow drBenefitValues_InNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalOrthodontiaServices != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontiaServices);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(13, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";
                    //Out Network
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalOrthodontiaServices != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontiaServices);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(13, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalOrthodontiaServices != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontiaServices);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(13, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Orthodontia Services / Adults (and covered full-time students - 14
                    //InNetwork
                    DataRow drBenefitValues_InNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalOrthodontia != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontia);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(14, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalOrthodontia != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontia);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(14, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalOrthodontia != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontia);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(14, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region Orthodontia Services / Dependent Children 15
                    //InNetwork
                    DataRow drBenefitValues_InNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalDependentChildren != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalDependentChildren);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(15, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalDependentChildren != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalDependentChildren);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(15, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalDependentChildren != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalDependentChildren);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(15, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region General Plan Information – Lifetime Orthodontial Plan Maximum -16
                    //InNetwork
                    DataRow drBenefitValues_InNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDentalLifetimeOrthodontia != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDentalLifetimeOrthodontia);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(16, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDentalLifetimeOrthodontia != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalLifetimeOrthodontia);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(16, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DentalLifetimeOrthodontia != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DentalLifetimeOrthodontia);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(16, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #region General Plan Information – Waiting Period - 17
                    //InNetwork
                    DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                    if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(17, InNetworkColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    //OutNetwork
                    if (PlanTier >= 2)
                    {
                        DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                        if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                        {
                            AttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(17, InNetworkColumnIndex + 1).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier == 3)
                        {
                            DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                            if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(17, InNetworkColumnIndex + 2).Range.Text = AttributeValue;
                            AttributeValue = "";
                        }
                    }
                    AttributeValue = "";
                    #endregion

                    #endregion

                    InNetworkColumnIndex = InNetworkColumnIndex + IncreamentCount;
                }

                strAllCarriers = strAllCarriers.TrimEnd(',');
                if (PlanCount > 1)
                {
                    int lastIndex = strAllCarriers.LastIndexOf(',');
                    strAllCarriers = (strAllCarriers.Substring(0, lastIndex) + " and " + strAllCarriers.Substring(lastIndex + 1));
                }

                switch (BenefitSummaryCount)
                {
                    case 1:
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 1, 1, null);
                        switch (PlanTier)
                        {
                            case 1:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 3, int.MaxValue, SkippeRowSpan);
                                break;
                            case 2:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 7, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 7, 3, int.MaxValue, SkippeRowSpan);
                                break;
                            case 3:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 10, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 4, 10, 3, int.MaxValue, SkippeRowSpan);
                                break;
                        }
                        break;
                    case 2:
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 1, 1, null);
                        switch (PlanTier)
                        {
                            case 1:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 3, int.MaxValue, SkippeRowSpan);
                                break;
                            case 2:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 7, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 5, 7, 3, int.MaxValue, SkippeRowSpan);
                                break;
                            case 3:
                                //Benefit Table Header
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 10, 2, 2, null);
                                //Benefit Table Body
                                MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 7, 10, 3, int.MaxValue, SkippeRowSpan);
                                break;
                        }
                        break;
                }

                BenefitCoverageTableIndex = BenefitCoverageTableIndex + 2;
                ContrbutionTableIndex = ContrbutionTableIndex + 2;
            }

            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Dental Carrier Name"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(strAllCarriers);
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteVisionSectionToTemplateBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            listPlan.Add("Vision");
            int BenefitCoverageTableIndex = 25;

            #region Mark written tables by removing from "AllBookmarks"

            int noOfTables = dictMap.Count;
            string bookmark = string.Empty;

            for (int i = 1; i <= noOfTables; i++)
            {
                bookmark = "VisionPlanTables" + i.ToString();     // MedicalPlanTables1, MedicalPlanTables2 etc....
                if (AllBookmarks["Vision"].ContainsKey(bookmark))
                {
                    AllBookmarks["Vision"].Remove(bookmark);
                }
            }

            #endregion

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected
            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;
                List<int> BenefitSummarries = dictMap[key];
                int AttributeValueColumnIndex = 2;
                // Write for each Benefit Summary selected
                int BenefitSummaryCount = 0;
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    string AttributeValue = "";
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                    string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount + 1).Range.Text = SummaryName;

                    #region Benefit Coverage-Copay-Routine Exam-4
                    //InNetwork
                    DataRow drBenefitValues_CopayRoutineExamFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_CopayRoutineExamFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_CopayRoutineExamFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(4, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Copay-Routine Materials-5
                    //InNetwork
                    DataRow drBenefitValues_CopayRoutineMaterialsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_CopayRoutineMaterialsFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_CopayRoutineMaterialsFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(5, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Lenses-Single Vision Lenses-7
                    //InNetwork
                    DataRow drBenefitValues_LensesSingleVisionFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 507 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_LensesSingleVisionFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_LensesSingleVisionFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(7, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Lenses-Bifocal Lenses-8
                    //InNetwork
                    DataRow drBenefitValues_LensesBifocalFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 73 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_LensesBifocalFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_LensesBifocalFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(8, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Lenses-Trifocal Lens-9
                    //InNetwork
                    DataRow drBenefitValues_LensesTrifocalFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 553 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_LensesTrifocalFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_LensesTrifocalFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(9, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Frames-Retail Equivalent-Frames-11
                    //InNetwork
                    DataRow drBenefitValues_CoveredServicesFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 208 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_CoveredServicesFramesFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServicesFramesFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(11, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Contact Lenses-Necessary / Prescribed-Frames-Contact Lenses-13
                    //InNetwork
                    DataRow drBenefitValues_CoveredServicesContactLensesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 356 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_CoveredServicesContactLensesFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServicesContactLensesFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(13, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Contact Lenses-Necessary / Prescribed-Frames-Elective-14
                    //InNetwork
                    DataRow drBenefitValues_CoveredServicesElectiveFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_CoveredServicesElectiveFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServicesElectiveFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(14, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Other Services Laser Corrective Surgery-Corrective Vision Services-16
                    //InNetwork
                    DataRow drBenefitValues_CoveredLaserCorrectiveSurgeryFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 133 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_CoveredLaserCorrectiveSurgeryFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredLaserCorrectiveSurgeryFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(16, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Frequency-Routine Exams-18
                    //InNetwork
                    DataRow drBenefitValues_GeneralPlanInformationExamsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 194 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_GeneralPlanInformationExamsFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationExamsFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(18, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Frequency-Routine Lenses-19
                    //InNetwork
                    DataRow drBenefitValues_GeneralPlanInformationLensesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_GeneralPlanInformationLensesFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationLensesFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(19, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Frequency-Routine Frames-20
                    //InNetwork
                    DataRow drBenefitValues_GeneralPlanInformationFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_GeneralPlanInformationFramesFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationFramesFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(20, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    #region Benefit Coverage-Frequency-Routine Contacts-21
                    //InNetwork
                    DataRow drBenefitValues_GeneralPlanInformationContactsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_GeneralPlanInformationContactsFacility != null)
                    {
                        AttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationContactsFacility);
                    }
                    oWordDoc.Tables[BenefitCoverageTableIndex].Cell(21, AttributeValueColumnIndex).Range.Text = AttributeValue;
                    AttributeValue = "";

                    #endregion

                    AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                }

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Vision_ClientName_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                    }
                }

                #endregion

                switch (BenefitSummaryCount)
                {
                    case 1:
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 1, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 2, 4, 3, int.MaxValue, null);
                        break;
                    case 2:
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 1, 2, null);
                        MergeTableColumns(oWordDoc, BenefitCoverageTableIndex, 3, 4, 3, int.MaxValue, null);
                        break;
                    default:
                        break;
                }

                BenefitCoverageTableIndex = BenefitCoverageTableIndex + 2;
            }
        }

        private string GetBenefitFormattedValue(DataRow dr)
        {
            if (dr != null)
                return (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
            return "";
        }
        public void getBookmarks()
        {
            AllBookmarks.Clear();
            /* =======================================================================================
             *Section         -> BookMark :-                             'VoluntaryADD'
             *Section         -> Header desc in 1st page (if exists):-   'VoluntaryADDMain'
             *Sub-Section     -> general Description:-                   'VoluntaryADDDescription'
             *Sub-Section     -> Single Plan Description: -              'VoluntaryADDSingleDescription'
             *Sub-Section     -> Multiple Plan Description :-            'VoluntaryADDMultipleDescription'
             *Sub-Section     -> Plan Tables :-                          'VoluntaryADDPlanTables'
             ============================================================================================*/
            #region Medical Bookmarks


            Dictionary<string, string> medicalBookmarks = new Dictionary<string, string>();
            medicalBookmarks.Add("MedicalSinglePlanDescription", "MedicalSinglePlanDescription");
            medicalBookmarks.Add("MedicalMultiplePlanDescription", "MedicalMultiplePlanDescription");

            medicalBookmarks.Add("MedicalHMODescription1", "MedicalHMODescription1");
            medicalBookmarks.Add("MedicalPPODescription1", "MedicalPPODescription1");
            medicalBookmarks.Add("MedicalPlanTables1", "MedicalPlanTables1");
            medicalBookmarks.Add("MedicalPlanTables2", "MedicalPlanTables2");
            medicalBookmarks.Add("MedicalPlanTables3", "MedicalPlanTables3");
            medicalBookmarks.Add("MedicalPlanTables4", "MedicalPlanTables4");
            medicalBookmarks.Add("MedicalPlanTables5", "MedicalPlanTables5");
            medicalBookmarks.Add("MedicalPlanTables6", "MedicalPlanTables6");

            medicalBookmarks.Add("MedicalSampleTest", "MedicalSampleTest");


            medicalBookmarks.Add("FrontPageMedPlan1", "FrontPageMedPlan1");
            medicalBookmarks.Add("FrontPageMedPlan2", "FrontPageMedPlan2");
            medicalBookmarks.Add("FrontPageMedPlan3", "FrontPageMedPlan3");
            medicalBookmarks.Add("FrontPageMedPlan4", "FrontPageMedPlan4");
            medicalBookmarks.Add("FrontPageMedPlan5", "FrontPageMedPlan5");

            #endregion

            #region Dental Bookmarks
            Dictionary<string, string> dentalBookmarks = new Dictionary<string, string>();
            //dentalBookmarks.Add("DentalSingleCarrier", "DentalSingleCarrier");
            dentalBookmarks.Add("DentalMultipleCarrier", "DentalMultipleCarrier");
            dentalBookmarks.Add("DentalPlanTables1", "DentalPlanTables1");
            dentalBookmarks.Add("DentalPlanTables2", "DentalPlanTables2");
            dentalBookmarks.Add("DentalPlanTables3", "DentalPlanTables3");

            #endregion

            #region Vision Bookmarks
            Dictionary<string, string> visionBookmarks = new Dictionary<string, string>();
            visionBookmarks.Add("VisionDescription1", "VisionDescription1");
            visionBookmarks.Add("VisionPlanTables1", "VisionPlanTables1");
            visionBookmarks.Add("VisionPlanTables2", "VisionPlanTables2");
            visionBookmarks.Add("VisionPlanTables3", "VisionPlanTables3");

            #endregion

            #region HSA Bookmarks
            Dictionary<string, string> HSABookmarks = new Dictionary<string, string>();
            // HSABookmarks.Add("HSADescription1", "HSADescription1");
            // visionBookmarks.Add("Vision_Description2", "Vision_Description2");
            #endregion

            #region HRA Bookmarks
            Dictionary<string, string> HRABookmarks = new Dictionary<string, string>();
            //HRABookmarks.Add("HRADescription1", "HRADescription1");
            #endregion

            #region FSA Bookmarks
            Dictionary<string, string> FSABookmarks = new Dictionary<string, string>();
            //FSABookmarks.Add("FSADescription1", "FSADescription1");
            #endregion

            #region Life and AD&D Bookmarks
            Dictionary<string, string> ADDBookmarks = new Dictionary<string, string>();
            ADDBookmarks.Add("LifeandADDPlan1", "LifeandADDPlan1");
            ADDBookmarks.Add("LifeandADDPlan2", "LifeandADDPlan2");

            #endregion

            #region Voluntary Life and AD&D Bookmarks
            Dictionary<string, string> VolLifeADDBookmarks = new Dictionary<string, string>();
            //VolLifeADDBookmarks.Add("VoluntaryLife1", "VoluntaryLife1");
            VolLifeADDBookmarks.Add("VoluntaryLifeDescription1", "VoluntaryLifeDescription1");
            VolLifeADDBookmarks.Add("VoluntaryLifeDescription2", "VoluntaryLifeDescription2");
            #endregion

            #region STD Bookmarks
            Dictionary<string, string> STDBookmarks = new Dictionary<string, string>();
            //STDBookmarks.Add("STDDescription", "STDDescription");
            #endregion

            #region LTD Bookmarks
            Dictionary<string, string> LTDBookmarks = new Dictionary<string, string>();
            LTDBookmarks.Add("LTDPlan1", "LTDPlan1");
            LTDBookmarks.Add("LTDPlan2", "LTDPlan2");
            #endregion

            #region EAP Bookmarks
            Dictionary<string, string> EAPBookmarks = new Dictionary<string, string>();
            //EAPBookmarks.Add("EAPDescription", "EAPDescription");
            #endregion

            AllBookmarks.Add("Medical", medicalBookmarks);
            AllBookmarks.Add("Dental", dentalBookmarks);
            AllBookmarks.Add("Vision", visionBookmarks);
            AllBookmarks.Add("HSA", HRABookmarks);
            AllBookmarks.Add("HRA", HRABookmarks);
            AllBookmarks.Add("FSA", FSABookmarks);
            //  AllBookmarks.Add("STD", STDBookmarks);
            AllBookmarks.Add("Voluntary Life", VolLifeADDBookmarks);
            AllBookmarks.Add("Life and AD&D", ADDBookmarks);
            AllBookmarks.Add("LTD", LTDBookmarks);
            AllBookmarks.Add("EAP", EAPBookmarks);


        }
        // Deletes Bookmarks which presents in "AllBookmarks" Dictonary
        public void DeleteBookmarks(Word.Document oWordDoc, Word.Application oWordApp, Dictionary<string, Dictionary<int, List<int>>> dictProductMap, DataTable PlanInfoTable, bool isBRCSelected)
        {
            string formattedPlanType = string.Empty;   //to format special characters and spaces -- which are not detected in bookmarks
            string mainDesc = string.Empty;            //Main descrption on 1st page

            #region Delete non-selected plans and sub-sections including Header on 1st Page
            foreach (string plantype in AllBookmarks.Keys)
            {

                if (!dictProductMap.ContainsKey(plantype))
                {
                    formattedPlanType = plantype.Replace("&", "").Replace(" ", "");

                    mainDesc = formattedPlanType + "Main";        //If Plan not selected

                    if (oWordDoc.Bookmarks.Exists(mainDesc))    // Delete Main Description on 1st page
                    {
                        oWordDoc.Bookmarks[mainDesc].Range.Delete();
                    }

                    if (oWordDoc.Bookmarks.Exists(formattedPlanType))     // Delete Enitre Section
                    {
                        oWordDoc.Bookmarks[formattedPlanType].Range.Delete();
                    }
                    //DeleteIndivialBookmark(oWordDoc, mainDesc);              UnComment if bookmark not deleted
                    // DeleteIndivialBookmark(oWordDoc, formattedPlanType);

                }
                else
                {                                                                     //If PlanType is selected
                    if (AllBookmarks[plantype] != null)
                    {
                        foreach (string bookmark in AllBookmarks[plantype].Keys)     // Loop through inner bookmarks and delete unwanted sub-sections
                        {
                            formattedPlanType = bookmark.Replace("&", "").Replace(" ", "");

                            if (oWordDoc.Bookmarks.Exists(formattedPlanType))
                            {
                                oWordDoc.Bookmarks[bookmark].Range.Delete();
                            }
                            DeleteIndivialBookmark(oWordDoc, formattedPlanType);
                        }
                    }
                }
            }
            #endregion

            #region Delete Product sections

            bool is_Patient_Advocacy_Selected = false;
            bool is_Consumer_Driven_Telemedicine_Selected = false;

            if (PlanInfoTable != null)
            {
                for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                {
                    if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                    {
                        is_Patient_Advocacy_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                    {
                        is_Consumer_Driven_Telemedicine_Selected = true;
                    }
                }
            }


            if (is_Patient_Advocacy_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("PatientAdvocacyProgram"))
                {
                    oWordDoc.Bookmarks["PatientAdvocacyProgram"].Range.Delete();
                }
            }
            if (is_Consumer_Driven_Telemedicine_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("Telemedicine"))
                {
                    oWordDoc.Bookmarks["Telemedicine"].Range.Delete();
                }

            }


            #endregion

            #region Delete BRC Section
            if (isBRCSelected == false)
            {
                if (oWordDoc.Bookmarks.Exists("BRC"))
                {
                    oWordDoc.Bookmarks["BRC"].Range.Delete();
                }
            }
            #endregion

        }
        // Call if bookmark which are not present in "AllBookmarks"
        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }
        public void DeleteColumn(Word.Document oWordDoc, int TableNo, int RowWithSplitColumns, int colStart, int ColEnd)
        {
            try
            {

                //Column delete
                Range ColumnsRange = oWordDoc.Range(oWordDoc.Tables[TableNo].Cell(RowWithSplitColumns, colStart).Range.Start, oWordDoc.Tables[TableNo].Cell(RowWithSplitColumns, ColEnd).Range.End);
                ColumnsRange.Columns.Delete();

                #region Commented -- Fixing 1st cloumns width and expanding remaining cloumns

                //Auto Fitting Table
                oWordDoc.Tables[TableNo].AllowAutoFit = true;
                oWordDoc.Tables[TableNo].AutoFitBehavior(WdAutoFitBehavior.wdAutoFitWindow);

                //Setting Left header i.e 1st Column to fixed width 2.18f
                Range LeftHeaderRange = oWordDoc.Tables[TableNo].Cell(1, 1).Range;
                LeftHeaderRange.Columns.PreferredWidthType = WdPreferredWidthType.wdPreferredWidthPoints;
                LeftHeaderRange.Columns.PreferredWidth = oWordDoc.Application.InchesToPoints(2.18f);

                #endregion

            }
            catch (Exception ex)
            {

            }
        }
        public void MergeTableColumns(Word.Document oWordDoc, int TableIndex, int MergeStart, int MergeEnd, int RowStartIndex, int RowEndIndex, List<int> SkippedRowIndexes)
        {
            Microsoft.Office.Interop.Word.Table objTable;
            objTable = oWordDoc.Tables[TableIndex];

            for (int i = RowStartIndex; i <= RowEndIndex; i++)
            {
                if (i > objTable.Rows.Count) break;
                if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                {
                    if (!SkippedRowIndexes.Contains(i))
                    {
                        objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                    }
                }
                else
                {
                    objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                }
            }
        }
        public int CheckPlanTier(int AttributeId, int BenefitSummaryId, DataTable BenefitTable)
        {
            int Count = 0;
            List<int> lstBenefitColumnID = new List<int>();
            foreach (DataRow dr in BenefitTable.Rows)
            {
                if (dr["attributeID"].ToString() == AttributeId.ToString() && dr["benefitSummaryID"].ToString() == BenefitSummaryId.ToString())
                {
                    int benefitColumnID = int.Parse(dr["benefitColumnID"].ToString());
                    if (!lstBenefitColumnID.Contains(benefitColumnID))
                        lstBenefitColumnID.Add(benefitColumnID);
                }
            }
            return lstBenefitColumnID.Count;
        }
        public void WriteToMergeField(Word.Document oWordDoc, Word.Application oWordApp, string FieldName, string Value)
        {

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(FieldName))
                    {
                        myMergeField.Select();
                        if (Value.Trim() == string.Empty)
                            myMergeField.Delete();
                        else
                            oWordApp.Selection.TypeText(Value);
                        continue;
                    }

                }
            }
        }
        public void FillPlanDetails(Word.Document oWordDoc, Word.Application oWordApp)
        {
            int rowCnt = 0;

            List<string> plansListed = new List<string>();

            foreach (string item in listPlan)
            {
                if (!plansListed.Contains(item))
                {
                    plansListed.Add(item);
                }
            }

            foreach (string planType in plansListed)
            {
                rowCnt++;
                if (rowCnt > 1)
                {
                    oWordDoc.Tables[2].Rows.Add();
                }

                oWordDoc.Tables[2].Cell(rowCnt, 1).Range.Text = planType;

            }

            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("FrontPage_STDLTD_Head"))
                    {
                        myMergeField.Select();
                        if (IsSTDExists == true && IsIsLTDExists == true)
                        {
                            oWordApp.Selection.TypeText("Short and Long Term Disability");
                        }
                        else
                        {
                            if (IsSTDExists)
                                oWordApp.Selection.TypeText("Short Term Disability");
                            if (IsIsLTDExists)
                                oWordApp.Selection.TypeText("Long Term Disability");
                        }
                        continue;
                    }
                }
            }

            #endregion
        }
        
        public void WriteEligibilityToBasicBlue(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string DefinationOf_eligible_Emplyee = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();

                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("EmployeeStatus"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Working"))
                    {
                        myMergeField.Select();
                        if (Working != string.Empty)
                            oWordApp.Selection.TypeText(Working);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unitofmeasure"))
                    {
                        myMergeField.Select();
                        if (UOM != string.Empty)
                            oWordApp.Selection.TypeText(UOM);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Frequency_Eligibility"))
                    {
                        myMergeField.Select();
                        if (Frequency != string.Empty)
                            oWordApp.Selection.TypeText(Frequency);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unmarriedchildtoage"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }

                    if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                    {
                        myMergeField.Select();
                        if (DefinationOf_eligible_Emplyee != string.Empty)
                            oWordApp.Selection.TypeText(DefinationOf_eligible_Emplyee);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Medical Plan Waiting Period"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period);
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }

        #region Contribution
        //Contribution 
        public void WriteMonthlyPremiumSectionToMedical(Word.Document oWordDoc, Word.Application oWordApp, DataSet ContributionDS, DataTable PlanTable, string selectedColor, Dictionary<int, List<int>> dictMap, Dictionary<int, List<int>> ContributionList)
        {
            try
            {
                Object missing = System.Reflection.Missing.Value;

                int ContrbutionTableIndex = 2;
                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;

                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = Convert.ToString(drPlanRow["ProductTypeDescription"]);
                    string Carrier = Convert.ToString(drPlanRow["Carrier"]);

                    int monthly_premium_row_counter = 2;
                    int monthly_premium_column_counter = 1;
                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];

                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        BenefitSummaryCount = BenefitSummaryCount + 1;

                        if (BenefitSummaryCount <= 3)  /// Check Not More than 3 Benefit Summery Contribution Print 
                        {

                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                            string ContributionId_1 = Convert.ToString(drPlanBenefitRow["ContributionId"]);
                            string ContributionId_2 = Convert.ToString(drPlanBenefitRow["ContributionId_2"]);
                            string PlanType = Convert.ToString(drPlanBenefitRow["PlanType"]);

                            string ContributionName = Convert.ToString(drPlanBenefitRow["ContributionName"]);

                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            foreach (int ContributionId in ContributionCollection)
                            {
                                /************ HERE WE ONLY ALLOW TO PRINT 3 COUNT CONTRIBUTION DETAILS ***************/
                                if (monthly_premium_column_counter < 4)
                                {
                                    #region  BuildTable
                                    DataTable PremiumTable = new DataTable();
                                    int premium_row_counter = 0;

                                    bool header_created = false;
                                    string Frequency_Of_Contribution = String.Empty;

                                    PremiumTable.Columns.Add("Plan", typeof(string));
                                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                                    PremiumTable.Columns.Add("summaryname", typeof(string));
                                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                                    PremiumTable.Columns.Add("contributionid", typeof(string));
                                    PremiumTable.Columns.Add("rateid", typeof(string));
                                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                                    PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                                    int iTotalFields = 0;
                                    #endregion

                                    #region contribution
                                    //new change
                                    Boolean flag = false;

                                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                    {
                                        if (Convert.ToString(ContributionId) == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                                        {
                                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                                            {
                                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == Convert.ToString(ContributionId) && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == Convert.ToString(PlanType))
                                                {
                                                    flag = true;
                                                    break;
                                                }
                                            }
                                            if (flag == false)
                                            {
                                                PremiumTable.Rows.Add();
                                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
                                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
                                                PremiumTable.Rows[premium_row_counter][3] = "";
                                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                                PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                                //PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                                PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim();
                                                PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString();
                                                Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                                //break;
                                                premium_row_counter++;
                                            }
                                        }
                                    }
                                    //end change
                                    #endregion

                                    #region AddTable

                                    DataTable dt = new DataTable();
                                    //change
                                    //if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                                    if (Convert.ToString(PlanType) == "Voluntary Life Plan")
                                    {
                                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                                        dt = PremiumTable.DefaultView.ToTable(true);
                                        PremiumTable = dt;
                                    }
                                    //End Change
                                    else
                                    {
                                        dt = PremiumTable.DefaultView.ToTable(true);
                                        PremiumTable = dt;
                                    }

                                    if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
                                    {


                                    }

                                    #endregion

                                    #region FillTable
                                    int TableCount = oWordDoc.Tables[ContrbutionTableIndex].Rows.Count;
                                    long differenceCount = Convert.ToInt32(PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count) - TableCount;

                                    oWordDoc.Tables[ContrbutionTableIndex].Rows[2].Range.Copy();
                                    for (int a = 0; a <= differenceCount; a++)
                                    {
                                        oWordDoc.Tables[ContrbutionTableIndex].Rows[2].Range.Paste();
                                    }

                                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                                    {
                                        if (PremiumTable.Rows[i][1].ToString() == "8")
                                        {

                                            monthly_premium_row_counter = 1;
                                            monthly_premium_row_counter++;

                                            //Added by Amogh 
                                            if (oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text.Replace("\r\a", "") != PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                                            {
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                            }
                                            oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            ////}
                                        }
                                        else
                                        {
                                            if (oWordDoc.Tables[ContrbutionTableIndex].Cell((monthly_premium_row_counter + 1), 1).Range.Text.Replace("\r\a", "") == "Employee & " + PremiumTable.Rows[i][2].ToString())
                                            {
                                                monthly_premium_row_counter++;
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[ContrbutionTableIndex].Rows.Add(ref missing);
                                                monthly_premium_row_counter++;


                                                if (oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text != Convert.ToString("Employee & " + PremiumTable.Rows[i][2].ToString()))
                                                {
                                                    oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                                }
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            }
                                        }
                                    }

                                    #endregion

                                    if (monthly_premium_column_counter == 1)
                                    {
                                        oWordDoc.Tables[ContrbutionTableIndex].Cell(1, 1).Range.Text = "Employee Contributions (per " + Frequency_Of_Contribution + ")";
                                    }

                                    monthly_premium_column_counter = monthly_premium_column_counter + 1;
                                }

                            }//ForEach ContributionCollection Close
                        }// BenefitSummaryCount Check 
                    }//Inner ForEach Close

                    ContrbutionTableIndex = ContrbutionTableIndex + 3;
                }//Outer ForEach close

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteMonthlyPremiumSectionToDental(Word.Document oWordDoc, Word.Application oWordApp, DataSet ContributionDS, DataTable PlanTable, string selectedColor, Dictionary<int, List<int>> dictMap, Dictionary<int, List<int>> ContributionList)
        {
            try
            {
                Object missing = System.Reflection.Missing.Value;

                int ContrbutionTableIndex = 20;
                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;

                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = Convert.ToString(drPlanRow["ProductTypeDescription"]);
                    string Carrier = Convert.ToString(drPlanRow["Carrier"]);

                    int monthly_premium_row_counter = 2;
                    int monthly_premium_column_counter = 1;
                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];

                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        BenefitSummaryCount = BenefitSummaryCount + 1;

                        if (BenefitSummaryCount <= 3)  /// Check Not More than 3 Benefit Summery Contribution Print 
                        {

                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                            string ContributionId_1 = Convert.ToString(drPlanBenefitRow["ContributionId"]);
                            string ContributionId_2 = Convert.ToString(drPlanBenefitRow["ContributionId_2"]);
                            string PlanType = Convert.ToString(drPlanBenefitRow["PlanType"]);

                            string ContributionName = Convert.ToString(drPlanBenefitRow["ContributionName"]);

                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            foreach (int ContributionId in ContributionCollection)
                            {
                                /************ HERE WE ONLY ALLOW TO PRINT 3 COUNT CONTRIBUTION DETAILS ***************/
                                if (monthly_premium_column_counter < 4)
                                {
                                    #region  BuildTable
                                    DataTable PremiumTable = new DataTable();
                                    int premium_row_counter = 0;

                                    bool header_created = false;
                                    string Frequency_Of_Contribution = String.Empty;

                                    PremiumTable.Columns.Add("Plan", typeof(string));
                                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                                    PremiumTable.Columns.Add("summaryname", typeof(string));
                                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                                    PremiumTable.Columns.Add("contributionid", typeof(string));
                                    PremiumTable.Columns.Add("rateid", typeof(string));
                                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                                    PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                                    int iTotalFields = 0;
                                    #endregion

                                    #region contribution
                                    //new change
                                    Boolean flag = false;

                                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                    {
                                        //if (Convert.ToString(ContributionId) == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim() || Convert.ToString(ContributionId_2) == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                                        if (Convert.ToString(ContributionId) == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                                        {
                                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                                            {
                                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == Convert.ToString(ContributionId) && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == Convert.ToString(PlanType))
                                                {
                                                    flag = true;
                                                    break;
                                                }
                                            }
                                            if (flag == false)
                                            {
                                                PremiumTable.Rows.Add();
                                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
                                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
                                                PremiumTable.Rows[premium_row_counter][3] = "";
                                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                                PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                                //PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                                PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim();
                                                PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString();
                                                Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                                //break;
                                                premium_row_counter++;
                                            }
                                        }
                                    }
                                    //end change
                                    #endregion

                                    #region AddTable

                                    DataTable dt = new DataTable();
                                    //change
                                    //if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                                    if (Convert.ToString(PlanType) == "Voluntary Life Plan")
                                    {
                                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                                        dt = PremiumTable.DefaultView.ToTable(true);
                                        PremiumTable = dt;
                                    }
                                    //End Change
                                    else
                                    {
                                        dt = PremiumTable.DefaultView.ToTable(true);
                                        PremiumTable = dt;
                                    }

                                    if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
                                    {

                                    }

                                    #endregion

                                    #region FillTable

                                    int TableCount = oWordDoc.Tables[ContrbutionTableIndex].Rows.Count;
                                    long differenceCount = Convert.ToInt32(PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count) - TableCount;

                                    oWordDoc.Tables[ContrbutionTableIndex].Rows[2].Range.Copy();
                                    for (int a = 0; a <= differenceCount; a++)
                                    {
                                        oWordDoc.Tables[ContrbutionTableIndex].Rows[2].Range.Paste();
                                    }

                                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                                    {
                                        if (PremiumTable.Rows[i][1].ToString() == "8")
                                        {
                                            monthly_premium_row_counter = 1;
                                            monthly_premium_row_counter++;

                                            //Added by Amogh 
                                            if (oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text.Replace("\r\a", "") != PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                                            {
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                            }
                                            oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            ////}
                                        }
                                        else
                                        {
                                            if (oWordDoc.Tables[ContrbutionTableIndex].Cell((monthly_premium_row_counter + 1), 1).Range.Text.Replace("\r\a", "") == "Employee & " + PremiumTable.Rows[i][2].ToString())
                                            {
                                                monthly_premium_row_counter++;

                                                // Added by Amogh 
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[ContrbutionTableIndex].Rows.Add(ref missing);
                                                monthly_premium_row_counter++;

                                                //Added by Amogh 
                                                if (oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text != Convert.ToString("Employee & " + PremiumTable.Rows[i][2].ToString()))
                                                {
                                                    oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                                }
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            }
                                        }
                                    }

                                    #endregion

                                    if (monthly_premium_column_counter == 1)
                                    {
                                        oWordDoc.Tables[ContrbutionTableIndex].Cell(1, 1).Range.Text = "Employee Contributions (per " + Frequency_Of_Contribution + ")";
                                    }
                                    monthly_premium_column_counter = monthly_premium_column_counter + 1;
                                }

                            }//ForEach ContributionCollection Close
                        }// BenefitSummaryCount Check 
                    }//Inner ForEach Close

                    ContrbutionTableIndex = ContrbutionTableIndex + 2;
                }//Outer ForEach close

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteMonthlyPremiumSectionToVision(Word.Document oWordDoc, Word.Application oWordApp, DataSet ContributionDS, DataTable PlanTable, string selectedColor, Dictionary<int, List<int>> dictMap, Dictionary<int, List<int>> ContributionList)
        {
            try
            {
                Object missing = System.Reflection.Missing.Value;

                int ContrbutionTableIndex = 26;
                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;

                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = Convert.ToString(drPlanRow["ProductTypeDescription"]);
                    string Carrier = Convert.ToString(drPlanRow["Carrier"]);

                    int monthly_premium_row_counter = 2;
                    int monthly_premium_column_counter = 1;
                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];

                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        BenefitSummaryCount = BenefitSummaryCount + 1;

                        if (BenefitSummaryCount <= 3)  /// Check Not More than 3 Benefit Summery Contribution Print 
                        {

                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                            string ContributionId_1 = Convert.ToString(drPlanBenefitRow["ContributionId"]);
                            string ContributionId_2 = Convert.ToString(drPlanBenefitRow["ContributionId_2"]);
                            string PlanType = Convert.ToString(drPlanBenefitRow["PlanType"]);

                            string ContributionName = Convert.ToString(drPlanBenefitRow["ContributionName"]);

                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            foreach (int ContributionId in ContributionCollection)
                            {
                                /************ HERE WE ONLY ALLOW TO PRINT 3 COUNT CONTRIBUTION DETAILS ***************/
                                if (monthly_premium_column_counter < 4)
                                {
                                    #region  BuildTable
                                    DataTable PremiumTable = new DataTable();
                                    int premium_row_counter = 0;

                                    bool header_created = false;
                                    string Frequency_Of_Contribution = String.Empty;

                                    PremiumTable.Columns.Add("Plan", typeof(string));
                                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                                    PremiumTable.Columns.Add("summaryname", typeof(string));
                                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                                    PremiumTable.Columns.Add("contributionid", typeof(string));
                                    PremiumTable.Columns.Add("rateid", typeof(string));
                                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                                    PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                                    int iTotalFields = 0;
                                    #endregion

                                    #region contribution
                                    //new change
                                    Boolean flag = false;

                                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                    {
                                        //if (Convert.ToString(ContributionId) == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim() || Convert.ToString(ContributionId_2) == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                                        if (Convert.ToString(ContributionId) == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                                        {
                                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                                            {
                                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == Convert.ToString(ContributionId) && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == Convert.ToString(PlanType))
                                                {
                                                    flag = true;
                                                    break;
                                                }
                                            }
                                            if (flag == false)
                                            {
                                                PremiumTable.Rows.Add();
                                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
                                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
                                                PremiumTable.Rows[premium_row_counter][3] = "";
                                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                                PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                                //PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                                PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim();
                                                PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString();
                                                Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                                //break;
                                                premium_row_counter++;
                                            }
                                        }
                                    }
                                    //end change
                                    #endregion

                                    #region AddTable

                                    DataTable dt = new DataTable();
                                    //change
                                    //if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                                    if (Convert.ToString(PlanType) == "Voluntary Life Plan")
                                    {
                                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                                        dt = PremiumTable.DefaultView.ToTable(true);
                                        PremiumTable = dt;
                                    }
                                    //End Change
                                    else
                                    {
                                        dt = PremiumTable.DefaultView.ToTable(true);
                                        PremiumTable = dt;
                                    }

                                    if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
                                    {
                                        #region Table color
                                        ////oWordDoc.Tables[PremiumTable_counter].Range.Font.Color = comFunObj.font_color(selectedColor);
                                        ////oWordDoc.Tables[PremiumTable_counter].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                                        ////oWordDoc.Tables[PremiumTable_counter].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                                        ////oWordDoc.Tables[PremiumTable_counter].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                                        ////oWordDoc.Tables[PremiumTable_counter].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                                        #endregion

                                        #region Merge Field

                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {

                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();
                                                if (fieldName.Contains("Frequency_Contribution_Vision_" + PlanCount))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(Frequency_Of_Contribution);
                                                }
                                            }
                                        }
                                        #endregion
                                    }

                                    #endregion

                                    #region FillTable
                                    int TableCount = oWordDoc.Tables[ContrbutionTableIndex].Rows.Count;
                                    long differenceCount = Convert.ToInt32(PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count) - TableCount;

                                    oWordDoc.Tables[ContrbutionTableIndex].Rows[2].Range.Copy();
                                    for (int a = 0; a <= differenceCount; a++)
                                    {
                                        oWordDoc.Tables[ContrbutionTableIndex].Rows[2].Range.Paste();
                                    }

                                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                                    {
                                        if (PremiumTable.Rows[i][1].ToString() == "8")
                                        {

                                            monthly_premium_row_counter = 1;
                                            monthly_premium_row_counter++;

                                            if (oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text.Replace("\r\a", "") != PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                                            {
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                            }
                                            oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            ////}
                                        }
                                        else
                                        {
                                            if (oWordDoc.Tables[ContrbutionTableIndex].Cell((monthly_premium_row_counter + 1), 1).Range.Text.Replace("\r\a", "") == "Employee & " + PremiumTable.Rows[i][2].ToString())
                                            {
                                                monthly_premium_row_counter++;

                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[ContrbutionTableIndex].Rows.Add(ref missing);
                                                monthly_premium_row_counter++;

                                                //Added by Amogh 
                                                if (oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text != Convert.ToString("Employee & " + PremiumTable.Rows[i][2].ToString()))
                                                {
                                                    oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                                }
                                                oWordDoc.Tables[ContrbutionTableIndex].Cell(monthly_premium_row_counter, monthly_premium_column_counter + 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                            }
                                        }
                                    }

                                    #endregion

                                    if (monthly_premium_column_counter == 1)
                                    {
                                        oWordDoc.Tables[ContrbutionTableIndex].Cell(1, 1).Range.Text = "Employee Contributions (per " + Frequency_Of_Contribution + ")";
                                    }
                                    monthly_premium_column_counter = monthly_premium_column_counter + 1;
                                }

                            }//ForEach ContributionCollection Close
                        }// BenefitSummaryCount Check 
                    }//Inner ForEach Close

                    ContrbutionTableIndex = ContrbutionTableIndex + 2;
                }//Outer ForEach close

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

    }
}