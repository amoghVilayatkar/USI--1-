﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.Tools;
using System.Collections;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.Tools;
using BenefitPointSummaryPortal.BAL.BenifitPointServiceSetting;

namespace BenefitPointSummaryPortal.View
{
    public partial class Acquisition_Transmittal_Form : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        ConstantValue cv = new ConstantValue();
        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                DictDepartment = sd.getDepartmentDetails();
                if (!IsPostBack)
                {
                    BindServiceOptions();
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }
                    if (Convert.ToString(Session["Summary"]) == "Tools2")
                    {
                        TitleSpan.InnerText = "BenefitPoint Data Entry Support Transmittal Form";
                        SpanClientIntake.Visible = false;
                        SpanAccountProfile.Visible = true;
                        SpanClientIntakePHM.Visible = false;

                        SpanClientIntakeComplaince.Visible = false;
                        trddlprimaryAccountContact.Visible = false;
                        hdnSummary.Value = "Tools2";
                        Activity_Group = "Tools";
                    }
                    txtsearch.Focus();
                    //Activity = lblHeading.Text;
                    Activity = TitleSpan.InnerText;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void BindServiceOptions()
        {
            ServiceSettingOperations objServiceOps = new ServiceSettingOperations();
            DataTable dtblServiceOptions = objServiceOps.GetServiceList();
            ddlWebServiceOptions.DataSource = dtblServiceOptions;
            ddlWebServiceOptions.DataBind();
            if (dtblServiceOptions != null && dtblServiceOptions.Rows.Count == 1)
            {
                ddlWebServiceOptions.SelectedIndex = 1;
                CreateSession();
            }
            else
                ddlWebServiceOptions.SelectedValue = "Select";

        }

        private void CreateSession()
        {
            SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
            Dictionary<string, string> dictCredentials = GetServiceCredentials();
            if (dictCredentials["IsError"] == "0")
            {
                if (dictCredentials["UserName"] != string.Empty && dictCredentials["Password"] != string.Empty)
                {
                    switch (ddlWebServiceOptions.SelectedValue)
                    {
                        case "BPSericeV1":
                            SessionId = sl.GetSessionID_BPSummaryWebServiceLogin(dictCredentials["UserName"], dictCredentials["Password"]);// Old Service
                            break;
                        case "BPSericeV2":
                            SessionId = sl.GetSessionID_wf_BPSummaryWebServiceLogin(dictCredentials["UserName"], dictCredentials["Password"]); // New Service developed by Vaibhav
                            break;
                        default:
                            Session["SessionId"] = "";
                            break;
                    }
                }
                else
                {
                    if (ddlWebServiceOptions.SelectedValue != "Select")
                        ScriptManager.RegisterStartupScript(ddlWebServiceOptions, this.GetType(), "alert", "<script>alert('Service Username or Password is empty')</script>", false);
                }

            }
            else
            {
                ScriptManager.RegisterStartupScript(ddlWebServiceOptions, this.GetType(), "alert", "<script>alert('Error occured while fetching service details, please try again')</script>", false);
            }

            Session["SessionId"] = SessionId;
        }

        private Dictionary<string, string> GetServiceCredentials()
        {
            Dictionary<string, string> Credentials = new Dictionary<string, string>();
            try
            {
                ServiceSettingOperations objServiceOps = new ServiceSettingOperations();
                Credentials = objServiceOps.GetServiceCredentials(ddlWebServiceOptions.SelectedValue);
                Credentials["IsError"] = "0";
            }
            catch (Exception ex)
            {
                Credentials["UserName"] = "";
                Credentials["Password"] = "";
                Credentials["IsError"] = "1";
            }
            return Credentials;
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {

                //ddlActivity.Items.Clear();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                pnlPlans.Visible = false;
                // rdlActivity.SelectedIndex = 0;

                ////Comments reoved by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                //BPBusiness bp = new BPBusiness();
                ////Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                ////wf_BPBusiness bp = new wf_BPBusiness();

                //List<Account> AccountList = new List<Account>();
                //SessionId = Session["SessionId"].ToString();

                //// Added by Ashish to new web service call for client list and  //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                ////AccountList = bp.wf_FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                ////Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

                //cblistAccountContact.Items.Clear();
                //Added by Vaibhav for multiple Web Service 
                BindClients();

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void BindClients()
        {
            SessionId = Session["SessionId"].ToString();
            List<Account> AccountList = new List<Account>();
            switch (ddlWebServiceOptions.SelectedValue)
            {
                case "BPSericeV1":
                    BPBusiness bp = new BPBusiness();
                    AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                    AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                    ddlClient.DataSource = AccountList;
                    ddlClient.DataBind();
                    break;
                case "BPSericeV2":
                    wf_BPBusiness wf_bp = new wf_BPBusiness();
                    AccountList = wf_bp.wf_FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                    AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                    ddlClient.DataSource = AccountList;
                    ddlClient.DataBind();
                    break;
            }
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            //ddlActivity.SelectedIndex = 0;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();


                ddlClient.Items.Clear();
                //ddlActivity.Items.Clear();
                // rdlActivity.SelectedIndex = 0;

                grdPlans.DataSource = null;
                grdPlans.DataBind();

                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;

                cblistAccountContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlActivity.Items.Clear();
            pnlPlans.Visible = false;
            if (Convert.ToString(Session["Summary"]) == "Tools2")
            {
                lblMessage.Visible = false;
                cblistAccountContact.Items.Clear();
                SessionId = Session["SessionId"].ToString();
                lblAccountContact.Visible = true;
                pnlChkAccountContact.Visible = true;
                if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance")
                {
                    divgrdSelectedAccountContact.Visible = true;
                }
                else
                {
                    divgrdSelectedAccountContact.Visible = false;

                }
                BindAccountContact();//Handling service reference
                ////Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                //// wf_BPBusiness wf_bp = new wf_BPBusiness();
                ////Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                //BPBusiness bp = new BPBusiness();
                //List<Contact> acctContact = new List<Contact>();
                ////Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                ////List<Wf_Contact> ContactList = new List<Wf_Contact>();
                ////Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                //List<Contact> ContactList = new List<Contact>();
                //Contact cont = new Contact();
                //if (ddlClient.SelectedValue != "")
                //{
                //    //ContactList = wf_bp.wf_FindContacts(ddlClient.SelectedValue, SessionId);
                //    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                //}

                //ContactList = ContactList.OrderBy(o => o.Last_Name).ToList();
                //if (ContactList != null)
                //{
                //    for (int i = 0; i < ContactList.Count; i++)
                //    {
                //        cont = new Contact();
                //        cont.ContactId = ContactList[i].ContactId;

                //        if (!string.IsNullOrEmpty(ContactList[i].Title))
                //        {
                //            cont.Name = ContactList[i].Name + " & " + ContactList[i].Title;
                //        }
                //        else
                //        {
                //            cont.Name = ContactList[i].Name;
                //        }

                //        acctContact.Add(cont);
                //    }
                //}

                //if (acctContact.Count > 0)
                //{
                //    cblistAccountContact.DataSource = acctContact;
                //    cblistAccountContact.DataBind();
                //    pnlChkAccountContact.Height = 130;
                //}
                //else
                //{
                //    lblMessage.Visible = true;
                //    pnlChkAccountContact.Height = 50;
                //}
            }

        }

        private void BindAccountContact()
        {
            SessionId = Session["SessionId"].ToString();
            List<Contact> acctContact = new List<Contact>();
            switch (ddlWebServiceOptions.SelectedValue)
            {
                case "BPSericeV1":
                    BPBusiness bp = new BPBusiness();
                    List<Contact> ContactList = new List<Contact>();
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    ContactList = ContactList.OrderBy(o => o.Last_Name).ToList();
                    if (ContactList != null)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            Contact cont = new Contact();
                            cont.ContactId = ContactList[i].ContactId;

                            if (!string.IsNullOrEmpty(ContactList[i].Title))
                            {
                                cont.Name = ContactList[i].Name + " & " + ContactList[i].Title;
                            }
                            else
                            {
                                cont.Name = ContactList[i].Name;
                            }

                            acctContact.Add(cont);
                        }
                    }
                    break;
                case "BPSericeV2":
                    wf_BPBusiness wf_bp = new wf_BPBusiness();
                    List<Wf_Contact> wf_ContactList = new List<Wf_Contact>();
                    wf_ContactList = wf_bp.wf_FindContacts(ddlClient.SelectedValue, SessionId);
                    wf_ContactList = wf_ContactList.OrderBy(o => o.Last_Name).ToList();
                    if (wf_ContactList != null)
                    {
                        for (int i = 0; i < wf_ContactList.Count; i++)
                        {
                            Contact cont = new Contact();
                            cont.ContactId = wf_ContactList[i].ContactId;

                            if (!string.IsNullOrEmpty(wf_ContactList[i].Title))
                            {
                                cont.Name = wf_ContactList[i].Name + " & " + wf_ContactList[i].Title;
                            }
                            else
                            {
                                cont.Name = wf_ContactList[i].Name;
                            }

                            acctContact.Add(cont);
                        }
                    }
                    break;
            }
            if (acctContact.Count > 0)
            {
                cblistAccountContact.DataSource = acctContact;
                cblistAccountContact.DataBind();
                pnlChkAccountContact.Height = 130;
            }
            else
            {
                lblMessage.Visible = true;
                pnlChkAccountContact.Height = 50;
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;
                DataTable PlanTable = new DataTable();
                DataTable PlanInfoTable = new DataTable();


                if (Convert.ToString(Session["Summary"]) == "Tools2")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                    }
                    PlanInfoTable = GetPlanInfoTable_Account_Profile();
                    if (grdPlans.Rows.Count == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please click \"View Plans\" button to select plan(s).')</script>");
                        return;
                    }
                    // Added validation to select atleast one plan requested by Nicole on 26th June 2018
                    if (PlanInfoTable != null && PlanInfoTable.Rows.Count <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select  atleast one plan.')</script>");
                        return;
                    }
                    //else
                    //{
                    //    flag = CheckAccountContactsSelected();
                    //}
                }


                if (flag == true)
                {
                    List<Contact> ContactList = new List<Contact>();
                    List<Wf_Contact> wf_ContactList = new List<Wf_Contact>();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    string mynewfile = "";
                    int engagement = 0;
                    if (ddlWebServiceOptions.SelectedValue == "BPSericeV1")
                    {
                        BPBusiness bp = new BPBusiness();
                        SummaryDetail sd = new SummaryDetail();
                        sd.BuildAccountTable();
                        sd.BuildProductTable();
                        AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
                        Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                        ProductDS = sd.GetProductDetail(PlanTable, SessionId);
                        if (Convert.ToString(Session["Summary"]) == "Tools2")
                        {
                            //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                            mynewfile = CreateTools2_V2(tc.Tools1_SubjectID, PlanInfoTable, AccountDS, AccountTeamMemberDS, ContactList, SessionId);
                        }

                    }
                    if (ddlWebServiceOptions.SelectedValue == "BPSericeV2")
                    {
                        wf_BPBusiness wf_bp = new wf_BPBusiness();
                        wf_bp.BuildAccountTable();
                        wf_bp.BuildProductTable();
                        AccountDS = wf_bp.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        wf_ContactList = wf_bp.wf_FindContacts(ddlClient.SelectedValue, SessionId);
                        AccountTeamMemberDS = wf_bp.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        Account_Office = wf_bp.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                        ProductDS = wf_bp.GetProductDetail(PlanTable, SessionId);
                        mynewfile = CreateTools2(tc.Tools1_SubjectID, PlanInfoTable, AccountDS, AccountTeamMemberDS, wf_ContactList, SessionId);
                    }
                    #region Commented code
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //  List<Wf_Contact> ContactList = new List<Wf_Contact>();

                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // wf_BPBusiness wf_bp = new wf_BPBusiness();

                    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //BPBusiness wf_bp = new BPBusiness();
                    // SummaryDetail sd = new SummaryDetail();

                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // wf_bp.BuildAccountTable();
                    //Comment end
                    //sd.BuildAccountTable();

                    //sd.BuildBenefitSummaryTable();
                    // sd.BuildBenifitSummaryStructureTable();
                    //sd.BuildContributionTable();
                    //sd.BuildEligibilityRuleTable();
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // wf_bp.BuildProductTable();
                    //Comment end
                    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // sd.BuildProductTable();
                    //sd.BuildRateTable();

                    //DataTable PlanTable1 = new DataTable();
                    //PlanTable1 = (DataTable)Session["PlanTable"];
                    //ContributionDS = sd.GetContribution(PlanTable1, SessionId);
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //AccountDS = wf_bp.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    //Comments End
                    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //ContactList = wf_bp.wf_FindContacts(ddlClient.SelectedValue, SessionId);
                    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // ContactList = wf_bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    //if (ddlClient.SelectedValue != "")
                    //{
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // AccountTeamMemberDS = wf_bp.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //  AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    //}
                    // Get the Account Office and Account Region for the selected client
                    // This uncommented by Amogh for Insert Log activity 
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //  Account_Office = wf_bp.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // CommonFunctionsBS objCommFun = new CommonFunctionsBS();
                    //Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    //string Office_Region = Account_Region;
                    // string Office_Region = Account_Region + " / " + Account_Office;
                    //code used for contract review and benchmark audit report
                    #region common for both
                    //if (Convert.ToString(Session["Summary"]) == "Tools2")
                    //{
                    //    PlanInfoTable = GetPlanInfoTable_Account_Profile();
                    //}


                    //PlanTable.Merge(PlanInfoTable);

                    //RateDS = sd.GetRateForTools(PlanTable, SessionId);
                    //ContributionDS = sd.GetContributionForTool(PlanTable, SessionId);
                    //var table = from x in PlanInfoTable.AsEnumerable() where !string.IsNullOrEmpty(x.Field<string>("PlanType")) select x;

                    //PlanTable.Clear();
                    //foreach (dynamic i in table)
                    //{
                    //    PlanTable.NewRow();
                    //    PlanTable.ImportRow(i);
                    //}
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //ProductDS = wf_bp.GetProductDetail(PlanTable, SessionId);
                    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // ProductDS = sd.GetProductDetail(PlanTable, SessionId);

                    //DataTable ProductType = new DataTable();
                    //ProductType.Columns.Add("ProductTypeId", typeof(Int32));
                    //ProductType.Columns.Add("ProductTypeDescription", typeof(string));
                    //ProductType.Columns.Add("PlanNumber", typeof(string));
                    //ProductType.Columns.Add("ProductId", typeof(Int32));
                    //DataRow[] foundrow = null;

                    //for (int i = 0; i < ProductDS.Tables["ProductTable"].Rows.Count; i++)
                    //{
                    //    ProductType.Rows.Add();
                    //    ProductType.Rows[i][0] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["productTypeID"]);

                    //    foundrow = PlanTable.Select("ProductId='" + ProductDS.Tables["ProductTable"].Rows[i]["ProductID"] + "'");

                    //    ProductType.Rows[i][1] = foundrow[0]["PlanType"];
                    //    ProductType.Rows[i][2] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["PlanNumber"]);
                    //    ProductType.Rows[i][3] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["ProductId"]);
                    //}

                    //BenefitStructureDS = sd.GetBenefitSummaryStructure(ProductType, SessionId);

                    #endregion






                    //if (Convert.ToString(Session["Summary"]) == "Tools2")
                    //{
                    //    PlanInfoTable = GetPlanInfoTable_Account_Profile();
                    //    // Added validation to select atleast one plan requested by Nicole on 26th June 2018
                    //    if (grdPlans.Rows.Count == 0)
                    //    {
                    //        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please click \"View Plans\" button to select plan(s).')</script>");
                    //        return;
                    //    }
                    //    // Added validation to select atleast one plan requested by Nicole on 26th June 2018
                    //    if (PlanInfoTable != null && PlanInfoTable.Rows.Count <= 0)
                    //    {
                    //        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select  atleast one plan.')</script>");
                    //        return;
                    //    }
                    //    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //    //mynewfile = CreateTools2(tc.Tools1_SubjectID, PlanInfoTable, AccountDS, AccountTeamMemberDS, ContactList, SessionId);
                    //    //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    //    mynewfile = CreateTools2_V2(tc.Tools1_SubjectID, PlanInfoTable, AccountDS, AccountTeamMemberDS, ContactList, SessionId);
                    //}
                    #endregion
                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Create Summary Template1
        /// </summary>
        protected string CreateTools2(int SubjectID, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Wf_Contact> ContactList, string SessionId)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm_Template.docm");

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            //DataTable ActivityInfoTable = new DataTable();
            //DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                //LoadColumnIdArrayList();


                WriteTemplate_Acquisition_Transmittal_Form wt = new WriteTemplate_Acquisition_Transmittal_Form();


                //ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                //ActivityDS = timeD.Get_Activity_Detail(Convert.ToInt32(ddlActivity.SelectedItem.Value), SessionId);

                ArrayList arrAcctContact = new ArrayList();

                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                    }
                }

                wt.WriteFieldToAcquisitionForm(oWordDoc, oWordApp, ddlClient, AccountDS, PlanInfoTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact);

                //RunMacro(oWordApp, new Object[] { "CleanTools2" });
                //temperror = temperror + " postmacro";
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 =  ddlWebServiceOptions.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2_AcquisitionForm(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected string CreateTools2_V2(int SubjectID, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm_Template.docm");

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            //DataTable ActivityInfoTable = new DataTable();
            //DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/AcqTransmittalForm"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                //LoadColumnIdArrayList();


                WriteTemplate_Acquisition_Transmittal_Form wt = new WriteTemplate_Acquisition_Transmittal_Form();


                //ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                //ActivityDS = timeD.Get_Activity_Detail(Convert.ToInt32(ddlActivity.SelectedItem.Value), SessionId);

                ArrayList arrAcctContact = new ArrayList();
                string AdditionalCrtieriaOption_1 = string.Empty;
                ////for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                ////{
                ////    if (AdditionalCrtieriaOption_1 == string.Empty)
                ////        AdditionalCrtieriaOption_1 = cblistAccountContact.Items[i].Text;

                ////    if (cblistAccountContact.Items[i].Selected == true)
                ////    {
                ////        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                ////    }
                ////}

                //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                //wt.WriteFieldToAcquisitionForm(oWordDoc, oWordApp, ddlClient, AccountDS, PlanInfoTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact);
                //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                wt.WriteFieldToAcquisitionForm_V2(oWordDoc, oWordApp, ddlClient, AccountDS, PlanInfoTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact);
                //RunMacro(oWordApp, new Object[] { "CleanTools2" });
                //temperror = temperror + " postmacro";
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                AdditionalCrtieriaOption_1 = ddlWebServiceOptions.SelectedItem.Text; 
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                // DicActivityLog = bp.ActivityLogData_V2_AcquisitionForm(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                //Added by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                DicActivityLog = bp.ActivityLogData_V2_AcquisitionForm_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        private List<Plan> GetPlans()
        {
            List<Plan> lstPlans = new List<Plan>();
            SessionId = Session["SessionId"].ToString();
            switch (ddlWebServiceOptions.SelectedValue)
            {
                case "BPSericeV1":
                    BPBusiness bp = new BPBusiness();
                    lstPlans = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    break;
                case "BPSericeV2":
                    wf_BPBusiness wf_bp = new wf_BPBusiness();
                    lstPlans = wf_bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    break;
            }
            return lstPlans;
        }

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                Hashtable htSortedPlanList = new Hashtable();


                if (Convert.ToString(Session["Summary"]) == "Tools2")
                {


                    grdPlans.DataSource = null;
                    grdPlans.DataBind();

                    // flag = CheckAccountContactsSelected();
                }

                if (flag == true)
                {
                    //Commented by Vaibhav to call existing service - Email- Scheduled changes for production Delivery on Tuesday 30 July 2018 by Nicole
                    // wf_BPBusiness wf_bp = new wf_BPBusiness();
                    //BPBusiness wf_bp = new BPBusiness();

                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {

                        PlanList = GetPlans();//wf_bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                                if (Convert.ToString(Session["Summary"]) == "Tools2")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (Convert.ToString(item.RenewalDate.ToShortDateString()) != "1/1/0001")
                                        {
                                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                        else if (Convert.ToString(item.RenewalDate.ToShortDateString()) == "1/1/0001")  // As Per Nicole here we show plan which have Rebewal date as ["1/1/0001"] [Acquisition Transmittal Form - not all plans listed on criteria page]
                                        {
                                            if (item.ProductStatus == item.ProductStatusCurrent)
                                            {

                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }
                                // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    commonPlanList.Add(item);
                                }
                            }

                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();

                            lstPlanList = (from l in commonPlanList
                                           orderby l.ProductTypeId, l.CarrierName ascending
                                           select l).ToList();

                            grdPlans.DataSource = lstPlanList;
                            grdPlans.DataBind();

                            if (commonPlanList.Count > 0)
                            {
                                pnlPlans.Visible = true;
                                CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                                ChkBoxHeader.Checked = true;
                                foreach (GridViewRow row in grdPlans.Rows)
                                {
                                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                                    ChkBoxRows.Checked = true;
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            else
                            {
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void grdPlans_RowDataBound(Object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //*** Date Information that displays - By Nicole [ Either remove the date of ‘01/01/0001’ or have the word ‘continuous’ appear ]
                if (e.Row.Cells[3].Text == "1/1/0001")
                {
                    e.Row.Cells[3].Text = "Continuous";
                }
            }
        }


        private Hashtable ClientIntake_planList()
        {
            Hashtable htSortedPlanList = new Hashtable();
            htSortedPlanList.Add(1, 100);   // Medical
            htSortedPlanList.Add(2, 110);   // Medical
            htSortedPlanList.Add(3, 120);   // Medical
            htSortedPlanList.Add(4, 140);   // Medical
            htSortedPlanList.Add(5, 150);   // Medical
            htSortedPlanList.Add(6, 160);   // Medical
            htSortedPlanList.Add(7, 170);   // Medical

            htSortedPlanList.Add(8, 180);   // Dental
            htSortedPlanList.Add(9, 190);   // Dental
            htSortedPlanList.Add(10, 200);   // Dental
            htSortedPlanList.Add(11, 210);   // Dental

            htSortedPlanList.Add(12, 230);   // Vision

            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life

            //htSortedPlanList.Add(15, 260);   // Voluntary Life
            //htSortedPlanList.Add(16, 270);   // AD&D
            //htSortedPlanList.Add(17, 280);   // Voluntary AD&D
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            //htSortedPlanList.Add(20, 330);   // Section 125


            htSortedPlanList.Add(21, 130);   // Medical
            //htSortedPlanList.Add(22, 310);   // EAP
            htSortedPlanList.Add(23, 178);   // HRA
            htSortedPlanList.Add(24, 179);   // HSA
            //htSortedPlanList.Add(22, 1116);   // Medical Plan Riders

            return htSortedPlanList;
        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }

        private DataTable GetPlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();


            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds();
            //List<int> MedicalPlanTypeList = new List<int>();

            ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            //MedicalPlanTypeList.Add(100);
            //MedicalPlanTypeList.Add(110);
            //MedicalPlanTypeList.Add(120);
            //MedicalPlanTypeList.Add(130);
            //MedicalPlanTypeList.Add(140);
            //MedicalPlanTypeList.Add(150);
            //MedicalPlanTypeList.Add(160);
            //MedicalPlanTypeList.Add(170);
            //MedicalPlanTypeList.Add(1116);

            //List<int> DentalPlanTypeList = new List<int>();
            //DentalPlanTypeList.Add(180);
            //DentalPlanTypeList.Add(190);
            //DentalPlanTypeList.Add(200);
            //DentalPlanTypeList.Add(210);

            //List<int> VisionPlanTypeList = new List<int>();
            //VisionPlanTypeList.Add(230);

            //List<int> LifeADDPlanTypeList = new List<int>();
            //LifeADDPlanTypeList.Add(240);
            ////  LifeADDPlanTypeList.Add(250);

            //List<int> GroupTermLifePlanTypeList = new List<int>();
            //GroupTermLifePlanTypeList.Add(250);

            //List<int> VoluntaryLifeList = new List<int>();
            //VoluntaryLifeList.Add(260);

            //List<int> ADD = new List<int>();
            //ADD.Add(270);

            //List<int> VoluntaryLife_ADDList = new List<int>();
            //VoluntaryLife_ADDList.Add(280);

            //List<int> STDPlanTypeList = new List<int>();
            //STDPlanTypeList.Add(290);

            //List<int> LTDPlanTypeList = new List<int>();
            //LTDPlanTypeList.Add(300);

            //List<int> FSAPlanTypeList = new List<int>();
            //FSAPlanTypeList.Add(330);

            ////List<int> EAPPlanTypeList = new List<int>();
            ////EAPPlanTypeList.Add(310);

            ////List<int> HSAPlanTypeList = new List<int>();
            ////HSAPlanTypeList.Add(179);

            ////List<int> HRAPlanTypeList = new List<int>();
            ////HRAPlanTypeList.Add(178);

            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            //if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            //}

                            //if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            //}

                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        private DataTable GetPlanInfoTable_PHM()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();


            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds();
            //List<int> MedicalPlanTypeList = new List<int>();

            ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            //MedicalPlanTypeList.Add(100);
            //MedicalPlanTypeList.Add(110);
            //MedicalPlanTypeList.Add(120);
            //MedicalPlanTypeList.Add(130);
            //MedicalPlanTypeList.Add(140);
            //MedicalPlanTypeList.Add(150);
            //MedicalPlanTypeList.Add(160);
            //MedicalPlanTypeList.Add(170);
            //MedicalPlanTypeList.Add(1116);

            //List<int> DentalPlanTypeList = new List<int>();
            //DentalPlanTypeList.Add(180);
            //DentalPlanTypeList.Add(190);
            //DentalPlanTypeList.Add(200);
            //DentalPlanTypeList.Add(210);

            //List<int> VisionPlanTypeList = new List<int>();
            //VisionPlanTypeList.Add(230);

            //List<int> LifeADDPlanTypeList = new List<int>();
            //LifeADDPlanTypeList.Add(240);
            ////  LifeADDPlanTypeList.Add(250);

            //List<int> GroupTermLifePlanTypeList = new List<int>();
            //GroupTermLifePlanTypeList.Add(250);

            //List<int> VoluntaryLifeList = new List<int>();
            //VoluntaryLifeList.Add(260);

            //List<int> ADD = new List<int>();
            //ADD.Add(270);

            //List<int> VoluntaryLife_ADDList = new List<int>();
            //VoluntaryLife_ADDList.Add(280);

            //List<int> STDPlanTypeList = new List<int>();
            //STDPlanTypeList.Add(290);

            //List<int> LTDPlanTypeList = new List<int>();
            //LTDPlanTypeList.Add(300);

            //List<int> FSAPlanTypeList = new List<int>();
            //FSAPlanTypeList.Add(330);

            ////List<int> EAPPlanTypeList = new List<int>();
            ////EAPPlanTypeList.Add(310);

            ////List<int> HSAPlanTypeList = new List<int>();
            ////HSAPlanTypeList.Add(179);

            ////List<int> HRAPlanTypeList = new List<int>();
            ////HRAPlanTypeList.Add(178);

            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = " ";
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 then it gives an error 'You are not authorized to access the requested information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        private DataTable GetPlanInfoTable_Account_Profile()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            DataTable ProductInfoTable = new DataTable();
            ProductInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
            objCommFun.LoadPlanTypeIds();
            try
            {
                int rowCount = 0;
                int rowCount1 = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            //if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            //}

                            //if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            //}

                            rowCount++;
                        }
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length == 4))
                        {



                            //foreach (var data in BenefitSummaryList)
                            //{

                            ProductInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount1++;


                        }
                        else
                        {

                        }

                    }


                    var Rows = (from row in PlanInfoTable.AsEnumerable()
                                select row);
                    PlanInfoTable = Rows.AsDataView().ToTable();

                    var Rows1 = (from row1 in ProductInfoTable.AsEnumerable()
                                 orderby row1["Name"] ascending
                                 select row1);
                    ProductInfoTable = Rows1.AsDataView().ToTable();


                    PlanInfoTable.Merge(ProductInfoTable);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }


        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        private bool CheckAccountContactsSelected()
        {
            bool flag = true;
            try
            {
                int cnt = 0;
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        cnt++;
                    }
                }

                if (cnt > 3)
                {
                    string script = "alert(\"Please select max 3 Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return flag;
        }

        private bool CheckAccountContactsClientIntakeSelected()
        {
            bool flag = true;
            try
            {
                int cnt = 0;
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        cnt++;
                    }
                }

                if (cnt > 2)
                {
                    string script = "alert(\"Please select max 2 Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
                else if (cnt == 0)
                {
                    string script = "alert(\"Please select Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return flag;
        }

        protected void cblistAccountContact_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dtAcctContactList = new DataTable();
                dtAcctContactList.Columns.Add("Name", typeof(string));
                dtAcctContactList.Columns.Add("ID", typeof(string));
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        dtAcctContactList.Rows.Add(cblistAccountContact.Items[i].Text, cblistAccountContact.Items[i].Value);
                    }
                }
                grdSelectedAccountContact.DataSource = dtAcctContactList;
                grdSelectedAccountContact.DataBind();

                ddlSelectedAccountContact.DataSource = dtAcctContactList;
                ddlSelectedAccountContact.DataBind();
            }

            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                MedicalBenefitColumnIdList.Add("109");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");

                //Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("110");
                MedicalBenefitColumnIdOutNetworkList.Add("113");

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlWebServiceOptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnReset_Click(null, null);
            CreateSession();
        }
    }
}