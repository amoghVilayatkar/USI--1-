﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using System.Collections;
using BenefitPointSummaryPortal.Common.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.ServiceCalendar;
using BenefitPointSummaryPortal.Common.OpenCloseWord;

namespace BenefitPointSummaryPortal.View
{
    public partial class ConsolidateServiceCalendar : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        List<UserDetails> lstUserDetails = new List<UserDetails>();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        WordOpenClose wobj = new WordOpenClose();

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btnSummary);
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                Page.MaintainScrollPositionOnPostBack = true;

                DictDepartment = sd.getDepartmentDetails();
                if (!IsPostBack)
                {
                    HidePanel();

                    pnlGrdAccounTeam.Visible = false;
                    pnlHeader.Visible = false;
                    // Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();
                    mvServiceCalendar.ActiveViewIndex = 0;

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;


                    ddlCalenderType.Focus();
                    Activity = TitleSpan.InnerText;

                    DataTable dt = new DataTable();
                    dt = bp.GetOfficeList();
                    Session["OffieceTable"] = dt;
                    ddlOffice.DataSource = dt;
                    ddlOffice.DataBind();
                    ddlOffice.SelectedIndex = 1;
                    ddlOffice1.DataSource = dt;
                    ddlOffice1.DataBind();
                    ddlOffice1.SelectedIndex = 1;

                    ///** Office Dropdown Enabled=False by Amogh*/
                    ddlOffice1.Enabled = false;
                    ddlOffice.Enabled = false;

                    Dictionary<int, string> dicMonth = new Dictionary<int, string>();
                    dicMonth = CreateMonth();

                    ddlRenewalMonth.DataSource = dicMonth;
                    ddlRenewalMonth.DataBind();

                    ddlCustomField1.DataSource = dicMonth;
                    ddlCustomField1.DataBind();

                    ddlCustomField2.DataSource = dicMonth;
                    ddlCustomField2.DataBind();

                    ddlCustomField3.DataSource = dicMonth;
                    ddlCustomField3.DataBind();


                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private void HidePanel()
        {
            TitleSpan.InnerText = "Service Calendars";
            pnlServiceCalenderDetails_BS_Text1.Visible = false;
            pnlServiceCalenderHighlights_BS_Text1.Visible = false;
            pnlAnnualComplience_BS_Text1.Visible = false;

            pnlServiceCalenderDetails_BS_Text2.Visible = false;
            pnlServiceCalenderHighlights_BS_Text2.Visible = false;
            pnlAnnualComplience_BS_Text2.Visible = true;
            Activity_Group = "Service Calendar";

            pnlSC_Highlights.Visible = false;
            pnlSC_Detail.Visible = false;
            pnlSC_Highlights2.Visible = false;
            pnlSC_Detail2.Visible = false;
            pnlSC_Compliance.Visible = false;
            trAddEvent3.Visible = false;
            tblgrids.Visible = false;
            trLegal.Visible = false;

            spanCriteriaPage1.InnerText = "General Information – Criteria Page 1 of 2";
            spanCriteriaPage2.InnerText = "Additional Options – Criteria Page 2 of 2";
            btnPrevious.Visible = false;
            btnNext.Visible = false;
            btnSummary.Visible = false;
            spanCriteriaPage1.Visible = false;
            spanCriteriaPage2.Visible = false;
        }

        private void HideSummaryOptions(string SummaryName)
        {
            if (ddlCalenderType.SelectedValue == "ServiceCalendar1")
            {
                //lblHeading.Text = "Service Calendar - Highlights";
                TitleSpan.InnerText = "Service Calendar - Highlights";
                pnlServiceCalenderDetails_BS_Text1.Visible = false;
                pnlServiceCalenderHighlights_BS_Text1.Visible = true;
                pnlAnnualComplience_BS_Text1.Visible = false;

                pnlServiceCalenderDetails_BS_Text2.Visible = false;
                pnlServiceCalenderHighlights_BS_Text2.Visible = true;
                pnlAnnualComplience_BS_Text2.Visible = false;
                //Activity_Group = "Service Calendar";
                Activity_Group = "Tools";
                Activity = "Service Calendar Highlights";

                pnlSC_Compliance.Visible = false;
                pnlSC_Highlights.Visible = true;
                pnlSC_Detail.Visible = false;
                pnlSC_Highlights2.Visible = true;
                pnlSC_Detail2.Visible = false;

                trAddEvent3.Visible = false;
                tblgrids.Visible = true;
                trAddEvent2.Visible = true;
                trLegal.Visible = false;
                tdLegalName.Visible = false;
                tdLegalNameddl.Visible = false;
                spanCriteriaPage1.Visible = true;
                spanCriteriaPage2.Visible = true;

                spanCriteriaPage1.InnerText = "General Information – Criteria Page 1 of 2";
                spanCriteriaPage2.InnerText = "Additional Options – Criteria Page 2 of 2";
                btnPrevious.Visible = false;
                btnNext.Visible = true;
                btnSummary.Visible = false;


            }

            if (ddlCalenderType.SelectedValue == "ServiceCalendar2")
            {
                //lblHeading.Text = "Service Calendar - Detailed";
                TitleSpan.InnerText = "Service Calendar - Detailed";
                pnlServiceCalenderDetails_BS_Text1.Visible = true;
                pnlServiceCalenderHighlights_BS_Text1.Visible = false;
                pnlAnnualComplience_BS_Text1.Visible = false;

                pnlServiceCalenderDetails_BS_Text2.Visible = true;
                pnlServiceCalenderHighlights_BS_Text2.Visible = false;
                pnlAnnualComplience_BS_Text2.Visible = false;
                //Activity_Group = "Service Calendar";

                Activity_Group = "Tools";
                Activity = "Service Calendar Detailed";

                pnlSC_Compliance.Visible = false;
                pnlSC_Highlights.Visible = false;
                pnlSC_Detail.Visible = true;
                pnlSC_Highlights2.Visible = false;
                pnlSC_Detail2.Visible = true;

                trAddEvent3.Visible = false;
                trAddEvent1.Visible = true;
                trAddEvent2.Visible = true;
                tblgrids.Visible = true;
                trLegal.Visible = false;
                btnPrevious.Visible = false;
                btnNext.Visible = true;
                btnSummary.Visible = false;

                spanCriteriaPage1.Visible = true;
                spanCriteriaPage2.Visible = true;
                spanCriteriaPage1.InnerText = "General Information – Criteria Page 1 of 2";
                spanCriteriaPage2.InnerText = "Additional Options – Criteria Page 2 of 2";
            }

            if (ddlCalenderType.SelectedValue == "ServiceCalendar3")
            {
                //lblHeading.Text = "Annual Compliance Calendar";
                TitleSpan.InnerText = "Annual Compliance Calendar";
                //Text1 
                pnlServiceCalenderDetails_BS_Text1.Visible = false;
                pnlServiceCalenderHighlights_BS_Text1.Visible = false;
                pnlAnnualComplience_BS_Text1.Visible = true;
                //Text2
                pnlServiceCalenderDetails_BS_Text2.Visible = false;
                pnlServiceCalenderHighlights_BS_Text2.Visible = false;
                pnlAnnualComplience_BS_Text2.Visible = true;

                //Activity_Group = "Compliance";
                Activity_Group = "Tools";
                Activity = "Service Calendar Compliance";
                pnlSC_Compliance.Visible = true;
                pnlSC_Highlights.Visible = false;
                pnlSC_Detail.Visible = false;
                pnlSC_Highlights2.Visible = false;
                pnlSC_Detail2.Visible = false;

                lblAccountContact.Visible = false;
                pnlGrdAccounTeam.Visible = false;
                trAddEvent1.Visible = false;
                trAddEvent2.Visible = false;
                trAddEvent3.Visible = false;
                trMedicalPlan.Visible = false;
                tblgrids.Visible = false;
                trLegal.Visible = false;

                btnPrevious.Visible = false;
                btnNext.Visible = false;
                btnSummary.Visible = true;

                spanCriteriaPage1.Visible = true;
                spanCriteriaPage2.Visible = true;
                spanCriteriaPage1.InnerText = "General Information - Criteria Page 1 of 1";
                spanCriteriaPage2.InnerText = "Additional Options – Criteria Page 1 of 1";
            }

        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            //code to fetch Medical Plans for Annual Complience calender
            if (ddlCalenderType.SelectedValue == "ServiceCalendar3")
            {

                FindPlans();
                //FillMedicalPlanList(rdlMedicalPlan, ddlMedicalPlan);
                trMedicalPlan.Visible = true;
                if (ddlMedicalPlan.SelectedIndex == -1)
                {
                    ddlMedicalPlan.DataSource = FillMedicalPlanList(rdlMedicalPlan);
                    ddlMedicalPlan.DataBind();
                    ddlMedicalPlan.Items.Insert(0, new ListItem("Select", string.Empty));
                    ddlMedicalPlan.SelectedIndex = 0;
                }
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                if (ddlCalenderType.SelectedIndex == -1 || ddlCalenderType.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Calendar Type.')</script>", false);
                    ddlCalenderType.Focus();
                    return;
                }

                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

                grdAccountTeam.DataSource = null;
                grdAccountTeam.DataBind();

                ClearControls();

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();
                ddlClient.Items.Clear();
                ddlReportFormatDetail.SelectedValue = "0";
                ddlReportStyleDetail.SelectedValue = "0";


                ClearControls();

                //pnlGrdAccounTeam.Visible = false;
                //pnlHeader.Visible = false;
                //lblAccountContact.Visible = false;
                //grdAccountTeam.DataSource = null;
                //grdAccountTeam.DataBind();
                //ddlRenewalCycle.SelectedValue = "0";
                //ddlServiceCalYear.SelectedValue = "1";
                //ddlReportFormat.SelectedValue = "0";
                //ddlReportFormatDetail.SelectedValue = "0";
                //ddlActivity.Items.Clear();
                //ddlHealthcareDetail.SelectedValue = "0";
                //ddlRenewalMonth.SelectedValue = "0";
                //ddl_5500_Report.SelectedValue = "0";
                //ddl_USI_Holidays.SelectedValue = "0";
                //ddl_USI_Holidays_Detail.SelectedValue = "0";
                //ddl_Experience_Reports.SelectedValue = "0";
                //ddlWellness.SelectedValue = "0";
                //ddlWellness_Detail.SelectedValue = "0";
                //ddlCustomField1.SelectedValue = "0";
                //ddlCustomField2.SelectedValue = "0";
                //ddlCustomField3.SelectedValue = "0";
                //txtCustomField1.Text = "";
                //txtCustomField2.Text = "";
                //txtCustomField3.Text = "";
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlCalenderType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlCalenderType.SelectedValue == "0")
            {
                HidePanel();
            }
            else
            {
                HideSummaryOptions(ddlCalenderType.SelectedValue);
                btnReset_Click(null, null);
            }

            if (ddlReportStyleDetail.SelectedIndex >= 0)
            {
                ddlReportStyleDetail.SelectedValue = "0";
            }
            if (ddlReportFormatDetail.SelectedIndex >= 0)
            {
                ddlReportFormatDetail.SelectedValue = "0";
            }
            if (ddlReportStyle.SelectedIndex >= 0)
            {
                ddlReportStyle.SelectedValue = "0";
            }

        }


        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlReportStyleDetail.SelectedIndex >= 0)
            {
                ddlReportStyleDetail.SelectedValue = "0";
            }
            if (ddlReportFormatDetail.SelectedIndex >= 0)
            {
                ddlReportFormatDetail.SelectedValue = "0";
            }
            if (ddlReportStyle.SelectedIndex >= 0)
            {
                ddlReportStyle.SelectedValue = "0";
            }

            if (ddlCalenderType.SelectedValue == "ServiceCalendar1" || ddlCalenderType.SelectedValue == "ServiceCalendar2")
            {
                lblMessage.Visible = false;
                grdAccountTeam.DataSource = null;
                grdAccountTeam.DataBind();
                SessionId = Session["SessionId"].ToString();
                List<string> lstUser = new List<string>();
                DataSet AccountTeamMemberDS = new DataSet();

                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                UserDetails objUserDetails = new UserDetails();

                if (AccountTeamMemberDS.Tables.Count > 0)
                {
                    if (AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < AccountTeamMemberDS.Tables[0].Rows.Count; i++)
                        {
                            lstUser = sd.GetUserDetails(Convert.ToInt32(AccountTeamMemberDS.Tables[0].Rows[i]["UserId"].ToString()), SessionId);

                            objUserDetails = new UserDetails();

                            objUserDetails.UserId = Convert.ToInt32(AccountTeamMemberDS.Tables[0].Rows[i]["UserId"]);
                            objUserDetails.First_Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]);
                            objUserDetails.Last_Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]);
                            objUserDetails.Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]);
                            //objUserDetails.Role = Convert.ToString(lstUser[0]);
                            objUserDetails.Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["role"]);
                            objUserDetails.WorkPhone = Convert.ToString(lstUser[1]);
                            objUserDetails.Email = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["Email"]);

                            lstUserDetails.Add(objUserDetails);
                        }
                    }
                }

                lblAccountContact.Visible = true;
                grdAccountTeam.Visible = true;
                pnlGrdAccounTeam.Visible = true;

                if (lstUserDetails.Count > 0)
                {
                    pnlGrdAccounTeam.Height = 150;
                    grdAccountTeam.DataSource = lstUserDetails;
                    grdAccountTeam.DataBind();
                    grdAccountTeam.Height = 130;

                    pnlHeader.Visible = true;
                    GridView1.DataSource = lstUserDetails;
                    GridView1.DataBind();

                    //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdAccountTeam');</script>", false);
                }
                else
                {
                    lblMessage.Visible = true;
                    pnlGrdAccounTeam.Height = 50;
                }

                if (ddlCalenderType.SelectedValue == "ServiceCalendar2")
                {
                    GetActivity_List(rdlActivity.SelectedItem.Text, tc.ServiceCalendar2_SubjectID);
                }
            }

            //else if (Convert.ToString(Session["Summary"]) == "ServiceCalendar3")
            //{
            //    FindPlans();
            //    //FillMedicalPlanList(rdlMedicalPlan, ddlMedicalPlan);

            //    if (ddlMedicalPlan.SelectedIndex == -1)
            //    {
            //        ddlMedicalPlan.DataSource = FillMedicalPlanList(rdlMedicalPlan);
            //        ddlMedicalPlan.DataBind();
            //        ddlMedicalPlan.Items.Insert(0, new ListItem("Select", string.Empty));
            //        ddlMedicalPlan.SelectedIndex = 0;
            //    }
            //}
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                bool flag = true;

                if (ddlCalenderType.SelectedValue == "ServiceCalendar1" || ddlCalenderType.SelectedValue == "ServiceCalendar2")
                {

                    if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                        //Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        ddlClient.Focus();
                        flag = false;
                    }
                    else if (ddlActivity.Items.Count > 0 && (ddlActivity.SelectedItem.Value == "0" || ddlActivity.SelectedItem.Value == "") && ddlCalenderType.SelectedValue == "ServiceCalendar2")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Activity.')</script>");
                        ddlActivity.Focus();
                        flag = false;
                    }
                    else if (ddlReportFormat.SelectedItem.Value == "0" && ddlReportFormatDetail.SelectedItem.Value == "0")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Calendar Style.')</script>");
                        if (ddlCalenderType.SelectedValue == "ServiceCalendar1")
                        {
                            ddlReportFormat.Focus();
                            flag = false;
                        }
                        else if (ddlCalenderType.SelectedValue == "ServiceCalendar2")
                        {
                            ddlReportFormatDetail.Focus();
                            flag = false;
                        }
                    }
                    else if (ddlRenewalCycle.SelectedItem.Value == "0" && ddlCalenderType.SelectedValue == "ServiceCalendar1")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Renewal Cycle.')</script>");
                        ddlRenewalCycle.Focus();
                        flag = false;
                    }
                    else if (ddlRenewalMonth.SelectedItem.Value == "0" && ddlCalenderType.SelectedValue == "ServiceCalendar1")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Renewal Month.')</script>");
                        ddlRenewalMonth.Focus();
                        flag = false;
                    }
                    else if (ddlcustomeventinclude.SelectedValue == "Included" && (ddlCustomField1.SelectedItem.Value == "0" && txtCustomField1.Text.Trim() == "" && ddlCustomField2.SelectedItem.Value == "0" && txtCustomField2.Text.Trim() == "" && ddlCustomField3.SelectedItem.Value == "0" && txtCustomField3.Text.Trim() == ""))
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please Add Custom Event(s).')</script>");
                        //ddlRenewalMonth.Focus();
                        flag = false;
                    }
                    else if (ddlcustomeventinclude.SelectedValue == "Included")
                    {
                        //else if (ddlCustomField1.SelectedItem.Value != "0" && txtCustomField1.Text.Trim() == "")
                        if (ddlCustomField1.SelectedItem.Value != "0" && txtCustomField1.Text.Trim() == "")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Event Text is required for Custom Event #1.')</script>");
                            txtCustomField1.Focus();
                            flag = false;
                        }
                        else if (ddlCustomField1.SelectedItem.Value == "0" && txtCustomField1.Text.Trim() != "")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Event Month is required for Custom Event #1.')</script>");
                            ddlCustomField1.Focus();
                            flag = false;
                        }
                        else if (ddlCustomField2.SelectedItem.Value != "0" && txtCustomField2.Text.Trim() == "")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Event Text is required for Custom Event #2.')</script>");
                            txtCustomField2.Focus();
                            flag = false;
                        }
                        else if (ddlCustomField2.SelectedItem.Value == "0" && txtCustomField2.Text.Trim() != "")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Event Month is required for Custom Event #2.')</script>");
                            ddlCustomField2.Focus();
                            flag = false;
                        }
                        else if (ddlCustomField3.SelectedItem.Value != "0" && txtCustomField3.Text.Trim() == "")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Event Text is required for Custom Event #3.')</script>");
                            txtCustomField3.Focus();
                            flag = false;
                        }
                        else if (ddlCustomField3.SelectedItem.Value == "0" && txtCustomField3.Text.Trim() != "")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Event Month is required for Custom Event #3.')</script>");
                            ddlCustomField3.Focus();
                            flag = false;
                        }
                    }

                }
                else if (ddlCalenderType.SelectedValue == "ServiceCalendar3")
                {
                    if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        ddlClient.Focus();
                        flag = false;
                    }
                    else if (ddlMedicalPlan.SelectedItem == null || ddlMedicalPlan.SelectedItem.Value == "0" || ddlMedicalPlan.SelectedItem.Value == "")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Medical Plan.')</script>");
                        ddlMedicalPlan.Focus();
                        flag = false;
                    }
                    else if (ddlReportFormatCompliance.SelectedItem.Value == "0")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Calendar Style.')</script>");
                        ddlReportFormatCompliance.Focus();
                        flag = false;
                    }


                    else if (ddlGroupMWEA.SelectedItem.Value == "0")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select MEWA Group.')</script>");
                        ddlGroupMWEA.Focus();
                        flag = false;
                    }
                    else if (ddlIsEmpInCA.SelectedItem.Value == "0")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select the option for : Are any employees in San Francisco, CA?')</script>");
                        ddlIsEmpInCA.Focus();
                        flag = false;
                    }
                    else if (ddlHRA.SelectedItem.Value == "0")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select the option for : Does this group have an HRA?')</script>");
                        ddlHRA.Focus();
                        flag = false;
                    }
                    else if (ddlMassachusetts.SelectedItem.Value == "0")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select the option for : Are any employees in Massachusetts?')</script>");
                        ddlHRA.Focus();
                        flag = false;
                    }
                }

                if (flag == true)
                {
                    string mynewfile = "";
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    //***************************** Code Added for Insert Activty Log 
                    List<Contact> ContactList = new List<Contact>();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();

                    sd.BuildAccountTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }

                    if (ddlCalenderType.SelectedValue == "ServiceCalendar1")
                    {
                        mynewfile = CreateServiceCalendar(SessionId, AccountDS, AccountTeamMemberDS, ContactList);
                    }

                    else if (ddlCalenderType.SelectedValue == "ServiceCalendar2")
                    {
                        mynewfile = CreateServiceCalendarDetail(SessionId, AccountDS, AccountTeamMemberDS, ContactList);
                    }

                    else if (ddlCalenderType.SelectedValue == "ServiceCalendar3")
                    {
                        mynewfile = CreateServiceCalendarCompliance(SessionId, AccountDS, AccountTeamMemberDS, ContactList);
                    }

                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Create Summary Template1
        /// </summary>
        protected string CreateServiceCalendar(string SessionId, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            string strFileName = string.Empty;
            string strReportName = string.Empty;

            if (ddlReportFormat.SelectedItem.Value == "1") // Landscape Format
            {
                strFileName = "Service Calendar Highlights - Landscape";
                strReportName = "Report1 - Landscape";
            }
            else if (ddlReportFormat.SelectedItem.Value == "2") // Portrait Format
            {
                strFileName = "Service Calendar Highlights - Portrait";
                strReportName = "Report1 - Portrait";
            }

            Object fileName = Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strFileName + ".docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName)))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                WriteServiceCalendarHighlights wt = new WriteServiceCalendarHighlights();
                Dictionary<int, string> dictionaryMonth = new Dictionary<int, string>();
                dictionaryMonth = CreateMonth(); // Get the list of month in the dictionary

                int Report_5500 = Convert.ToInt16(ddl_5500_Report.SelectedItem.Value);
                int Renewal_Cycle = Convert.ToInt16(ddlRenewalCycle.SelectedItem.Value);
                int USI_Holidays = Convert.ToInt16(ddl_USI_Holidays.SelectedItem.Value);
                int Experience = Convert.ToInt16(ddl_Experience_Reports.SelectedItem.Value);
                int Wellness = Convert.ToInt16(ddlWellness.SelectedItem.Value);
                int Cust_Field_1 = Convert.ToInt16(ddlCustomField1.SelectedItem.Value);
                int Cust_Field_2 = Convert.ToInt16(ddlCustomField2.SelectedItem.Value);
                int Cust_Field_3 = Convert.ToInt16(ddlCustomField3.SelectedItem.Value);

                string strCustField1 = Convert.ToString(txtCustomField1.Text).Replace("\r\n", " ");
                string strCustField2 = Convert.ToString(txtCustomField2.Text).Replace("\r\n", " ");
                string strCustField3 = Convert.ToString(txtCustomField3.Text).Replace("\r\n", " ");

                if (ddlReportFormat.SelectedItem.Value == "1") // Landscape Format
                {
                    wt.WriteFieldToSC_Highlights_Landscape(oWordDoc, oWordApp, ddlOffice1, ddlClient, dictionaryMonth, Convert.ToInt16(ddlRenewalMonth.SelectedItem.Value),
                                Report_5500, USI_Holidays, Experience, Wellness, Cust_Field_1, Cust_Field_2, Cust_Field_3, strCustField1, strCustField2, strCustField3, grdAccountTeam, ddlServiceCalYear, Renewal_Cycle, ddlReportStyle);
                }
                else if (ddlReportFormat.SelectedItem.Value == "2") // Portrait Format
                {
                    wt.WriteFieldToSC_Highlights_Portrait(oWordDoc, oWordApp, ddlOffice1, ddlClient, dictionaryMonth, Convert.ToInt16(ddlRenewalMonth.SelectedItem.Value),
                             Report_5500, USI_Holidays, Experience, Wellness, Cust_Field_1, Cust_Field_2, Cust_Field_3, strCustField1, strCustField2, strCustField3, grdAccountTeam, ddlServiceCalYear, Renewal_Cycle, ddlReportStyle);
                }

                //RunMacro(oWordApp, new Object[] { "CleanTools1" });
                //temperror = temperror + " postmacro";
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(ddlClient.SelectedItem.Text), Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

                //*********** insert activity log new format
                string AdditionalCrtieriaOption_1 = ddlReportStyle.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlReportFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlRenewalCycle.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlServiceCalYear.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        /// <summary>
        /// Create Summary Template2
        /// </summary>
        protected string CreateServiceCalendarDetail(string SessionId, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            string strFileName = string.Empty;
            string strReportName = string.Empty;

            if (ddlReportFormatDetail.SelectedItem.Value == "1") // Landscape Format
            {
                strFileName = "Service Calendar Detail - Landscape";
                strReportName = "Report2 - Landscape";
            }
            else if (ddlReportFormatDetail.SelectedItem.Value == "2") // Portrait Format
            {
                strFileName = "Service Calendar Detail - Portrait";
                strReportName = "Report2 - Portrait";
            }

            Object fileName = Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strFileName + ".docm");

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();
            DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName)))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                WriteServiceCalendarDetail wt = new WriteServiceCalendarDetail();
                Dictionary<int, string> dictionaryMonth = new Dictionary<int, string>();
                dictionaryMonth = CreateMonth(); // Get the list of month in the dictionary

                int Healthcare_Reform = Convert.ToInt16(ddlHealthcareDetail.SelectedItem.Value);
                int USI_Holidays = Convert.ToInt16(ddl_USI_Holidays_Detail.SelectedItem.Value);
                int Wellness = Convert.ToInt16(ddlWellness_Detail.SelectedItem.Value);
                int Cust_Field_1 = Convert.ToInt16(ddlCustomField1.SelectedItem.Value);
                int Cust_Field_2 = Convert.ToInt16(ddlCustomField2.SelectedItem.Value);
                int Cust_Field_3 = Convert.ToInt16(ddlCustomField3.SelectedItem.Value);

                string strCustField1 = Convert.ToString(txtCustomField1.Text).Replace("\r\n", " ");
                string strCustField2 = Convert.ToString(txtCustomField2.Text).Replace("\r\n", " ");
                string strCustField3 = Convert.ToString(txtCustomField3.Text).Replace("\r\n", " ");

                string RenewalDate = string.Empty;

                ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, tc.ServiceCalendar2_SubjectID);
                ActivityDS = timeD.Get_Activity_Detail(Convert.ToInt32(ddlActivity.SelectedItem.Value), SessionId);

                if (ActivityDS.Tables.Count > 0)
                {
                    if (ActivityDS.Tables["activityCustomFieldValues_table"].Rows.Count > 0)
                    {
                        for (int i = 0; i < ActivityDS.Tables["activityCustomFieldValues_table"].Rows.Count; i++)
                        {
                            // Get the renewal date from the Activity table to get the Renewal Month for further calculations
                            if (ActivityDS.Tables["activityCustomFieldValues_table"].Rows[i]["customFieldValues_CustomFieldId"].ToString() == "49101")
                            {
                                RenewalDate = Convert.ToDateTime(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[i]["customFieldValues_valueText"].ToString()).ToString("MM,dd,yyyy");
                            }
                        }
                    }
                }

                if (ddlReportFormatDetail.SelectedItem.Value == "1") // Landscape Format
                {
                    wt.WriteFieldToSC_Detail_Landscape(oWordDoc, oWordApp, ddlOffice, ddlClient, dictionaryMonth, Convert.ToInt16(Convert.ToDateTime(RenewalDate).Month),
                                Healthcare_Reform, USI_Holidays, Wellness, Cust_Field_1, Cust_Field_2, Cust_Field_3, strCustField1, strCustField2, strCustField3, grdAccountTeam, ddlServiceCalYear, ActivityDS, Convert.ToInt16(Convert.ToDateTime(RenewalDate).Year), ddlReportStyleDetail);
                }
                else if (ddlReportFormatDetail.SelectedItem.Value == "2") // Portrait Format
                {
                    wt.WriteFieldToSC_Detail_Portrait(oWordDoc, oWordApp, ddlOffice, ddlClient, dictionaryMonth, Convert.ToInt16(Convert.ToDateTime(RenewalDate).Month),
                             Healthcare_Reform, USI_Holidays, Wellness, Cust_Field_1, Cust_Field_2, Cust_Field_3, strCustField1, strCustField2, strCustField3, grdAccountTeam, ddlServiceCalYear, ActivityDS, Convert.ToInt16(Convert.ToDateTime(RenewalDate).Year), ddlReportStyleDetail);
                }

                //RunMacro(oWordApp, new Object[] { "CleanTools1" });
                //temperror = temperror + " postmacro";
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(ddlClient.SelectedItem.Text), Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                string AdditionalCrtieriaOption_1 = ddlActivity.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlReportStyleDetail.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlReportFormatDetail.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlOffice.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {

                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        /// <summary>
        /// Create Summary Template3
        /// </summary>
        protected string CreateServiceCalendarCompliance(string SessionId, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            //Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            string strFileName = string.Empty;
            string strReportName = string.Empty;

            if (ddlReportFormatCompliance.SelectedItem.Value == "1") // 12-mo SMP/SP w/2-mo AP
            {
                strFileName = "Compliance Calendar - 12-mo SMP-SP w2-mo AP";
                strReportName = "Report3 - Compliance_12mo_W2";
            }
            else if (ddlReportFormatCompliance.SelectedItem.Value == "2") // 12-mo SMP/SP w/2.5-mo AP
            {
                strFileName = "Compliance Calendar - 12-mo SMP-SP w2.5-mo AP";
                strReportName = "Report3 - Compliance_12mo_w25";
            }
            else if (ddlReportFormatCompliance.SelectedItem.Value == "3") // 6-mo SMP/SP w/2-mo AP
            {
                strFileName = "Compliance Calendar - 6-mo SMP-SP w2-AP";
                strReportName = "Report3 - Compliance_6mo_w2";
            }

            //Object fileName = Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strFileName + ".docm");

            //Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();
            DataSet ActivityDS = new DataSet();

            //Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
            //                        ref missing, ref readOnly,
            //                        ref missing, ref missing, ref missing,
            //                        ref missing, ref missing, ref missing,
            //                        ref missing, ref missing, ref isVisible,
            //                        ref missing, ref missing, ref missing, ref missing);

            //object savefilename = Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
            //                     System.DateTime.Now.Month.ToString() +
            //                     System.DateTime.Now.Day.ToString() +
            //                      System.DateTime.Now.Hour.ToString() +
            //                       System.DateTime.Now.Minute.ToString() +
            //                      System.DateTime.Now.Second.ToString() +
            //                      System.DateTime.Now.Millisecond.ToString() +
            //                     ".docm");

            try
            {
                //oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName)))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ServiceCalendar/Documents/Templates/" + strReportName));
                }

                string filename = "~/Files/ServiceCalendar/Documents/Templates/" + strFileName + ".docm";
                string _savefilename = "~/Files/ServiceCalendar/Documents/Templates/" + strReportName + "/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                //oWordDoc.SaveAs(ref savefilename,
                //    ref missing, ref missing, ref missing, ref missing, ref missing,
                //    ref missing, ref missing, ref missing, ref missing, ref missing,
                //    ref missing, ref missing, ref missing, ref missing, ref missing);
                WriteServiceCalendarCompliance wt = new WriteServiceCalendarCompliance();
                Dictionary<int, string> dictionaryMonth = new Dictionary<int, string>();
                dictionaryMonth = CreateMonth(); // Get the list of month in the dictionary

                List<Plan> MedicalPlanList = new List<Plan>();

                MedicalPlanList = FillMedicalPlanList(rdlMedicalPlan);

                //string RenewalDate = string.Empty;
                // Effective Date Here 
                var EffectiveDate = from n in MedicalPlanList
                                    where n.ProductId == Convert.ToInt32(ddlMedicalPlan.SelectedItem.Value)
                                    select n.EffectiveDate;

                //Original RenewalDate
                var Original_RenewalDate = from n in MedicalPlanList
                                           where n.ProductId == Convert.ToInt32(ddlMedicalPlan.SelectedItem.Value)
                                           select n.RenewalDate;

                DateTime dtEffectiveDate = new DateTime();
                dtEffectiveDate = Convert.ToDateTime(EffectiveDate.First());

                DateTime dtOriginal_RenewalDate = new DateTime();
                dtOriginal_RenewalDate = Convert.ToDateTime(Original_RenewalDate.First());

                int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(ddlMedicalPlan.SelectedItem.Value), SessionId);

                // 52403: FundingType = "Self-Insured"; 
                //************************ Commented by Amogh 
                //////DataSet AccountDS = new DataSet();
                //////sd.BuildAccountTable();
                //////AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                if (ddlReportFormatCompliance.SelectedItem.Value == "1") // 12-mo SMP/SP w/2-mo AP
                {
                    wt.WriteFieldToSC_Compliance_12mo_W2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlOffice, ddlClient, dictionaryMonth, dtEffectiveDate, OptionFieldValueiD, ddlGroupMWEA, ddlIsEmpInCA,
                          AccountDS, ddlReportFormatCompliance.SelectedIndex, dtOriginal_RenewalDate, ddlHRA, ddlMassachusetts);
                }
                else if (ddlReportFormatCompliance.SelectedItem.Value == "2") // 12-mo SMP/SP w/2.5-mo AP
                {
                    wt.WriteFieldToSC_Compliance_12mo_W2_5(wobj.office.oWordDoc, wobj.office.oWordApp, ddlOffice, ddlClient, dictionaryMonth, dtEffectiveDate, OptionFieldValueiD, ddlGroupMWEA, ddlIsEmpInCA,
                          AccountDS, dtOriginal_RenewalDate, ddlReportFormatCompliance.SelectedIndex, ddlHRA, ddlMassachusetts);
                }
                else if (ddlReportFormatCompliance.SelectedItem.Value == "3") // 6-mo SMP/SP w/2-mo AP
                {
                    wt.WriteFieldToSC_Compliance_6mo_W2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlOffice, ddlClient, dictionaryMonth, dtEffectiveDate, OptionFieldValueiD, ddlGroupMWEA, ddlIsEmpInCA,
                          AccountDS, ddlReportFormatCompliance.SelectedIndex, dtOriginal_RenewalDate, ddlHRA, ddlMassachusetts);
                }

                //RunMacro(oWordApp, new Object[] { "CleanTools1" });
                //temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();
                //oWordDoc.Save();

                //if (oWordApp != null)
                //{
                //    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                //    Marshal.ReleaseComObject(oWordDoc);

                //    oWordDoc = null;
                //    oWordApp.Quit(ref missing, ref missing, ref missing);
                //    Marshal.FinalReleaseComObject(oWordApp);
                //    oWordApp = null;
                //}

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(ddlClient.SelectedItem.Text), Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                string AdditionalCrtieriaOption_1 = ddlMedicalPlan.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlReportFormatCompliance.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlGroupMWEA.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlIsEmpInCA.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                //if (oWordApp != null)
                //{

                //    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                //    Marshal.ReleaseComObject(oWordDoc);

                //    oWordDoc = null;
                //    oWordApp.Quit(ref missing, ref missing, ref missing);
                //    Marshal.FinalReleaseComObject(oWordApp);
                //    oWordApp = null;
                //}
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Function to create the list of month
        public Dictionary<int, string> CreateMonth()
        {
            Dictionary<int, string> dicMonth = new Dictionary<int, string>();

            try
            {
                dicMonth.Add(0, "Select");
                dicMonth.Add(1, "January");
                dicMonth.Add(2, "February");
                dicMonth.Add(3, "March");
                dicMonth.Add(4, "April");
                dicMonth.Add(5, "May");
                dicMonth.Add(6, "June");
                dicMonth.Add(7, "July");
                dicMonth.Add(8, "August");
                dicMonth.Add(9, "September");
                dicMonth.Add(10, "October");
                dicMonth.Add(11, "November");
                dicMonth.Add(12, "December");
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return dicMonth;
        }

        protected void rdlActivity_SelectedIndexChanged(object sender, EventArgs e)
        {
            SummaryDetail.isClientChanged_ForMedical = true;
            if (ddlActivity.SelectedIndex >= 0)
            {
                ddlActivity.SelectedIndex = 0;
                ddlActivity.Items.Clear();
                if (ddlCalenderType.SelectedValue == "ServiceCalendar2")
                {
                    GetActivity_List(rdlActivity.SelectedItem.Text, tc.ServiceCalendar2_SubjectID);
                }
            }
        }

        protected void rdlMedicalPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlan.SelectedIndex >= 0)
            {
                ddlMedicalPlan.SelectedIndex = 0;
                ddlMedicalPlan.Items.Clear();
                if (ddlCalenderType.SelectedValue == "ServiceCalendar3")
                {
                    if (ddlMedicalPlan.SelectedIndex == -1)
                    {
                        ddlMedicalPlan.DataSource = FillMedicalPlanList(rdlMedicalPlan);
                        ddlMedicalPlan.DataBind();
                        ddlMedicalPlan.Items.Insert(0, new ListItem("Select", string.Empty));
                        ddlMedicalPlan.SelectedIndex = 0;
                    }
                }
            }
        }

        private void GetActivity_List(string rdlValue, int SubjectID)
        {
            bool isActivityPresent = false;
            try
            {
                BPBusiness bp = new BPBusiness();
                TimelineDetail timeD = new TimelineDetail();
                DataTable ActivityTable = new DataTable();
                string ActivityName = string.Empty;
                string ActivityID = string.Empty;
                SessionId = Session["SessionId"].ToString();
                int rowIndex = 1;
                ddlActivity.Items.Clear();
                ddlActivity.Items.Insert(0, new ListItem("Select", string.Empty));

                if (ddlClient.SelectedIndex == 0)
                {

                }
                else
                {
                    ActivityTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                    Session["ActivityTable"] = ActivityTable;

                    if (ActivityTable.Rows.Count > 0)
                    {

                        for (int i = 0; i < ActivityTable.Rows.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["recordID"])))
                            {
                                ActivityID = Convert.ToString(ActivityTable.Rows[i]["recordID"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["subject"])))
                            {
                                ActivityName = Convert.ToString(ActivityTable.Rows[i]["subject"]);
                            }

                            if (rdlValue == "Open" && Convert.ToString(ActivityTable.Rows[i]["status"]).Trim().ToLower() == "open")
                            {
                                ddlActivity.Items.Insert(rowIndex, new ListItem(ActivityName, ActivityID));
                                rowIndex++;
                            }
                            else if (rdlValue == "All")
                            {
                                ddlActivity.Items.Insert(i + 1, new ListItem(ActivityName, ActivityID));
                            }
                        }
                        isActivityPresent = true;
                    }
                }

                if (isActivityPresent == false)
                {
                    if (ddlClient.SelectedItem.Text != "Select")
                    {
                        string script = "alert(\"There is no Activity available for the Client '" + ddlClient.SelectedItem.Text + "'.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void ClearControls()
        {
            pnlGrdAccounTeam.Visible = false;
            grdAccountTeam.DataSource = null;
            grdAccountTeam.DataBind();
            pnlHeader.Visible = false;
            lblAccountContact.Visible = false;

            ddlRenewalCycle.SelectedValue = "0";
            ddlServiceCalYear.SelectedValue = "1";
            //ddlCalenderType.SelectedValue = "0";
            ddlReportFormat.SelectedValue = "0";
            ddlReportFormatDetail.SelectedValue = "0";
            ddlReportStyle.SelectedValue = "0";
            ddlActivity.Items.Clear();
            ddlHealthcareDetail.SelectedValue = "0";
            ddlRenewalMonth.SelectedValue = "0";
            ddl_5500_Report.SelectedValue = "0";
            ddl_USI_Holidays.SelectedValue = "0";
            ddl_USI_Holidays_Detail.SelectedValue = "0";
            ddl_Experience_Reports.SelectedValue = "0";
            ddlWellness.SelectedValue = "0";
            ddlWellness_Detail.SelectedValue = "0";
            ddlcustomeventinclude.SelectedIndex = 0;
            ddlCustomField1.SelectedValue = "0";
            ddlCustomField2.SelectedValue = "0";
            ddlCustomField3.SelectedValue = "0";
            txtCustomField1.Text = "";
            txtCustomField2.Text = "";
            txtCustomField3.Text = "";

            // Controls of Service Calendar 3 - Compiance Report
            ddlMedicalPlan.Items.Clear();
            ddlReportFormatCompliance.SelectedValue = "0";
            ddlGroupMWEA.SelectedValue = "0";
            ddlIsEmpInCA.SelectedValue = "0";
            ddlHRA.SelectedValue = "0";
        }

        /// <summary>
        /// Get all the plan for selected client.
        /// </summary>
        private void FindPlans()
        {
            BPBusiness bp = new BPBusiness();
            List<Plan> PlanList = new List<Plan>();
            Session["PlanList"] = null;
            SessionId = Session["SessionId"].ToString();
            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
            Session["PlanList"] = PlanList;
        }

        public List<Plan> FillMedicalPlanList(RadioButtonList rdlMedicalPlan)
        {
            List<Plan> MedicalPlanList = new List<Plan>();
            try
            {
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> MedicalPlanTypeList = new List<int>();

                MedicalPlanTypeList.Add(100);
                MedicalPlanTypeList.Add(110);
                MedicalPlanTypeList.Add(120);
                MedicalPlanTypeList.Add(130);
                MedicalPlanTypeList.Add(140);
                MedicalPlanTypeList.Add(150);
                MedicalPlanTypeList.Add(160);
                MedicalPlanTypeList.Add(170);
                //  MedicalPlanTypeList.Add(173);Prescription Drugs
                MedicalPlanTypeList.Add(1116);

                // If radio button is selected as 'ACTIVE'
                if (rdlMedicalPlan.SelectedIndex == 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                        {
                            if (MedicalPlanTypeList.Contains(item.ProductTypeId))
                            {
                                MedicalPlanList.Add(item);
                            }
                        }
                    }
                }
                // If radio button is selected as 'ALL'
                if (rdlMedicalPlan.SelectedIndex == 1)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (MedicalPlanTypeList.Contains(item.ProductTypeId))
                        {
                            MedicalPlanList.Add(item);
                        }
                    }
                }
                ConstantValue cv = new ConstantValue();

                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in MedicalPlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.MedicalPlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }
                Session["ProductSummaryTable"] = ProductSummaryTable;
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return MedicalPlanList;

        }

        /// <summary>
        /// Create Product Summary Table of selected Plan.
        /// </summary>
        /// <returns> ProductSummaryTable</returns>
        protected DataTable CreateProductSummaryTable()
        {
            DataTable ProductSummaryTable = new DataTable();
            try
            {
                if (Session["ProductSummaryTable"] != null)
                {
                    ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
                }
                else
                {
                    ProductSummaryTable.Columns.Add("ProductId", typeof(Int32));
                    ProductSummaryTable.Columns.Add("ProductName", typeof(string));
                    ProductSummaryTable.Columns.Add("Carrier", typeof(string));
                    ProductSummaryTable.Columns.Add("Effective", typeof(string));
                    ProductSummaryTable.Columns.Add("Renewal", typeof(string));
                    ProductSummaryTable.Columns.Add("PolicyNumber", typeof(string));
                    ProductSummaryTable.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductSummaryTable.Columns.Add("PlanType", typeof(string));
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return ProductSummaryTable;
        }

        protected void ddlcustomeventinclude_selectedindexchanged(object sender, EventArgs e)
        {
            if (ddlcustomeventinclude.SelectedIndex > 0)
            {
                if (ddlcustomeventinclude.SelectedValue == "Included")
                {
                    trAddEvent3.Visible = true;
                }
                else
                {
                    trAddEvent3.Visible = false;
                    ddlCustomField1.SelectedIndex = 0;
                    ddlCustomField2.SelectedIndex = 0;
                    ddlCustomField3.SelectedIndex = 0;

                    txtCustomField1.Text = "";
                    txtCustomField2.Text = "";
                    txtCustomField3.Text = "";
                }
            }
            else
            {
                trAddEvent3.Visible = false;
                ddlCustomField1.SelectedIndex = 0;
                ddlCustomField2.SelectedIndex = 0;
                ddlCustomField3.SelectedIndex = 0;

                txtCustomField1.Text = "";
                txtCustomField2.Text = "";
                txtCustomField3.Text = "";
            }
        }
        protected void btnNext_Click(object sender, EventArgs e)
        {
            bool flag = true;
            try
            {
                if (mvServiceCalendar.ActiveViewIndex == 0)
                {
                    if (ddlCalenderType.SelectedValue == "ServiceCalendar1" || ddlCalenderType.SelectedValue == "ServiceCalendar2")
                    {
                        if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                            ddlClient.Focus();
                            flag = false;
                        }
                        else if (ddlActivity.Items.Count > 0 && (ddlActivity.SelectedItem.Value == "0" || ddlActivity.SelectedItem.Value == "") && ddlCalenderType.SelectedValue == "ServiceCalendar2")
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Activity.')</script>", false);
                            ddlActivity.Focus();
                            flag = false;
                        }
                        //else if (ddlReportStyle.SelectedItem.Value == "0" && ddlReportStyleDetail.SelectedItem.Value == "0")
                        //{
                        //    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Calendar Style.')</script>", false);
                        //    if (Convert.ToString(Session["Summary"]) == "ServiceCalendar1")
                        //    {
                        //        ddlReportStyle.Focus();
                        //        flag = false;
                        //    }
                        //    else if (Convert.ToString(Session["Summary"]) == "ServiceCalendar2")
                        //    {
                        //        ddlReportStyleDetail.Focus();
                        //        flag = false;
                        //    }
                        //}
                        else if (ddlReportFormat.SelectedItem.Value == "0" && ddlReportFormatDetail.SelectedItem.Value == "0")
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Layout Option.')</script>", false);
                            if (ddlCalenderType.SelectedValue == "ServiceCalendar1")
                            {
                                ddlReportFormat.Focus();
                                flag = false;
                            }
                            else if (ddlCalenderType.SelectedValue == "ServiceCalendar2")
                            {
                                ddlReportFormatDetail.Focus();
                                flag = false;
                            }
                        }
                        else if (ddlRenewalCycle.SelectedItem.Value == "0" && ddlCalenderType.SelectedValue == "ServiceCalendar1")
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Renewal Cycle.')</script>", false);
                            ddlRenewalCycle.Focus();
                            flag = false;
                        }
                        else if (ddlRenewalMonth.SelectedItem.Value == "0" && ddlCalenderType.SelectedValue == "ServiceCalendar1")
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Renewal Month.')</script>", false);
                            ddlRenewalMonth.Focus();
                            flag = false;
                        }

                        if (flag == true)
                        {
                            mvServiceCalendar.ActiveViewIndex = 1;
                            btnPrevious.Visible = true;
                            btnNext.Visible = false;
                            btnSummary.Visible = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (mvServiceCalendar.ActiveViewIndex == 1)
                {
                    mvServiceCalendar.ActiveViewIndex = 0;
                    btnPrevious.Visible = false;
                    btnNext.Visible = true;
                    btnSummary.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}