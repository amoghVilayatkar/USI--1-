﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls;
using Microsoft.Office.Core;
using System.Threading;
using BenefitPointSummaryPortal.BAL.ClientServiceUtility;
using BenefitPointSummaryPortal.Common.ClientUserControl;
using BenefitPointSummaryPortal.BAL.PHMStrategicPlan;
using BenefitPointSummaryPortal.Common.ServiceCalendar;

namespace BenefitPointSummaryPortal.View
{
    public partial class PHMStrategicPlan : System.Web.UI.Page
    {
        string SessionId = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        ClientServiveFactory ServiceFactory;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        private static string Activity = "Three Year Strategic Plan";
        private static string Activity_Group = "Population Health Management";
        private static readonly string DeliverableCategory = "Population Health Management";
        string mynewfile = "";
        bool flag = true;
        string AccountContactSession = "AccountContactList";

        
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());



                if (!IsPostBack)
                {
                    txtsearch.Focus();
                    objCommFun.GetUserDetails();
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            BPBusiness bp = new BPBusiness();
            List<Account> AccountList = new List<Account>();
            SessionId = Session["SessionId"].ToString();
            AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
            AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
            ddlClient.Items.Clear();
            ddlClient.DataSource = AccountList;
            ddlClient.DataBind();
            ddlClient.Items.Insert(0, new ListItem("Select", ""));

        }
        protected void ddlClient_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<string> lstUser = new List<string>();
                DataSet AccountTeamMemberDS = new DataSet();
                SessionId = Session["SessionId"].ToString();
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }


                UserDetails objUserDetails = new UserDetails();
                List<UserDetails> lstUserDetails = new List<UserDetails>();

                if (AccountTeamMemberDS.Tables.Count > 0)
                {
                    if (AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < AccountTeamMemberDS.Tables[0].Rows.Count; i++)
                        {
                            objUserDetails = new UserDetails();
                            objUserDetails.UserId = Convert.ToInt32(AccountTeamMemberDS.Tables[0].Rows[i]["UserId"]);
                            objUserDetails.Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]);
                            objUserDetails.Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["Role"]);
                            lstUserDetails.Add(objUserDetails);
                        }
                    }
                }

                Session[AccountContactSession] = lstUserDetails;
                ddlAcountContact.DataSource = lstUserDetails;
                ddlAcountContact.DataBind();
                ddlAcountContact.Items.Insert(0, new ListItem("Select", "Select"));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlAcountContact_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        
        public DataSet GetAccountDetails()
        {
            DataSet AccountDS = null;
            if (ddlClient.SelectedIndex > 0)
            {
                try
                {
                    SessionId = Session["SessionId"].ToString();
                    SummaryDetail sd = new SummaryDetail();
                    sd.BuildAccountTable();
                    AccountDS = ServiceFactory.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return AccountDS;
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            rdlClient.SelectedIndex = 0;
            txtsearch.Text = "";
            BPBusiness bp = new BPBusiness();
            SessionId = Session["SessionId"].ToString();
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", ""));
            rdlClient.SelectedIndex = 0;
            ddlAcountContact.Items.Clear();
            ddlAcountContact.Items.Insert(0, new ListItem("Select", ""));
        }


        protected void btnSummary_Click(object sender, EventArgs e)
        {

            try
            {
                if (Convert.ToString(Session["Summary"]) == "PHMStrategicPlan")
                {

                    if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        ddlClient.Focus();
                        flag = false;
                    }

                    else if (ddlAcountContact.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Account Contact.')</script>");
                        ddlAcountContact.Focus();
                        flag = false;

                    }
                    else
                    {
                        DataSet AccountDS = new DataSet();
                        SessionId = Session["SessionId"].ToString();
                        DataSet AccountTeamMemberDS = new DataSet();
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        sd.BuildAccountTable();
                        AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        List<Contact> lstContact = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                        List<UserDetails> lstUserDetails = Session[AccountContactSession] as List<UserDetails>;
                        if (lstUserDetails != null && lstUserDetails.Count > 0)
                        {
                            UserDetails selectedAccountContact = lstUserDetails.Where(r => r.UserId == int.Parse(ddlAcountContact.SelectedValue)).First();
                            
                            mynewfile = Create_SrategicPlan(ddlClient.SelectedItem.Text.Trim(), SessionId, AccountDS, AccountTeamMemberDS, lstContact, ddlAcountContact.SelectedItem.Text.Trim(), selectedAccountContact.Role);
                            DownloadFileNew(mynewfile);
                            
                            
                        }
                        else
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('No Account Contact(s) found or session expired.')</script>");
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private string Create_SrategicPlan(string ClientName, string SessionId, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string AccountContact, string Role)
        {
            SessionId = Session["SessionId"].ToString();
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp1 = new Word.Application();
            Word.Application oWordApp2 = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/PHMStrategicPlan/Documents/Templates/PHM_3yrStrategy_Template.docm");
            Object fileNameSource = Server.MapPath("~/Files/PHMStrategicPlan/Documents/Templates/PHM_3yrStrategy_Template.docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp1.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            Word.Document oWordDoc1 = oWordApp2.Documents.Open(ref fileNameSource,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/PHMStrategicPlan/Documents/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp1.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/PHMStrategicPlan/Documents/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PHMStrategicPlan/Documents/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                WriteTemplatePHMStrategicPlan wrt = new WriteTemplatePHMStrategicPlan();
                wrt.WriteCommonValueOnTemplate(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, ClientName, AccountContact,Role);
                oWordDoc.Save();

                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;

                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;

                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;

                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;

                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }
            #region ------- Code for Add Activity Log --------
            string AdditionalCrtieriaOption_1 = ddlAcountContact.SelectedItem.Text;
            string AdditionalCrtieriaOption_2 = string.Empty;
            string AdditionalCrtieriaOption_3 = string.Empty;
            string AdditionalCrtieriaOption_4 = string.Empty;
            DictDepartment = sd.getDepartmentDetails();
            Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
            DicActivityLog.Clear();
            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientName, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(DeliverableCategory), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
            #endregion
            return (savefilename.ToString());
        }
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {

                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}