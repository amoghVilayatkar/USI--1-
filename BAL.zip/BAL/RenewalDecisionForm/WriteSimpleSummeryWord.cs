﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Outlook = Microsoft.Office.Interop.Outlook;
using Word = Microsoft.Office.Interop.Word;

namespace BenefitPointSummaryPortal.BAL.RenewalDecisionForm
{
    public class WriteSimpleSummeryWord
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        ConstantValue cv = new ConstantValue();
        Dictionary<string, string> DictBookmarks = new Dictionary<string, string>();

        public void WriteUpperDescription(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DropDownList ddlAccountContact, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary, string SessionId)
        {
            string AccountContactFirstName = string.Empty;
            DateTime EffectiveDate = new DateTime();
            DateTime RenewalDate = new DateTime();
            List<Contact> ContactList = new List<Contact>();
            string ClientName = ddlClient.SelectedItem.Text;

            #region Aquring Effective and Renewal Dates
            if (SelectedPlansBenefitSummary != null && SelectedPlansBenefitSummary.Count > 0)
            {
                DateTime.TryParse(SelectedPlansBenefitSummary[0].EffectiveDate, out EffectiveDate);
                DateTime.TryParse(SelectedPlansBenefitSummary[0].RenewalDate, out RenewalDate);

            }
            #endregion

            #region Aquring Account contact
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
            foreach (Contact contact in ContactList)
            {
                if (Convert.ToString(contact.ContactId) == ddlAccountContact.SelectedValue)
                {
                    AccountContactFirstName = contact.First_Name;
                    break;
                }
            }
            #endregion

            #region MergeField
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("ClientName"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }

                    if (fieldName.Contains("SysDate"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                        continue;
                    }
                    if (fieldName.Contains("ClientContact"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ddlAccountContact.SelectedItem.Text);
                        continue;
                    }
                    if (fieldName.Contains("RenewalYear"))
                    {
                        myMergeField.Select();
                        if (RenewalDate != null)
                        {
                            oWordApp.Selection.TypeText(RenewalDate.Year.ToString());
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }

                        continue;
                    }
                    if (fieldName.Contains("AccountContactFirstName"))
                    {
                        myMergeField.Select();
                        if (AccountContactFirstName!=null && AccountContactFirstName.Trim()!="")
                        {
                            oWordApp.Selection.TypeText(AccountContactFirstName);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                       
                        continue;
                    }
                    if (fieldName.Contains("EffectiveDate"))
                    {
                        myMergeField.Select();
                        if (EffectiveDate != null)
                        {
                            oWordApp.Selection.TypeText(EffectiveDate.ToString("MM/dd/yyyy"));
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }

                    if (fieldName.Contains("RenewalDate"))
                    {
                        myMergeField.Select();
                        if (RenewalDate != null)
                        {
                            oWordApp.Selection.TypeText(RenewalDate.ToString("MM/dd/yyyy"));
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }


                }
            }
            #endregion

        }

        public void WriteMedicalPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "Medical";  //Section bookmark
            string RepeatSection = "RepeatMedical";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "MedicalPlanType";  //mergefield
            string CarrierNameField = "MedicalCarrierName"; //mergefield
            string LOC = cv.MedicalLOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
                //oWordDoc.Bookmarks[bookmark].Delete();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteStopLossPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "StopLoss";  //Section bookmark
            string RepeatSection = "RepeatStopLoss";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "StopLossPlanType";  //mergefield
            string CarrierNameField = "StopLossCarrierName"; //mergefield
            string LOC = cv.StopLoss;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
                //oWordDoc.Bookmarks[bookmark].Delete();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteDentalPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "Dental";  //Section bookmark
            string RepeatSection = "RepeatDental";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "DentalPlanType";  //mergefield
            string CarrierNameField = "DentalCarrierName"; //mergefield
            string LOC = cv.DentalLOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
                //oWordDoc.Bookmarks[bookmark].Delete();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteVisionPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "Vision";  //Section bookmark
            string RepeatSection = "RepeatVision";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "VisionPlanType";  //mergefield
            string CarrierNameField = "VisionCarrierName"; //mergefield
            string LOC = cv.VisionLOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteLifeADnDPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "LifeADnD";  //Section bookmark
            string RepeatSection = "RepeatLifeADnD";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "LifeADnDPlanType";  //mergefield
            string CarrierNameField = "LifeADnDCarrierName"; //mergefield
            string LOC = cv.LifeADDLOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteGroupTermLifePlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "TermLife";  //Section bookmark
            string RepeatSection = "RepeatTermLife";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "TermLifePlanType";  //mergefield
            string CarrierNameField = "TermLifeCarrierName"; //mergefield
            string LOC = cv.GroupTermLifePlanType_CommonCriteria;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteVoluntaryADnDPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "VoluntaryADnD";  //Section bookmark
            string RepeatSection = "RepeatVoluntaryLife";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "VoluntaryLifePlanType";  //mergefield
            string CarrierNameField = "VoluntaryLifeCarrierName"; //mergefield
            string LOC = cv.VoluntaryLife;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteSTDPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "STD";  //Section bookmark
            string RepeatSection = "RepeatSTD";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "STDPlanType";  //mergefield
            string CarrierNameField = "STDCarrierName"; //mergefield
            string LOC = cv.STDLOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteLTDPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "LTD";  //Section bookmark
            string RepeatSection = "RepeatLTD";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "LTDPlanType";  //mergefield
            string CarrierNameField = "LTDCarrierName"; //mergefield
            string LOC = cv.LTDLOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteEAPPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "EAP";  //Section bookmark
            string RepeatSection = "RepeatEAP";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "EAPPlanType";  //mergefield
            string CarrierNameField = "EAPCarrierName"; //mergefield
            string LOC = cv.EAPLOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteFSAPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "FSA";  //Section bookmark
            string RepeatSection = "RepeatFSA";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "FSAPlanType";  //mergefield
            string CarrierNameField = "FSACarrierName"; //mergefield
            string LOC = cv.FSAPlanType;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteHRAPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "HRA";  //Section bookmark
            string RepeatSection = "RepeatHRA";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "HRAPlanType";  //mergefield
            string CarrierNameField = "HRACarrierName"; //mergefield
            string LOC = cv.HRALOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteHSAPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "HSA";  //Section bookmark
            string RepeatSection = "RepeatHSA";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "HSAPlanType";  //mergefield
            string CarrierNameField = "HSACarrierName"; //mergefield
            string LOC = cv.HSALOC;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteWellnessPlan(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary)
        {
            int plancount = 0;
            int iTotalFields = 0;
            Word.Range BookmarkRange = null;

            string SectionBookmarkName = "Wellness";  //Section bookmark
            string RepeatSection = "RepeatWellness";   //mergefield and bookmark for repating part in section
            string PlanTypeField = "WellnessPlanType";  //mergefield
            string CarrierNameField = "WellnessCarrierName"; //mergefield
            string LOC = cv.Wellness;     //Plan LOC

            BookmarkRange = oWordDoc.Bookmarks[SectionBookmarkName].Range;
            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Range.Copy();
            }

            foreach (RenewalPlanSelectionViewModel Plan in SelectedPlansBenefitSummary)
            {
                if (Plan.LOC == LOC)
                {
                    plancount++;
                    if (plancount > 1)
                    {
                        #region copy paste section
                        iTotalFields = 0;
                        foreach (Word.Field myMergeField in BookmarkRange.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(RepeatSection))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Paste();
                                    break;
                                }
                            }
                        }
                        #endregion
                    }

                    #region writing Merge Fields
                    iTotalFields = 0;
                    foreach (Word.Field myMergeField in BookmarkRange.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        string fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains(PlanTypeField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.ProductTypeDescription);
                                continue;
                            }
                            if (fieldName.Contains(CarrierNameField))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Plan.CarrierName);
                                continue;
                            }
                        }
                    }
                    #endregion
                }
            }

            #region delete merge field
            iTotalFields = 0;
            foreach (Word.Field myMergeField in BookmarkRange.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains(RepeatSection))
                    {
                        myMergeField.Delete();
                        break;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists(RepeatSection))
            {
                oWordDoc.Bookmarks[RepeatSection].Delete();
            }
            #endregion

        }

        public void WriteBottomContent(Word.Document oWordDoc, Word.Application oWordApp, DataSet AccountTeamMemberDS, DataSet AccountDS)
        {
            string PrimaryServiceLead = string.Empty;
            string ServiceLeadTitle = string.Empty;
            #region For Address and Phone Number - Team Members

            if (AccountDS != null)
            {
                for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                {
                    if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                    {
                        for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                        {

                            if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                            {
                                PrimaryServiceLead = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) +" "+ Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                ServiceLeadTitle = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                            }
                        }
                    }
                }
            }
            #endregion

            #region writing Merge Fields
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("PrimaryServiceLeadName"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(PrimaryServiceLead);
                        continue;
                    }
                    if (fieldName.Contains("PrimaryServiceLeadTitle"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ServiceLeadTitle);
                        continue;
                    }
                }
            }
            #endregion
        }

        public void LoadDictBookmarks()
        {
            DictBookmarks.Clear();
            DictBookmarks.Add(cv.MedicalLOC, "Medical");
            DictBookmarks.Add(cv.DentalLOC, "Dental");
            DictBookmarks.Add(cv.VisionLOC, "Vision");
            DictBookmarks.Add(cv.StopLoss, "StopLoss");
            DictBookmarks.Add(cv.HRALOC, "HRA");
            DictBookmarks.Add(cv.HSALOC, "HSA");
            DictBookmarks.Add(cv.LifeADDLOC, "LifeADnD");
            DictBookmarks.Add(cv.GroupTermLifePlanType_CommonCriteria, "TermLife");
            DictBookmarks.Add(cv.EAPLOC, "EAP");
            DictBookmarks.Add(cv.FSAPlanType, "FSA");
            DictBookmarks.Add(cv.Wellness, "Wellness");
            DictBookmarks.Add(cv.VoluntaryLife, "VoluntaryADnD");
            DictBookmarks.Add(cv.STDLOC, "STD");
            DictBookmarks.Add(cv.LTDLOC, "LTD");
        }

        public void DeleteBookmarks(Word.Document oWordDoc, Word.Application oWordApp, List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary) 
        {
            LoadDictBookmarks();
            foreach (RenewalPlanSelectionViewModel plan in SelectedPlansBenefitSummary)
            {
                if (DictBookmarks.ContainsKey(plan.LOC))
                {
                    DictBookmarks.Remove(plan.LOC);
                }
            }

            foreach (string section in DictBookmarks.Keys)
            {
                DeleteIndivialBookmark(oWordDoc, DictBookmarks[section]);
            }
        }

        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }

    }

    //Note: This class should be moved to BAL after BAL creation.
    public class RenewalPlanSelectionViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ProductTypeId { get; set; }
        public string ProductTypeDescription { get; set; }
        public string CarrierName { get; set; }
        public string EffectiveDate { get; set; }
        public string RenewalDate { get; set; }
        public string PolicyNumber { get; set; }
        public string SummaryName { get; set; }
        public int SummaryId { get; set; }
        public string LOC { get; set; }
    }
}