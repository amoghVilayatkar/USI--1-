﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Drawing;
using System.Configuration;


namespace BenefitPointSummaryPortal.BAL.Pilot
{
    public class WritePilot_BenchmarkingTool : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        public void WriteClientOverview(Excel.Application myExcelApp, string Client)
        {
            int count = 1;
            Excel.Worksheet wkSheet = null;
            ////Excel.Worksheet wkSheet = null;
            if (count == 1)
            {
                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[1];
            }
             try
             {
                 wkSheet.Cells[2, 3] = Convert.ToString(Client);
             }
             catch (Exception ex)
             {
                 bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                 Response.Redirect("~/view/ErrorNotification.aspx");
             }
          
        
        
        }
    }
}