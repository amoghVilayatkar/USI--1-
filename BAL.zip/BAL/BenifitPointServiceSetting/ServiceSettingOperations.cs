﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using BenefitPointSummaryPortal.DAL;


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;


namespace BenefitPointSummaryPortal.BAL.BenifitPointServiceSetting
{
    public class ServiceSettingOperations
    {
        DBHelper DB_helper = new DBHelper();


        public bool DeleteServiceSetting(int ServiceID)
        {
            bool IsSuccess = false;
            try
            {
                // IsActive = false;                
                string flag = "Delete";
                SqlParameter[] parameters = { new SqlParameter("@ServiceID ", SqlDbType.NVarChar), new SqlParameter("@op ", SqlDbType.NVarChar) };
                parameters[0].Value = ServiceID;
                parameters[1].Value = flag;
                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteBenifitPointServices", parameters);
                IsSuccess = bool.Parse(dtblResult.Rows[0]["IsSuccess"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return IsSuccess;
        }
        public DataTable SearchServiceSettingData(string SericeName, string UserName, string IsActive)
        
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@ServiceName", SqlDbType.VarChar, 500), new SqlParameter("@UserName", SqlDbType.VarChar, 500), new SqlParameter("@IsActive", SqlDbType.Bit) };
                parameters[0].Value = SericeName;
                parameters[1].Value = UserName;
                 if (IsActive=="2")
                 {
                      parameters[2].Value=  DBNull.Value;
                 }
                 else if (IsActive == "1")
                 {
                     parameters[2].Value = true;
                 }
                 else if (IsActive == "0")
                 {
                     parameters[2].Value = false;
                 }
                DataTable dtblBenifitPointServices = DB_helper.ExecProcedure("GetBenefitPointServiceList", parameters);
                return dtblBenifitPointServices;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        public bool IsDuplicateBenifitPointService(int ServiceID, string ServiceName, string ServiceCode)
        {

            bool IsDuplicate = false;
            try
            {
                SqlParameter[] parameters = { 
                                                
                                                new SqlParameter("@ServiceID ", SqlDbType.Int), 
                                                new SqlParameter("@ServiceCode", SqlDbType.VarChar), 
                                                new SqlParameter("@ServiceName", SqlDbType.VarChar)
                                             };
                parameters[0].Value = ServiceID;
                parameters[1].Value = ServiceCode;
                parameters[2].Value = ServiceName;
                DataTable dtblResult = DB_helper.ExecProcedure("IsDuplicateServiceOption ", parameters);
                IsDuplicate = dtblResult.Rows[0]["IsDuplicate"].ToString().ToLower() == "true" ? true : false;
                return IsDuplicate;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

        }
        public DataTable InsertUpdateBenifitPointServices(int ServiceID, string ServiceName, string ServiceUrl, string UserName, string Password, bool IsActive, bool IsDelete, string UserLogin, string ServiceCode)
        {

        DateTime dateTime = DateTime.UtcNow.Date;

            bool IsSuccess = false;
            string IsDuplicate;
            try
            {
                string flag = "Insert";
                if (ServiceID  > 0)
                    flag = "Update";
                SqlParameter[] parameters = { 
                                                
                                                new SqlParameter("@ServiceName ", SqlDbType.VarChar), 
                                                new SqlParameter("@ServiceUrl", SqlDbType.VarChar), 
                                                new SqlParameter("@UserName", SqlDbType.VarChar), 
                                                new SqlParameter("@Password", SqlDbType.VarChar), 
                                                new SqlParameter("@IsActive", SqlDbType.Bit), 
                                                new SqlParameter("@IsDelete", SqlDbType.Bit), 
                                                new SqlParameter("@AddedDate", SqlDbType.DateTime), 
                                                new SqlParameter("@AddedBy", SqlDbType.VarChar), 
                                                new SqlParameter("@ModifiedDate", SqlDbType.DateTime), 
                                                new SqlParameter("@ModifiedBy", SqlDbType.VarChar),
                                                new SqlParameter("@op ", SqlDbType.NVarChar),
                                                new SqlParameter("@ServiceID ", SqlDbType.Int), 
                                                new SqlParameter("@ServiceCode ", SqlDbType.VarChar), 
                 
                                            };
                parameters[0].Value = ServiceName;
                parameters[1].Value = ServiceUrl;
                parameters[2].Value = UserName;
                parameters[3].Value = Encrypt(Password.Trim());
                parameters[4].Value = IsActive;
                parameters[5].Value = IsDelete;
                parameters[6].Value = dateTime;
                parameters[7].Value = UserLogin;
                parameters[8].Value = dateTime;
                parameters[9].Value = UserLogin;
                parameters[10].Value = flag;
                parameters[11].Value = ServiceID;
                parameters[12].Value = ServiceCode;

                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteBenifitPointServices", parameters);
                return dtblResult;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            
        }
        public DataTable GetServiceSettingById(int ServiceID)
        {
            DataTable dtbl = new DataTable();
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@ServiceID ", SqlDbType.Int) };
                parameters[0].Value = ServiceID;
                dtbl = DB_helper.ExecProcedure("GetServiceSettingDatabyId", parameters);//("select Office_name from dbo.BROKER_OFFICE");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtbl;
        }
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        public string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";


            //cipherText = cipherText + new string('=', (4 - cipherText.Length % 4) % 4);
           
            byte[] cipherBytes = Convert.FromBase64String(cipherText);

            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                   cipherText = Encoding.Unicode.GetString(ms.ToArray());
                   // cipherText = Convert.ToBase64String(ms.ToArray);
                }
            }
            return cipherText ;
        }
        public DataTable GetServiceList()
        {
            DataTable dtbl = new DataTable();
            try
            {
                dtbl = DB_helper.ExecProcedure("GetActiveServicesList", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtbl;
        }
        public Dictionary<string,string> GetServiceCredentials(string ServiceCode)
        {
            DataTable dtbl = new DataTable();
            Dictionary<string, string> dictCredentials = new System.Collections.Generic.Dictionary<string, string>();
            dictCredentials["UserName"] = "";
            dictCredentials["Password"] = "";
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@ServiceCode", SqlDbType.VarChar, 50) };
                parameters[0].Value = ServiceCode;
                dtbl = DB_helper.ExecProcedure("GetServiceCredentials", parameters);
                if (dtbl != null && dtbl.Rows.Count > 0)
                {
                    string EncryptedPassword = dtbl.Rows[0]["Password"].ToString();
                    string DecryptedPassword = dtbl.Rows[0]["Password"].ToString();
                    if (EncryptedPassword != string.Empty)
                        DecryptedPassword = Decrypt(EncryptedPassword);
                    dictCredentials["UserName"] = dtbl.Rows[0]["UserName"].ToString();
                    dictCredentials["Password"] = DecryptedPassword;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dictCredentials;
        }
    }
}