﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class BRC
    {
        #region Variable
        private int _BRCId;
        private string _BRCName;
        private string _BRCLocation;
        private string _BRCDayHours;
        private string _BRCPhone;
        private string _BRCEmail;
        private string _BRCFax;

        private int _BRC_RegionId;
        private string _BRC_Region_Desc;
        #endregion

        #region Properties

        /// <summary>
        /// Get and SetBRC_RegionId
        /// </summary>
        public int BRC_Region_Id
        {
            get
            {
                return _BRC_RegionId;
            }
            set
            {
                _BRC_RegionId = value;
            }
        }

        /// <summary>
        /// Get and SetBRC_Region_Desc
        /// </summary>
        public string BRC_Region_Desc
        {
            get
            {
                return _BRC_Region_Desc;
            }
            set
            {
                _BRC_Region_Desc = value;
            }
        }
        /// <summary>
        /// Get and SetBRCId
        /// </summary>
        public int BRCId
        {
            get
            {
                return _BRCId;
            }
            set
            {
                _BRCId = value;
            }
        }
        /// <summary>
        /// Get and SetBRCName
        /// </summary>
        public string BRCName
        {
            get
            {
                return _BRCName;
            }
            set
            {
                _BRCName = value;
            }
        }
        /// <summary>
        /// Get and SetBRCLocation
        /// </summary>
        public string BRCLocation
        {
            get
            {
                return _BRCLocation;
            }
            set
            {
                _BRCLocation = value;
            }
        }
        /// <summary>
        /// Get and SetBRCEmail
        /// </summary>
        public string BRCEmail
        {
            get
            {
                return _BRCEmail;
            }
            set
            {
                _BRCEmail = value;
            }
        }
        /// <summary>
        /// Get and SetBRCPhone
        /// </summary>
        public string BRCPhone
        {
            get
            {
                return _BRCPhone;
            }
            set
            {
                _BRCPhone = value;
            }
        }
        /// <summary>
        /// Get and SetBRCFax
        /// </summary>
        public string BRCFax
        {
            get
            {
                return _BRCFax;
            }
            set
            {
                _BRCFax = value;
            }
        }
        /// <summary>
        /// Get and SetBRCDayHours
        /// </summary>
        public string BRCDayHours
        {
            get
            {
                return _BRCDayHours;
            }
            set
            {
                _BRCDayHours = value;
            }
        }
        #endregion
    }
}