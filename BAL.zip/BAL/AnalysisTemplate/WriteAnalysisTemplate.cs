﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.Collections;


namespace BenefitPointSummaryPortal.BAL.AnalysisTemplate
{
    public class WriteAnalysisTemplate
    {
        List<string> DentalBenefitColumnIdOutNetworkList = new List<string>();
        List<string> DentalBenefitColumnIdList = new List<string>();
        List<string> VisionBenefitColumnIdOutNetworkList = new List<string>();
        List<string> VisionBenefitColumnIdList = new List<string>();
        List<string> STDBenefitColumnIdList = new List<string>();
        List<string> EAPBenefitColumnIdList = new List<string>();

        public WriteAnalysisTemplate()
        {
            //Outnetwok Dental 
            DentalBenefitColumnIdOutNetworkList.Add("117");
            DentalBenefitColumnIdOutNetworkList.Add("119");
            //Dental      
            DentalBenefitColumnIdList.Add("115");
            DentalBenefitColumnIdList.Add("116");
            DentalBenefitColumnIdList.Add("118");
            DentalBenefitColumnIdList.Add("121");
            //Vision
            VisionBenefitColumnIdList.Add("123");
            //Outnetwok Vision
            VisionBenefitColumnIdOutNetworkList.Add("124");
            //STD
            STDBenefitColumnIdList.Add("131");
            STDBenefitColumnIdList.Add("151");
            STDBenefitColumnIdList.Add("152");
            STDBenefitColumnIdList.Add("153");
            STDBenefitColumnIdList.Add("154");
            STDBenefitColumnIdList.Add("155");
            STDBenefitColumnIdList.Add("156");
            //EAP
            EAPBenefitColumnIdList.Add("133");
        }
        public void WriteFields_AnalysisTemplate(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string ClientName, DateTime dtRenevalDate, List<string> lstWorkSheets)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            wkSheet.Cells[1, 2] = ClientName;
            wkSheet.Cells[3, 2] = dtRenevalDate.ToString("MMMM d, yyyy") + " Renewal Date";

            //Hide all Analysis sheets which are not selected by User 
            for (int i = 1; i <= myWorkbook.Worksheets.Count; i++)
            {
                Excel.Worksheet wkSheetToCheck = (Excel.Worksheet)myWorkbook.Worksheets[i];
                if (wkSheetToCheck.Name != null)
                {
                    if (!lstWorkSheets.Contains(wkSheetToCheck.Name))
                    {
                        wkSheetToCheck.Visible = Excel.XlSheetVisibility.xlSheetHidden;
                    }
                }
            }


        }
        public void WritePlans_AnalysisTemplate(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, DataTable dtblPlan, DataTable dtblDualPlans, DataSet BenefitDS, DataSet BenefitDSDual)
        {
            //DataTable dtLOCData = new DataTable();
            //dtLOCData.Columns.Add(new DataColumn("PlanType"));
            //dtLOCData.Columns.Add(new DataColumn("CarrierName")); 

            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            int SelectedPlanRowStartIndex = 6;
            int SelectedPlanRowEndIndex = 29;
            int PlanCostSummaryRowStartIndex = 32;
            int PlanCostSummaryRowEndIndex = 52;
            int PlanRowCount = SelectedPlanRowStartIndex;
            if (dtblPlan != null && dtblPlan.Rows.Count > 0)
            {
                if (dtblPlan.Rows.Count > 24)
                {
                    int PlanRowToInsert = dtblPlan.Rows.Count - 24;
                    SelectedPlanRowEndIndex = SelectedPlanRowEndIndex + PlanRowToInsert;
                    PlanCostSummaryRowStartIndex = PlanCostSummaryRowStartIndex + PlanRowToInsert;
                    for (int i = 1; i <= PlanRowToInsert; i++)
                    {
                        wkSheet.Rows[SelectedPlanRowStartIndex + 1].EntireRow.Insert();
                    }
                }
                if (dtblPlan.Rows.Count > 21)
                {
                    int PlanSummaryRowToInsert = dtblPlan.Rows.Count - 21;
                    PlanCostSummaryRowEndIndex = (PlanCostSummaryRowStartIndex + 20);
                    for (int i = 1; i <= PlanSummaryRowToInsert; i++)
                    {
                        wkSheet.Rows[PlanCostSummaryRowEndIndex].EntireRow.Insert();
                    }
                    PlanCostSummaryRowEndIndex = PlanCostSummaryRowEndIndex + PlanSummaryRowToInsert;
                }
                //Write Plan table
                int tempStartCostSummary = PlanCostSummaryRowStartIndex;
                foreach (DataRow dr in dtblPlan.Rows)
                {
                    wkSheet.Cells[PlanRowCount, 2] = dr["PlanType"] != null ? dr["PlanType"].ToString().Replace("(STD)", " ").Replace("(LTD)", " ").Replace("(EAP)", " ") : "";
                    wkSheet.Cells[PlanRowCount, 3] = dr["CarrierName"] != null ? dr["CarrierName"].ToString() : ""; ;
                    wkSheet.Cells[PlanRowCount, 4] = dr["CarrierName"] != null ? dr["CarrierName"].ToString() : "";
                    PlanRowCount++;
                    tempStartCostSummary++;
                }

                int cnt = 0;
                for (int i = PlanCostSummaryRowStartIndex; i <= PlanCostSummaryRowEndIndex; i++)
                {
                    Excel.Range rangeSelect = wkSheet.Cells[i, 2] as Excel.Range;
                    rangeSelect.Formula = "=B" + (SelectedPlanRowStartIndex + cnt).ToString();
                    rangeSelect.Calculate();
                    cnt++;
                }

                if (PlanRowCount <= SelectedPlanRowEndIndex)
                {
                    for (int i = PlanRowCount; i <= SelectedPlanRowEndIndex; i++)
                    {
                        Excel.Range rangeToCopy = ((Excel.Range)wkSheet.Cells[i, 1]).EntireRow;
                        rangeToCopy.Hidden = true;
                    }
                }

                if (tempStartCostSummary <= PlanCostSummaryRowEndIndex)
                {
                    for (int i = tempStartCostSummary; i <= PlanCostSummaryRowEndIndex; i++)
                    {
                        Excel.Range rangeToCopy = ((Excel.Range)wkSheet.Cells[i, 1]).EntireRow;
                        rangeToCopy.Hidden = true;
                    }
                }

                foreach (DataRow dr in dtblPlan.Rows)
                {
                    string AnalysisType = dr["AnalysisType"].ToString();
                    int BenefitSummaryId = 0;
                    int DualBenefitSummaryId = 0;
                    int.TryParse(dr["SummaryId"].ToString(), out BenefitSummaryId);
                    switch (AnalysisType)
                    {
                        case "Dental":
                            WriteBenefitsDetails_Dental(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;
                        case "Dental Dual":
                            WriteBenefitsDetails_DentalDual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, 4, 6);
                            DataRow DualPlanRow = dtblDualPlans.Select("LOCNo =" + dr["LOCNo"].ToString()).FirstOrDefault();
                            if (DualPlanRow != null)
                            {
                                int.TryParse(DualPlanRow["SummaryId"].ToString(), out DualBenefitSummaryId);
                                WriteBenefitsDetails_DentalDual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), DualPlanRow["PlanType"].ToString(), DualPlanRow["CarrierName"].ToString(), BenefitDSDual, DualBenefitSummaryId, 5, 7);
                            }

                            break;
                        case "Dental DHMO":
                            WriteBenefitsDetails_DentalDHMO(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;
                        case "Dental ASO":
                            WriteBenefitsDetails_DentalASO(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;
                        case "Dental ASO Dual":
                            WriteBenefitsDetails_DentalASODual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, 4, 6);
                            DataRow DualASOPlanRow = dtblDualPlans.Select("LOCNo =" + dr["LOCNo"].ToString()).FirstOrDefault();
                            if (DualASOPlanRow != null)
                            {
                                int.TryParse(DualASOPlanRow["SummaryId"].ToString(), out DualBenefitSummaryId);
                                WriteBenefitsDetails_DentalASODual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), DualASOPlanRow["PlanType"].ToString(), DualASOPlanRow["CarrierName"].ToString(), BenefitDSDual, DualBenefitSummaryId, 5, 7);
                            }
                            break;
                        case "Vision":
                            WriteBenefitsDetails_Vision(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;
                        case "Vision Dual":
                            WriteBenefitsDetails_VisionDual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, 4, 6);
                            DataRow DualVisionPlanRow = dtblDualPlans.Select("LOCNo =" + dr["LOCNo"].ToString()).FirstOrDefault();
                            if (DualVisionPlanRow != null)
                            {
                                int.TryParse(DualVisionPlanRow["SummaryId"].ToString(), out DualBenefitSummaryId);
                                WriteBenefitsDetails_VisionDual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), DualVisionPlanRow["PlanType"].ToString(), DualVisionPlanRow["CarrierName"].ToString(), BenefitDSDual, DualBenefitSummaryId, 5, 7);
                            }
                            break;
                        case "Vision ASO":
                            WriteBenefitsDetails_VisionASO(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;
                        case "Vision ASO Dual":
                            WriteBenefitsDetails_VisionASODual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, 4, 6);
                            DataRow AsoDualVisionPlanRow = dtblDualPlans.Select("LOCNo =" + dr["LOCNo"].ToString()).FirstOrDefault();
                            if (AsoDualVisionPlanRow != null)
                            {
                                int.TryParse(AsoDualVisionPlanRow["SummaryId"].ToString(), out DualBenefitSummaryId);
                                WriteBenefitsDetails_VisionASODual(myExcelApp, myWorkbook, dr["SheetName"].ToString(), AsoDualVisionPlanRow["PlanType"].ToString(), AsoDualVisionPlanRow["CarrierName"].ToString(), BenefitDSDual, DualBenefitSummaryId, 5, 7);
                            }
                            break;
                        case "LADD":
                            WriteBenefitsDetails_LADD(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            break;
                        case "LADD Classes":
                            WriteBenefitsDetails_LADDClasses(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            WriteBenefitsDetails_LADDClasses_ClassData(myExcelApp, myWorkbook, dr["SheetName"].ToString(), BenefitDS, BenefitSummaryId, dr["SelectedBenefitSummary"].ToString(), 11, 15, 19);
                            DataRow[] LADDClassesRow = dtblDualPlans.Select("LOCNo =" + dr["LOCNo"].ToString());
                            int LADDClassNames_RowStart = 12;
                            int LADDBenefitAmount_RowStart = 16;
                            int LADDOverallMax_RowStart = 20;
                            foreach (DataRow ClassRow in LADDClassesRow)
                            {
                                int ClassBenefitSummaryId = 0;
                                int.TryParse(ClassRow["SummaryId"].ToString(), out ClassBenefitSummaryId);
                                WriteBenefitsDetails_LADDClasses_ClassData(myExcelApp, myWorkbook, dr["SheetName"].ToString(), BenefitDSDual, ClassBenefitSummaryId, ClassRow["SelectedBenefitSummary"].ToString(), LADDClassNames_RowStart, LADDBenefitAmount_RowStart, LADDOverallMax_RowStart);
                                LADDClassNames_RowStart++;
                                LADDBenefitAmount_RowStart++;
                                LADDOverallMax_RowStart++;
                            }
                            break;
                        case "LADD Vol":
                            WriteBenefitsDetails_LADDVol(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            break;
                        case "STD Single":
                            WriteBenefitsDetails_STDSingle(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            break;
                        case "STD Classes":
                            WriteBenefitsDetails_STDClasses(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            WriteBenefitsDetails_STDClasses_ClassData(myExcelApp, myWorkbook, dr["SheetName"].ToString(), BenefitDS, BenefitSummaryId, dr["SelectedBenefitSummary"].ToString(), 11, 18, 22);
                            DataRow[] STDClassesRow = dtblDualPlans.Select("LOCNo =" + dr["LOCNo"].ToString());
                            int STDClassNames_RowStart = 12;
                            int STDBenefiPercentage_RowStart = 19;
                            int STDWeeeklyBenefitMax_RowStart = 23;
                            foreach (DataRow ClassRow in STDClassesRow)
                            {
                                int ClassBenefitSummaryId = 0;
                                int.TryParse(ClassRow["SummaryId"].ToString(), out ClassBenefitSummaryId);
                                WriteBenefitsDetails_STDClasses_ClassData(myExcelApp, myWorkbook, dr["SheetName"].ToString(), BenefitDSDual, ClassBenefitSummaryId, ClassRow["SelectedBenefitSummary"].ToString(), STDClassNames_RowStart, STDBenefiPercentage_RowStart, STDWeeeklyBenefitMax_RowStart);
                                STDClassNames_RowStart++;
                                STDBenefiPercentage_RowStart++;
                                STDWeeeklyBenefitMax_RowStart++;
                            }
                            break;
                        case "STD Vol":
                            WriteBenefitsDetails_VolSTD(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            break;
                        case "STD Statutory":
                            WriteBenefitsDetails_StatutorySTD(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;
                        case "LTD Single":
                            WriteBenefitsDetails_LTDSingle(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            break;
                        case "LTD Classes":
                            WriteBenefitsDetails_LTDClasses(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            WriteBenefitsDetails_LTDClasses_ClassData(myExcelApp, myWorkbook, dr["SheetName"].ToString(), BenefitDS, BenefitSummaryId, dr["SelectedBenefitSummary"].ToString(), 11, 15, 19);
                            DataRow[] LTDClassesRow = dtblDualPlans.Select("LOCNo =" + dr["LOCNo"].ToString());
                            int LTDClassNames_RowStart = 12;
                            int LTDPerncentage_RowStart = 16;
                            int LTDMaximumMonthlyBenefit_RowStart = 20;
                            foreach (DataRow ClassRow in LTDClassesRow)
                            {
                                int ClassBenefitSummaryId = 0;
                                int.TryParse(ClassRow["SummaryId"].ToString(), out ClassBenefitSummaryId);
                                WriteBenefitsDetails_LTDClasses_ClassData(myExcelApp, myWorkbook, dr["SheetName"].ToString(), BenefitDSDual, ClassBenefitSummaryId, ClassRow["SelectedBenefitSummary"].ToString(), LTDClassNames_RowStart, LTDPerncentage_RowStart, LTDMaximumMonthlyBenefit_RowStart);
                                LTDClassNames_RowStart++;
                                LTDPerncentage_RowStart++;
                                LTDMaximumMonthlyBenefit_RowStart++;
                            }
                            break;
                        case "LTD Vol":
                            WriteBenefitsDetails_LTDVol(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId, dr["Eligibility"].ToString());
                            break;
                        case "EAP":
                            WriteBenefitsDetails_EAP(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;
                        case "Absence Management":
                            WriteBenefitsDetails_AbsenceMngt(myExcelApp, myWorkbook, dr["SheetName"].ToString(), dr["PlanType"].ToString(), dr["CarrierName"].ToString(), BenefitDS, BenefitSummaryId);
                            break;

                    }
                }

            }


        }
        private string GetBenefitFormattedValue(DataRow dr)
        {
            if (dr != null)
            {
                string Value = dr["value"].ToString().Trim();
                if (!Value.Contains(","))
                {
                    if (Value != string.Empty && dr["UOM"].ToString().ToLower() == "dollars")
                    {
                        if (Value.Contains('.'))
                            Value = string.Format("{0:#,0.##}", double.Parse(Value));
                        else
                            Value = string.Format("{0:#,0.##}", int.Parse(Value));
                    }
                }
                return (dr["prefix"].ToString() + Value + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
            }
            return "";
        }
        private string GetBenefitFormattedValueUOM(DataRow drUOM)
        {
            if (drUOM != null)
                return (drUOM["value"].ToString().Trim() + " " + drUOM["UOM"].ToString().Trim());
            return "";
        }

        #region Dental Analysis Tab
        private void WriteBenefitsDetails_Dental(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            int InNetworkRowStart = 9;
            Excel.Range range = wkSheet.UsedRange;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
            wkSheet.Cells[8, 3] = PlanType;
            wkSheet.Cells[8, 4] = PlanType;
            while (InNetworkRowStart <= 20)
            {
                string strBenefitSummaryAttributeValue = string.Empty;
                string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;
                #region Deductible (Individual / Family)
                if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                {
                    DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Individual != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                    }
                    DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Family != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                        else
                        {
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                        }
                    }
                }
                #endregion
                #region Waived For Preventive
                if (colVal != string.Empty && colVal.Trim() == "Waived For Preventive")
                {
                    DataRow drBenefitValues_WaiveForPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_WaiveForPreventive != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_WaiveForPreventive);
                    }

                }
                #endregion
                #region Annual Maximum
                if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                {
                    DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_AnnualMaximum != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                    }

                }
                #endregion
                #region Preventive Services
                if (colVal != string.Empty && colVal.Trim() == "Preventive Services")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_DignosticAndPreventive != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                    }

                }
                #endregion
                #region Basic Services
                if (colVal != string.Empty && colVal.Trim() == "Basic Services")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_BasicServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    }

                }
                #endregion
                #region Major Services
                if (colVal != string.Empty && colVal.Trim() == "Major Services")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_MajorServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    }

                }
                #endregion
                #region Endodontics / Periodontics
                if (colVal != string.Empty && colVal.Trim() == "Endodontics / Periodontics")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    //DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_BasicServices != null)
                    //{
                    //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    //    else
                    //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    //}
                    DataRow drBenefitValues_EndodonticsTreatment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 190 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_EndodonticsTreatment != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                    }

                }
                #endregion
                #region Implants
                if (colVal != string.Empty && colVal.Trim() == "Implants")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    //DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_MajorServices != null)
                    //{
                    //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    //    else
                    //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    //}
                    DataRow drBenefitValues_Implants = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 255 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Implants != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Implants);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Implants);
                    }

                }
                #endregion
                #region Orthodontia
                if (colVal != string.Empty && colVal.Trim() == "Orthodontia")
                {
                    DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    //DataRow drBenefitValues_OrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 393 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_OrthodontiaServices != null)
                    //{
                    //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                    //    else
                    //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                    //}
                    DataRow drBenefitValues_Orthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Orthodontia != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                    }

                }
                #endregion
                #region Lifetime Maximum
                if (colVal != string.Empty && colVal.Trim() == "Lifetime Maximum")
                {
                    //DataRow drBenefitValues_GeneralPlanInformation = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 210 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_GeneralPlanInformation != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformation);
                    //}
                    DataRow drBenefitValues_LifetimeOrthodontiaPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_LifetimeOrthodontiaPlanMaximum != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                    }
                }
                #endregion

                if (InNetworkRowStart != 12 && InNetworkRowStart != 19)
                {
                    wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                    wkSheet.Cells[InNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                }

                InNetworkRowStart++;
            }

            int OutNetworkRowStart = 23;
            while (OutNetworkRowStart <= 25)
            {
                string strBenefitSummaryAttributeValue = string.Empty;
                string colVal = (string)(range.Cells[OutNetworkRowStart, 1] as Excel.Range).Value2;
                #region Deductible (Individual / Family)
                if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                {
                    DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Individual != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                    }
                    DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Family != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                        else
                        {
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                        }
                    }
                }
                #endregion
                #region Annual Maximum
                if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                {
                    DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_AnnualMaximum != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                    }

                }
                #endregion
                #region Prev. / Basic / Major
                if (colVal != string.Empty && colVal.Trim() == "Prev. / Basic / Major")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_DignosticAndPreventive != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                    }
                    DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_BasicServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    }
                    DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_MajorServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    }
                }

                #endregion
                wkSheet.Cells[OutNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[OutNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                OutNetworkRowStart++;
            }


        }
        private void WriteBenefitsDetails_DentalDual(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, int Current_ColumnIndex, int RenewalColumnIndex)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            int InNetworkRowStart = 9;
            Excel.Range range = wkSheet.UsedRange;
            wkSheet.Cells[7, Current_ColumnIndex] = CarrierName;
            wkSheet.Cells[7, RenewalColumnIndex] = CarrierName;
            wkSheet.Cells[8, Current_ColumnIndex] = PlanType;
            wkSheet.Cells[8, RenewalColumnIndex] = PlanType;
            if (BenefitSummaryID != 0)
            {
                while (InNetworkRowStart <= 20)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;
                    #region Deductible (Individual / Family)
                    if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                    {
                        DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Individual != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                        }
                        DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Family != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                            }
                        }
                    }
                    #endregion
                    #region Waived For Preventive
                    if (colVal != string.Empty && colVal.Trim() == "Waived For Preventive")
                    {
                        DataRow drBenefitValues_WaiveForPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_WaiveForPreventive != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_WaiveForPreventive);
                        }

                    }
                    #endregion
                    #region Annual Maximum
                    if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                    {
                        DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_AnnualMaximum != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                        }

                    }
                    #endregion
                    #region Preventive Services
                    if (colVal != string.Empty && colVal.Trim() == "Preventive Services")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_DignosticAndPreventive != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        }

                    }
                    #endregion
                    #region Basic Services
                    if (colVal != string.Empty && colVal.Trim() == "Basic Services")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BasicServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        }

                    }
                    #endregion
                    #region Major Services
                    if (colVal != string.Empty && colVal.Trim() == "Major Services")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_MajorServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        }

                    }
                    #endregion
                    #region Endodontics / Periodontics
                    if (colVal != string.Empty && colVal.Trim() == "Endodontics / Periodontics")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        //DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_BasicServices != null)
                        //{
                        //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        //    else
                        //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        //}
                        DataRow drBenefitValues_EndodonticsTreatment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 190 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_EndodonticsTreatment != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                        }

                    }
                    #endregion
                    #region Implants
                    if (colVal != string.Empty && colVal.Trim() == "Implants")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        //DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_MajorServices != null)
                        //{
                        //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        //    else
                        //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        //}
                        DataRow drBenefitValues_Implants = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 255 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Implants != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Implants);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Implants);
                        }

                    }
                    #endregion
                    #region Orthodontia
                    if (colVal != string.Empty && colVal.Trim() == "Orthodontia")
                    {
                        DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        //DataRow drBenefitValues_OrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 393 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_OrthodontiaServices != null)
                        //{
                        //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                        //    else
                        //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                        //}
                        DataRow drBenefitValues_Orthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Orthodontia != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                        }

                    }
                    #endregion
                    #region Lifetime Maximum
                    if (colVal != string.Empty && colVal.Trim() == "Lifetime Maximum")
                    {
                        //DataRow drBenefitValues_GeneralPlanInformation = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 210 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_GeneralPlanInformation != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformation);
                        //}
                        DataRow drBenefitValues_LifetimeOrthodontiaPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_LifetimeOrthodontiaPlanMaximum != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                        }
                    }
                    #endregion

                    if (InNetworkRowStart != 12 && InNetworkRowStart != 19)
                    {
                        wkSheet.Cells[InNetworkRowStart, Current_ColumnIndex] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                    }

                    InNetworkRowStart++;
                }

                int OutNetworkRowStart = 23;
                while (OutNetworkRowStart <= 25)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[OutNetworkRowStart, 1] as Excel.Range).Value2;
                    #region Deductible (Individual / Family)
                    if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                    {
                        DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Individual != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                        }
                        DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Family != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                            }
                        }
                    }
                    #endregion
                    #region Annual Maximum
                    if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                    {
                        DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_AnnualMaximum != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                        }

                    }
                    #endregion
                    #region Prev. / Basic / Major
                    if (colVal != string.Empty && colVal.Trim() == "Prev. / Basic / Major")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_DignosticAndPreventive != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        }
                        DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BasicServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        }
                        DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_MajorServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        }
                    }

                    #endregion
                    wkSheet.Cells[OutNetworkRowStart, Current_ColumnIndex] = strBenefitSummaryAttributeValue;
                    wkSheet.Cells[OutNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                    OutNetworkRowStart++;
                }
            }
        }
        private void WriteBenefitsDetails_DentalASO(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            int InNetworkRowStart = 9;
            Excel.Range range = wkSheet.UsedRange;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
            wkSheet.Cells[8, 3] = PlanType;
            wkSheet.Cells[8, 4] = PlanType;
            while (InNetworkRowStart <= 20)
            {
                string strBenefitSummaryAttributeValue = string.Empty;
                string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;
                #region Deductible (Individual / Family)
                if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                {
                    DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Individual != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                    }
                    DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Family != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                        else
                        {
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                        }
                    }
                }
                #endregion
                #region Waived For Preventive
                if (colVal != string.Empty && colVal.Trim() == "Waived For Preventive")
                {
                    DataRow drBenefitValues_WaiveForPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_WaiveForPreventive != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_WaiveForPreventive);
                    }

                }
                #endregion
                #region Annual Maximum
                if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                {
                    DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_AnnualMaximum != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                    }

                }
                #endregion
                #region Preventive Services
                if (colVal != string.Empty && colVal.Trim() == "Preventive Services")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_DignosticAndPreventive != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                    }

                }
                #endregion
                #region Basic Services
                if (colVal != string.Empty && colVal.Trim() == "Basic Services")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_BasicServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    }

                }
                #endregion
                #region Major Services
                if (colVal != string.Empty && colVal.Trim() == "Major Services")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_MajorServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    }

                }
                #endregion
                #region Endodontics / Periodontics
                if (colVal != string.Empty && colVal.Trim() == "Endodontics / Periodontics")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    //DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_BasicServices != null)
                    //{
                    //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    //    else
                    //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    //}
                    DataRow drBenefitValues_EndodonticsTreatment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 190 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_EndodonticsTreatment != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                    }

                }
                #endregion
                #region Implants
                if (colVal != string.Empty && colVal.Trim() == "Implants")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    //DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_MajorServices != null)
                    //{
                    //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    //    else
                    //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    //}
                    DataRow drBenefitValues_Implants = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 255 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Implants != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Implants);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Implants);
                    }

                }
                #endregion
                #region Orthodontia
                if (colVal != string.Empty && colVal.Trim() == "Orthodontia")
                {
                    DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    //DataRow drBenefitValues_OrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 393 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_OrthodontiaServices != null)
                    //{
                    //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                    //    else
                    //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                    //}
                    DataRow drBenefitValues_Orthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Orthodontia != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                    }

                }
                #endregion
                #region Lifetime Maximum
                if (colVal != string.Empty && colVal.Trim() == "Lifetime Maximum")
                {
                    //DataRow drBenefitValues_GeneralPlanInformation = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 210 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_GeneralPlanInformation != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformation);
                    //}
                    DataRow drBenefitValues_LifetimeOrthodontiaPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                    if (drBenefitValues_LifetimeOrthodontiaPlanMaximum != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                    }
                }
                #endregion
                if (InNetworkRowStart != 12 && InNetworkRowStart != 19)
                {
                    wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                    wkSheet.Cells[InNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                }
                InNetworkRowStart++;
            }

            int OutNetworkRowStart = 23;
            while (OutNetworkRowStart <= 25)
            {
                string strBenefitSummaryAttributeValue = string.Empty;
                string colVal = (string)(range.Cells[OutNetworkRowStart, 1] as Excel.Range).Value2;
                #region Deductible (Individual / Family)
                if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                {
                    DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Individual != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                    }
                    DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_Family != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                        else
                        {
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                        }
                    }
                }
                #endregion
                #region Annual Maximum
                if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                {
                    DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_AnnualMaximum != null)
                    {
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                    }

                }
                #endregion
                #region Prev. / Basic / Major
                if (colVal != string.Empty && colVal.Trim() == "Prev. / Basic / Major")
                {
                    //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    //if (drBenefitValues_CoveredServices != null)
                    //{
                    //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                    //}
                    DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_DignosticAndPreventive != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                    }
                    DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_BasicServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                    }
                    DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                    if (drBenefitValues_MajorServices != null)
                    {
                        if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        else
                            strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                    }
                }

                #endregion
                wkSheet.Cells[OutNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[OutNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                OutNetworkRowStart++;
            }


        }
        private void WriteBenefitsDetails_DentalASODual(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, int Current_ColumnIndex, int RenewalColumnIndex)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            int InNetworkRowStart = 9;
            Excel.Range range = wkSheet.UsedRange;
            wkSheet.Cells[7, Current_ColumnIndex] = CarrierName;
            wkSheet.Cells[7, RenewalColumnIndex] = CarrierName;
            wkSheet.Cells[8, Current_ColumnIndex] = PlanType;
            wkSheet.Cells[8, RenewalColumnIndex] = PlanType;
            if (BenefitSummaryID != 0)
            {
                while (InNetworkRowStart <= 20)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;
                    #region Deductible (Individual / Family)
                    if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                    {
                        DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Individual != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                        }
                        DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Family != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                            }
                        }
                    }
                    #endregion
                    #region Waived For Preventive
                    if (colVal != string.Empty && colVal.Trim() == "Waived For Preventive")
                    {
                        DataRow drBenefitValues_WaiveForPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_WaiveForPreventive != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_WaiveForPreventive);
                        }

                    }
                    #endregion
                    #region Annual Maximum
                    if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                    {
                        DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_AnnualMaximum != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                        }

                    }
                    #endregion
                    #region Preventive Services
                    if (colVal != string.Empty && colVal.Trim() == "Preventive Services")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_DignosticAndPreventive != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        }

                    }
                    #endregion
                    #region Basic Services
                    if (colVal != string.Empty && colVal.Trim() == "Basic Services")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BasicServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        }

                    }
                    #endregion
                    #region Major Services
                    if (colVal != string.Empty && colVal.Trim() == "Major Services")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_MajorServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        }

                    }
                    #endregion
                    #region Endodontics / Periodontics
                    if (colVal != string.Empty && colVal.Trim() == "Endodontics / Periodontics")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        //DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_BasicServices != null)
                        //{
                        //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        //    else
                        //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        //}
                        DataRow drBenefitValues_EndodonticsTreatment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 190 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_EndodonticsTreatment != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EndodonticsTreatment);
                        }

                    }
                    #endregion
                    #region Implants
                    if (colVal != string.Empty && colVal.Trim() == "Implants")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        //DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_MajorServices != null)
                        //{
                        //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        //    else
                        //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        //}
                        DataRow drBenefitValues_Implants = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 255 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Implants != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Implants);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Implants);
                        }

                    }
                    #endregion
                    #region Orthodontia
                    if (colVal != string.Empty && colVal.Trim() == "Orthodontia")
                    {
                        DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        //DataRow drBenefitValues_OrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 393 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_OrthodontiaServices != null)
                        //{
                        //    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        //        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                        //    else
                        //        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_OrthodontiaServices);
                        //}
                        DataRow drBenefitValues_Orthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Orthodontia != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Orthodontia);
                        }

                    }
                    #endregion
                    #region Lifetime Maximum
                    if (colVal != string.Empty && colVal.Trim() == "Lifetime Maximum")
                    {
                        //DataRow drBenefitValues_GeneralPlanInformation = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 210 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_GeneralPlanInformation != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformation);
                        //}
                        DataRow drBenefitValues_LifetimeOrthodontiaPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_LifetimeOrthodontiaPlanMaximum != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_LifetimeOrthodontiaPlanMaximum);
                        }
                    }
                    #endregion
                    if (InNetworkRowStart != 12 && InNetworkRowStart != 19)
                    {
                        wkSheet.Cells[InNetworkRowStart, Current_ColumnIndex] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                    }
                    InNetworkRowStart++;
                }

                int OutNetworkRowStart = 23;
                while (OutNetworkRowStart <= 25)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[OutNetworkRowStart, 1] as Excel.Range).Value2;
                    #region Deductible (Individual / Family)
                    if (colVal != string.Empty && colVal.Trim() == "Deductible (Individual / Family)")
                    {
                        DataRow drBenefitValues_Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Individual != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Individual);
                        }
                        DataRow drBenefitValues_Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Family != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Family);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_Family);
                            }
                        }
                    }
                    #endregion
                    #region Annual Maximum
                    if (colVal != string.Empty && colVal.Trim() == "Annual Maximum")
                    {
                        DataRow drBenefitValues_AnnualMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_AnnualMaximum != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AnnualMaximum);
                        }

                    }
                    #endregion
                    #region Prev. / Basic / Major
                    if (colVal != string.Empty && colVal.Trim() == "Prev. / Basic / Major")
                    {
                        //DataRow drBenefitValues_CoveredServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 135 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        //if (drBenefitValues_CoveredServices != null)
                        //{
                        //    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CoveredServices);
                        //}
                        DataRow drBenefitValues_DignosticAndPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_DignosticAndPreventive != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_DignosticAndPreventive);
                        }
                        DataRow drBenefitValues_BasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BasicServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BasicServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_BasicServices);
                        }
                        DataRow drBenefitValues_MajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", DentalBenefitColumnIdOutNetworkList) + ") ").FirstOrDefault();
                        if (drBenefitValues_MajorServices != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MajorServices);
                            else
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_MajorServices);
                        }
                    }

                    #endregion
                    wkSheet.Cells[OutNetworkRowStart, Current_ColumnIndex] = strBenefitSummaryAttributeValue;
                    wkSheet.Cells[OutNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                    OutNetworkRowStart++;
                }
            }
        }
        private void WriteBenefitsDetails_DentalDHMO(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            int InNetworkRowStart = 9;
            Excel.Range range = wkSheet.UsedRange;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
        }
        #endregion
        #region Vision Analysis Tabs
        private void WriteBenefitsDetails_Vision(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 19)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;

                    #region (Exam Copay)
                    if (colVal != string.Empty && colVal.Trim() == "Exam Copay")
                    {
                        DataRow drBenefitValues_Examination = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Examination != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Examination);
                        }
                    }
                    #endregion

                    #region Materials Copay
                    if (colVal != string.Empty && colVal.Trim() == "Materials Copay")
                    {
                        DataRow drBenefitValues_Materials = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Materials);
                    }
                    #endregion

                    #region Exam
                    if (colVal != string.Empty && colVal.Trim() == "Exam")
                    {
                        DataRow drBenefitValues_Exam = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Exam != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Exam);
                        }

                    }
                    #endregion

                    #region Lenses / Single
                    if (colVal != string.Empty && colVal.Trim() == "Single")
                    {
                        DataRow drBenefitValues_Single = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 507 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Single != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Single);
                        }
                    }
                    #endregion

                    #region  Lenses / Bifocal
                    if (colVal != string.Empty && colVal.Trim() == "Bifocal")
                    {
                        DataRow drBenefitValues_Bifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 73 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Bifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Bifocal);
                        }

                    }
                    #endregion

                    #region Lenses / Trifocal
                    if (colVal != string.Empty && colVal.Trim() == "Trifocal")
                    {
                        DataRow drBenefitValues_Trifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 553 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Trifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Trifocal);
                        }

                    }

                    #endregion
                    #region Lenses / Lenticular
                    if (colVal != string.Empty && colVal.Trim() == "Lenticular")
                    {
                        DataRow drBenefitValues_Lenticular = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 311 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Lenticular != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Lenticular);
                        }

                    }
                    #endregion

                    #region Frames
                    if (colVal != string.Empty && colVal.Trim() == "Frames")
                    {
                        DataRow drBenefitValues_Frames = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Frames != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Frames);
                        }
                    }

                    #endregion
                    #region Elective Contacts
                    if (colVal != string.Empty && colVal.Trim() == "Elective Contacts")
                    {
                        DataRow drBenefitValues_ElectiveContacts = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_ElectiveContacts != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ElectiveContacts);
                        }
                    }
                    #endregion

                    #region Lasik Surgery Discount
                    if (colVal != string.Empty && colVal.Trim() == "Lasik Surgery Discount")
                    {
                        DataRow drBenefitValues_SurgeryDiscount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 133 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_SurgeryDiscount != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SurgeryDiscount);
                        }
                    }
                    #endregion

                    #region Benefit Frequencies (E / L / F / C)
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Frequencies (E / L / F / C)")
                    {
                        DataRow drBenefitValues_BenefitFrequenciesE = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 194 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesE != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesE);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesL = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesL != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                        }
                        DataRow drBenefitValues_BenefitFrequenciesF = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesF != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesC = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesC != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                        }
                    }
                    #endregion

                    if (InNetworkRowStart != 11)
                    {
                        wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    InNetworkRowStart++;
                }
            }


        }
        private void WriteBenefitsDetails_VisionDual(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, int Current_ColumnIndex, int RenewalColumnIndex)
        {


            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, Current_ColumnIndex] = CarrierName;
            wkSheet.Cells[7, RenewalColumnIndex] = CarrierName;
            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 19)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;

                    #region Deductible (Exam Copay)
                    if (colVal != string.Empty && colVal.Trim() == "Exam Copay")
                    {
                        DataRow drBenefitValues_Examination = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Examination != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Examination);
                        }
                    }
                    #endregion

                    #region Materials Copay
                    if (colVal != string.Empty && colVal.Trim() == "Materials Copay")
                    {
                        DataRow drBenefitValues_Materials = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Materials != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Materials);
                        }

                    }
                    #endregion
                    #region Exam
                    if (colVal != string.Empty && colVal.Trim() == "Exam")
                    {
                        DataRow drBenefitValues_Exam = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Exam != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Exam);
                        }

                    }
                    #endregion
                    #region Lenses / Single
                    if (colVal != string.Empty && colVal.Trim() == "Single")
                    {
                        DataRow drBenefitValues_Single = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 507 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Single != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Single);
                        }
                    }
                    #endregion

                    #region  Lenses / Bifocal
                    if (colVal != string.Empty && colVal.Trim() == "Bifocal")
                    {
                        DataRow drBenefitValues_Bifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 73 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Bifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Bifocal);
                        }

                    }
                    #endregion

                    #region Lenses / Trifocal
                    if (colVal != string.Empty && colVal.Trim() == "Trifocal")
                    {
                        DataRow drBenefitValues_Trifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 553 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Trifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Trifocal);
                        }

                    }

                    #endregion
                    #region Lenses / Lenticular
                    if (colVal != string.Empty && colVal.Trim() == "Lenticular")
                    {
                        DataRow drBenefitValues_Lenticular = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 311 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Lenticular != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Lenticular);
                        }

                    }
                    #endregion

                    #region Frames
                    if (colVal != string.Empty && colVal.Trim() == "Frames")
                    {
                        DataRow drBenefitValues_Frames = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Frames != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Frames);
                        }
                    }

                    #endregion
                    #region Elective Contacts
                    if (colVal != string.Empty && colVal.Trim() == "Elective Contacts")
                    {
                        DataRow drBenefitValues_ElectiveContacts = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_ElectiveContacts != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ElectiveContacts);
                        }
                    }
                    #endregion

                    #region Lasik Surgery Discount
                    if (colVal != string.Empty && colVal.Trim() == "Lasik Surgery Discount")
                    {
                        DataRow drBenefitValues_SurgeryDiscount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 133 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_SurgeryDiscount != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SurgeryDiscount);
                        }
                    }
                    #endregion

                    #region Benefit Frequencies (E / L / F / C)
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Frequencies (E / L / F / C)")
                    {
                        DataRow drBenefitValues_BenefitFrequenciesE = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 194 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesE != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesE);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesL = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesL != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                        }
                        DataRow drBenefitValues_BenefitFrequenciesF = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesF != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesC = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesC != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                        }
                    }
                    #endregion

                    if (InNetworkRowStart != 11)
                    {
                        wkSheet.Cells[InNetworkRowStart, Current_ColumnIndex] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                        //if (InNetworkRowStart != 10 && InNetworkRowStart != 17)
                        //{
                        //    wkSheet.Cells[InNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                        //}
                    }
                    InNetworkRowStart++;
                }
            }


        }
        private void WriteBenefitsDetails_VisionASO(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 19)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;

                    #region (Exam Copay)
                    if (colVal != string.Empty && colVal.Trim() == "Exam Copay")
                    {
                        DataRow drBenefitValues_Examination = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Examination != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Examination);
                        }
                    }
                    #endregion

                    #region Materials Copay
                    if (colVal != string.Empty && colVal.Trim() == "Materials Copay")
                    {
                        DataRow drBenefitValues_Materials = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Materials);
                    }
                    #endregion

                    #region Exam
                    if (colVal != string.Empty && colVal.Trim() == "Exam")
                    {
                        DataRow drBenefitValues_Exam = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Exam != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Exam);
                        }

                    }
                    #endregion
                    #region Lenses / Single
                    if (colVal != string.Empty && colVal.Trim() == "Single")
                    {
                        DataRow drBenefitValues_Single = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 507 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Single != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Single);
                        }
                    }
                    #endregion

                    #region  Lenses / Bifocal
                    if (colVal != string.Empty && colVal.Trim() == "Bifocal")
                    {
                        DataRow drBenefitValues_Bifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 73 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Bifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Bifocal);
                        }

                    }
                    #endregion

                    #region Lenses / Trifocal
                    if (colVal != string.Empty && colVal.Trim() == "Trifocal")
                    {
                        DataRow drBenefitValues_Trifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 553 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Trifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Trifocal);
                        }

                    }

                    #endregion
                    #region Lenses / Lenticular
                    if (colVal != string.Empty && colVal.Trim() == "Lenticular")
                    {
                        DataRow drBenefitValues_Lenticular = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 311 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Lenticular != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Lenticular);
                        }

                    }
                    #endregion

                    #region Frames
                    if (colVal != string.Empty && colVal.Trim() == "Frames")
                    {
                        DataRow drBenefitValues_Frames = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Frames != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Frames);
                        }
                    }

                    #endregion
                    #region Elective Contacts
                    if (colVal != string.Empty && colVal.Trim() == "Elective Contacts")
                    {
                        DataRow drBenefitValues_ElectiveContacts = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_ElectiveContacts != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ElectiveContacts);
                        }
                    }
                    #endregion

                    #region Lasik Surgery Discount
                    if (colVal != string.Empty && colVal.Trim() == "Lasik Surgery Discount")
                    {
                        DataRow drBenefitValues_SurgeryDiscount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 133 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_SurgeryDiscount != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SurgeryDiscount);
                        }
                    }
                    #endregion

                    #region Benefit Frequencies (E / L / F / C)
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Frequencies (E / L / F / C)")
                    {
                        DataRow drBenefitValues_BenefitFrequenciesE = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 194 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesE != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesE);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesL = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesL != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                        }
                        DataRow drBenefitValues_BenefitFrequenciesF = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesF != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesC = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesC != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                        }
                    }
                    #endregion

                    if (InNetworkRowStart != 11)
                    {
                        wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    InNetworkRowStart++;
                }
            }


        }
        private void WriteBenefitsDetails_VisionASODual(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, int Current_ColumnIndex, int RenewalColumnIndex)
        {


            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, Current_ColumnIndex] = CarrierName;
            wkSheet.Cells[7, RenewalColumnIndex] = CarrierName;
            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 19)
                {

                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;

                    #region (Exam Copay)
                    if (colVal != string.Empty && colVal.Trim() == "Exam Copay")
                    {
                        DataRow drBenefitValues_Examination = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Examination != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Examination);
                        }
                    }
                    #endregion

                    #region Materials Copay
                    if (colVal != string.Empty && colVal.Trim() == "Materials Copay")
                    {
                        DataRow drBenefitValues_Materials = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Materials);
                    }
                    #endregion
                    #region Exam
                    if (colVal != string.Empty && colVal.Trim() == "Exam")
                    {
                        DataRow drBenefitValues_Exam = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Exam != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Exam);
                        }

                    }
                    #endregion
                    #region Lenses / Single
                    if (colVal != string.Empty && colVal.Trim() == "Single")
                    {
                        DataRow drBenefitValues_Single = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 507 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Single != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Single);
                        }
                    }
                    #endregion

                    #region  Lenses / Bifocal
                    if (colVal != string.Empty && colVal.Trim() == "Bifocal")
                    {
                        DataRow drBenefitValues_Bifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 73 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Bifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Bifocal);
                        }

                    }
                    #endregion

                    #region Lenses / Trifocal
                    if (colVal != string.Empty && colVal.Trim() == "Trifocal")
                    {
                        DataRow drBenefitValues_Trifocal = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 553 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Trifocal != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Trifocal);
                        }

                    }

                    #endregion
                    #region Lenses / Lenticular
                    if (colVal != string.Empty && colVal.Trim() == "Lenticular")
                    {
                        DataRow drBenefitValues_Lenticular = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 311 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Lenticular != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Lenticular);
                        }

                    }
                    #endregion

                    #region Frames
                    if (colVal != string.Empty && colVal.Trim() == "Frames")
                    {
                        DataRow drBenefitValues_Frames = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Frames != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Frames);
                        }
                    }

                    #endregion
                    #region Elective Contacts
                    if (colVal != string.Empty && colVal.Trim() == "Elective Contacts")
                    {
                        DataRow drBenefitValues_ElectiveContacts = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_ElectiveContacts != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ElectiveContacts);
                        }
                    }
                    #endregion

                    #region Lasik Surgery Discount
                    if (colVal != string.Empty && colVal.Trim() == "Lasik Surgery Discount")
                    {
                        DataRow drBenefitValues_SurgeryDiscount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 133 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_SurgeryDiscount != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SurgeryDiscount);
                        }
                    }
                    #endregion

                    #region Benefit Frequencies (E / L / F / C)
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Frequencies (E / L / F / C)")
                    {
                        DataRow drBenefitValues_BenefitFrequenciesE = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 194 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesE != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesE);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesL = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesL != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesL);
                        }
                        DataRow drBenefitValues_BenefitFrequenciesF = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesF != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesF);
                        }

                        DataRow drBenefitValues_BenefitFrequenciesC = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", VisionBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitFrequenciesC != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                            else
                                strBenefitSummaryAttributeValue += " / " + GetBenefitFormattedValue(drBenefitValues_BenefitFrequenciesC);
                        }
                    }
                    #endregion
                    if (InNetworkRowStart != 11)
                    {
                        wkSheet.Cells[InNetworkRowStart, Current_ColumnIndex] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                        //if (InNetworkRowStart != 10 && InNetworkRowStart != 17)
                        //{
                        //    wkSheet.Cells[InNetworkRowStart, RenewalColumnIndex] = strBenefitSummaryAttributeValue;
                        //}
                    }
                    InNetworkRowStart++;
                }
            }


        }
        #endregion
        #region Life ADD Tabs
        private void WriteBenefitsDetails_LADD(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            if (BenefitSummaryID > 0)
            {
                int RowStart = 10;
                Excel.Range range = wkSheet.UsedRange;
                wkSheet.Cells[7, 3] = CarrierName;
                wkSheet.Cells[7, 4] = CarrierName;

                wkSheet.Cells[10, 3] = Eligibility;
                wkSheet.Cells[10, 4] = Eligibility;

                while (RowStart <= 24)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[RowStart, 2] as Excel.Range).Value2;
                    #region Benefit Amount
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Amount")
                    {
                        DataRow drBenefitValues_EmployeeBenefitAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186").FirstOrDefault();
                        if (drBenefitValues_EmployeeBenefitAmount != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EmployeeBenefitAmount);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EmployeeBenefitAmount);
                            }
                        }
                    }
                    #endregion
                    #region Benefit Maximum
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Maximum")
                    {
                        DataRow drBenefitValues_EmployeeMaximumAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
                        if (drBenefitValues_EmployeeMaximumAmount != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EmployeeMaximumAmount);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EmployeeMaximumAmount);
                            }
                        }
                    }
                    #endregion
                    #region Spouse Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Spouse Benefit")
                    {
                        DataRow drBenefitValues_SpouseBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 517").FirstOrDefault();
                        if (drBenefitValues_SpouseBenefit != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SpouseBenefit);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_SpouseBenefit);
                            }
                        }
                    }
                    #endregion
                    #region Child Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Child Benefit")
                    {
                        DataRow drBenefitValues_ChildBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 102").FirstOrDefault();
                        if (drBenefitValues_ChildBenefit != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ChildBenefit);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_ChildBenefit);
                            }
                        }
                    }
                    #endregion

                    if (RowStart == 11 || RowStart == 12 || RowStart == 23 || RowStart == 24)
                    {
                        wkSheet.Cells[RowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[RowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    RowStart++;
                }
            }


        }
        private void WriteBenefitsDetails_LADDClasses(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
            wkSheet.Cells[10, 3] = Eligibility;
            wkSheet.Cells[10, 4] = Eligibility;
            if (BenefitSummaryID > 0)
            {
                int RowStart = 32;
                Excel.Range range = wkSheet.UsedRange;
                while (RowStart <= 33)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[RowStart, 2] as Excel.Range).Value2;
                    #region Spouse Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Spouse Benefit")
                    {
                        DataRow drBenefitValues_SpouseBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 517").FirstOrDefault();
                        if (drBenefitValues_SpouseBenefit != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SpouseBenefit);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_SpouseBenefit);
                            }
                        }
                    }
                    #endregion
                    #region Child Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Child Benefit")
                    {
                        DataRow drBenefitValues_ChildBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 102").FirstOrDefault();
                        if (drBenefitValues_ChildBenefit != null)
                        {
                            if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ChildBenefit);
                            else
                            {
                                strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_ChildBenefit);
                            }
                        }
                    }
                    #endregion

                    wkSheet.Cells[RowStart, 3] = strBenefitSummaryAttributeValue;
                    wkSheet.Cells[RowStart, 4] = strBenefitSummaryAttributeValue;
                    RowStart++;
                }
            }


        }
        private void WriteBenefitsDetails_LADDClasses_ClassData(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, DataSet BenefitDS, int BenefitSummaryID, string BenefitSummaryName, int ClassNameRowNum, int ClassValueBenefitAmtRowNum, int ClassValueOverAllMaxEmpRowNum)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            if (BenefitSummaryID > 0)
            {
                wkSheet.Cells[ClassNameRowNum, 3] = BenefitSummaryName;
                wkSheet.Cells[ClassNameRowNum, 4] = BenefitSummaryName;
                string strBenefitSummaryAttributeValue = "";
                DataRow drBenefitValues_LifeADDBenefitAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186 ").FirstOrDefault();
                if (drBenefitValues_LifeADDBenefitAmount != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_LifeADDBenefitAmount);
                }
                wkSheet.Cells[ClassValueBenefitAmtRowNum, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[ClassValueBenefitAmtRowNum, 4] = strBenefitSummaryAttributeValue;

                strBenefitSummaryAttributeValue = "";
                DataRow drBenefitValues_OverallMaximumEmployee = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188 ").FirstOrDefault();
                if (drBenefitValues_OverallMaximumEmployee != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OverallMaximumEmployee);
                }

                wkSheet.Cells[ClassValueOverAllMaxEmpRowNum, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[ClassValueOverAllMaxEmpRowNum, 4] = strBenefitSummaryAttributeValue;
            }
            else
            {
                Excel.Range range1 = ((Excel.Range)wkSheet.Cells[ClassNameRowNum, 1]).EntireRow;
                range1.Hidden = true;

                Excel.Range range2 = ((Excel.Range)wkSheet.Cells[ClassValueBenefitAmtRowNum, 1]).EntireRow;
                range2.Hidden = true;

                Excel.Range range3 = ((Excel.Range)wkSheet.Cells[ClassValueOverAllMaxEmpRowNum, 1]).EntireRow;
                range3.Hidden = true;

            }
        }
        private void WriteBenefitsDetails_LADDVol(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
            wkSheet.Cells[9, 3] = Eligibility;
            wkSheet.Cells[9, 4] = Eligibility;
            if (BenefitSummaryID > 0)
            {
                int RowStart = 12;
                Excel.Range range = wkSheet.UsedRange;
                while (RowStart <= 22)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[RowStart, 2] as Excel.Range).Value2;
                    if (RowStart <= 14)
                    {
                        #region Benefit Increments Employee
                        if (colVal != string.Empty && colVal.Trim() == "Employee")
                        {
                            DataRow drBenefitValues_EmployeeBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186").FirstOrDefault();
                            if (drBenefitValues_EmployeeBenefit != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EmployeeBenefit);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EmployeeBenefit);
                                }
                            }
                        }
                        #endregion
                        #region Benefit Increments Spouse Benefit
                        if (colVal != string.Empty && colVal.Trim() == "Spouse")
                        {
                            DataRow drBenefitValues_SpouseBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 516").FirstOrDefault();
                            if (drBenefitValues_SpouseBenefit != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SpouseBenefit);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_SpouseBenefit);
                                }
                            }
                        }
                        #endregion
                        #region Benefit Increments Children Benefit
                        if (colVal != string.Empty && colVal.Trim() == "Children")
                        {
                            DataRow drBenefitValues_ChildBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 106").FirstOrDefault();
                            if (drBenefitValues_ChildBenefit != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ChildBenefit);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_ChildBenefit);
                                }
                            }
                        }
                        #endregion
                    }
                    if (RowStart > 14 && RowStart <= 18)
                    {
                        #region Benefit Maximums - Employee
                        if (colVal != string.Empty && colVal.Trim() == "Employee")
                        {
                            DataRow drBenefitValues_EmployeeMaximumAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
                            if (drBenefitValues_EmployeeMaximumAmount != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EmployeeMaximumAmount);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EmployeeMaximumAmount);
                                }
                            }
                        }
                        #endregion
                        #region Benefit Maximums - Spouse
                        if (colVal != string.Empty && colVal.Trim() == "Spouse")
                        {
                            DataRow drBenefitValues_SpouseMaximumAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 519").FirstOrDefault();
                            if (drBenefitValues_SpouseMaximumAmount != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SpouseMaximumAmount);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_SpouseMaximumAmount);
                                }
                            }
                        }
                        #endregion
                        #region Benefit Maximums - Children
                        if (colVal != string.Empty && colVal.Trim() == "Children")
                        {
                            DataRow drBenefitValues_ChildMaximumAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 104").FirstOrDefault();
                            if (drBenefitValues_ChildMaximumAmount != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ChildMaximumAmount);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_ChildMaximumAmount);
                                }
                            }
                        }
                        #endregion
                    }
                    if (RowStart > 18 && RowStart <= 22)
                    {
                        #region Guarantee Issue - Employee
                        if (colVal != string.Empty && colVal.Trim() == "Employee")
                        {
                            DataRow drBenefitValues_EmployeeGuaranteeIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 187").FirstOrDefault();
                            if (drBenefitValues_EmployeeGuaranteeIssue != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EmployeeGuaranteeIssue);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_EmployeeGuaranteeIssue);
                                }
                            }
                        }
                        #endregion
                        #region Guarantee Issue- Spouse
                        if (colVal != string.Empty && colVal.Trim() == "Spouse")
                        {
                            DataRow drBenefitValues_SpouseGuaranteeIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 518").FirstOrDefault();
                            if (drBenefitValues_SpouseGuaranteeIssue != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_SpouseGuaranteeIssue);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_SpouseGuaranteeIssue);
                                }
                            }
                        }
                        #endregion
                        #region Guarantee Issue - Children
                        if (colVal != string.Empty && colVal.Trim() == "Children")
                        {
                            DataRow drBenefitValues_ChildGauranteeIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 103").FirstOrDefault();
                            if (drBenefitValues_ChildGauranteeIssue != null)
                            {
                                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ChildGauranteeIssue);
                                else
                                {
                                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_ChildGauranteeIssue);
                                }
                            }
                        }
                        #endregion
                    }



                    wkSheet.Cells[RowStart, 3] = strBenefitSummaryAttributeValue;
                    wkSheet.Cells[RowStart, 4] = strBenefitSummaryAttributeValue;
                    RowStart++;
                }
            }


        }
        #endregion
        #region LTD
        private void WriteBenefitsDetails_LTDSingle(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;

            wkSheet.Cells[10, 3] = Eligibility;
            wkSheet.Cells[10, 4] = Eligibility;
            if (BenefitSummaryID > 0)
            {
                List<int> lstWrittableCells = new List<int>() { 8, 11, 12, 16, 17, 23, 24, 27 };
                int RowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (RowStart <= 27)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[RowStart, 2] as Excel.Range).Value2;
                    #region Definition of Earnings
                    if (colVal != string.Empty && colVal.Trim() == "Definition of Earnings")
                    {
                        DataRow drBenefitValues_DefinitionOfEarnings = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 142 ").FirstOrDefault();
                        if (drBenefitValues_DefinitionOfEarnings != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DefinitionOfEarnings);
                        }
                    }
                    #endregion
                    #region Benefit Percentage
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Percentage")
                    {
                        DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 ").FirstOrDefault();
                        if (drBenefitValues_BenefitPercentage != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                        }
                    }
                    #endregion
                    #region Maximum Monthly Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Maximum Monthly Benefit")
                    {
                        DataRow drBenefitValues_MaximumMonthlyBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 ").FirstOrDefault();
                        if (drBenefitValues_MaximumMonthlyBenefit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MaximumMonthlyBenefit);
                        }
                    }
                    #endregion
                    #region Elimination Period
                    if (colVal != string.Empty && colVal.Trim() == "Elimination Period")
                    {
                        DataRow drBenefitValues_EliminationPeriod = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 ").FirstOrDefault();
                        if (drBenefitValues_EliminationPeriod != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EliminationPeriod);
                        }
                    }
                    #endregion
                    #region Benefit Duration
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Duration")
                    {
                        DataRow drBenefitValues_BenefitDuration = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 351 ").FirstOrDefault();
                        if (drBenefitValues_BenefitDuration != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitDuration);
                        }
                    }
                    #endregion
                    #region Alcohol and Drug Benefit Limit
                    if (colVal != string.Empty && colVal.Trim() == "Alcohol and Drug Benefit Limit")
                    {
                        DataRow drBenefitValues_AlcoholDrugBenefitLimit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 526 ").FirstOrDefault();
                        if (drBenefitValues_AlcoholDrugBenefitLimit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AlcoholDrugBenefitLimit);
                        }
                    }
                    #endregion
                    #region Mental Nervous Benefit Limit
                    if (colVal != string.Empty && colVal.Trim() == "Mental Nervous Benefit Limit")
                    {
                        DataRow drBenefitValues_MentalNervousBenefitLimit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 365 ").FirstOrDefault();
                        if (drBenefitValues_MentalNervousBenefitLimit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MentalNervousBenefitLimit);
                        }
                    }
                    #endregion
                    #region Pre-Existing Conditions Exclusion
                    if (colVal != string.Empty && colVal.Trim() == "Pre-Existing Conditions Exclusion")
                    {
                        DataRow drBenefitValues_PreExistingConditionsExclusion = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 449 ").FirstOrDefault();
                        if (drBenefitValues_PreExistingConditionsExclusion != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_PreExistingConditionsExclusion);
                        }
                    }
                    #endregion

                    if (lstWrittableCells.Contains(RowStart))
                    {
                        wkSheet.Cells[RowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[RowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    RowStart++;
                }
            }


        }
        private void WriteBenefitsDetails_LTDClasses(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            List<int> lstWrittableCells = new List<int>() { 8, 25, 26, 32, 33, 36 };
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;

            wkSheet.Cells[10, 3] = Eligibility;
            wkSheet.Cells[10, 4] = Eligibility;

            if (BenefitSummaryID > 0)
            {
                int RowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (RowStart <= 36)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[RowStart, 2] as Excel.Range).Value2;
                    #region Definition of Earnings
                    if (colVal != string.Empty && colVal.Trim() == "Definition of Earnings")
                    {
                        DataRow drBenefitValues_DefinitionOfEarnings = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 142 ").FirstOrDefault();
                        if (drBenefitValues_DefinitionOfEarnings != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DefinitionOfEarnings);
                        }
                    }
                    #endregion
                    #region Benefit Percentage (Class 1 / 2 / 3)
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Percentage (Class 1 / 2 / 3)12354")
                    {
                        DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 ").FirstOrDefault();
                        if (drBenefitValues_BenefitPercentage != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                        }
                    }
                    #endregion
                    #region Maximum Monthly Benefit (Class 1 / 2 / 3)
                    if (colVal != string.Empty && colVal.Trim() == "Maximum Monthly Benefit (Class 1 / 2 / 3)12354")
                    {
                        DataRow drBenefitValues_MaximumMonthlyBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 ").FirstOrDefault();
                        if (drBenefitValues_MaximumMonthlyBenefit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MaximumMonthlyBenefit);
                        }
                    }
                    #endregion
                    #region Elimination Period
                    if (colVal != string.Empty && colVal.Trim() == "Elimination Period")
                    {
                        DataRow drBenefitValues_EliminationPeriod = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 ").FirstOrDefault();
                        if (drBenefitValues_EliminationPeriod != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EliminationPeriod);
                        }
                    }
                    #endregion
                    #region Benefit Duration
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Duration")
                    {
                        DataRow drBenefitValues_BenefitDuration = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 351 ").FirstOrDefault();
                        if (drBenefitValues_BenefitDuration != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitDuration);
                        }
                    }
                    #endregion
                    #region Alcohol and Drug Benefit Limit
                    if (colVal != string.Empty && colVal.Trim() == "Alcohol and Drug Benefit Limit")
                    {
                        DataRow drBenefitValues_AlcoholDrugBenefitLimit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 526 ").FirstOrDefault();
                        if (drBenefitValues_AlcoholDrugBenefitLimit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AlcoholDrugBenefitLimit);
                        }
                    }
                    #endregion
                    #region Mental Nervous Benefit Limit
                    if (colVal != string.Empty && colVal.Trim() == "Mental Nervous Benefit Limit")
                    {
                        DataRow drBenefitValues_MentalNervousBenefitLimit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 365 ").FirstOrDefault();
                        if (drBenefitValues_MentalNervousBenefitLimit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MentalNervousBenefitLimit);
                        }
                    }
                    #endregion
                    #region Pre-Existing Conditions Exclusion
                    if (colVal != string.Empty && colVal.Trim() == "Pre-Existing Conditions Exclusion")
                    {
                        DataRow drBenefitValues_PreExistingConditionsExclusion = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 449 ").FirstOrDefault();
                        if (drBenefitValues_PreExistingConditionsExclusion != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_PreExistingConditionsExclusion);
                        }
                    }
                    #endregion

                    if (lstWrittableCells.Contains(RowStart))
                    {
                        wkSheet.Cells[RowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[RowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    RowStart++;
                }
            }


        }
        private void WriteBenefitsDetails_LTDClasses_ClassData(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, DataSet BenefitDS, int BenefitSummaryID, string BenefitSummaryName, int ClassNameRowNum, int ClassValueBenefitPerncentageRowNum, int ClassValueMonthlyBenefitRowNum)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            if (BenefitSummaryID > 0)
            {
                wkSheet.Cells[ClassNameRowNum, 3] = BenefitSummaryName;
                wkSheet.Cells[ClassNameRowNum, 4] = BenefitSummaryName;
                string strBenefitSummaryAttributeValue = "";
                DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 ").FirstOrDefault();
                if (drBenefitValues_BenefitPercentage != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                }
                wkSheet.Cells[ClassValueBenefitPerncentageRowNum, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[ClassValueBenefitPerncentageRowNum, 4] = strBenefitSummaryAttributeValue;

                strBenefitSummaryAttributeValue = "";
                DataRow drBenefitValues_MonthlyBenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 ").FirstOrDefault();
                if (drBenefitValues_MonthlyBenefitMaximum != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MonthlyBenefitMaximum);
                }

                wkSheet.Cells[ClassValueMonthlyBenefitRowNum, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[ClassValueMonthlyBenefitRowNum, 4] = strBenefitSummaryAttributeValue;
            }
            else
            {
                Excel.Range range1 = ((Excel.Range)wkSheet.Cells[ClassNameRowNum, 1]).EntireRow;
                range1.Hidden = true;

                Excel.Range range2 = ((Excel.Range)wkSheet.Cells[ClassValueBenefitPerncentageRowNum, 1]).EntireRow;
                range2.Hidden = true;

                Excel.Range range3 = ((Excel.Range)wkSheet.Cells[ClassValueMonthlyBenefitRowNum, 1]).EntireRow;
                range3.Hidden = true;

            }
        }
        private void WriteBenefitsDetails_LTDVol(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;

            wkSheet.Cells[9, 3] = Eligibility;
            wkSheet.Cells[9, 4] = Eligibility;

            if (BenefitSummaryID > 0)
            {
                List<int> lstWrittableCells = new List<int>() { 8, 10, 11, 16, 17, 23, 24, 27 };
                int RowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (RowStart <= 27)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[RowStart, 2] as Excel.Range).Value2;
                    #region Definition of Earnings
                    if (colVal != string.Empty && colVal.Trim() == "Definition of Earnings")
                    {
                        DataRow drBenefitValues_DefinitionOfEarnings = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 142 ").FirstOrDefault();
                        if (drBenefitValues_DefinitionOfEarnings != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_DefinitionOfEarnings);
                        }
                    }
                    #endregion
                    #region Benefit Percentage
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Percentage")
                    {
                        DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 ").FirstOrDefault();
                        if (drBenefitValues_BenefitPercentage != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                        }
                    }
                    #endregion
                    #region Maximum Monthly Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Maximum Monthly Benefit")
                    {
                        DataRow drBenefitValues_MaximumMonthlyBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 ").FirstOrDefault();
                        if (drBenefitValues_MaximumMonthlyBenefit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MaximumMonthlyBenefit);
                        }
                    }
                    #endregion
                    #region Elimination Period
                    if (colVal != string.Empty && colVal.Trim() == "Elimination Period")
                    {
                        DataRow drBenefitValues_EliminationPeriod = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 ").FirstOrDefault();
                        if (drBenefitValues_EliminationPeriod != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_EliminationPeriod);
                        }
                    }
                    #endregion
                    #region Benefit Duration
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Duration")
                    {
                        DataRow drBenefitValues_BenefitDuration = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 351 ").FirstOrDefault();
                        if (drBenefitValues_BenefitDuration != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitDuration);
                        }
                    }
                    #endregion
                    #region Alcohol and Drug Benefit Limit
                    if (colVal != string.Empty && colVal.Trim() == "Alcohol and Drug Benefit Limit")
                    {
                        DataRow drBenefitValues_AlcoholDrugBenefitLimit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 526 ").FirstOrDefault();
                        if (drBenefitValues_AlcoholDrugBenefitLimit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_AlcoholDrugBenefitLimit);
                        }
                    }
                    #endregion
                    #region Mental Nervous Benefit Limit
                    if (colVal != string.Empty && colVal.Trim() == "Mental Nervous Benefit Limit")
                    {
                        DataRow drBenefitValues_MentalNervousBenefitLimit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 365 ").FirstOrDefault();
                        if (drBenefitValues_MentalNervousBenefitLimit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_MentalNervousBenefitLimit);
                        }
                    }
                    #endregion
                    #region Pre-Existing Conditions Exclusion
                    if (colVal != string.Empty && colVal.Trim() == "Pre-Existing Conditions Exclusion")
                    {
                        DataRow drBenefitValues_PreExistingConditionsExclusion = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 449 ").FirstOrDefault();
                        if (drBenefitValues_PreExistingConditionsExclusion != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_PreExistingConditionsExclusion);
                        }
                    }
                    #endregion

                    if (lstWrittableCells.Contains(RowStart))
                    {
                        wkSheet.Cells[RowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[RowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    RowStart++;
                }
            }


        }
        #endregion
        #region EAP
        private void WriteBenefitsDetails_EAP(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 2] = CarrierName;
            wkSheet.Cells[7, 3] = CarrierName;
            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 8;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 14)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;

                    #region Number of In-Person Counseling Visits
                    if (colVal != string.Empty && colVal.Trim() == "Number of In-Person Counseling Visits")
                    {
                        DataRow drBenefitValues_Num = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 384").FirstOrDefault();
                        if (drBenefitValues_Num != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Num);
                        }
                    }
                    #endregion

                    #region Child Care Consultation
                    if (colVal != string.Empty && colVal.Trim() == "Child Care Consultation")
                    {
                        DataRow drBenefitValues_ChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 101").FirstOrDefault();
                        if (drBenefitValues_ChildCare != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ChildCare);
                        }

                    }
                    #endregion

                    #region Elder Care Consultation
                    if (colVal != string.Empty && colVal.Trim() == "Elder Care Consultation")
                    {
                        DataRow drBenefitValues_ElderCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 177").FirstOrDefault();
                        if (drBenefitValues_ElderCare != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ElderCare);
                        }
                    }
                    #endregion

                    #region  Financial Consultation
                    if (colVal != string.Empty && colVal.Trim() == "Financial Consultation")
                    {
                        DataRow drBenefitValues_Finance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 202").FirstOrDefault();
                        if (drBenefitValues_Finance != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Finance);
                        }

                    }
                    #endregion

                    #region Legal Consultation
                    if (colVal != string.Empty && colVal.Trim() == "Legal Consultation")
                    {
                        DataRow drBenefitValues_LegalCon = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 306").FirstOrDefault();
                        if (drBenefitValues_LegalCon != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_LegalCon);
                        }

                    }
                    #endregion

                    #region Critical Illness Counseling
                    if (colVal != string.Empty && colVal.Trim() == "Critical Illness Counseling")
                    {
                        DataRow drBenefitValues_CriticalIllness = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 136").FirstOrDefault();
                        if (drBenefitValues_CriticalIllness != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_CriticalIllness);
                        }
                    }

                    #endregion

                    if (InNetworkRowStart != 9)
                    {
                        wkSheet.Cells[InNetworkRowStart, 2] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                    }
                    InNetworkRowStart++;
                }
            }
        }
        #endregion
        #region STD Analysis Tabs
        private void WriteBenefitsDetails_STDSingle(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;

            wkSheet.Cells[10, 3] = Eligibility;
            wkSheet.Cells[10, 4] = Eligibility;

            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 12;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 17)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 2] as Excel.Range).Value2;

                    #region Accident
                    if (colVal != string.Empty && colVal.Trim() == "Accident")
                    {
                        DataRow drBenefitValues_Accident = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Accident != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Accident);
                        }

                    }
                    #endregion

                    #region Sickness
                    if (colVal != string.Empty && colVal.Trim() == "Sickness")
                    {
                        DataRow drBenefitValues_Sickness = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 505 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Sickness != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Sickness);
                        }

                    }
                    #endregion

                    #region Benefit Percentage
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Percentage")
                    {
                        DataRow drBenefitValues_BenefitPer = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitPer != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPer);
                        }
                    }
                    #endregion

                    #region  Maximum Weekly Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Maximum Weekly Benefit")
                    {
                        DataRow drBenefitValues_Max = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Max != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Max);
                        }

                    }
                    #endregion

                    #region Benefit Duration w/ EP
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Duration w/ EP")
                    {
                        DataRow drBenefitValues_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValueUOM(drBenefitValues_Benefit);
                        }

                    }

                    #endregion

                    if (InNetworkRowStart != 16)
                    {
                        wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    InNetworkRowStart++;
                }
            }
        }
        private void WriteBenefitsDetails_STDClasses(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;

            wkSheet.Cells[10, 3] = Eligibility;
            wkSheet.Cells[10, 4] = Eligibility;

            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 15;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 20)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 2] as Excel.Range).Value2;

                    #region Accident
                    if (colVal != string.Empty && colVal.Trim() == "Accident")
                    {
                        DataRow drBenefitValues_Accident = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Accident != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Accident);
                        }

                    }
                    #endregion

                    #region Sickness
                    if (colVal != string.Empty && colVal.Trim() == "Sickness")
                    {
                        DataRow drBenefitValues_Sickness = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 505 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Sickness != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Sickness);
                        }

                    }
                    #endregion

                    #region Benefit Percentage (Class 1 / 2 / 3)
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Percentage (Class 1 / 2 / 3)123")
                    {
                        DataRow drBenefitValues_BenefitPer = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitPer != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPer);
                        }
                    }
                    #endregion

                    #region  Maximum Weekly Benefit (Class 1 / 2 / 3)
                    if (colVal != string.Empty && colVal.Trim() == "Maximum Weekly Benefit (Class 1 / 2 / 3)123")
                    {
                        DataRow drBenefitValues_Max = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Max != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Max);
                        }

                    }
                    #endregion

                    #region Benefit Duration w/ EP
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Duration w/ EP")
                    {
                        DataRow drBenefitValues_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValueUOM(drBenefitValues_Benefit);
                        }

                    }

                    #endregion

                    if (InNetworkRowStart != 19)
                    {
                        wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                    }
                    InNetworkRowStart++;
                }
            }

        }
        private void WriteBenefitsDetails_STDClasses_ClassData(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, DataSet BenefitDS, int BenefitSummaryID, string BenefitSummaryName, int ClassNameRowNum, int ClassValueBenefitPercentageRowNum, int ClassValueWeeklyBenefitMaximumRowNum)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            if (BenefitSummaryID > 0)
            {
                wkSheet.Cells[ClassNameRowNum, 3] = BenefitSummaryName;
                wkSheet.Cells[ClassNameRowNum, 4] = BenefitSummaryName;
                string strBenefitSummaryAttributeValue = "";
                DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 ").FirstOrDefault();
                if (drBenefitValues_BenefitPercentage != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                }
                wkSheet.Cells[ClassValueBenefitPercentageRowNum, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[ClassValueBenefitPercentageRowNum, 4] = strBenefitSummaryAttributeValue;

                strBenefitSummaryAttributeValue = "";
                DataRow drBenefitValues_WeeklyBenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 ").FirstOrDefault();
                if (drBenefitValues_WeeklyBenefitMaximum != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_WeeklyBenefitMaximum);
                }

                wkSheet.Cells[ClassValueWeeklyBenefitMaximumRowNum, 3] = strBenefitSummaryAttributeValue;
                wkSheet.Cells[ClassValueWeeklyBenefitMaximumRowNum, 4] = strBenefitSummaryAttributeValue;
            }
            else
            {
                Excel.Range range1 = ((Excel.Range)wkSheet.Cells[ClassNameRowNum, 1]).EntireRow;
                range1.Hidden = true;

                Excel.Range range2 = ((Excel.Range)wkSheet.Cells[ClassValueBenefitPercentageRowNum, 1]).EntireRow;
                range2.Hidden = true;

                Excel.Range range3 = ((Excel.Range)wkSheet.Cells[ClassValueWeeklyBenefitMaximumRowNum, 1]).EntireRow;
                range3.Hidden = true;

            }
        }
        private void WriteBenefitsDetails_VolSTD(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID, string Eligibility)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 2] = CarrierName;
            wkSheet.Cells[7, 3] = CarrierName;

            wkSheet.Cells[9, 2] = Eligibility;
            wkSheet.Cells[9, 3] = Eligibility;

            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 11;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 16)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 1] as Excel.Range).Value2;

                    #region Accident
                    if (colVal != string.Empty && colVal.Trim() == "Accident")
                    {
                        DataRow drBenefitValues_Accident = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Accident != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Accident);
                        }

                    }
                    #endregion

                    #region Sickness
                    if (colVal != string.Empty && colVal.Trim() == "Sickness")
                    {
                        DataRow drBenefitValues_Sickness = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 505 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Sickness != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Sickness);
                        }

                    }
                    #endregion

                    #region Benefit Percentage
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Percentage")
                    {
                        DataRow drBenefitValues_BenefitPer = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitPer != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPer);
                        }
                    }
                    #endregion

                    #region  Maximum Weekly Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Maximum Weekly Benefit")
                    {
                        DataRow drBenefitValues_Max = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Max != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Max);
                        }

                    }
                    #endregion

                    #region Benefit Duration w/ EP
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Duration w/ EP")
                    {
                        DataRow drBenefitValues_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValueUOM(drBenefitValues_Benefit);
                        }

                    }
                    #endregion

                    if (InNetworkRowStart != 15)
                    {
                        wkSheet.Cells[InNetworkRowStart, 2] = strBenefitSummaryAttributeValue;
                        wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                    }
                    InNetworkRowStart++;
                }
            }
        }
        private void WriteBenefitsDetails_StatutorySTD(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            wkSheet.Cells[7, 3] = CarrierName;
            wkSheet.Cells[7, 4] = CarrierName;
            if (BenefitSummaryID > 0)
            {
                int InNetworkRowStart = 11;
                Excel.Range range = wkSheet.UsedRange;
                while (InNetworkRowStart <= 15)
                {
                    string strBenefitSummaryAttributeValue = string.Empty;
                    string colVal = (string)(range.Cells[InNetworkRowStart, 2] as Excel.Range).Value2;

                    #region Accident
                    if (colVal != string.Empty && colVal.Trim() == "Accident")
                    {
                        DataRow drBenefitValues_Accident = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Accident != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Accident);
                        }

                    }
                    #endregion

                    #region Sickness
                    if (colVal != string.Empty && colVal.Trim() == "Sickness")
                    {
                        DataRow drBenefitValues_Sickness = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 505 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Sickness != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Sickness);
                        }

                    }
                    #endregion

                    #region Benefit Percentage
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Percentage")
                    {
                        DataRow drBenefitValues_BenefitPer = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitPer != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenefitPer);
                        }
                    }
                    #endregion

                    #region  Maximum Weekly Benefit
                    if (colVal != string.Empty && colVal.Trim() == "Maximum Weekly Benefit")
                    {
                        DataRow drBenefitValues_Max = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Max != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_Max);
                        }

                    }
                    #endregion

                    #region Benefit Duration w/ EP
                    if (colVal != string.Empty && colVal.Trim() == "Benefit Duration w/ EP")
                    {
                        DataRow drBenefitValues_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", STDBenefitColumnIdList) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit != null)
                        {
                            strBenefitSummaryAttributeValue = GetBenefitFormattedValueUOM(drBenefitValues_Benefit);
                        }

                    }
                    #endregion

                    wkSheet.Cells[InNetworkRowStart, 3] = strBenefitSummaryAttributeValue;
                    wkSheet.Cells[InNetworkRowStart, 4] = strBenefitSummaryAttributeValue;
                    InNetworkRowStart++;
                }
            }
        }
        #endregion
        #region Absence Management
        private void WriteBenefitsDetails_AbsenceMngt(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string PlanType, string CarrierName, DataSet BenefitDS, int BenefitSummaryID)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int attributeID = 0;
            int InNetworkRowStart = 9;
            Excel.Range range = wkSheet.UsedRange;
            wkSheet.Cells[7, 2] = CarrierName;
            wkSheet.Cells[7, 3] = CarrierName;
        }
        #endregion
    }
}