﻿using System;
using Microsoft.Reporting.WebForms;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Reflection;
using System.Web.Configuration;

namespace BenefitPointSummaryPortal.View
{
    public partial class PHM_WellnessReport_SSRS : System.Web.UI.Page
    {
        CommonFunctionsBS commnObj = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //DisableUnwantedExportFormat(rptViewer, "PDF");
                div_footer.Controls.Add(commnObj.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    TitleSpan.InnerText = "PHM Wellness Report";
                    rptViewer.ProcessingMode = ProcessingMode.Remote;
                    ServerReport serverReport = rptViewer.ServerReport;
                    rptViewer.ProcessingMode = ProcessingMode.Remote;
                   // serverReport.ReportServerUrl = new Uri("http://usi-sq-10/ReportServer_ADPConcur");
                    //serverReport.ReportPath = "/BP/BP PHM Wellness Report";
                    //serverReport.ReportServerUrl = new Uri("http://reports.usii.com/reportserver");
                    string ReportServer = WebConfigurationManager.AppSettings["SSRSReportServer"].ToString();
                    serverReport.ReportServerUrl = new Uri(ReportServer);
                    serverReport.ReportPath = "/BP/BP PHM Wellness Report";
                    rptViewer.ServerReport.GetParameters();
                    rptViewer.ShowParameterPrompts = true;
                    //rptViewer.ServerReport.SetParameters(Param);
                    string Activity = string.Empty;
                    string Activity_Group = string.Empty;
                    Activity = "Wellness Plan Report";
                    Activity_Group = "Reports";
                    string AdditionalCrtieriaOption_1 = string.Empty; // string.Empty;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;

                    rptViewer.ServerReport.Refresh();
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, "", "", Convert.ToString(Session["DeliverableCategory"]), "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}