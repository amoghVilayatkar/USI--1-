﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_FAQSummaryV2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        static Dictionary<string, Dictionary<string, string>> AllBookmarks = new Dictionary<string, Dictionary<string, string>>();
        string std_carrier = "";
        string ltd_carrier = "";

        public void WriteMedicalSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, string NumberOfPlan, DataTable CarrierSpecific)
        {
            try
            {
                int iTotalFields = 0;
                int plancount = 0;

                getBookmarks();

                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                int count = 1;
                string AnnualDeductible = "";
                string AnnualOutofPocket = "";
                string ProfessionalVisit = "";
                DataRow[] foundRows = null;
                string Carrier = "";
                string Website = "";
                string OldCarrier = "";
                string OldWebsite = "";
                string effectivedate = "";
                Dictionary<string, string> unqiueCarriers = new Dictionary<string, string>();
                string uniqueCarrier = "";
                Dictionary<string, string> unqiueWebsites = new Dictionary<string, string>();
                string uniqueWebsite = "";
                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedical.Add(3, "45");          //Annual Deductible[Per Person]
                HashtableMedical.Add(33, "44");         //Annual Deductible[Maximum Per Family]
                HashtableMedical.Add(4, "112");         //Benefits[Coinsurance]
                HashtableMedical.Add(5, "53");          //Annual Out-of-Pocket Maximum[Maximum Per Person]
                HashtableMedical.Add(55, "52");         //Annual Out-of-Pocket Maximum[Maximum Per Family]
                HashtableMedical.Add(6, "386");         //Professional[Office Visit]
                HashtableMedical.Add(66, "414");        //Professional [Outpatient Visit]
                HashtableMedical.Add(7, "16");          //Preventive Care[Office Visit]
                HashtableMedical.Add(8, "184");         //Other Services[Emergency Room]
                HashtableMedical.Add(9, "295");         //Hospital/Facility[Inpatient Care]
                HashtableMedical.Add(10, "168");        //Other Services[Diagnostic X-Ray and Lab Tests]
                //  HashtableMedical.Add(11, "971");        //Other Services[Complex Radiology]

                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                        if (foundRows.Count() > 0)
                        {
                            Website = foundRows[0]["Website"].ToString();
                        }
                        if (rowindex == 0)
                        {
                            effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                        }
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            plancount++;
                            Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                            //if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            //{
                            //    Carrier = Carrier + (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " ";
                            //    OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            //}
                            if (!unqiueCarriers.ContainsKey(Carrier) && Carrier.Trim() != "")
                            {
                                unqiueCarriers.Add(Carrier, Carrier);
                            }

                            if (OldWebsite != Website)
                            {
                                OldWebsite = Website;
                            }
                            //if (OldWebsite != foundRows[0]["Website"].ToString())
                            //{
                            //    Website = foundRows[0]["Website"].ToString();
                            //    OldWebsite = foundRows[0]["Website"].ToString();
                            //}

                            #region MedicalTable

                            oWordDoc.Tables[1].Cell(1, count + 1).Select();
                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["PolicyNumber"].ToString()).Trim() + " " + (BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"].ToString()).Trim();

                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        switch (key)
                                        {
                                            case 33: AnnualDeductible = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " max per family"; break;
                                            case 55: AnnualOutofPocket = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " max per family" + "\n\nThe deductible is included in the out of pocket max.\nCopays do not count towards out of pocket max."; break;
                                            case 66: ProfessionalVisit = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " specialist visit"; break;
                                        }
                                        switch (key)
                                        {
                                            case 3: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " per person \n" + AnnualDeductible; break;
                                            case 4: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " of medical charges after you meet deductible"; break;
                                            case 5: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " per person\n" + AnnualOutofPocket; break;
                                            case 6: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " primary care visit\n" + ProfessionalVisit; break;
                                        }
                                        if (key > 6 && key < 33)
                                        {
                                            oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim()).Replace("  ", " ");
                                        }
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }

                switch (unqiueCarriers.Keys.Count)
                {
                    case 1: uniqueCarrier = unqiueCarriers.ElementAt(0).Value;
                        break;
                    case 2: uniqueCarrier = unqiueCarriers.ElementAt(0).Value + " and " + unqiueCarriers.ElementAt(1).Value;
                        break;
                    case 3: uniqueCarrier = unqiueCarriers.ElementAt(0).Value + ", " + unqiueCarriers.ElementAt(1).Value + " and " + unqiueCarriers.ElementAt(2).Value;
                        break;
                }


                float colWidth = (float)(1.9 * 3) / plancount;
                for (int i = 2; i <= plancount + 1; i++)
                {
                    oWordDoc.Tables[1].Columns[i].Width = oWordApp.InchesToPoints(colWidth);
                }

                switch (plancount)
                {
                    case 1: oWordDoc.Tables[1].Columns[3].Delete();
                        oWordDoc.Tables[1].Columns[3].Delete();
                        break;
                    case 2: oWordDoc.Tables[1].Columns[4].Delete();
                        break;
                    default:
                        break;
                }

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Number of Medical Plan"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(NumberOfPlan);
                        }
                        if (fieldName.Equals("MedicalPlanEffectiveDate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                        }
                        if (fieldName.Contains("Medical Benefits"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Medical Benefits");
                        }
                        if (fieldName.Contains("Medical Plan Carrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(uniqueCarrier.Trim());
                        }
                        if (fieldName.Contains("Medical Plan Website"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Website.Trim()))
                            {
                                oWordApp.Selection.TypeText(Website);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }

                        /*New Changes-25 June 2014*/
                        if (fieldName.Contains("Medical_Plans"))
                        {
                            myMergeField.Select();
                            if (NumberOfPlan == "1")
                            {
                                oWordApp.Selection.TypeText("medical plan");
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("medical plans");
                            }
                        }
                        //end change
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePrescriptionDrugsSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string Preferred_Specialty = "";
                int rowcount = 11;
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");//Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");//Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");//Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "881");   //Prescription Categories[Preferred Specialty]

                #endregion
                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211");//Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");//Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");//Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "884");    //Mail Order[Preferred Specialty]

                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = value + " Tier 1\n"; break;
                                            case 2: Formulary = value + " Tier 2\n"; break;
                                            case 3: NonFormulary = value + " Tier 3\n"; break;
                                            case 4: Preferred_Specialty = value + " Tier 4"; break;
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[1].Cell(rowcount, count + 1).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;

                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = value + " Tier 1\n"; break;
                                            case 2: Formulary = value + " Tier 2\n"; break;
                                            case 3: NonFormulary = value + " Tier 3\n"; break;
                                            case 4: Preferred_Specialty = value + " Tier 4"; break;
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[1].Cell(rowcount + 1, count + 1).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteFieldToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable Office, List<BRCData> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = 0;
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                int index = -1;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                    }

                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name);
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    if (ContactList[index].Phone.Count - 1 != i)
                                                    {
                                                        Phone.Append("\n");
                                                    }
                                                }
                                            }
                                            oWordApp.Selection.TypeText(Phone.ToString());
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                    }

                                    if (fieldName.Contains("Renewal Date"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[rowindex]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.Year.ToString());
                                    }

                                    if (fieldName.Contains("EffectiveDateOfMedicalPlan"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                        //oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("EffectiveMonthOfMedicalPlan"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                        //oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("MMMM") + " " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (ddlBRC.SelectedIndex > 0)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC TimeZone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCTimezone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCTimezone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                            }

                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritHSASectionToTemplateFAQv2(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            string Max_Annual_Contribution_Individual1 = " ";
            string Max_Annual_Contribution_Family1 = " ";
            string value = "";

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int PlanCount = 0;
            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected
            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;
                List<int> BenefitSummarries = dictMap[key];
                int AttributeValueColumnIndex = 2;
                // Write for each Benefit Summary selected
                int BenefitSummaryCount = 0;
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    string AttributeValue = "";
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                    string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    //  oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount + 1).Range.Text = SummaryName;

                    #region Annual Deductible Individual - 4
                    //In Network
                    DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 635").FirstOrDefault();
                    if (drBenefitValues_InNetworkIndividual != null)
                    {
                        Max_Annual_Contribution_Individual1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                    }

                    DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 636").FirstOrDefault();
                    if (drBenefitValues_OutNetworkIndividual != null)
                    {
                        Max_Annual_Contribution_Family1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                    }
                    #endregion

                    AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                }

                #region merge fields
                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Delete HSA"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                        }
                        if (fieldName.Contains("HSA Carrier"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Carrier))
                            {
                                oWordApp.Selection.TypeText(Carrier);
                            }
                            continue;
                        }
                        if (fieldName.Contains("IRS Employee Only coverage"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Max_Annual_Contribution_Individual1))
                            {
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Individual1.Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("IRS Family Coverage"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Max_Annual_Contribution_Family1))
                            {
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Family1.Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }
                }

                #endregion

            }
        }

        public void WritHRASectionToTemplateFAQv2(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {

            string HRA_Tier_1 = string.Empty;
            string HRA_Tier_2 = string.Empty;
            string value = "";

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected
            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;
                List<int> BenefitSummarries = dictMap[key];
                int AttributeValueColumnIndex = 2;
                // Write for each Benefit Summary selected
                int BenefitSummaryCount = 0;
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    string AttributeValue = "";
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                    string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    //  oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount + 1).Range.Text = SummaryName;

                    #region Annual Deductible Individual - 4
                    //In Network

                    DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 238").FirstOrDefault();
                    if (drBenefitValues_InNetworkIndividual != null)
                    {
                        HRA_Tier_1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                    }

                    DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 239").FirstOrDefault();
                    if (drBenefitValues_OutNetworkIndividual != null)
                    {
                        HRA_Tier_2 = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                    }
                    #endregion

                    AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                }

                #region merge fields
                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Delete HSA"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                        }
                        if (fieldName.Contains("HRA Carrier Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Carrier))
                            {
                                oWordApp.Selection.TypeText(Carrier);
                            }
                            continue;
                        }
                        if (fieldName.Contains("HRA Tier One"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(HRA_Tier_1))
                            {
                                oWordApp.Selection.TypeText(HRA_Tier_1.Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("HRA Tier Two"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(HRA_Tier_2))
                            {
                                oWordApp.Selection.TypeText(HRA_Tier_2.Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }
                }

                #endregion

            }
        }

        public void WriteDentalSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, DataTable CarrierSpecific, DataTable PlanTypeSpecific)
        {
            try
            {

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(22, "44");//Calendar Year Deductible
                HashtableDentalInNetwork.Add(2, "45");//Calendar Year Deductible
                HashtableDentalInNetwork.Add(3, "55");//Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(4, "164");//Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(5, "64");//Basic Services – Basic
                HashtableDentalInNetwork.Add(6, "336");//Major Services – Major


                #endregion

                int count = 1;
                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;
                string AnnualDeductible = "";
                string OldCarrier = "";
                string Carrier = "";
                string OldCarrier_Website = "";
                string Carrier_Website = "";
                string Website = "";
                string value = "";
                string FirstCarrier = "";
                string FirstWebsite = "";
                int plancount = 0;
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            plancount++;
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            if (foundRows.Count() > 0)
                            {
                                Website = foundRows[0]["Website"].ToString().Trim();
                            }
                            if (plancount == 1)
                            {
                                FirstCarrier = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                FirstWebsite = Website;
                            }
                            /*New Changes-25 June 2014*/
                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                if (count > 1)
                                {
                                    Carrier = Carrier.Trim() + " and " + (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " ";
                                }
                                else
                                {
                                    Carrier = Carrier.Trim() + (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " ";
                                    // Carrier_Website = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString() + "'");
                                }
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            }
                            // end change


                            if (OldCarrier_Website != Website)
                            {
                                if (count > 1)
                                {
                                    Carrier_Website = Carrier_Website.Trim() + " or " + Website;
                                }
                                else
                                {
                                    Carrier_Website = Carrier_Website.Trim() + Website + " ";
                                    // Carrier_Website = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString() + "'");
                                }
                                OldCarrier_Website = Website;
                            }

                            //Carrier_Website = foundRows[0]["Website"].ToString().Trim();

                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + "'");

                            #region DentalTable

                            oWordDoc.Tables[2].Cell(1, count + 1).Select();
                            oWordDoc.Tables[2].Cell(1, count + 1).Range.Text = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["PolicyNumber"].ToString()).Trim() + " " + (BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"].ToString().Trim());

                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 22: AnnualDeductible = value.ToString().Trim() + " family maximum"; break;

                                            case 2: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value.ToString().Trim() + " per person\n" + AnnualDeductible; break;
                                            //case 3: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value + " (annually)"; break;  
                                            case 3: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value.ToString().Trim() + " maximum per person"; break;
                                            case 4: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value + "\nInsurance pays 100% for oral exams, x-rays and cleanings Annual Limits Apply"; break;
                                            case 5: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = "After deductible is met, insurance pays " + value + "\nServices include fillings, extractions, periodontics, root canals and general anesthesia"; break;
                                            case 6: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = "After deductible is met, insurance pays " + value + "\nServices include crowns, dentures, fixed and removable prosthetics"; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Benefits");
                                    }

                                    //if (fieldName.Contains("Dental Plan Carrier"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.TypeText(Carrier);
                                    //}

                                    if (fieldName.Contains("Dental Plan Specific Text" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundPlanTypeRows[0]["PlanSpecific"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }

                                    //if (fieldName.Contains("Dental Plan Website"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (foundRows.Count() > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString().Trim());
                                    //    }
                                    //    else
                                    //    {
                                    //        myMergeField.Delete();
                                    //    }
                                    //}
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }

                if (plancount == 1)
                {
                    oWordDoc.Tables[2].Columns[2].Width = oWordApp.InchesToPoints(4.96f);
                    oWordDoc.Tables[2].Columns[3].Delete();
                }


                /*New Changes-25 June 2014*/
                int iTotalField = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalField++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Dental Plan Carrier"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                            oWordApp.Selection.TypeText(FirstCarrier.Trim());
                        }
                        if (fieldName.Contains("Dental Plan Website"))
                        {
                            myMergeField.Select();

                            //oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString().Trim());
                            if (!string.IsNullOrEmpty(FirstWebsite.Trim()))
                            {
                                oWordApp.Selection.TypeText(FirstWebsite.Trim());
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                    }
                }
                //End change
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteVisionSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, DataTable CarrierSpecific, ArrayList VisionBenefitColumnIdOutNetworkList)
        {
            try
            {
                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefit = new Hashtable();
                #region HastableVisionBenefit

                //HashtableVisionBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                //HashtableVisionBenefit.Add(3, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(4, "208");//Covered Services – Frames
                ////HashtableVisionBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                ////HashtableVisionBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                ////HashtableVisionBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                //HashtableVisionBenefit.Add(9, "178");//Covered Services – Contact Lenses - Elective
                ////HashtableVisionBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                ////HashtableVisionBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                //HashtableVisionBenefit.Add(13, "194");//General Plan Information – Benefit Frequency – Examination
                //HashtableVisionBenefit.Add(14, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts
                //HashtableVisionBenefit.Add(15, "207");//General Plan Information – Benefit Frequency – Frames

                /*For Old Template--Just Uncomment single if needed*/
                //HashtableVisionBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                ///*Chnge 26 Jun 2014 issue #26*/
                //// HashtableVisionBenefit.Add(3, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(3, "344");//General Plan Information – Material
                ////End change
                //HashtableVisionBenefit.Add(4, "208");//Covered Services – Frames
                ////HashtableVisionBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                ////HashtableVisionBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                ////HashtableVisionBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                //HashtableVisionBenefit.Add(5, "178");//Covered Services – Contact Lenses - Elective
                ////HashtableVisionBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                ////HashtableVisionBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                //HashtableVisionBenefit.Add(7, "194");//General Plan Information – Benefit Frequency – Examination
                ///*Chnge 26 Jun 2014 issue #26*/
                ////HashtableVisionBenefit.Add(8, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(8, "344");//General Plan Information – Benefit Frequency –Lenses
                ////end change
                //HashtableVisionBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts
                //HashtableVisionBenefit.Add(9, "207");//General Plan Information – Benefit Frequency – Frames


                /*After New Template Hash Table*/

                HashtableVisionBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                HashtableVisionBenefit.Add(3, "344");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefit.Add(4, "208");//Covered Services – Frames
                HashtableVisionBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefit.Add(9, "178");//Covered Services – Contact Lenses - Elective
                HashtableVisionBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                HashtableVisionBenefit.Add(13, "194");//General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefit.Add(14, "309");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefit.Add(15, "122");//General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefit.Add(16, "207");//General Plan Information – Benefit Frequency – Frame
                HashtableVisionBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts

                Hashtable HashtableVisionOutNetworkBenefit = new Hashtable();
                HashtableVisionOutNetworkBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                HashtableVisionOutNetworkBenefit.Add(3, "344");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionOutNetworkBenefit.Add(4, "208");//Covered Services – Frames
                HashtableVisionOutNetworkBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                HashtableVisionOutNetworkBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                HashtableVisionOutNetworkBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                HashtableVisionOutNetworkBenefit.Add(9, "178");//Covered Services – Contact Lenses - Elective
                HashtableVisionOutNetworkBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionOutNetworkBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                HashtableVisionOutNetworkBenefit.Add(13, "194");//General Plan Information – Benefit Frequency – Examination
                HashtableVisionOutNetworkBenefit.Add(14, "309");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionOutNetworkBenefit.Add(15, "122");//General Plan Information – Benefit Frequency – Contacts
                HashtableVisionOutNetworkBenefit.Add(16, "207");//General Plan Information – Benefit Frequency – Frame
                HashtableVisionOutNetworkBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts

                #endregion
                int iTotalFields = 0;
                int count = 1;
                string Contacts = "";
                string OldCarrier = "";
                string Carrier = "";

                string value = "";
                string value1 = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            /*New Changes-25 June 2014*/
                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                Carrier = Carrier + (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + " ";
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                            }
                            //end change
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            # region VisionBenefitTable
                            oWordDoc.Tables[3].Cell(1, count + 1).Select();
                            //oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim())+ " " + (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() .Trim())+ " " + (PlanTable.Rows[rowindex]["PolicyNumber"].ToString().Trim()) + " " + (BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"].ToString().Trim());
                            #region VisionInNetwork
                            foreach (int key in HashtableVisionBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {
                                        value = ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim()).Replace("  ", " ");


                                        //if (key > 1 && key < 5)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}
                                        ////if (key > 5 && key < 9 || key == 11 || key == 13 || key == 15)
                                        //if (key == 7 || key == 9)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}

                                        switch (key)
                                        {
                                            case 2: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 3: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 4: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 6: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 7: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 8: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\nIn lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;

                                            case 10: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\nDetermined at provider’s discretion for certain conditions"; break;
                                            case 11: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 13: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 14: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 16: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 15: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 66: Contacts = value; break;
                                            //case 14: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n In lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;
                                            // case 5: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 10: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n Determined at provider’s discretion for certain conditions"; break;
                                            case 66: Contacts = value; break;

                                            //case 8: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Vision OutNetwork
                            foreach (int key in HashtableVisionOutNetworkBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionOutNetworkBenefit[key].ToString())
                                    {
                                        value1 = ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim()).Replace("  ", " ");


                                        //if (key > 1 && key < 5)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}
                                        ////if (key > 5 && key < 9 || key == 11 || key == 13 || key == 15)
                                        //if (key == 7 || key == 9)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}

                                        switch (key)
                                        {
                                            case 2: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 3: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 4: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 6: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 7: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 8: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 9: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1 + "\nIn lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;

                                            case 10: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1 + "\nDetermined at provider’s discretion for certain conditions"; break;
                                            case 11: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 13: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 14: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 16: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 15: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 66: Contacts = value; break;
                                            //case 14: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n In lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;
                                            // case 5: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 10: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n Determined at provider’s discretion for certain conditions"; break;
                                            case 66: Contacts = value1; break;

                                            //case 8: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;
                                        }
                                    }
                                }
                            }


                            #endregion
                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    //if (fieldName.Contains("Vision Plan Carrier"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                    //}
                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Vision Benefits");
                                    }


                                    if (fieldName.Contains("Vision Plan Website"))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }

                /*New Changes-25 June 2014*/

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Vision Plan Carrier"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                            oWordApp.Selection.TypeText(Carrier.Trim());
                        }
                    }
                }
                //end change
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteLifeADDToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> LifeAndADnDPlans, List<int> VoluntaryLifeAndADnDPlans)
        {
            int LifeADDTableIndex = 4;

            if (LifeAndADnDPlans.Count > 0)
            {
                if (AllBookmarks["Life and AD&D"].ContainsKey("LifeADnD"))
                {
                    AllBookmarks["Life and AD&D"].Remove("LifeADnD");
                }
            }

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            int PlanCount = 0;
            int GroupPlanCount = dictMap.Keys.Count;
            string VoluntaryLifeAndADnDCarrier = " ";
            string Carrier = " ";
            // Write for each disctinct plan selected
            foreach (int key in dictMap.Keys)
            {
                if (LifeAndADnDPlans.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    Carrier = drPlanRow["Carrier"].ToString();


                    if (VoluntaryLifeAndADnDPlans.Count > 0 && VoluntaryLifeAndADnDPlans.Contains(key))
                    {
                        VoluntaryLifeAndADnDCarrier = drPlanRow["Carrier"].ToString();
                    }

                    List<int> BenefitSummarries = dictMap[key];
                    // Write for each Benefit Summary selected
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {

                        string AttributeValue = "";
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string CarrierName = drPlanBenefitRow["Carrier"].ToString();

                        #region – Life and AD&D Benefit Amt- Employee
                        //InNetwork
                        DataRow drBenefitValues_BenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186").FirstOrDefault();
                        if (drBenefitValues_BenefitMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitMaximum);
                        }
                        oWordDoc.Tables[LifeADDTableIndex].Cell(2, 2).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion
                    }

                }
            }


            int iTotalFields = 0;

            #region merge fields
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("LifeADnDCarrier"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(Carrier);
                    }
                }
            }
            #endregion
        }

        public void WriteGroupLifeADDtoFAQv2(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList GroupTermLifeBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> GroupTermLife)
        {
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            string LifeBenefitAmount = string.Empty;

            if (GroupTermLife.Count > 0)
            {
                if (AllBookmarks["Life and AD&D"].ContainsKey("GroupLife"))
                {
                    AllBookmarks["Life and AD&D"].Remove("GroupLife");
                }
            }

            foreach (int key in dictMap.Keys)
            {
                if (GroupTermLife.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string CarrierName = drPlanBenefitRow["Carrier"].ToString();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();


                        #region Benefit Maximum-3
                        //InNetwork
                        DataRow drBenefitValues_BenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
                        if (drBenefitValues_BenefitMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitMaximum);
                        }
                        LifeBenefitAmount = AttributeValue;
                        AttributeValue = "";

                        #endregion
                    }

                    #region MergeField

                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("GroupLifeBenefitAmount"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(LifeBenefitAmount);
                                continue;
                            }
                            if (fieldName.Contains("GroupLifeCarrierName"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Carrier);
                                continue;
                            }
                        }
                    }

                    #endregion

                    // ContrbutionTableIndex = ContrbutionTableIndex + 2;
                }
            }
        }

        public void WriteADandDSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, ArrayList ADDBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> ADnDPlans)
        {
            try
            {
                string ADnDBenefitAmount = string.Empty;
                string Carrier = string.Empty;
                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();
                List<string> lstOutNetworkColumnID = new List<string>();

                if (ADnDPlans.Count > 0)
                {
                    if (AllBookmarks["Life and AD&D"].ContainsKey("ADDADnD"))
                    {
                        AllBookmarks["Life and AD&D"].Remove("ADDADnD");
                    }
                }

                foreach (object item in ADDBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }
                foreach (object item in LifeADDBenefitColumnIdList)
                {
                    lstOutNetworkColumnID.Add(item.ToString());
                }


                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    if (ADnDPlans.Contains(key))
                    {

                        DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                        string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                        Carrier = drPlanRow["Carrier"].ToString();

                        List<int> BenefitSummarries = dictMap[key];
                        // Write for each Benefit Summary selected
                        int BenefitSummaryCount = 0;
                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            string AttributeValue = "";
                            BenefitSummaryCount = BenefitSummaryCount + 1;
                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string CarrierName = drPlanBenefitRow["Carrier"].ToString();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();


                            #region General Plan Info –Benefit Amount – Employee
                            //InNetwork
                            DataRow drBenefitValues_CopayRoutineExamFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_CopayRoutineExamFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineExamFacility);
                            }
                            ADnDBenefitAmount = AttributeValue;
                            AttributeValue = "";

                            #endregion

                        }

                    }


                }


                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("ADnDBenefitAmount"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ADnDBenefitAmount);
                            continue;
                        }
                        if (fieldName.Contains("ADnDCarrierName"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                    }
                }

                #endregion

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteSTDSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlSTDNoOfPlan, DropDownList ddlLTDNoOfPlan, DropDownList ddlVoluntaryLifeADDNoOfPlan)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableSTD
                HashtableSTD.Add(2, "8");//STD General Information – Elimination Period – Accident
                HashtableSTD.Add(22, "505");//STD General Information – Elimination Period –Sickness
                HashtableSTD.Add(3, "71");//STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "373");//STD General Plan Information – Minimum Weekly Benefit 
                HashtableSTD.Add(5, "569");//STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(6, "350");//STD General Information – Maximum Period of Payment
                HashtableSTD.Add(7, "449");//STD General Plan Information –Pre-Existing Condition Limitations


                #endregion
                string EliminationPeriod = "";
                string ProductName = "";

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            oWordDoc.Tables[5].Cell(1, 2).Range.Text = "Description";
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Replace("  ", " ").Trim();
                                        switch (key)
                                        {
                                            case 22: EliminationPeriod = value + " Illness"; break;
                                            case 2: oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = value + " Accident / " + EliminationPeriod; break;
                                            case 3: oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = value + " of your weekly earnings\n\nEarnings includes your basic weekly earnings and commissions in effect prior to your period of disability.\nIt does not include overtime pay."; break;
                                        }

                                        if (key > 3 && key < 8)
                                        {
                                            oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = value;
                                        }
                                        if (key == 6)
                                        {
                                            if (dr["UOM"].ToString() == "text")
                                            {
                                                dr["UOM"] = "";
                                            }
                                            oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim().Replace("_", " ");
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("STD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        std_carrier = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                        if (ddlLTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Plan administered by " + std_carrier);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Plans administered by " + std_carrier + " and");
                                        }
                                    }


                                    if (fieldName.Contains("STD_LTDField"))
                                    {
                                        myMergeField.Select();
                                        if (ddlLTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Short Term Disability");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Both the Short Term and Long Term Disability plans are");
                                        }

                                    }

                                    if (fieldName.Contains("Short Term"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Short Term and Long Term Disability coverage");
                                    }
                                    if (fieldName.Contains("Income continued"))
                                    {
                                        myMergeField.Select();
                                        if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits continued");
                                        }
                                    }

                                    if (fieldName.Contains("VoluntarySTD Disability"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Short Term Disability Premium Calculation");
                                        }
                                    }
                                    if (fieldName.Contains("Employee continued"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Employee Payroll Contributions continued");
                                        }
                                    }
                                    if (fieldName.Contains("STD_Table"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.TypeText("");

                                    }

                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteLTDSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlSTDNoOfPlan, DropDownList ddlLTDNoOfPlan, DropDownList ddlVoluntaryLifeADDNoOfPlan)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                string ProductName = "";
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableLTD
                HashtableLTD.Add(2, "181");//General Plan Information – Elimination Period
                HashtableLTD.Add(3, "71");//General Plan Information – Benefit Percentage
                HashtableLTD.Add(4, "374");//General Plan Information – Monthly Benefit Maximum
                HashtableLTD.Add(5, "351");//General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(6, "449");//General Plan Information – Pre-Existing Condition Limitations


                #endregion

                string value = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            //oWordDoc.Tables[7].Cell(8, 2).Range.Text = "Description";
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 2: oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value + " from the day the disability begins"; break;
                                            case 3: oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value + " of your monthly earnings\n\nEarnings includes your basic monthly earnings and commissions in effect prior to your period of disability.\nIt does not include bonuses or overtime pay."; break;
                                        }

                                        if (key > 3)
                                        {
                                            if (key == 5)
                                            {
                                                if (dr["UOM"].ToString() == "text")
                                                {
                                                    dr["UOM"] = "";
                                                }
                                                oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LTD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Plan administered by " + (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()));
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()));
                                        }
                                    }

                                    if (fieldName.Contains("STD_LTDField"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Long Term Disability");
                                        }
                                        //else
                                        //{
                                        //    oWordApp.Selection.TypeText("Both the Short Term and Long Term Disability plans");
                                        //}

                                    }

                                    if (fieldName.Contains("Short Term"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Short Term and Long Term Disability coverage");
                                    }
                                    if (fieldName.Contains("Income continued"))
                                    {
                                        myMergeField.Select();
                                        if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits continued");
                                        }
                                    }
                                    if (fieldName.Contains("VoluntaryLTD Disability"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Long Term Disability Premium Calculation");
                                        }
                                    }

                                    if (fieldName.Contains("Employee continued"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Employee Payroll Contributions continued");
                                        }
                                    }
                                    if (fieldName.Contains("LTD_Table"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.TypeText("");

                                    }

                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteVoluntaryLifeToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, List<int> VoluntaryLife, List<int> VoluntaryADnD)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                int count = 1;
                int PlanCount = 0;


                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string value = "";

                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(2, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(22, "188");//Employee[Overall Maximum]

                HashtableVoluntaryLifeADDBenifit.Add(3, "516");//Spouse[Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(33, "519"); //Spouse[Overall Maximum]

                HashtableVoluntaryLifeADDBenifit.Add(4, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(44, "104");//Child(ren)[Overall Maximum]


                HashtableVoluntaryLifeADDBenifit.Add(55, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(65, "103");//Child(ren)[Guarantee Issue Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(5, "187");//Employee [Guarantee Issue Amount]
                #endregion

                string OverallMaximumEmployee = "";
                string OverallMaximumSpouse = "";
                string OverallMaximumChild = "";
                string voluntaryLifeSpouse = "";
                string voluntaryLifeChildren = "";

                string GuaranteeIssueSpouse = "";
                string GuaranteeIssueChild = "";
                string GuaranteeIssueEmployee = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            if (PlanCount == 0 && ((VoluntaryLife.Count > 0 && VoluntaryLife.Contains(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"].ToString()))) || (VoluntaryLife.Count == 0)))
                            {
                                PlanCount++;
                                #region VoluntaryLifeADDBenifitTable
                                foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {

                                        if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            value = value.Replace("  ", " ");

                                            switch (key)
                                            {
                                                case 2: oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = "Units of " + value + " to a maximum of " + OverallMaximumEmployee; break;
                                                //case 3: oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = "Units of " + value + " to a maximum of " + OverallMaximumSpouse + "\nElection cannot exceed 50% of employee’s coverage amount"; break;
                                                //case 4: oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = "Units of " + value + " to a maximum of " + OverallMaximumChild + "\nThe maximum benefit for children under 6 months of age is $500"; break;
                                                case 3: voluntaryLifeSpouse = "Units of " + value + " to a maximum of " + OverallMaximumSpouse; break;
                                                case 4: voluntaryLifeChildren = "Units of " + value + " to a maximum of " + OverallMaximumChild; break;
                                                //case 5: oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = "Employee -" + value + GuaranteeIssueSpouse + GuaranteeIssueChild; break;
                                                case 5: GuaranteeIssueEmployee = "Employee -" + value; break;
                                                case 22: OverallMaximumEmployee = value; break;
                                                case 33: OverallMaximumSpouse = value; break;
                                                case 44: OverallMaximumChild = value; break;
                                                case 55: GuaranteeIssueSpouse = "\nSpouse - " + value; break;
                                                case 65: GuaranteeIssueChild = "\nChild - " + value; break;
                                            }
                                        }
                                    }
                                }


                                #endregion
                                #region merge fields
                                foreach (Word.Field myMergeField in oWordDoc.Fields)
                                {

                                    iTotalFields++;

                                    Word.Range rngFieldCode = myMergeField.Code;

                                    String fieldText = rngFieldCode.Text;

                                    if (fieldText.StartsWith(" MERGEFIELD"))
                                    {

                                        Int32 endMerge = fieldText.IndexOf("\\");
                                        if (endMerge == -1)
                                        {
                                            endMerge = fieldText.Length;
                                        }

                                        Int32 fieldNameLength = fieldText.Length - endMerge;

                                        String fieldName = fieldText.Substring(11, endMerge - 11);

                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("voluntaryLifeChildren"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(voluntaryLifeChildren);
                                        }
                                        if (fieldName.Contains("voluntaryLifeSpouse"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(voluntaryLifeSpouse);
                                        }
                                        if (fieldName.Contains("GuaranteeIssueAmounts"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(GuaranteeIssueEmployee + GuaranteeIssueSpouse + GuaranteeIssueChild);
                                        }
                                        if (fieldName.Contains("VoluntaryLife"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Voluntary Life insurance for you and your family");
                                        }

                                        if (fieldName.Contains("Voluntary Life Plan Carrierr"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()));
                                        }

                                        if (fieldName.Contains("Income Protection Benefits"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Income Protection Benefits");
                                        }

                                        if (fieldName.Contains("Voluntary Life Plan Name"))
                                        {
                                            myMergeField.Select();
                                            if (VoluntaryLife.Count > 0 && VoluntaryADnD.Count > 0)
                                            {
                                                oWordApp.Selection.TypeText("Voluntary Life and AD&D");
                                            }
                                            else if (VoluntaryLife.Count > 0 && VoluntaryADnD.Count == 0)
                                            {
                                                oWordApp.Selection.TypeText("Voluntary Life");
                                            }
                                            else if (VoluntaryLife.Count == 0 && VoluntaryADnD.Count > 0)
                                            {
                                                oWordApp.Selection.TypeText("Voluntary AD&D");
                                            }
                                        }

                                    }

                                }
                                #endregion
                                count++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteFSASectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, Dictionary<int, List<int>> dictMap)
        {

            try
            {
                int BenefitCoverageTableIndex = 10;

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();

                foreach (object item in FSABenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }

                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    int AttributeRowIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        ////oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount).Range.Text = SummaryName;

                        #region Health Care FSA - Spending Account Maximum

                        DataRow drBenefitValues_SpendingAccountMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 354 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_SpendingAccountMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpendingAccountMaximum);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(AttributeRowIndex, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Dependent Care FSA - Administration Services – Dependent Care

                        DataRow drBenefitValues_DependentCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 150 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_DependentCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_DependentCare);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(AttributeRowIndex + 1, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion
                    }


                    #region merge fields
                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("FSACarrierName"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Carrier);
                            }
                        }
                    }
                    #endregion
                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEAPSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;
                string OldCarrier = "";
                ConstantValue cv = new ConstantValue();
                int count = 1;
                Hashtable HashtableEAP = new Hashtable();
                string number_visit_item = "";
                string carrier = "";
                HashtableEAP.Add(1, "384");

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {

                            /*Added by client requirement --- starts here --- 03 June 2014*/
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(8, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = oWordDoc.Tables[1].Cell(7, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();

                            }
                            /*Added by client requirement --- ends here --- 03 June 2014*/
                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        number_visit_item = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        carrier = PlanTable.Rows[k]["Carrier"].ToString().Trim();
                                    }
                                }

                            }

                        }
                    }
                }

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {

                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();


                        if (fieldName.Contains("Number of Visit Item"))
                        {
                            myMergeField.Select();

                            if (number_visit_item.Trim().Length == 0)
                            {
                                oWordApp.Selection.TypeText(number_visit_item);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(number_visit_item.Trim());
                            }
                        }

                        if (fieldName.Contains("EAP Plan Carrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(carrier);
                        }
                    }

                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteMonthlyPremiumSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int MedicalCount = 0;
                int DentalCount = 0;
                int VisionCount = 0;
                List<string> ContributionDescList = new List<string>();

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");

                DataTable PremiumTable = new DataTable();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("rateTierID", typeof(int));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("contributionDescription", typeof(string));
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("ProductTypeDescription", typeof(string));
                PremiumTable.Columns.Add("SummaryName", typeof(string));
                PremiumTable.Columns.Add("contributionFrequency", typeof(string));

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        #region Build Contribution Table

                        // Medical Plan
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                        {
                            MedicalCount++;

                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                            {
                                if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["ContributionId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                    PremiumTable.Rows[premium_row_counter][1] = GetBenefitFormattedValue_Contribtion(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString());
                                    PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                    PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"] + MedicalCount.ToString();
                                    PremiumTable.Rows[premium_row_counter][4] = PlanTable.Rows[rowindex]["ProductTypeDescription"];
                                    PremiumTable.Rows[premium_row_counter][5] = PlanTable.Rows[rowindex]["SummaryName"];
                                    PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString().Replace("_", " ").Replace("or", "per");
                                    premium_row_counter++;
                                }
                            }
                        }

                        // Dental Plan
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                        {
                            DentalCount++;

                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                            {
                                if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["ContributionId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                    PremiumTable.Rows[premium_row_counter][1] = GetBenefitFormattedValue_Contribtion(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString());
                                    PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                    PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"] + DentalCount.ToString();
                                    PremiumTable.Rows[premium_row_counter][4] = PlanTable.Rows[rowindex]["ProductTypeDescription"];
                                    PremiumTable.Rows[premium_row_counter][5] = PlanTable.Rows[rowindex]["SummaryName"];
                                    PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString().Replace("_", " ").Replace("or", "per");
                                    premium_row_counter++;
                                }
                            }
                        }

                        // Vision Plan
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                        {
                            VisionCount++;

                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                            {
                                if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["ContributionId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                    PremiumTable.Rows[premium_row_counter][1] = GetBenefitFormattedValue_Contribtion(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString());
                                    PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                    PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"] + VisionCount.ToString();
                                    PremiumTable.Rows[premium_row_counter][4] = PlanTable.Rows[rowindex]["ProductTypeDescription"];
                                    PremiumTable.Rows[premium_row_counter][5] = PlanTable.Rows[rowindex]["SummaryName"];
                                    PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString().Replace("_", " ").Replace("or", "per");
                                    premium_row_counter++;
                                }
                            }
                        }

                        #endregion
                    }
                }
                DataTable dt1 = new DataTable();

                PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                dt1 = PremiumTable.DefaultView.ToTable(true);

                // The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                //for (int k = 0; k < dt1.Rows.Count; k++)
                //{
                //    if (Convert.ToDecimal(dt1.Rows[k]["monthlycost"]) == 0)
                //    {
                //        dt1.Rows[k].Delete();
                //        k = k - 1;
                //    }
                //}

                PremiumTable = dt1;

                dt1 = PremiumTable.DefaultView.ToTable(true, "contributionDescription");
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    ContributionDescList.Add(dt1.Rows[i][0].ToString());
                }
                int m = 3;
                for (int i = 0; i < ContributionDescList.Count; i++)
                {
                    oWordDoc.Tables[11].Rows.Add();
                    if (ContributionDescList[i].ToString().Contains("Employee"))
                    {
                        oWordDoc.Tables[11].Cell(m, 1).Range.Text = ContributionDescList[i].ToString() + " Only";
                    }
                    else if (ContributionDescList[i].ToString().Contains("Spouse & Child(ren) (Family)"))
                    {
                        oWordDoc.Tables[11].Cell(m, 1).Range.Text = "Employee + " + ContributionDescList[i].ToString().Replace("Spouse & Child(ren) (Family)", "Spouse & Child(ren)");
                    }
                    else
                    {
                        oWordDoc.Tables[11].Cell(m, 1).Range.Text = "Employee + " + ContributionDescList[i].ToString();
                    }
                    m++;
                }
                string OldRateDesc = "";
                int rowcount = 2;

                for (int i = 0; i < PremiumTable.Rows.Count; i++)
                {
                    if (OldRateDesc != PremiumTable.Rows[i]["contributionDescription"].ToString())
                    {
                        rowcount++;
                        OldRateDesc = PremiumTable.Rows[i]["contributionDescription"].ToString();
                    }

                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.MedicalLOC + "1")
                    {
                        oWordDoc.Tables[11].Cell(2, 2).Range.Text = PremiumTable.Rows[i]["SummaryName"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();

                        oWordDoc.Tables[11].Cell(rowcount, 2).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.MedicalLOC + "2")
                    {
                        oWordDoc.Tables[11].Cell(2, 3).Range.Text = PremiumTable.Rows[i]["SummaryName"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();
                        oWordDoc.Tables[11].Cell(rowcount, 3).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.MedicalLOC + "3")
                    {
                        oWordDoc.Tables[11].Cell(2, 4).Range.Text = PremiumTable.Rows[i]["SummaryName"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();
                        oWordDoc.Tables[11].Cell(rowcount, 4).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.DentalLOC + "1")
                    {
                        oWordDoc.Tables[11].Cell(2, 5).Range.Text = PremiumTable.Rows[i]["SummaryName"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();
                        oWordDoc.Tables[11].Cell(rowcount, 5).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.DentalLOC + "2")
                    {
                        oWordDoc.Tables[11].Cell(2, 6).Range.Text = PremiumTable.Rows[i]["SummaryName"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();
                        oWordDoc.Tables[11].Cell(rowcount, 6).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.VisionLOC + "1")
                    {
                        oWordDoc.Tables[11].Cell(2, 7).Range.Text = PremiumTable.Rows[i]["SummaryName"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();
                        oWordDoc.Tables[11].Cell(rowcount, 7).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.VisionLOC + "2")
                    {
                        oWordDoc.Tables[11].Cell(2, 8).Range.Text = PremiumTable.Rows[i]["SummaryName"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();
                        oWordDoc.Tables[11].Cell(rowcount, 8).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                }
                oWordDoc.Tables[11].Rows.Last.Delete();
                int cloumnCount = oWordDoc.Tables[11].Columns.Count;
                float colWidth = 5.86f / (MedicalCount + DentalCount + VisionCount);

                for (int i = 2; i <= cloumnCount; i++)
                {
                    if (oWordDoc.Tables[11].Cell(2, i).Range.Text.Trim() == "\a")
                    {
                        oWordDoc.Tables[11].Columns[i].Delete();
                        i--;
                        cloumnCount--;
                    }
                    else
                    {
                        oWordDoc.Tables[11].Columns[i].Width = oWordApp.InchesToPoints(colWidth);
                    }
                }

                List<int> planCount = new List<int>();
                int headCol = 2;
                if (MedicalCount > 0)
                {
                    planCount.Add(MedicalCount);
                }
                if (DentalCount > 0)
                {
                    planCount.Add(DentalCount);
                }
                if (VisionCount > 0)
                {
                    planCount.Add(VisionCount);
                }

                for (int i = 0; i < planCount.Count; i++)
                {
                    if (planCount[i] > 1)
                    {
                        oWordDoc.Tables[11].Cell(1, headCol).Merge(oWordDoc.Tables[11].Cell(1, headCol + planCount[i] - 1));
                    }
                    headCol++;
                }

                #region merge fields
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {

                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();


                        if (fieldName.Contains("Employee Payroll Contributions"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Employee Payroll Contributions");
                        }

                        if (PremiumTable.Rows.Count > 0)
                        {
                            if (fieldName.Contains("RateTable"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }

                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteVoluntaryLifeMonthlyPremiumSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, List<int> VoluntaryLife, List<int> VoluntaryADnD)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();
                int PlanCount = 0;
                //List<string> RateDescList = new List<string>();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanCount == 0 && ((VoluntaryLife.Count > 0 && VoluntaryLife.Contains(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"].ToString()))) || (VoluntaryLife.Count == 0)))
                        {
                            PlanCount++;
                            int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                            int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                            int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                            for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                            {
                                if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                                {
                                    if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                    {
                                        PremiumTable.Rows.Add();
                                        PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                        PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                        PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                        PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                        PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                        PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                        PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                        premium_row_counter++;
                                    }
                                }
                            }

                            oWordDoc.Tables[13].Cell(3, 1).Range.Text = "Under " + Start.ToString();
                            int StartValue = Start;
                            int RowCount = 4;
                            while (StartValue < End - 1)
                            {
                                oWordDoc.Tables[13].Rows.Add();
                                if (StartValue == Start)
                                {
                                    oWordDoc.Tables[13].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                    StartValue = Start + Interval;
                                }
                                else
                                {
                                    oWordDoc.Tables[13].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                    StartValue = StartValue + Interval + 1;
                                }
                                RowCount++;
                            }
                            oWordDoc.Tables[13].Rows.Add();
                            oWordDoc.Tables[13].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                            oWordDoc.Tables[13].Rows.Add();
                            oWordDoc.Tables[13].Cell(RowCount + 1, 1).Range.Text = "Composite";

                            string dependent_child_life = string.Empty;

                            int ColumnCount = 0;
                            int oldageBand = -1;
                            DataTable dt = new DataTable();

                            PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                            dt = PremiumTable.DefaultView.ToTable(true);
                            PremiumTable = dt;
                            RowCount = 3;
                            int RowCount1 = 3;
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                // for (int j = 0; j < RateDescList.Count; j++)
                                //{
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                    oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                                    oWordDoc.Tables[13].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse UniSmoker")
                                {
                                    ColumnCount = 3;
                                    oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                                    oWordDoc.Tables[13].Cell(RowCount1, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount1++;
                                }
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Dependent Child Life")
                                {
                                    ColumnCount = 2;
                                    dependent_child_life = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    //RowCount1++;
                                }
                                //if (int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString()) != oldageBand)
                                //{
                                //    RowCount++;
                                //}
                                ////oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());
                                //oWordDoc.Tables[8].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                // }
                            }

                            if (!string.IsNullOrEmpty(dependent_child_life))
                            {
                                oWordDoc.Tables[13].Rows.Add();
                                oWordDoc.Tables[13].Cell(RowCount + 2, 1).Range.Text = "Per $1,000 Child Life";
                                oWordDoc.Tables[13].Cell(RowCount + 2, 2).Merge(oWordDoc.Tables[13].Cell(RowCount + 2, 3));
                                oWordDoc.Tables[13].Cell(RowCount + 2, 2).Range.Text = dependent_child_life;

                            }

                            oWordDoc.Tables[13].PreferredWidth = oWordApp.InchesToPoints(7.5f);
                        }
                    }
                }

                #region MergeField
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Voluntary Rates Plan Name"))
                        {
                            myMergeField.Select();

                            if (VoluntaryLife.Count > 0)
                            {
                                oWordApp.Selection.TypeText("Voluntary Life");
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("Voluntary AD&D");
                            }
                        }

                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteVoluntarySTDandLTDMonthlyPremiumSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();

                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                int Start = 0;
                int End = 0;
                int Interval = 0;

                int ColumnCount = 0;
                int oldageBand = -1;
                int PlanCount = 0;
                DataTable dt = new DataTable();
                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType_CommonCriteria.ToLower() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        PlanCount++;
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"] != null)
                        {
                            Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"] != null)
                        {
                            End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"] != null)
                        {
                            Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;
                        }
                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {

                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }
                        int StartValue = Start;
                        int RowCount = 5;

                        if ((Start > 0 && PlanCount == 1) || (Start > 0 && PlanCount == 2 && oWordDoc.Tables[14].Rows.Count <= 5))
                        {
                            oWordDoc.Tables[14].Cell(4, 1).Range.Text = "Under " + Start.ToString();

                            while (StartValue < End - 1)
                            {
                                oWordDoc.Tables[14].Rows.Add();
                                if (StartValue == Start)
                                {
                                    oWordDoc.Tables[14].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                    StartValue = Start + Interval;
                                }
                                else
                                {
                                    oWordDoc.Tables[14].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                    StartValue = StartValue + Interval + 1;
                                }
                                RowCount++;
                            }
                            oWordDoc.Tables[14].Rows.Add();
                            oWordDoc.Tables[14].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                            oWordDoc.Tables[14].Rows.Add();
                            oWordDoc.Tables[14].Cell(RowCount + 1, 1).Range.Text = "Composite";
                        }


                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 2;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.STDPlanType_CommonCriteria)
                            {
                                ColumnCount = 2;
                            }

                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.LTDPlanType_CommonCriteria)
                            {
                                ColumnCount = 3;
                            }
                            if (int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString()) != oldageBand)
                            {
                                RowCount++;
                            }
                            oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                            oWordDoc.Tables[14].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                        }
                    }
                }

                ColumnCount = oWordDoc.Tables[14].Columns.Count;

                //bool flag = false;
                //if (oWordDoc.Tables[14].Rows.Count < 5)
                //{
                //    DeleteIndivialBookmark(oWordDoc, "STDLTDRatesTable");     
                //}
                //else
                //{
                //    while (ColumnCount > 1)
                //    {
                //        for (int i = 4; i < oWordDoc.Tables[14].Rows.Count; i++)
                //        {
                //            if (oWordDoc.Tables[14].Cell(i, ColumnCount).Range.Text.Trim() != "\a")
                //            {
                //                flag = false;
                //                break;
                //            }
                //            else
                //            {
                //                flag = true;
                //            }
                //        }
                //        if (flag == true)
                //        {
                //            oWordDoc.Tables[14].Columns[ColumnCount].Delete();

                //        }
                //        ColumnCount--;
                //    }
                //}




            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteContactInformationToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable)
        {
            DataTable uniquePlanCarrier = PlanTable.DefaultView.ToTable(true, "Carrier", "PlanType");
            int medicalCount = 0;
            int dentalCount = 0;
            int visionCount = 0;
            int lifeCount = 0;
            int LTDCount = 0;
            int STDCount = 0;
            Dictionary<string, string> DictPlanCarriers = new Dictionary<string, string>();

            foreach (DataRow dr in uniquePlanCarrier.Rows)
            {
                switch (dr["PlanType"].ToString())
                {

                    case "Medical":
                        medicalCount++;
                        DictPlanCarriers.Add("MedicalPlan" + medicalCount, dr["Carrier"].ToString());
                        break;
                    case "Dental":
                        dentalCount++;
                        DictPlanCarriers.Add("DentalPlan" + dentalCount, dr["Carrier"].ToString());
                        break;
                    case "Vision":
                        visionCount++;
                        DictPlanCarriers.Add("VisionPlan" + visionCount, dr["Carrier"].ToString());
                        break;
                    case "Life and AD&D":
                        lifeCount++;
                        DictPlanCarriers.Add("LifePlan" + lifeCount, dr["Carrier"].ToString());
                        break;
                    case "LTD":
                        LTDCount++;
                        DictPlanCarriers.Add("LTDPlan" + LTDCount, dr["Carrier"].ToString());
                        break;
                    case "STD":
                        STDCount++;
                        DictPlanCarriers.Add("STDPlan" + STDCount, dr["Carrier"].ToString());
                        break;
                }

            }

            #region MergeField
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (DictPlanCarriers.ContainsKey(fieldName))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(DictPlanCarriers[fieldName]);
                    }
                }
            }
            #endregion

            if (medicalCount == 1)
            {
                DeleteIndivialBookmark(oWordDoc, "MedicalPlan2");
                DeleteIndivialBookmark(oWordDoc, "MedicalPlan3");
            }
            else if (medicalCount == 2)
            {
                DeleteIndivialBookmark(oWordDoc, "MedicalPlan3");
            }

            if (dentalCount == 0)
            {
                DeleteIndivialBookmark(oWordDoc, "DentalPlan1");
                DeleteIndivialBookmark(oWordDoc, "DentalPlan2");
            }
            else if (dentalCount == 1)
            {
                DeleteIndivialBookmark(oWordDoc, "DentalPlan2");
            }

            if (visionCount == 0)
            {
                DeleteIndivialBookmark(oWordDoc, "VisionPlan1");
            }

            if (lifeCount == 0)
            {
                DeleteIndivialBookmark(oWordDoc, "LifePlan1");
            }

            if (STDCount == 0)
            {
                DeleteIndivialBookmark(oWordDoc, "STDPlan1");
            }

            if (LTDCount == 0)
            {
                DeleteIndivialBookmark(oWordDoc, "LTDPlan1");
            }

            if (STDCount == 1 && LTDCount == 1)
            {
                if (DictPlanCarriers.ContainsKey("LTDPlan1") && DictPlanCarriers.ContainsKey("STDPlan1"))
                {
                    if (DictPlanCarriers["LTDPlan1"].ToString().Trim() == DictPlanCarriers["STDPlan1"].ToString().Trim())
                    {
                        DeleteIndivialBookmark(oWordDoc, "LifePlan1");
                    }
                }
            }

        }

        public void WriteNoticeSectionToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                /********************HERE WE DELETE THE LEGAL NOTICE SECTION IF NOT SELECTED ...**/
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "AnnualAndChipNotices");
                }

                if (ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "LegalNoticeSectionBayView");
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        String fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();



                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish_FAQv2.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);


                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included")
                                {

                                }
                                else
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                /******************* Call common function to write the contact information page fields ****************************/
                //Added By Vaibhav -- Calling by Mr.Amogh 
                selectedcolor = "Gray";
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor);




            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void getBookmarks()
        {
            AllBookmarks.Clear();
            /* =======================================================================================
             *Section         -> BookMark :-                             'VoluntaryADD'
             *Section         -> Header desc in 1st page (if exists):-   'VoluntaryADDMain'
             *Sub-Section     -> general Description:-                   'VoluntaryADDDescription'
             *Sub-Section     -> Single Plan Description: -              'VoluntaryADDSingleDescription'
             *Sub-Section     -> Multiple Plan Description :-            'VoluntaryADDMultipleDescription'
             *Sub-Section     -> Plan Tables :-                          'VoluntaryADDPlanTables'
             ============================================================================================*/

            #region Medical Bookmarks


            Dictionary<string, string> medicalBookmarks = new Dictionary<string, string>();
            #endregion

            #region Dental Bookmarks
            Dictionary<string, string> dentalBookmarks = new Dictionary<string, string>();


            #endregion

            #region Vision Bookmarks
            Dictionary<string, string> visionBookmarks = new Dictionary<string, string>();

            #endregion

            #region HSA Bookmarks
            Dictionary<string, string> HSABookmarks = new Dictionary<string, string>();
            // HSABookmarks.Add("HSADescription1", "HSADescription1");
            // visionBookmarks.Add("Vision_Description2", "Vision_Description2");
            #endregion

            #region HRA Bookmarks
            Dictionary<string, string> HRABookmarks = new Dictionary<string, string>();
            //HRABookmarks.Add("HRADescription1", "HRADescription1");
            #endregion

            #region FSA Bookmarks
            Dictionary<string, string> FSABookmarks = new Dictionary<string, string>();
            //FSABookmarks.Add("FSADescription1", "FSADescription1");
            #endregion

            #region Life and AD&D Bookmarks
            Dictionary<string, string> ADDBookmarks = new Dictionary<string, string>();
            ADDBookmarks.Add("ADDADnD", "ADDADnD");

            ADDBookmarks.Add("LifeADnD", "LifeADnD");

            ADDBookmarks.Add("GroupLife", "GroupLife");
            #endregion

            #region Voluntary Life and AD&D Bookmarks
            Dictionary<string, string> VolLifeADDBookmarks = new Dictionary<string, string>();

            #endregion

            #region STD Bookmarks
            Dictionary<string, string> STDBookmarks = new Dictionary<string, string>();
            //STDBookmarks.Add("STDDescription", "STDDescription");
            #endregion

            #region LTD Bookmarks
            Dictionary<string, string> LTDBookmarks = new Dictionary<string, string>();
            //LTDBookmarks.Add("LTDPlan1", "LTDPlan1");
            #endregion

            #region EAP Bookmarks
            Dictionary<string, string> EAPBookmarks = new Dictionary<string, string>();
            //EAPBookmarks.Add("EAPDescription", "EAPDescription");
            #endregion

            AllBookmarks.Add("Medical", medicalBookmarks);
            AllBookmarks.Add("Dental", dentalBookmarks);
            AllBookmarks.Add("Vision", visionBookmarks);
            AllBookmarks.Add("HSA", HRABookmarks);
            AllBookmarks.Add("HRA", HRABookmarks);
            AllBookmarks.Add("FSA", FSABookmarks);
            //AllBookmarks.Add("STD", STDBookmarks);
            AllBookmarks.Add("Voluntary Life", VolLifeADDBookmarks);
            AllBookmarks.Add("Life and AD&D", ADDBookmarks);
            //AllBookmarks.Add("LTD", LTDBookmarks);
            AllBookmarks.Add("EAP", EAPBookmarks);


        }

        // Deletes Bookmarks which presents in "AllBookmarks" Dictonary
        public void DeleteBookmarks(Word.Document oWordDoc, Word.Application oWordApp, Dictionary<string, Dictionary<int, List<int>>> dictProductMap, DataTable PlanInfoTable, bool isBRCSelected, List<int> STD, List<int> LTD, List<int> VoluntarySTD, List<int> VoluntaryLTD)
        {
            string formattedPlanType = string.Empty;   //to format special characters and spaces -- which are not detected in bookmarks                                                                                                                                                             
            string mainDesc = string.Empty;            //Main descrption on 1st page

            #region Delete non-selected plans and sub-sections including Header on 1st Page
            foreach (string plantype in AllBookmarks.Keys)
            {

                if (!dictProductMap.ContainsKey(plantype))
                {
                    formattedPlanType = plantype.Replace("&", "").Replace(" ", "");

                    mainDesc = formattedPlanType + "Main";        //If Plan not selected

                    if (oWordDoc.Bookmarks.Exists(mainDesc))    // Delete Main Description on 1st page
                    {
                        oWordDoc.Bookmarks[mainDesc].Range.Delete();
                    }

                    if (oWordDoc.Bookmarks.Exists(formattedPlanType))     // Delete Enitre Section
                    {
                        oWordDoc.Bookmarks[formattedPlanType].Range.Delete();
                    }
                    //DeleteIndivialBookmark(oWordDoc, mainDesc);              UnComment if bookmark not deleted
                    // DeleteIndivialBookmark(oWordDoc, formattedPlanType);

                }
                else
                {                                                                     //If PlanType is selected
                    if (AllBookmarks[plantype] != null)
                    {
                        foreach (string bookmark in AllBookmarks[plantype].Keys)     // Loop through inner bookmarks and delete unwanted sub-sections
                        {
                            formattedPlanType = bookmark.Replace("&", "").Replace(" ", "");

                            if (oWordDoc.Bookmarks.Exists(formattedPlanType))
                            {
                                oWordDoc.Bookmarks[bookmark].Range.Delete();
                            }
                            DeleteIndivialBookmark(oWordDoc, formattedPlanType);
                        }
                    }
                }
            }
            #endregion

            #region Delete Product sections

            bool is_Patient_Advocacy_Selected = false;
            bool is_Consumer_Driven_Telemedicine_Selected = false;
            bool is_Accident_Selected = false;
            bool is_CriticalIllness_Selected = false;
            bool is_Wellness_Selected = false;


            if (PlanInfoTable != null)
            {
                for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                {
                    if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                    {
                        is_Patient_Advocacy_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                    {
                        is_Consumer_Driven_Telemedicine_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                    {
                        is_Accident_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                    {
                        is_CriticalIllness_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Wellness)
                    {
                        is_Wellness_Selected = true;
                    }
                }
            }


            if (is_Patient_Advocacy_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("PatientAdvocacyProgram"))
                {
                    oWordDoc.Bookmarks["PatientAdvocacyProgram"].Range.Delete();
                }
            }
            if (is_Consumer_Driven_Telemedicine_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("Telemedicine"))
                {
                    oWordDoc.Bookmarks["Telemedicine"].Range.Delete();
                }
            }
            if (is_Wellness_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("Welness"))
                {
                    oWordDoc.Bookmarks["Welness"].Range.Delete();
                }
            }
            #region Worksite
            if (is_Accident_Selected == false && is_CriticalIllness_Selected == false)  // when both selected Delete "Worksite" section
            {
                if (oWordDoc.Bookmarks.Exists("Worksite"))
                {
                    oWordDoc.Bookmarks["Worksite"].Range.Delete();
                }
            }
            else if (is_Accident_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("Accident"))
                {
                    oWordDoc.Bookmarks["Accident"].Range.Delete();
                }
            }
            else if (is_CriticalIllness_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("CriticalIllness"))
                {
                    oWordDoc.Bookmarks["CriticalIllness"].Range.Delete();
                }
            }
            #endregion

            #endregion

            #region STD and LTD with rates section

            if (!dictProductMap.ContainsKey("Life and AD&D") && !dictProductMap.ContainsKey("STD") && !dictProductMap.ContainsKey("LTD"))
            {
                DeleteIndivialBookmark(oWordDoc, "IncomeProtectionBenefits");
            }
            else
            {
                if (STD.Count == 0 && LTD.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "STDorLTD");
                }

                if (STD.Count > 0 && LTD.Count > 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "STDorLTDDesc");
                }
                else if (STD.Count > 0 || LTD.Count > 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "BothSTDLTDDesc");
                }

                if (STD.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "STDtable");
                }

                if (LTD.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "LTDtable");
                }
            }

            if (VoluntaryLTD.Count == 0 && VoluntarySTD.Count == 0)
            {
                DeleteIndivialBookmark(oWordDoc, "VoluntaryDisability");
            }
            else
            {
                Word.Table table = null;
                if (oWordDoc.Bookmarks.Exists("VoluntaryDisability"))
                {
                    if (oWordDoc.Bookmarks["VoluntaryDisability"].Range.Tables.Count > 0)
                    {
                        table = oWordDoc.Bookmarks["VoluntaryDisability"].Range.Tables[1];
                    }
                }

                if (VoluntaryLTD.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "VolLTDRatesDesc");
                    table.Columns[3].Delete();
                }

                if (VoluntarySTD.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "VolSTDRatesDesc");
                    table.Columns[2].Delete();
                }

                if (table.Columns.Count > 1)
                {
                    table.Cell(1, 1).Merge(table.Cell(1, table.Columns.Count));
                }
                table.PreferredWidth = oWordApp.InchesToPoints(7.56f);
            }


            #endregion

            #region Delete bookmark - Voluntary Life rates section
            if (!dictProductMap.ContainsKey("Voluntary Life"))
            {
                DeleteIndivialBookmark(oWordDoc, "VoluntaryLifeRatesTable");
            }

            #endregion

            #region
            if (oWordDoc.Bookmarks.Exists("ContributionTable2"))
            {
                if (oWordDoc.Bookmarks["ContributionTable2"].Range.Tables.Count > 0)
                {
                    if (oWordDoc.Bookmarks["ContributionTable2"].Range.Tables[1].Columns.Count == 1)
                    {
                        DeleteIndivialBookmark(oWordDoc, "ContributionTable2");
                    }
                }
            }
            #endregion

            #region Delete BRC Section
            if (isBRCSelected == false)
            {
                if (oWordDoc.Bookmarks.Exists("BRC"))
                {
                    oWordDoc.Bookmarks["BRC"].Range.Delete();
                }
            }
            #endregion


            if (oWordDoc.TablesOfContents.Count > 0)
            {
                oWordDoc.TablesOfContents[1].Update();
            }

        }

        // Call if bookmark which are not present in "AllBookmarks"
        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }

        public bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }

        public void DeleteRemainingFields(Word.Document oWordDoc)
        {
            int countFields = oWordDoc.Fields.Count;
            for (int i = 1; i <= countFields; i++)
            {
                Word.Range rngFieldCode = oWordDoc.Fields[i].Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    oWordDoc.Fields[i].Delete();
                    i--;
                    countFields--;
                }
            }
        }

        public void DeleteEmptyRows(Word.Document oWordDoc, Dictionary<string, Dictionary<int, List<int>>> dictProductMap)
        {

            if (dictProductMap.ContainsKey("STD"))
            {
                int stdRowCount = oWordDoc.Tables[5].Rows.Count;
                for (int i = 2; i <= stdRowCount; i++)
                {
                    if (oWordDoc.Tables[5].Cell(i, 2).Range.Text == "\r\a")
                    {
                        oWordDoc.Tables[5].Rows[i].Delete();
                        i--;
                        stdRowCount--;
                    }
                }
            }

            if (dictProductMap.ContainsKey("LTD"))
            {
                int ltdRowCount = oWordDoc.Tables[5].Rows.Count;
                for (int i = 2; i <= ltdRowCount; i++)
                {
                    if (oWordDoc.Tables[6].Cell(i, 2).Range.Text == "\r\a")
                    {
                        oWordDoc.Tables[6].Rows[i].Delete();
                        i--;
                        ltdRowCount--;
                    }
                }
            }

            if (dictProductMap.ContainsKey("Medical"))
            {
                int medRowCount = oWordDoc.Tables[1].Rows.Count;
                int medColCount = oWordDoc.Tables[1].Columns.Count;
                bool isFilled = false;

                for (int i = 2; i <= medRowCount; i++)
                {
                    isFilled = false;

                    for (int j = 2; j <= medColCount; j++)
                    {
                        if (oWordDoc.Tables[1].Cell(i, j).Range.Text != "\r\a")
                        {
                            isFilled = true;
                        }
                    }

                    if (isFilled == false)
                    {
                        oWordDoc.Tables[1].Rows[i].Delete();
                        i--;
                        medRowCount--;
                    }
                }
            }

        }

        public string GetBenefitFormattedValue_Contribtion(string value)
        {

            if (!string.IsNullOrEmpty(value))
            {
                if (IsNumeric(Convert.ToString(value)))
                {
                    if (value.Contains('.'))
                    {
                        value = string.Format("{0:#,0.00}", double.Parse(value));
                    }
                    else
                    {
                        value = string.Format("{0:#,0.##}", int.Parse(value));
                    }
                }
            }
            return value;
        }

        private static bool IsNumeric(string inputValue)
        {
            double Result;
            return double.TryParse(inputValue, out Result);  // TryParse routines were added in Framework version 2.0.
        }

        public void WriteContribution(Word.Document oWordDoc, Word.Application oWordApp, Dictionary<int, List<int>> dictContributionMap, DataSet ContributionDS, DataTable PlanTable)
        {

            int ContributionValuescount = ContributionDS.Tables["ContributionValueTable"].Rows.Count;
            for (int i = 0; i < ContributionValuescount; i++)
            {
                double PremiumPercentageValue = 0;
                double SalaryPercentageValue = 0;
                double.TryParse(ContributionDS.Tables["ContributionValueTable"].Rows[i]["contributionValues_percentOfPremium"].ToString(), out PremiumPercentageValue);
                double.TryParse(ContributionDS.Tables["ContributionValueTable"].Rows[i]["contributionValues_percentOfSalary"].ToString(), out SalaryPercentageValue);
                if (PremiumPercentageValue > 0 || SalaryPercentageValue > 0)
                {
                    ContributionDS.Tables["ContributionValueTable"].Rows[i].Delete();
                    ContributionValuescount--;
                    i--;
                }
            }

            int tableIndex = 11;
            DataTable PremiumTable = new DataTable();
            List<string> ContributionDescList = new List<string>();
            Dictionary<string, string> DictPlanType = new Dictionary<string, string>();
            int premium_row_counter = 0;
            PremiumTable.Columns.Add("rateTierID", typeof(int));
            PremiumTable.Columns.Add("monthlycost", typeof(string));
            PremiumTable.Columns.Add("Description", typeof(string));              // Contribution Description
            PremiumTable.Columns.Add("contributionDescription", typeof(string));  // Contribution type
            PremiumTable.Columns.Add("Plan", typeof(string));
            PremiumTable.Columns.Add("contributionFrequency", typeof(string));
            PremiumTable.Columns.Add("PlanType", typeof(string));

            foreach (DataRow dr in PlanTable.Rows)
            {
                if (!DictPlanType.ContainsKey(dr["ContributionId"].ToString().Trim()) && dr["ContributionId"].ToString().Trim() != "-1")
                {
                    DictPlanType.Add(dr["ContributionId"].ToString().Trim(), dr["ProductTypeDescription"].ToString().Trim());
                }
                if (!DictPlanType.ContainsKey(dr["ContributionId_2"].ToString().Trim()) && dr["ContributionId_2"].ToString().Trim() != "-1")
                {
                    DictPlanType.Add(dr["ContributionId_2"].ToString().Trim(), dr["ProductTypeDescription"].ToString().Trim());
                }
            }

            foreach (int key in dictContributionMap.Keys)
            {
                foreach (int ContributionID in dictContributionMap[key])
                {
                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == ContributionID)
                        {
                            PremiumTable.Rows.Add();
                            PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                            PremiumTable.Rows[premium_row_counter][1] = GetBenefitFormattedValue_Contribtion(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString());
                            PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                            PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                            PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                            PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString().Replace("_", " ").Replace("or", "per");
                            PremiumTable.Rows[premium_row_counter][6] = DictPlanType[ContributionID.ToString()];
                            premium_row_counter++;
                        }
                    }
                }
            }

            DataTable dt1 = new DataTable();
            dt1 = PremiumTable.DefaultView.ToTable(true, "contributionDescription");
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                ContributionDescList.Add(dt1.Rows[i][0].ToString());
            }
            int m = 3;
            for (int i = 0; i < ContributionDescList.Count; i++)
            {
                if (i != 0)
                {
                    oWordDoc.Tables[11].Rows.Add();
                }
                if (ContributionDescList[i].ToString().Contains("Employee"))
                {
                    oWordDoc.Tables[11].Cell(m, 1).Range.Text = ContributionDescList[i].ToString() + " Only";
                }
                else if (ContributionDescList[i].ToString().Contains("Spouse & Child(ren) (Family)"))
                {
                    oWordDoc.Tables[11].Cell(m, 1).Range.Text = "Employee + " + ContributionDescList[i].ToString().Replace("Spouse & Child(ren) (Family)", "Spouse & Child(ren)");
                }
                else
                {
                    oWordDoc.Tables[11].Cell(m, 1).Range.Text = "Employee + " + ContributionDescList[i].ToString();
                }
                m++;
            }

            int rowcount = 3;
            int cloumncount = 1;
            string OldDesc = "";
            if (PremiumTable.Rows.Count > 0)
            {
                OldDesc = PremiumTable.Rows[0]["Description"].ToString();
                oWordDoc.Tables[11].Columns.Add();
                cloumncount++;
                oWordDoc.Tables[11].Cell(2, 2).Range.Text = PremiumTable.Rows[0]["PlanType"].ToString() + "\n" + PremiumTable.Rows[0]["Description"].ToString() + "\n" + PremiumTable.Rows[0]["contributionFrequency"].ToString();
            }
            for (int i = 0; i < PremiumTable.Rows.Count; i++)
            {
                if (OldDesc != PremiumTable.Rows[i]["Description"].ToString())
                {
                    OldDesc = PremiumTable.Rows[i]["Description"].ToString();
                    if (cloumncount == 6)
                    {
                        tableIndex++;
                        cloumncount = 1;
                        Dictionary<string, string> ConType = new Dictionary<string, string>();
                        for (int k = i; k < PremiumTable.Rows.Count; k++)
                        {
                            if (!ConType.ContainsKey(PremiumTable.Rows[k]["contributionDescription"].ToString()) && PremiumTable.Rows[k]["contributionDescription"].ToString().Trim() != "")
                            {
                                ConType.Add(PremiumTable.Rows[k]["contributionDescription"].ToString(), PremiumTable.Rows[k]["contributionDescription"].ToString());
                            }
                        }
                        m = 3;
                        for (int l = 0; l < ConType.Keys.Count; l++)
                        {
                            if (l != 0)
                            {
                                oWordDoc.Tables[tableIndex].Rows.Add();
                            }
                            if (ConType.ElementAt(l).Value.Contains("Employee"))
                            {
                                oWordDoc.Tables[tableIndex].Cell(m, 1).Range.Text = ConType.ElementAt(l).Value + " Only";
                            }
                            else if (ConType.ElementAt(l).Value.Contains("Spouse & Child(ren) (Family)"))
                            {
                                oWordDoc.Tables[tableIndex].Cell(m, 1).Range.Text = "Employee + " + ConType.ElementAt(l).Value.Replace("Spouse & Child(ren) (Family)", "Spouse & Child(ren)");
                            }
                            else
                            {
                                oWordDoc.Tables[tableIndex].Cell(m, 1).Range.Text = "Employee + " + ConType.ElementAt(l).Value;
                            }
                            m++;
                        }

                    }
                    oWordDoc.Tables[tableIndex].Columns.Add();
                    rowcount = 3;
                    cloumncount++;
                    oWordDoc.Tables[tableIndex].Cell(2, cloumncount).Range.Text = PremiumTable.Rows[i]["PlanType"].ToString() + "\n" + PremiumTable.Rows[i]["Description"].ToString() + "\n" + PremiumTable.Rows[i]["contributionFrequency"].ToString();
                }
                oWordDoc.Tables[tableIndex].Cell(rowcount, cloumncount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                rowcount++;


            }

            if (oWordDoc.Tables[11].Columns.Count > 1)
            {
                float Width = (7.55f - 1.69f) / (float)(oWordDoc.Tables[11].Columns.Count - 1);
                for (int i = 2; i <= oWordDoc.Tables[11].Columns.Count; i++)
                {
                    if (i == 2)
                    {
                        oWordDoc.Tables[11].Columns[1].Width = oWordApp.InchesToPoints(1.69f);
                    }
                    oWordDoc.Tables[11].Columns[i].Width = oWordApp.InchesToPoints(Width);

                }
            }
            if (oWordDoc.Tables[12].Columns.Count > 1)
            {
                float Width = (7.55f - 1.69f) / (float)(oWordDoc.Tables[12].Columns.Count - 1);
                for (int i = 2; i <= oWordDoc.Tables[12].Columns.Count; i++)
                {
                    if (i == 2)
                    {
                        oWordDoc.Tables[12].Columns[1].Width = oWordApp.InchesToPoints(1.69f);
                    }
                    oWordDoc.Tables[12].Columns[i].Width = oWordApp.InchesToPoints(Width);

                }
            }

        }

        public void WriteEligibilityToFAQv2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                    //{
                    //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                    //}
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Employee Status"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Working"))
                    {
                        myMergeField.Select();
                        if (Working != string.Empty)
                            oWordApp.Selection.TypeText(Working);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Unit to Measure"))
                    {
                        myMergeField.Select();
                        if (UOM != string.Empty)
                            oWordApp.Selection.TypeText(UOM);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Frequency"))
                    {
                        myMergeField.Select();
                        if (Frequency != string.Empty)
                            oWordApp.Selection.TypeText(Frequency);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unmarriedchildtoage"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Medical Plan Waiting Period"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period);
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }
    }
}