﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;

namespace BenefitPointSummaryPortal.BAL.RFPReports
{
    public class WriteAncillaryIntakeFormRFP
    {
        #region Ancillary Template
        public void WritePlanTo_AncillaryIntakeForm(Excel.Application myExcelApp, string SheetNames, DataTable PlanTable, int AdditionalLOCCount, int MaxAdditionalLOCRowCount)
        {
            List<string> lstLOC = new List<string>();
            foreach (DataRow dr in PlanTable.Rows)
            {
                string planType = dr["LOCName"].ToString();
                lstLOC.Add(planType);
                switch (planType)
                {
                    case "Dental":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Dental", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, true);
                        break;
                    case "Vision":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Vision", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, true);
                        break;
                    case "Life / AD&D":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Life / AD&D", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                    case "Voluntary Life / AD&D":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Voluntary Life / AD&D", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), false, false);
                        break;
                    case "Short Term Disability":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Short Term Disability", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, true);
                        break;
                    case "Voluntary STD":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Voluntary STD", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), false, true);
                        break;
                    case "Long Term Disability":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Long Term Disability", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                    case "Voluntary LTD":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Voluntary LTD", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), false, false);
                        break;
                    case "Absence Management":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Absence Management", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                    case "EAP Administration":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "EAP Administration", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                    case "Cancer":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Cancer", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                    case "Hospital":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Hospital", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                    case "Critical Illness":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Critical Illness", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                    case "Accident":
                        WriteLOCInfo_AncillaryIntakeForm(myExcelApp, SheetNames, "Accident", dr["SelectedPlan"].ToString(), dr["CarrierName"].ToString(), dr["Contribution"].ToString(), dr["FundingType"].ToString(), dr["BidSpecifications"].ToString(), true, false);
                        break;
                }
            }
            AddDeleteAdditionalLOC(myExcelApp, AdditionalLOCCount, MaxAdditionalLOCRowCount, lstLOC);
        }
        private void WriteLOCInfo_AncillaryIntakeForm(Excel.Application myExcelApp, string SheetNames, string LocName, string PlaneDesignName, string CarrierName, string Contributions, string FundingType, string BidSpecifications, bool WriteContribution, bool WriteFundingType)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            int Carrier_ColumnNumber = 4;
            int Plan_Design_ColumnNumber = 11;
            int Contributions_ColumnNumber = 7;
            int FundingType_ColumnNumber = 8;
            int BidSpecifications_ColumnNumber = 5;

            Excel.Range range;

            int RowCount;
            int ColumnCount;

            range = wkSheet.UsedRange;
            RowCount = range.Rows.Count;
            ColumnCount = range.Columns.Count;

            int LOCNo = 0;

            for (int i = 52; i <= 81; i++)
            {
                string colVal = (string)(range.Cells[i, 3] as Excel.Range).Value2;
                if (colVal != null && colVal.Trim() == LocName)
                {
                    Excel.Range Range = wkSheet.Rows[i];
                    Range.Hidden = true;

                    if (CarrierName.Trim() != string.Empty || BidSpecifications == "New Line of Coverage")
                    {
                        string bidSpec = (string)(range.Cells[i, BidSpecifications_ColumnNumber] as Excel.Range).Value2;
                        if (bidSpec == null || bidSpec.Trim() == string.Empty)
                        {
                            range.Cells[i, Carrier_ColumnNumber] = CarrierName;
                            range.Cells[i, Plan_Design_ColumnNumber] = PlaneDesignName;
                            range.Cells[i, BidSpecifications_ColumnNumber] = BidSpecifications;
                            if (WriteContribution)
                                range.Cells[i, Contributions_ColumnNumber] = Contributions;
                            if (WriteFundingType)
                                range.Cells[i, FundingType_ColumnNumber] = FundingType;
                            Range.Hidden = false;
                            CarrierName = "";
                            BidSpecifications = "";
                        }
                        else
                        {
                            Range.Hidden = false;
                        }

                    }
                }
            }

        }
        public void AddDeleteAdditionalLOC(Excel.Application myExcelApp, int RowCount, int maxAdditionLocCount, List<string> lstLOC)
        {
            int AddtionalRowStart = 82;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets["RFP Submission"];
            var Options = string.Join(",", lstLOC.ToArray());

            if (RowCount == 0)
            {
                for (int i = 0; i < maxAdditionLocCount; i++)
                {
                    Excel.Range Range = wkSheet.Rows[AddtionalRowStart + i];
                    Range.Hidden = true;
                }
            }
            else
            {
                int cnt = 0;
                for (int i = 0; i < maxAdditionLocCount; i++)
                {
                    cnt++;

                    if (cnt <= RowCount)
                    {
                        Excel.Range cell = (Microsoft.Office.Interop.Excel.Range)wkSheet.Cells[AddtionalRowStart + i, 3];
                        cell.Validation.Add(Excel.XlDVType.xlValidateList, Excel.XlDVAlertStyle.xlValidAlertInformation, Excel.XlFormatConditionOperator.xlBetween, Options, Type.Missing);
                        cell.Validation.IgnoreBlank = true;
                        cell.Validation.InCellDropdown = true;
                    }
                    else
                    {
                        Excel.Range Range = wkSheet.Rows[AddtionalRowStart + i];
                        Range.Hidden = true;
                    }
                }

            }

        }
        #endregion
        public bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }
        public Dictionary<string, string> GetProductCustomValue(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            Dictionary<string, string> dictCustomValue = new Dictionary<string, string>();
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            dictCustomValue["IsValuntary"] = "no";
            dictCustomValue["FundingMethod"] = "";
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            dictCustomValue["IsValuntary"] = "yes";
                        }
                        else
                        {
                            dictCustomValue["IsValuntary"] = "no";
                        }
                    }
                    if (value.customFieldID == 18111) //Funding Type
                    {
                        if (value.valueText != null)
                        {
                            dictCustomValue["FundingMethod"] = value.valueText;
                        }
                        else
                        {
                            dictCustomValue["FundingMethod"] = "";
                        }
                    }
                }
            }
            return dictCustomValue;
        }

        #region Created By Kiran
        public void WriteRFPDetails(Excel.Application myExcelApp, DropDownList ddlClient, string SheetName, string MainAddress, DataSet AccountDS, DataSet AccountTeamMemberDS, string Account_Region, string Account_Office, DataTable OfficeAddress, DateTime EffectiveRenewalDate, DateTime RFPSentDate, DateTime MeetingDate, string BPUserName, string MedicalCarriers)
        {

            int count = 1;

            Excel.Worksheet wkSheet = null;
            if (count == 1)
            {
                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];
            }

            DateTime dateValue = new DateTime();
            string SalesLead_FirstName = string.Empty;
            string SalesLead_LastName = string.Empty;
            string ServiceLead_FirstName = string.Empty;
            string ServiceLead_LastName = string.Empty;


            string Street1 = string.Empty;
            string Street2 = string.Empty;
            string City = string.Empty;
            string State = string.Empty;
            string Zip = string.Empty;
            string Country = string.Empty;
            string ClientType = string.Empty;
            string BusinessType = string.Empty;
            string SICCode = string.Empty;
            string TotalAnnualRevenue = string.Empty;
            string PrimaryContact_EMail = string.Empty;
            string PrimaryContact_FirstName = string.Empty;
            string PrimaryContact_LastName = string.Empty;
            int Num_Of_FTE = 0;
            string USICity = string.Empty;
            string USIState = string.Empty;
            string USIZip = string.Empty;
            string USIStreetAddress = string.Empty;


            DateTime CurrrentDate = DateTime.Now;

            try
            {
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]).Trim();
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]).Trim();

                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]).Trim();
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]).Trim();
                                    }
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryContactUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        PrimaryContact_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        PrimaryContact_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        PrimaryContact_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    }
                                }
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                            {
                                City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                            {
                                State = Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"]);
                                State = State.Replace("_", " ");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                            {
                                Zip = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["accountType"])))
                            {
                                ClientType = Convert.ToString(AccountDS.Tables[1].Rows[j]["accountType"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_businessType"])))
                            {
                                BusinessType = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_businessType"]).Replace('_', '-');
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_SICCode"])))
                            {
                                SICCode = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_SICCode"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_budgetedTotalAnnualRevenue"])))
                            {
                                TotalAnnualRevenue = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_budgetedTotalAnnualRevenue"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                            {
                                Street1 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                            {
                                Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                            }
                            // Get the Full Time Employees details
                            var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                                      select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                            Num_Of_FTE = Convert.ToInt32(FTE.First());
                        }
                    }
                }
                if (OfficeAddress != null)
                {
                    if (OfficeAddress.Rows.Count > 0)
                    {
                        USICity = OfficeAddress.Rows[0]["City"].ToString();
                        USIState = OfficeAddress.Rows[0]["State"].ToString();
                        USIState = USIState.Replace("_", " ");
                        USIZip = OfficeAddress.Rows[0]["Zip"].ToString();
                        USIStreetAddress = OfficeAddress.Rows[0]["Office Street Address"].ToString();
                        USIStreetAddress = USIStreetAddress.Replace("_", " ");
                    }
                }

                wkSheet.Cells[2, 5] = ddlClient.SelectedItem.Text.ToString(); //Account Name   
                wkSheet.Cells[2, 9] = "USI" + " " + Account_Office == string.Empty ? "" : "USI" + " " + Account_Office;//USI office 
                wkSheet.Cells[6, 4] = CurrrentDate.ToString("MM/dd/yyyy"); //CurrrentDate.ToString("MMMM dd,yyyy");
                wkSheet.Cells[7, 4] = BPUserName;
                wkSheet.Cells[8, 4] = Account_Region == string.Empty ? "" : Account_Region;// Region 
                wkSheet.Cells[9, 4] = MeetingDate.ToString("MM/dd/yyyy");
                wkSheet.Cells[27, 4] = MedicalCarriers; // MEdical Carrier Names
                wkSheet.Cells[34, 4] = EffectiveRenewalDate.ToString("MM/dd/yyyy"); // 33=>34 new templates 
                wkSheet.Cells[34, 7] = RFPSentDate.ToString("MM/dd/yyyy");// 33=>34 new templates 



                //wkSheet.Cells[36, 8] = Account_Office == string.Empty ? "" : Account_Office;//USI office 

                //  wkSheet.Cells[10, 4] = TotalAnnualRevenue == string.Empty ? "" : TotalAnnualRevenue;//Total Annual Revenue 

                // wkSheet.Cells[7, 4] = SalesLead_FirstName + " " + SalesLead_LastName;



                wkSheet.Cells[37, 4] = ddlClient.SelectedItem.Text.ToString();  // Client Name
                wkSheet.Cells[38, 4] = ClientType == string.Empty ? "" : ClientType;  // Client Type

                var SomeCell = (Excel.Range)wkSheet.Cells[39, 4];

                if (!String.IsNullOrEmpty(Street2))
                {
                    wkSheet.Cells[39, 4].Style.WrapText = true;
                    SomeCell.RowHeight = 30;
                    wkSheet.Cells[39, 4] = Street1 + "\n" + Street2;
                }
                else
                {
                    wkSheet.Cells[39, 4] = Street1 == string.Empty ? "" : Street1;
                }

                //// for new CR Cell (I36)
                //if (!String.IsNullOrEmpty(USIStreetAddress))
                //{
                //    wkSheet.Cells[36, 9].Style.WrapText = true;
                //    SomeCell.RowHeight = 30;
                //    wkSheet.Cells[36, 9] = USIStreetAddress;
                //}
                //else
                //{
                //    wkSheet.Cells[36, 9] = Street1 == string.Empty ? "" : Street1;
                //}

                // for new CR Cell (H36)
                if (!String.IsNullOrEmpty(USIStreetAddress))
                {
                    //wkSheet.Cells[36, 8] = Account_Office == string.Empty ? "" : Account_Office;//USI office 
                    wkSheet.Cells[38, 8].Style.WrapText = true;
                    SomeCell.RowHeight = 30;
                    wkSheet.Cells[37, 8] = Account_Office + "\n" + USIStreetAddress;
                }
                else
                {
                    wkSheet.Cells[37, 8] = Account_Office == string.Empty ? "" : Account_Office + "\n" + Street1 == string.Empty ? "" : Street1;
                }

                // wkSheet.Cells[38, 9] = USICity + ", " + USIState + " " + USIZip;  // City State Zip // New CR cell (I38)

                wkSheet.Cells[39, 8] = USICity + ", " + USIState + " " + USIZip;  // City State Zip // New CR cell (H38)

                wkSheet.Cells[40, 4] = City + ", " + State + " " + Zip;  // City State Zip
                wkSheet.Cells[41, 4] = SICCode == string.Empty ? "" : SICCode; // SIC Code
                wkSheet.Cells[42, 4] = BusinessType == string.Empty ? "" : BusinessType;  // Tax Status
                wkSheet.Cells[43, 4] = Num_Of_FTE;  // Eligible Emp

                wkSheet.Cells[43, 8] = ServiceLead_FirstName + " " + ServiceLead_LastName;
                wkSheet.Cells[42, 8] = SalesLead_FirstName + " " + SalesLead_LastName;



                //New CR change
                //  wkSheet.Cells[39, 8] = PrimaryContact_FirstName + " " + PrimaryContact_LastName;//Primary Contact
                //   wkSheet.Cells[40, 8] = PrimaryContact_EMail == string.Empty ? "" : PrimaryContact_EMail; //Contact Email               


                List<string> getRgionalPanelCarrierList = GetRegionalPanelCarrierList(Account_Region);

                if ((getRgionalPanelCarrierList != null) && getRgionalPanelCarrierList.Count > 0)
                {
                    int cnt = 0;
                    int cellRow = 0;
                    int cntCellColur = 0;
                    int cellRowColor = 0;

                    cnt = getRgionalPanelCarrierList.Count();

                    for (int i = 0; i < cnt; i++)
                    {
                        string lst = getRgionalPanelCarrierList[i].ToString();
                        string[] lstItem = lst.Split(new string[] { "" }, StringSplitOptions.None);
                        cellRow = 16 + i;
                        wkSheet.Cells[cellRow, 4] = lstItem[0].ToString();
                    }
                    if (cnt != 9)
                    {
                        cntCellColur = 9 - cnt;
                        for (int j = 0; j < cntCellColur; j++)
                        {
                            cellRowColor = cellRow + j + 1;
                            // wkSheet.Cells[cellRowColor, 4] = "";
                            wkSheet.Cells[cellRowColor, 4].Interior.Color = ColorTranslator.ToOle(System.Drawing.Color.Gray);
                        }

                    }
                }
                List<string> getAncillaryEmail = GetRegionalAncillaryEmail(Account_Region);

                #region Add DropdownList to Excel
                if (getAncillaryEmail != null)
                {
                    if (getAncillaryEmail.Count > 1)
                    {
                        var emailList = string.Join(", ", getAncillaryEmail.ToArray());
                        var cell = (Excel.Range)wkSheet.Cells.get_Range("H9");
                        cell.Select();
                        cell.Show();
                        cell.Validation.Delete();
                        cell.Validation.Add(Excel.XlDVType.xlValidateList,
                           Excel.XlDVAlertStyle.xlValidAlertInformation,
                          Excel.XlFormatConditionOperator.xlBetween,
                           emailList,
                            Type.Missing);
                        cell.Validation.IgnoreBlank = true;
                        cell.Validation.InCellDropdown = true;

                        wkSheet.Cells[9, 8].Interior.Color = ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                    }
                    else
                    {
                        string ancillary_Email = getAncillaryEmail.First().ToString();
                        wkSheet.Cells[9, 8] = ancillary_Email;  // Ancillary Email
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void CreateRegionList(Excel.Application myExcelApp, object fileName, string regionName)
        {
            string filePath = fileName.ToString();

            List<string> lst = GetRegionalAncillaryEmail(regionName);

            //Excel.Application myExcelApp1 = null;
            Excel.Workbook myWorkbook1 = null;
            Excel.Worksheet myWorksheet1 = null;

            myExcelApp = new Excel.Application();
            myExcelApp.Visible = false;

            Object missing = System.Reflection.Missing.Value;

            myWorkbook1 = myExcelApp.Workbooks.Open(filePath);
            myWorksheet1 = myExcelApp.ActiveSheet;

            string workSheetName = "RFP Submission";

            myWorksheet1 = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[workSheetName];

            var flatList = string.Join(", ", lst.ToArray());

            var cell = (Excel.Range)myWorksheet1.Cells.get_Range("H9");
            cell.Select();
            cell.Validation.Delete();
            cell.Validation.Add(Excel.XlDVType.xlValidateList,
               Excel.XlDVAlertStyle.xlValidAlertInformation,
              Excel.XlFormatConditionOperator.xlBetween,
               flatList,
                Type.Missing);
            cell.Validation.IgnoreBlank = true;
            cell.Validation.InCellDropdown = true;


            myWorkbook1.Save();
            myWorkbook1.Close(true, Type.Missing, Type.Missing);
            myExcelApp.Quit();
        }

        private List<string> GetRegionalAncillaryEmail(string Region)
        {
            List<string> lstRegion = new List<string>();
            List<string> lstDistEmail = new List<string>();
            DataTable dtRegion = new DataTable();
            dtRegion = USIRegionData();

            bool flag = false;

            foreach (DataRow dr in dtRegion.Rows)
            {
                if (dr["Region"].ToString() == Region)
                {
                    lstDistEmail.Add(dr["Ancillary Email"].ToString());
                    flag = true;
                }
                lstRegion = lstDistEmail.Distinct().ToList();
            }
            if (!flag)
            {

                lstRegion = (from row in dtRegion.AsEnumerable()
                             select row.Field<string>("Ancillary Email")).Distinct().ToList();
            }

            return lstRegion;
        }

        private List<string> GetRegionalPanelCarrierList(string Region)
        {
            List<string> lstPanelList = new List<string>();
            List<string> lstDistPanel = new List<string>();

            DataTable dtPanelCarrierllist = new DataTable();

            dtPanelCarrierllist = USIRegionData();

            bool flag = false;

            foreach (DataRow dr in dtPanelCarrierllist.Rows)
            {

                if (dr["Region"].ToString() == Region)
                {
                    lstDistPanel.Add(dr["Regional Panel Carrier List"].ToString());
                    flag = true;
                }
                lstPanelList = lstDistPanel.Distinct().ToList();
            }
            if (!flag)
            {

                lstPanelList = (from row in dtPanelCarrierllist.AsEnumerable()
                                select row.Field<string>("Regional Panel Carrier List")).Distinct().ToList();
            }

            return lstPanelList;
        }

        private DataTable USIRegionData()
        {
            DataTable region_table = new DataTable();
            region_table.Columns.Add("Region", typeof(string));
            region_table.Columns.Add("Region BP Codes", typeof(string));
            region_table.Columns.Add("Regional Panel Carrier List", typeof(string));
            region_table.Columns.Add("Ancillary Email", typeof(string));

            region_table.Rows.Add("Mid-Atlantic", "8499", "Anthem Blue Cross", "MidAtlantic.Ancillary@usi.com");
            region_table.Rows.Add("Mid-Atlantic", "8499", "United Concordia", "MidAtlantic.Ancillary@usi.com");

            region_table.Rows.Add("Midwest", "8071", "Anthem Blue Cross", "MidWest.Ancillary@usi.com");
            region_table.Rows.Add("Midwest", "8071", "Delta Dental", "MidWest.Ancillary@usi.com");

            region_table.Rows.Add("Mountain", "10258", "Delta Dental", "Mountain.Ancillary@usi.com");

            region_table.Rows.Add("New England", "8501", "Anthem Blue Cross", "NewEngland.Ancillary@usi.com");
            region_table.Rows.Add("New England", "8501", "The Standard", "NewEngland.Ancillary@usi.com");
            region_table.Rows.Add("New England", "8501", "Cigna", "NewEngland.Ancillary@usi.com");

            region_table.Rows.Add("Northeast", "8869", "Anthem Blue Cross", "NorthEast.Ancillary@usi.com");
            region_table.Rows.Add("Northeast", "8869", "Reliance Standard", "NorthEast.Ancillary@usi.com");//replaced Delta Dental => Reliance Standard  

            region_table.Rows.Add("Southeast", "5628", "The Standard", "SouthEast.Ancillary@usi.com");
            region_table.Rows.Add("Southeast", "5628", "Unum", "SouthEast.Ancillary@usi.com");
            region_table.Rows.Add("Southeast", "5628", "Cigna", "SouthEast.Ancillary@usi.com");

            region_table.Rows.Add("Southwest", "8868", "The Standard", "SouthWest.Ancillary@usi.com");
            region_table.Rows.Add("Southwest", "8868", "United Concordia", "SouthWest.Ancillary@usi.com");
            region_table.Rows.Add("Southwest", "8868", "Voya", "SouthWest.Ancillary@usi.com");

            // region_table.Rows.Add("West", "14020", "Delta Dental", "West.Ancillary@usi.com");// Removed all west region
            // region_table.Rows.Add("West", "14020", "The Standard", "West.Ancillary@usi.com");// Removed all west region
            // region_table.Rows.Add("West", "14020", "Symetra", "West.Ancillary@usi.com");// Removed all west region
            region_table.Rows.Add("West", "14020", "Cigna", "West.Ancillary@usi.com");// Removed all west region


            // region_table.Rows.Add("Midsouth", "14022", "The Standard", "SouthEast.Ancillary@usi.com");// Removed all Midsouth region
            //  region_table.Rows.Add("Midsouth", "14022", "Unum", "SouthEast.Ancillary@usi.com");// Removed all Midsouth region
            region_table.Rows.Add("Midsouth", "14022", "Reliance Standard", "MidSouth.Ancillary@usi.com");
            region_table.Rows.Add("Midsouth", "14022", "Cigna", "MidSouth.Ancillary@usi.com");

            region_table.Rows.Add("Northwest", "8178", "Delta Dental", "NorthWest.Ancillary@usi.com"); // updated Email West.Ancillary => NorthWest.Ancillary
            region_table.Rows.Add("Northwest", "8178", "The Standard", "NorthWest.Ancillary@usi.com");// updated Email West.Ancillary => NorthWest.Ancillary
            region_table.Rows.Add("Northwest", "8178", "Symetra", "NorthWest.Ancillary@usi.com");// updated Email West.Ancillary => NorthWest.Ancillary
            region_table.Rows.Add("Northwest", "8178", "Cigna", "NorthWest.Ancillary@usi.com");// updated Email West.Ancillary => NorthWest.Ancillary

            return region_table;
        }
        #endregion


    }
}