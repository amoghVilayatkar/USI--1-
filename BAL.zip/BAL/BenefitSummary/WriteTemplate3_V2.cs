﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate3_V2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        string plan_carrier = "";
        string std_carrier = "";

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">List<Contact> ContactList Object</param>
        /// <param name="AccountDS">DataSet AccountDS Object as optional parameter</param>
        /// <param name="selectedcolor">string selectedcolor Object as optional parameter</param>
        /// <param name="BenefitStructureDS">DataSet BenefitStructureDS Object as optional parameter</param>
        /// <param name="ddlImageOption">DropDownList ddlImageOption Object as optional parameter</param>
        public void WriteFieldToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRCData> BRCList, string ddlBRCSelectedValue, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null, DropDownList ddlImageOption = null)
        {
            try
            {
                int iTotalFields = 0;
                DataTable Office = OfficeTable;
                DataTable Emp = new DataTable();
                int BRCindex = 0;
                int index = -1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Rectangle 25" || shape.Name == "Rectangle 26" || shape.Name == "Rectangle 33")
                    {
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                ////if (ddlBRC.SelectedIndex > 1)
                ////{
                ////    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                ////}
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Picture 1"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //  Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //  var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 1.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.75f);
                                        //shape.Height = oWordApp.InchesToPoints(2.05f);
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 1", 3.75f, 2.05f);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 2"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 2.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.01f);
                                        //shape.Height = oWordApp.InchesToPoints(2.23f);
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 3.01f, 2.23f);

                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 3"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 3.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.01f);
                                        //shape.Height = oWordApp.InchesToPoints(2.23f);
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 3", 3.01f, 2.23f);
                                        continue;
                                    }
                                    //if (fieldName.Contains("Picture 4"))
                                    //{
                                    //    myMergeField.Delete();
                                    //    object missing = System.Type.Missing;
                                    //    Word.Range r = oWordDoc.Range();
                                    //    r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                    //    var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 4.jpg"), false, true);
                                    //    shape.Width = oWordApp.InchesToPoints(7.54f);
                                    //    shape.Height = oWordApp.InchesToPoints(2.05f);
                                    //    continue;
                                    //}
                                    //if (fieldName.Contains("Picture 5"))
                                    //{
                                    //    myMergeField.Delete();
                                    //    object missing = System.Type.Missing;
                                    //    Word.Range r = oWordDoc.Range();
                                    //    r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                    //    var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 5.jpg"), false, true);
                                    //    shape.Width = oWordApp.InchesToPoints(7.54f);
                                    //    shape.Height = oWordApp.InchesToPoints(2.05f);
                                    //    continue;
                                    //}
                                    if (fieldName.Contains("Picture 6"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);

                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 6.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 6", 1.96f, 1.51f);
                                        //shape.Width = oWordApp.InchesToPoints(1.96f);
                                        //shape.Height = oWordApp.InchesToPoints(1.51f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 7"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 7.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 7", 4.22f, 1.12f);
                                        //shape.Width = oWordApp.InchesToPoints(4.22f);
                                        //shape.Height = oWordApp.InchesToPoints(1.12f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 8"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 8.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 8", 7f, 3.1f);
                                        //shape.Width = oWordApp.InchesToPoints(2.67f);
                                        //shape.Height = oWordApp.InchesToPoints(5.2f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("First Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).Year.ToString() + " Plan Year").Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Renewal Plan Year"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string renewaldate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(renewaldate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Plan Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Account Summary/Main Phone Number"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(comFunObj.GetAccountMainPhoneNumber(AccountDS));
                                        continue;
                                    }
                                    if (fieldName.Contains("Renewal Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        //Commented by:Mandar Apate
                                        //Date:8/24/2016
                                        //purpose:As per client said the date should be Medical Plan  effective Date

                                        //string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        //DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);

                                        string renewal = PlanTable.Rows[k]["Effective"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal);
                                        oWordApp.Selection.TypeText((renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString()).Trim());
                                        continue;
                                    }

                                    //if (fieldName.Contains("unmarriedchildtoage"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText((EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString()).Trim());
                                    //        continue;
                                    //    }
                                    //    else
                                    //    {
                                    //        myMergeField.Delete();
                                    //    }
                                    //}

                                    if (fieldName.Contains("The Deadline to Enroll"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("The Deadline to Enroll is");
                                        continue;

                                    }
                                    if (fieldName.Contains("add applicable date"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("add applicable date");
                                        continue;

                                    }

                                    //if (fieldName.Contains("definition of employee"))
                                    //{
                                    //    myMergeField.Select();

                                    //    if (Emp.Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                    //    }
                                    //    else
                                    //    {
                                    //        oWordApp.Selection.TypeText(" ");
                                    //    }
                                    //}

                                    //if (fieldName.Contains("definitionofdomesticpartner"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                    //        oWordApp.Selection.TypeText(domesticPartner.Trim());
                                    //        continue;
                                    //    }
                                    //}
                                    //if (Emp.Rows.Count > 0)
                                    //{
                                    //    if (fieldName.Contains("EmployeeStatus"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("working"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("frequency"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("unitofmeasure"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //}
                                    //if (fieldName.Contains("medicalplanwaitingperiod"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //}

                                    if (ddlBRCSelectedValue == "YES") // if BRC need to Include
                                    {
                                        if (BRCList.Count > 0)
                                        {
                                            if (fieldName.Contains("BRC Selected"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                continue;
                                            }
                                            if (fieldName.Contains("Benefit Resource Center"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText("Benefit Resource Center");
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Hours"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                                }
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Phone"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                                }
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Email"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                                }
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Fax"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                                }
                                                continue;
                                            }
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Address"))
                                            {
                                                myMergeField.Select();
                                                string var = Convert.ToString(FoundRow[0]["OfficeAddress"].ToString());
                                                if (string.IsNullOrEmpty(var))
                                                {
                                                    var = " ";
                                                }
                                                oWordApp.Selection.TypeText(var);
                                                continue;
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                                continue;
                                            }
                                        }
                                    }
                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name.Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            if (Phone.ToString() == "")
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Phone.ToString());
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Renewal Date"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.Year.ToString());
                                        continue;
                                    }

                                    // For giving color to header and text
                                    if (fieldName.Contains("EMPLOYEE BENEFITS ENROLLMENT GUIDE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("EMPLOYEE BENEFITS ENROLLMENT GUIDE");
                                        continue;
                                    }
                                    if (fieldName.Contains("Employee Benefits Open Enrollment"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Employee Benefits Open Enrollment");
                                        continue;
                                    }
                                    if (fieldName.Contains("What is Open Enrollment?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What is Open Enrollment?");
                                        continue;
                                    }
                                    if (fieldName.Contains("What’s new this year?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What’s new this year?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Eligibility"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Eligibility");
                                        continue;
                                    }
                                    if (fieldName.Contains("Family Status Change Events"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Family Status Change Events");
                                        continue;
                                    }
                                    if (fieldName.Contains("Disclaimer"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Disclaimer");
                                        continue;
                                    }
                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Contact Information");
                                        continue;
                                    }
                                    if (fieldName.Contains("Have Questions? Need Help?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Have Questions? Need Help?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Medical Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Dental Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Vision Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Wellness Initiative"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Wellness Initiative");
                                        continue;
                                    }
                                    if (fieldName.Contains("Health Savings Account (HSA)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Health Savings Account (HSA)");
                                        continue;
                                    }
                                    if (fieldName.Contains("What is a Health Savings Account (HSA)?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What is a Health Savings Account (HSA)?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Plus, you get extra tax advantages with an HSA because:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Plus, you get extra tax advantages with an HSA because:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Are you eligible to open a Health Savings Account (HSA)?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Are you eligible to open a Health Savings Account (HSA)?");
                                        continue;
                                    }
                                    if (fieldName.Contains("HSA Contributions"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("HSA Contributions");
                                        continue;
                                    }
                                    if (fieldName.Contains("FOR THE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("FOR THE");
                                        continue;
                                    }
                                    if (fieldName.Contains("TAX YEAR:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("TAX YEAR:");
                                        continue;
                                    }
                                    if (fieldName.Contains("How do I get reimbursed for my eligible expenses?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("How do I get reimbursed for my eligible expenses?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Health Reimbursement Account (HRA)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Health Reimbursement Account (HRA)");
                                        continue;
                                    }
                                    if (fieldName.Contains("Flexible Spending Account (FSA)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Flexible Spending Account (FSA)");
                                        continue;
                                    }
                                    if (fieldName.Contains("Healthcare Expense Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Healthcare Expense Account");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dependent Care Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Dependent Care Account");
                                        continue;
                                    }
                                    if (fieldName.Contains("What are the risks of FSAs?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What are the risks of FSAs?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Life & Accidental Death and Dismemberment"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Life & Accidental Death and Dismemberment");
                                        continue;
                                    }
                                    if (fieldName.Contains("Disability Insurance"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Disability Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("Long Term Disability"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Long Term Disability");
                                        continue;
                                    }
                                    if (fieldName.Contains("Pre-existing limitations may apply:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Pre-existing limitations may apply:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Short Term Disability"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Short Term Disability");
                                        continue;
                                    }
                                    if (fieldName.Contains("Employee Assistance Plan (EAP)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Employee Assistance Plan (EAP)");
                                        continue;
                                    }
                                    if (fieldName.Contains("Employee Assistance Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Employee Assistance Plan");
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">List<Contact> ContactList Object</param>
        /// <param name="AccountDS">DataSet AccountDS Object as optional parameter</param>
        /// <param name="selectedcolor">string selectedcolor Object as optional parameter</param>
        /// <param name="BenefitStructureDS ">DataSet BenefitStructureDS  Object as optional parameter</param>
        public void WriteAdditionalProductsToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable OfficeTable, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null)
        {
            try
            {
                int iTotalFields = 0;
                DataTable Office = OfficeTable;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                bool is_Patient_Advocacy_Selected = false;
                bool is_Consumer_Driven_Telemedicine_Selected = false;
                bool is_Accident_Selected = false;
                bool is_Voluntary_Cancer_Selected = false;
                bool is_Voluntary_Critical_Illness_Selected = false;

                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        {
                            is_Patient_Advocacy_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        {
                            is_Consumer_Driven_Telemedicine_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        {
                            is_Accident_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            is_Voluntary_Cancer_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            is_Voluntary_Critical_Illness_Selected = true;
                        }
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (is_Patient_Advocacy_Selected == true)
                        {
                            if (fieldName.Contains("Patient Advocacy Program"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Patient Advocacy Program");
                                continue;
                            }
                            if (fieldName.Contains("COMPASS - YOUR PERSONAL HEALTHCARE ADVISORS"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("COMPASS - YOUR PERSONAL HEALTHCARE ADVISORS");
                                continue;
                            }
                            if (fieldName.Contains("WHY SHOULD YOU CONTACT COMPASS??"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WHY SHOULD YOU CONTACT COMPASS??");
                                continue;
                            }
                        }

                        if (is_Consumer_Driven_Telemedicine_Selected == true)
                        {
                            if (fieldName.Contains("Telemedicine"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Telemedicine");
                                continue;
                            }
                            if (fieldName.Contains("HERE ARE SOME FREQUENTLY ASKED QUESTIONS REGARDING TELADOC:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HERE ARE SOME FREQUENTLY ASKED QUESTIONS REGARDING TELADOC:");
                                continue;
                            }
                        }

                        if (is_Accident_Selected == true || is_Voluntary_Cancer_Selected == true || is_Voluntary_Critical_Illness_Selected == true)
                        {
                            if (fieldName.Contains("Worksite Products"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Worksite Products");
                                continue;
                            }
                            if (fieldName.Contains("Accident Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Accident Insurance");
                                continue;
                            }
                            if (fieldName.Contains("Cancer Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Cancer Insurance");
                                continue;
                            }
                            if (fieldName.Contains("Critical Illness Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Critical Illness Insurance");
                                continue;
                            }
                            if (fieldName.Contains("To find out more information or to apply for coverage, leave a detailed message (name/contact information) or email at:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("To find out more information or to apply for coverage, leave a detailed message (name/contact information) or email at:");
                                continue;
                            }
                            if (fieldName.Contains("Phone Number and/or E-mail Address"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Phone Number and/or E-mail Address");
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="selectedColor">selectedColor contain selected color (Optional Paramter)</param>
        public void WriteDentalSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, DataTable CarrierSpecific, DataTable PlanTypeSpecific, string selectedColor = "")
        {
            try
            {
                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(8, "566"); //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalInNetwork.Add(7, "45");  //Calendar Year Deductible - Individual
                HashtableDentalInNetwork.Add(6, "44");  //Calendar Year Deductible - Family
                HashtableDentalInNetwork.Add(5, "55");  //Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(4, "164"); //Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(3, "64");  //Basic Services – Basic
                HashtableDentalInNetwork.Add(2, "336"); //Major Services – Major
                HashtableDentalInNetwork.Add(1, "314"); //Orthodontia[Lifetime Orthodontia Maximum]
                #endregion

                int count = 1;
                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;
                string AnnualDeductibleIndividual = string.Empty;
                int dentalCount = 1; //For 3 different dental plans
                int dentalTableNo = 14; //For giving proper table numbers for selected plans
                string value = "";
                int rowCnt = 3;
                bool isRowIncremented = false;

                string Carrier = "";
                string OldCarrier = "";
                ArrayList arrCarrierName = new ArrayList();

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, dentalTableNo, selectedColor, cv.DentalLOC);
                oWordDoc.Tables[dentalTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    // Check for only Dental plans from the given PlanTable
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        rowCnt = 3;
                        if (dentalCount == 1)
                        {
                            count = 1;
                        }
                        else if (dentalCount == 2)
                        {
                            count = 2;
                        }
                        else if (dentalCount == 3)
                        {
                            count = 3;
                        }

                        oWordDoc.Tables[dentalTableNo].Cell(1, count + 1).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();

                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + "'");

                            #region DentalTable

                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                if (OldCarrier == "")
                                {
                                    Carrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                                    arrCarrierName.Add(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim());
                                }
                                else
                                {
                                    if (!arrCarrierName.Contains(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim()))
                                    {
                                        Carrier = Carrier + " and " + (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim());
                                        arrCarrierName.Add(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim());
                                    }
                                }
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            }

                            // Iterate the loop for above created HashTable to get the value for selected Key
                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                isRowIncremented = false;
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        // Set value = Prefix + Value + Suffix + AncillaryTest + ExclusionsLimitations
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 8:
                                                rowCnt = 3;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 7:
                                                rowCnt = 4;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 6:
                                                rowCnt = 5;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 5:
                                                rowCnt = 7;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 4:
                                                rowCnt = 9;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 3:
                                                rowCnt = 11;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 2:
                                                rowCnt = 13;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 1:
                                                rowCnt = 15;
                                                oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                        }
                                        isRowIncremented = true;
                                    }
                                }
                                if (isRowIncremented == false)
                                {
                                    // Do not increment the row when Key = 8 because we are not writing any valye for key = 9, we are only taking valye for key = 9 in variable and
                                    // we have already incremented row in the above switch(key)
                                    if (key != 8)
                                    {
                                        rowCnt++;
                                    }
                                }
                            }
                            #endregion

                            count++;
                            dentalCount++;
                        }
                    }
                }

                int iTotalFields1 = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields1++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Dental Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier.Trim());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">selectedColor contain selected color (Optional Paramter)</param>
        public void WriteVisionSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, DataTable CarrierSpecific, string selectedColor = "")
        {
            try
            {
                DataRow[] foundRows = null;
                Hashtable HashtableVisionBenefit = new Hashtable();

                #region HastableVisionBenefit

                HashtableVisionBenefit.Add(3, "195");   //General Plan Information – Copay – Deductible
                HashtableVisionBenefit.Add(4, "194");   //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefit.Add(6, "344");   //General Plan Information – Material
                HashtableVisionBenefit.Add(7, "309");   //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefit.Add(8, "178");   //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefit.Add(88, "122");  //General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefit.Add(9, "208");   //Covered Services – Frames
                HashtableVisionBenefit.Add(99, "207");  //General Plan Information – Benefit Frequency – Frame
                #endregion

                ArrayList arrVisionBenefit = new ArrayList();
                foreach (int key in HashtableVisionBenefit.Keys)
                {
                    arrVisionBenefit.Add(key);
                }

                arrVisionBenefit.Sort();
                arrVisionBenefit.Reverse();

                string BenefitFrequency_Frames = string.Empty;
                string BenefitFrequency_Contacts = string.Empty;
                string BenefitFrequency_Lenses = string.Empty;
                string Materials_Copay = string.Empty;
                string BenefitFrequency_Examination = string.Empty;
                string CopayExamination = string.Empty;

                int iTotalFields = 0;
                int count = 1;
                int tableNoVision = 16;
                int colCount = 0;
                string value = "";

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoVision, selectedColor, cv.VisionLOC);
                oWordDoc.Tables[tableNoVision].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            # region VisionBenefitTable

                            if (count == 1)
                            {
                                colCount = 2;
                            }
                            if (count == 2)
                            {
                                BenefitFrequency_Lenses = "";
                                colCount = 3;
                            }
                            if (count == 3)
                            {
                                BenefitFrequency_Lenses = "";
                                colCount = 4;
                            }

                            oWordDoc.Tables[tableNoVision].Cell(1, colCount).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();

                            foreach (int key in arrVisionBenefit)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 99: BenefitFrequency_Frames = value;

                                                break;
                                            case 88: BenefitFrequency_Contacts = value;

                                                break;
                                            case 9:
                                                oWordDoc.Tables[tableNoVision].Cell(key, colCount).Range.Text = "Covered at " + value.Trim() + " every " + BenefitFrequency_Frames;
                                                break;
                                            case 8:
                                                oWordDoc.Tables[tableNoVision].Cell(key, colCount).Range.Text = "Elective contacts covered " + value.Trim() + " every " + BenefitFrequency_Contacts;
                                                break;
                                            case 7: BenefitFrequency_Lenses = value;
                                                oWordDoc.Tables[tableNoVision].Cell(key, colCount).Range.Text = "Benefit varies by type of lens. Covered every " + value;
                                                break;
                                            case 6: Materials_Copay = value;
                                                oWordDoc.Tables[tableNoVision].Cell(key, colCount).Range.Text = value;
                                                break;
                                            case 4: BenefitFrequency_Examination = value;
                                                oWordDoc.Tables[tableNoVision].Cell(key, colCount).Range.Text = value;
                                                break;
                                            case 3: CopayExamination = value;
                                                oWordDoc.Tables[tableNoVision].Cell(key, colCount).Range.Text = value;
                                                break;
                                        }
                                        if (key != 99 && key != 88 && key != 9 && key != 8 && key != 7 && key != 6 && key != 4 && key != 3)
                                        {
                                            oWordDoc.Tables[tableNoVision].Cell(key, colCount).Range.Text = value;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            // Iterate through each field in word document to write values for that field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Vision Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Plan Selected"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        /// <param name="ddlSTDPlanName">DropDownList ddlSTDPlanName object</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        public void WriteSTDSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlSTDPlanName, string selectedColor = "")
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                int colCount = 1;
                Hashtable HashtableSTD = new Hashtable();

                #region HashtableSTD
                HashtableSTD.Add(6, "71");  //STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(5, "569"); //STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(4, "8");   //STD General Information – Elimination Period – Accident
                HashtableSTD.Add(3, "505"); //STD General Information – Elimination Period – Sickness
                HashtableSTD.Add(2, "350"); //STD General Information – Maximum Period of Payment
                #endregion

                string Accident = string.Empty;
                string ProductName = "";
                int tableNoSTD = 28;
                string value = "";

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoSTD, selectedColor, cv.STDPlanType_CommonCriteria);
                oWordDoc.Tables[tableNoSTD].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            if (count == 1)
                            {
                                colCount = 2;
                            }
                            if (count == 2)
                            {
                                colCount = 3;
                            }

                            oWordDoc.Tables[tableNoSTD].Cell(1, colCount).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        // value = Prefix + Value + AncillaryText + ExclusionsLimitations
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 6: oWordDoc.Tables[tableNoSTD].Cell(3, colCount).Range.Text = value.Trim(); break;
                                            case 5: oWordDoc.Tables[tableNoSTD].Cell(5, colCount).Range.Text = value.Trim(); break;
                                            case 4: Accident = value.Trim(); break;
                                            case 3:
                                                if (!string.IsNullOrEmpty(Accident.Trim()) && !string.IsNullOrEmpty(value.Trim()))
                                                {
                                                    oWordDoc.Tables[tableNoSTD].Cell(7, colCount).Range.Text = "Accident: " + Accident.Trim() + " / " + "Sickness: " + value.Trim();
                                                }
                                                else
                                                {
                                                    if (!string.IsNullOrEmpty(Accident.Trim()))
                                                    {
                                                        oWordDoc.Tables[tableNoSTD].Cell(7, colCount).Range.Text = "Accident: " + Accident.Trim();
                                                    }
                                                    if (!string.IsNullOrEmpty(value.Trim()))
                                                    {
                                                        oWordDoc.Tables[tableNoSTD].Cell(7, colCount).Range.Text = "Sickness: " + value.Trim();
                                                    }

                                                    if (string.IsNullOrEmpty(Accident.Trim()) && string.IsNullOrEmpty(value.Trim()))
                                                    {
                                                        oWordDoc.Tables[tableNoSTD].Cell(7, colCount).Range.Text = "";
                                                    }
                                                }
                                                break;
                                            case 2: oWordDoc.Tables[tableNoSTD].Cell(9, colCount).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim(); break;
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            // Iterate through each field in the word document to write value for that field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VlSTD"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("STD_Or_LTD_Selected"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("STD Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        std_carrier = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                        oWordApp.Selection.TypeText(std_carrier);
                                        continue;
                                    }

                                    if (fieldName.Contains("VoluntarySTD Disability"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Short Term Disability Premium Calculation");
                                            continue;
                                        }
                                    }

                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan </param>
        /// <param name="ddlLTDPlanName">DropDownList ddlLTDPlanName object</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        public void WriteLTDSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlLTDPlanName, string selectedColor = "")
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                string ProductName = "";
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableLTD
                HashtableLTD.Add(6, "71");  //General Plan Information – Benefit Percentage
                HashtableLTD.Add(5, "374"); //General Plan Information – Weekly Benefit Maximum
                HashtableLTD.Add(4, "181"); //LTD General Information – Elimination Period
                // HashtableLTD.Add(3, "351"); //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(3, "141"); //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(2, "449"); //General Plan Information – Pre-Existing Condition Limitations
                #endregion

                string Accident = string.Empty;
                int tableNoLTD = 27;
                string value = "";
                int colCount = 0;

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoLTD, selectedColor, cv.LTDPlanType_CommonCriteria);
                oWordDoc.Tables[tableNoLTD].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();

                            if (count == 1)
                            {
                                colCount = 2;
                            }
                            if (count == 2)
                            {
                                colCount = 3;
                            }

                            oWordDoc.Tables[tableNoLTD].Cell(1, colCount).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        // value = Prefix + Value + AncillaryText + ExclusionsLimitations
                                        if (!string.IsNullOrEmpty(dr["suffix"].ToString().Trim()))
                                        {
                                            dr["suffix"] = dr["suffix"].ToString().Trim() + " ";
                                        }
                                        else
                                        {
                                            dr["suffix"] = dr["suffix"].ToString().Trim();
                                        }

                                        if (!string.IsNullOrEmpty(dr["ancillaryText"].ToString().Trim()))
                                        {
                                            dr["ancillaryText"] = dr["ancillaryText"].ToString().Trim() + " ";
                                        }
                                        else
                                        {
                                            dr["ancillaryText"] = dr["ancillaryText"].ToString().Trim();
                                        }

                                        value = dr["prefix"].ToString() + dr["value"].ToString().Trim() + " " + dr["suffix"].ToString() + dr["ancillaryText"].ToString() + dr["exclusionsLimitations"].ToString().Trim();
                                        switch (key)
                                        {
                                            case 6: oWordDoc.Tables[tableNoLTD].Cell(3, colCount).Range.Text = value.Trim(); break;
                                            case 5: oWordDoc.Tables[tableNoLTD].Cell(5, colCount).Range.Text = value.Trim(); break;
                                            case 4: oWordDoc.Tables[tableNoLTD].Cell(7, colCount).Range.Text = value.Trim(); break;
                                            case 3:
                                                if (dr["UOM"].ToString() != "text")
                                                {
                                                    oWordDoc.Tables[tableNoLTD].Cell(9, colCount).Range.Text = value.Trim() + " " + dr["UOM"].ToString();
                                                }
                                                else
                                                {
                                                    oWordDoc.Tables[tableNoLTD].Cell(9, colCount).Range.Text = value.Trim();
                                                }

                                                //  oWordDoc.Tables[tableNoLTD].Cell(9, colCount).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim();
                                                break;
                                            case 2: oWordDoc.Tables[tableNoLTD].Cell(11, colCount).Range.Text = value.Trim(); break;
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            // Interate through each field in the word document to write values for that field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("VlLTD"))
                                    {
                                        myMergeField.Select();
                                        if (ddlLTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("STD_Or_LTD_Selected"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("LTD Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        /// <param name="dtPlanContactDetails">DataTable dtPlanContactDetails contain the plan contact information (Optional Parameter)</param>
        public void WriteContactinformationToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string selectedColor = "", DataTable dtPlanContactDetails = null)
        {
            try
            {
                int count = 1;
                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                DataRow[] foundRows = null;
                int cnt = 2;

                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;

                int rowCnt = 2;
                foreach (Word.Border border in oWordDoc.Tables[count].Borders)
                {
                    carrier = oWordDoc.Tables[count].Cell(cnt, 1).Range.Text;
                    description_Policy = oWordDoc.Tables[count].Cell(cnt, 2).Range.Text;
                    website_phone = oWordDoc.Tables[count].Cell(cnt, 3).Range.Text.Replace("\r\r", "\r");
                }

                oWordDoc.Tables[1].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[1].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[1].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[1].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        if (k > 1)
                        {
                            oWordDoc.Tables[count].Rows.Add();
                        }
                        carriername = PlanTable.Rows[i]["Carrier"].ToString();
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                        oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"].ToString()) + " / " + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());
                        //foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");

                        var planContactName = (from n in dtPlanContactDetails.AsEnumerable()
                                               where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                               select n.Field<string>("ContactName")).FirstOrDefault();

                        var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                                where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();

                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = Convert.ToString(planContactName) + "\n" + Convert.ToString(planContactPhone);

                        k++;
                        rowCnt++;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        ///// <summary>
        ///// Write Voluntary STD  and LTD Monthly Premium Section to template.
        ///// </summary>
        ///// <param name="oWordDoc">Word Document Object</param>
        ///// <param name="oWordApp">Word Application Object</param>
        ///// <param name="PlanTable">PlanTable contain selected Plan</param>
        ///// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        //public void WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS)
        //{
        //    try
        //    {
        //        ConstantValue cv = new ConstantValue();
        //        DataTable PremiumTable = new DataTable();

        //        int premium_row_counter = 0;
        //        PremiumTable.Columns.Add("Plan", typeof(string));
        //        PremiumTable.Columns.Add("rateTierID", typeof(string));
        //        PremiumTable.Columns.Add("rateTier_description", typeof(string));
        //        PremiumTable.Columns.Add("monthlycost", typeof(string));
        //        PremiumTable.Columns.Add("rateid", typeof(string));
        //        PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
        //        PremiumTable.Columns.Add("ageBandIndex", typeof(int));
        //        int Start = 0;
        //        int End = 0;
        //        int Interval = 0;

        //        int rowCnt = 2;
        //        int ColumnCount = 0;
        //        int oldageBand = -1;
        //        int PlanCount = 0;
        //        DataTable dt = new DataTable();
        //        int tableNo = 0;

        //        for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
        //        {
        //            if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
        //            {
        //                if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower())
        //                {
        //                    tableNo = 30;
        //                }
        //                else if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
        //                {
        //                    tableNo = 31;
        //                    PlanCount = 0;
        //                }

        //                PlanCount++;
        //                if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"] != null)
        //                {
        //                    Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
        //                }
        //                if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"] != null)
        //                {
        //                    End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
        //                }
        //                if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"] != null)
        //                {
        //                    Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;
        //                }
        //                for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
        //                {
        //                    if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
        //                    {
        //                        if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
        //                        {
        //                            PremiumTable.Rows.Add();
        //                            PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //                            PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        //                            PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //                            PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //                            PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //                            PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //                            PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
        //                            premium_row_counter++;
        //                        }
        //                    }
        //                }
        //                int StartValue = Start;
        //                int RowCount = 3;

        //                if (Start > 0 && PlanCount == 1)
        //                {
        //                    oWordDoc.Tables[tableNo].Cell(rowCnt, 1).Range.Text = "Under " + Start.ToString();

        //                    while (StartValue < End - 1)
        //                    {
        //                        oWordDoc.Tables[tableNo].Rows.Add();
        //                        if (StartValue == Start)
        //                        {
        //                            oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
        //                            StartValue = Start + Interval;
        //                        }
        //                        else
        //                        {
        //                            oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
        //                            StartValue = StartValue + Interval + 1;
        //                        }
        //                        RowCount++;
        //                    }
        //                    oWordDoc.Tables[tableNo].Rows.Add();
        //                    oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
        //                    oWordDoc.Tables[tableNo].Rows.Add();
        //                    oWordDoc.Tables[tableNo].Cell(RowCount + 1, 1).Range.Text = "Composite";
        //                }

        //                PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
        //                dt = PremiumTable.DefaultView.ToTable(true);
        //                PremiumTable = dt;
        //                RowCount = 1;
        //                for (int i = 0; i < PremiumTable.Rows.Count; i++)
        //                {
        //                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.STDPlanType)
        //                    {
        //                        ColumnCount = 2;
        //                    }

        //                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.LTDPlanType)
        //                    {
        //                        ColumnCount = 2;
        //                    }
        //                    if (int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString()) != oldageBand)
        //                    {
        //                        RowCount++;
        //                    }
        //                    oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());
        //                    oWordDoc.Tables[tableNo].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
        //                }
        //            }


        //            #region FormatTable
        //            if (PremiumTable.Rows.Count > 0)
        //            {
        //                foreach (Word.Border border in oWordDoc.Tables[tableNo].Borders)
        //                {
        //                    border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
        //                }

        //                oWordDoc.Tables[tableNo].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[tableNo].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[tableNo].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                object sortfield = 1;

        //                for (int k = 2; k < oWordDoc.Tables[tableNo].Rows.Count + 1; k++)
        //                {
        //                    oWordDoc.Tables[tableNo].Rows[k].Range.Paragraphs.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
        //                    oWordDoc.Tables[tableNo].Rows[k].Range.Font.Color = Word.WdColor.wdColorBlack;
        //                }
        //            }

        //            #endregion
        //        }

        //        if (tableNo != 0)
        //        {
        //            ColumnCount = oWordDoc.Tables[tableNo].Columns.Count;
        //            bool flag = false;
        //            if (oWordDoc.Tables[tableNo].Rows.Count < 5)
        //            {
        //                oWordDoc.Tables[tableNo].Delete();
        //            }
        //            else
        //            {
        //                while (ColumnCount > 1)
        //                {
        //                    for (int i = rowCnt; i < oWordDoc.Tables[tableNo].Rows.Count; i++)
        //                    {
        //                        if (oWordDoc.Tables[tableNo].Cell(i, ColumnCount).Range.Text.Trim() != "\a")
        //                        {
        //                            flag = false;
        //                            break;
        //                        }
        //                        else
        //                        {
        //                            flag = true;
        //                        }
        //                    }
        //                    if (flag == true)
        //                    {
        //                        oWordDoc.Tables[tableNo].Columns[ColumnCount].Delete();
        //                    }
        //                    ColumnCount--;
        //                }
        //            }
        //        }
        //    }

        //    catch (Exception ex)
        //    {
        //        //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        private void GetPlanTableFirstColumnHeadingName_And_ColorFormatting(Word.Document oWordDoc, DataTable PlanTable, DataSet BenefitDS, int rowindex, int TableNo_FirstTable, string selectedColor, string PlanTypeName)
        {
            Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
            Word.WdColor wdColor_cell = comFunObj.cell_color(selectedColor);

            oWordDoc.Tables[TableNo_FirstTable].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
            oWordDoc.Tables[TableNo_FirstTable].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

            for (int i = 1; i <= oWordDoc.Tables[TableNo_FirstTable].Rows.Count; i++)
            {
                if (i == 1)
                {
                    oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                }
                if (PlanTypeName == "Voluntary ADnD Plan Type" && i == 2)
                {
                    oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    oWordDoc.Tables[TableNo_FirstTable].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                }

                // For Medical table background shading color formatting
                if (PlanTypeName == cv.MedicalLOC)
                {
                    if (i == 2 || i == 5 || i == 7 || i == 10 || i == 13 || i == 15 || i == 18 || i == 21 || i == 23 || i == 25 || i == 30)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }

                    oWordDoc.Tables[TableNo_FirstTable].Cell(1, 1).Select();
                    oWordDoc.Tables[TableNo_FirstTable].Cell(1, 1).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                }
                // For Dental table background shading color formatting
                else if (PlanTypeName == cv.DentalLOC)
                {
                    if (i == 2 || i == 6 || i == 8 || i == 10 || i == 12 || i == 14 || i == 16)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                // For Vison table background shading color formatting
                else if (PlanTypeName == cv.VisionLOC)
                {
                    if (i == 2 || i == 5)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                // For LTD table background shading color formatting
                else if (PlanTypeName == cv.LTDPlanType_CommonCriteria)
                {
                    if (i == 2 || i == 4 || i == 6 || i == 8 || i == 10)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                // For STD table background shading color formatting
                else if (PlanTypeName == cv.STDPlanType_CommonCriteria)
                {
                    if (i == 2 || i == 4 || i == 6 || i == 8)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                // For Life & ADnD table background shading color formatting
                else if (PlanTypeName == cv.LifeADDLOC || PlanTypeName == cv.VoluntaryLifeADDLOC)
                {
                    if (i == 2)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
            }
            oWordDoc.Tables[TableNo_FirstTable].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="NumberofPlan">string NumberofPlan Object</param>
        /// <param name="selectedColor">string selectedColor Object (Optional Parameter)</param>
        /// <param name="MedicalBenefitColumnId_Tier3">ArrayList MedicalBenefitColumnId_Tier3 Object (Optional Parameter)</param>
        /// <param name="BenefitStructureDS">DataSet BenefitStructureDS Object (Optional Parameter)</param>
        public void WriteMedicalSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan, string selectedColor = "", ArrayList MedicalBenefitColumnId_Tier3 = null, DataSet BenefitStructureDS = null)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(3, "45");        //Calendar Year Deductible indivisual
                HashtableMedicalInNetwork1.Add(4, "44");        //Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(6, "112");       //General Plan Information Coinsurence
                HashtableMedicalInNetwork1.Add(8, "53");        //Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedicalInNetwork1.Add(9, "52");        //Calendar Year Out of Pocket Maximum(Family)
                HashtableMedicalInNetwork1.Add(11, "386");      //Physician Office Visit (Primary)
                HashtableMedicalInNetwork1.Add(12, "414");      //Specialists Office Visit
                HashtableMedicalInNetwork1.Add(14, "16");       //Preventive Care
                HashtableMedicalInNetwork1.Add(16, "168");      //Lab and Care (Diagnostic X-Ray and Lab Tests)
                HashtableMedicalInNetwork1.Add(17, "971");      //Other Services[Complex Radiology]
                HashtableMedicalInNetwork1.Add(19, "295");      //Inpatient Hospitalization
                HashtableMedicalInNetwork1.Add(20, "409");      //Outpatient Hospitalization
                HashtableMedicalInNetwork1.Add(22, "184");      //Emergency Room
                HashtableMedicalInNetwork1.Add(24, "555");      //Urgent Care
                #endregion

                #region HashtableMedicalOutNetwork
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedicalOutNetwork.Add(3, "45");        //Calendar Year Deductible indivisual
                HashtableMedicalOutNetwork.Add(4, "44");        //Calendar Year Deductible Family
                HashtableMedicalOutNetwork.Add(6, "112");       //General Plan Information Coinsurence
                HashtableMedicalOutNetwork.Add(8, "53");        //Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedicalOutNetwork.Add(9, "52");        //Calendar Year Out of Pocket Maximum(Family)
                HashtableMedicalOutNetwork.Add(11, "386");      //Physician Office Visit (Primary)
                HashtableMedicalOutNetwork.Add(12, "414");      //Specialists Office Visit
                HashtableMedicalOutNetwork.Add(14, "16");       //Preventive Care
                HashtableMedicalOutNetwork.Add(16, "168");      //Lab and Care (Diagnostic X-Ray and Lab Tests)
                HashtableMedicalOutNetwork.Add(17, "971");      //Other Services[Complex Radiology]
                HashtableMedicalOutNetwork.Add(19, "295");      //Inpatient Hospitalization
                HashtableMedicalOutNetwork.Add(20, "409");      //Outpatient Hospitalization
                HashtableMedicalOutNetwork.Add(24, "555");      //Urgent Care
                #endregion

                #region HashtableMedical_Tier3
                Hashtable HashtableMedical_Tier3 = new Hashtable();
                HashtableMedical_Tier3.Add(3, "45");        //Calendar Year Deductible indivisual
                HashtableMedical_Tier3.Add(4, "44");        //Calendar Year Deductible Family
                HashtableMedical_Tier3.Add(6, "112");       //General Plan Information Coinsurence
                HashtableMedical_Tier3.Add(8, "53");        //Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedical_Tier3.Add(9, "52");        //Calendar Year Out of Pocket Maximum(Family)
                HashtableMedical_Tier3.Add(11, "386");      //Physician Office Visit (Primary)
                HashtableMedical_Tier3.Add(12, "414");      //Specialists Office Visit
                HashtableMedical_Tier3.Add(14, "16");       //Preventive Care
                HashtableMedical_Tier3.Add(16, "168");      //Lab and Care (Diagnostic X-Ray and Lab Tests)
                HashtableMedical_Tier3.Add(17, "971");      //Other Services[Complex Radiology]
                HashtableMedical_Tier3.Add(19, "295");      //Inpatient Hospitalization
                HashtableMedical_Tier3.Add(20, "409");      //Inpatient Hospitalization
                HashtableMedical_Tier3.Add(24, "555");      //Urgent Care
                #endregion

                int count = 1;

                int TableNo_FirstTable = 2;
                ArrayList arrPlanTypeIds = new ArrayList();

                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                ConstantValue cv = new ConstantValue();
                int tblCnt = 2;
                int colCnt = 2;
                string Carrier = "";
                string OldCarrier = "";
                ArrayList arrCarrierName = new ArrayList();
                ArrayList arrPlanNumber = new ArrayList();
                string planNumber = string.Empty;

                if (BenefitStructureDS != null)
                {
                    if (BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count > 0)
                    {
                        // Get the plan numbers
                        for (int i = 0; i < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; i++)
                        {
                            planNumber = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[i][4]);
                            if (!arrPlanNumber.Contains(planNumber) && (Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[i][0]) == cv.MedicalLOC))
                            {
                                arrPlanNumber.Add(planNumber);
                            }
                        }

                        // Iterate through the plan number's ArrayList to check how many columns to be added for each plans
                        for (int k = 0; k < arrPlanNumber.Count; k++)
                        {
                            colCnt = 2;
                            for (int j = 0; j < BenefitStructureDS.Tables["BenefitColumnsTable"].Rows.Count; j++)
                            {
                                if ((Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][4]).Trim() == Convert.ToString(arrPlanNumber[k]).Trim() && (Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][0]) == cv.MedicalLOC)))
                                {
                                    oWordDoc.Tables[tblCnt].Columns.Add();
                                    oWordDoc.Tables[tblCnt].Cell(1, colCnt).Select();
                                    // Give a column heading
                                    oWordDoc.Tables[tblCnt].Cell(1, colCnt).Range.Text = Convert.ToString(BenefitStructureDS.Tables["BenefitColumnsTable"].Rows[j][3]);
                                    oWordDoc.Tables[tblCnt].Columns[colCnt].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                    colCnt++;
                                }
                            }
                            oWordDoc.Tables[tblCnt].PreferredWidth = oWordApp.InchesToPoints(7.00f);
                            tblCnt = tblCnt + 2;
                        }
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region MedicalTable

                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                if (OldCarrier == "")
                                {
                                    Carrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                                    arrCarrierName.Add(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim());
                                }
                                else
                                {
                                    if (!arrCarrierName.Contains(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim()))
                                    {
                                        Carrier = Carrier + " and " + (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim()) + " ";
                                        arrCarrierName.Add(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim());
                                    }
                                }
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            }

                            if (count == 1)
                            {
                                TableNo_FirstTable = 2;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                            }
                            if (count == 2)
                            {
                                TableNo_FirstTable = 4;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                            }
                            if (count == 3)
                            {
                                TableNo_FirstTable = 6;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                            }
                            if (count == 4)
                            {
                                TableNo_FirstTable = 8;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                            }
                            if (count == 5)
                            {
                                TableNo_FirstTable = 10;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                            }
                            if (count == 6)
                            {
                                TableNo_FirstTable = 12;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                            }

                            oWordDoc.Tables[TableNo_FirstTable].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                            foreach (int key in HashtableMedicalInNetwork1.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        if (key == 6 || key == 14 || key == 22 || key == 24)
                                        { }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.ListFormat.ApplyBulletDefault();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableMedicalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                                    {
                                        oWordDoc.Tables[TableNo_FirstTable].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        if (key == 6 || key == 14 || key == 22 || key == 24)
                                        { }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 3).Range.ListFormat.ApplyBulletDefault();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableMedical_Tier3.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnId_Tier3.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical_Tier3[key].ToString())
                                    {
                                        oWordDoc.Tables[TableNo_FirstTable].Cell(key, 4).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        if (key == 6 || key == 14 || key == 22 || key == 24)
                                        { }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 4).Range.ListFormat.ApplyBulletDefault();
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region MergeField

                            int iTotalFields = 0;

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (count == 1)
                                    {
                                        if (fieldName.Contains("Medical Plan Carrier1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                            continue;
                                        }
                                    }

                                    if (count > 1)
                                    {
                                        if (fieldName.Contains("More than one Medical plan"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (count == 2)
                                    {
                                        if (fieldName.Contains("Medical Plan 2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                    if (count == 3)
                                    {
                                        if (fieldName.Contains("Medical Plan 3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (count == 4)
                                    {
                                        if (fieldName.Contains("Medical Plan 4"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (count == 5)
                                    {
                                        if (fieldName.Contains("Medical Plan 5"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (count == 6)
                                    {
                                        if (fieldName.Contains("Medical Plan 6"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region Code for Merging the rows
                            for (int rowNum = 1; rowNum <= oWordDoc.Tables[TableNo_FirstTable].Rows.Count; rowNum++)
                            {
                                if (rowNum == 7 || rowNum == 15 || rowNum == 25 || rowNum == 30)
                                {
                                    for (int columnNum = 1; columnNum <= oWordDoc.Tables[TableNo_FirstTable].Columns.Count; columnNum++)
                                    {
                                        oWordDoc.Tables[TableNo_FirstTable].Rows[rowNum].Cells.Merge();
                                        oWordDoc.Tables[TableNo_FirstTable].Rows[rowNum].Cells[1].Range.Text = oWordDoc.Tables[TableNo_FirstTable].Rows[rowNum].Cells[1].Range.Text.Replace("\r", " ");
                                        break;
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }

                int iTotalFields1 = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields1++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Carrier Name Multiple"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier.Trim());
                        }
                        if (count == 2)
                        {
                            if (fieldName.Contains("Single Medical Plan"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePrescriptionDrugsSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, ArrayList MedicalBenefitColumnId_Tier3 = null)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string PreferredSpecialty = "";
                string Maximum_Day_Supply = string.Empty;

                int colcount = 2;

                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");    //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "881");   //Prescription Categories[Preferred Specialty]
                HashtablePrescriptionDrugs.Add(5, "380");//Prescription Categories[Maximum Day Supply]
                #endregion

                #region HashtablePrescriptionDrugs_OutNetwork
                Hashtable HashtablePrescriptionDrugs_OutNetwork = new Hashtable();
                HashtablePrescriptionDrugs_OutNetwork.Add(1, "213");    //Prescription Categories[Generic]
                HashtablePrescriptionDrugs_OutNetwork.Add(2, "78");     //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(3, "84");     //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(4, "881");    //Prescription Categories[Preferred Specialty]
                // HashtablePrescriptionDrugs_OutNetwork.Add(4, "380");//Prescription Categories[Maximum Day Supply]
                #endregion

                #region HashtablePrescriptionDrugs_Tier3
                Hashtable HashtablePrescriptionDrugs_Tier3 = new Hashtable();
                HashtablePrescriptionDrugs_Tier3.Add(1, "213");    //Prescription Categories[Generic]
                HashtablePrescriptionDrugs_Tier3.Add(2, "78");     //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs_Tier3.Add(3, "84");     //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs_Tier3.Add(4, "881");    //Prescription Categories[Preferred Specialty]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211");   //Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");    //Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");    //Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "884");   //Mail Order[Preferred Specialty]
                #endregion

                #region MailOrder_OutNetwork
                Hashtable HashtableMailOrder_OutNetwork = new Hashtable();
                HashtableMailOrder_OutNetwork.Add(1, "211");    //Mail Order[Generic]
                HashtableMailOrder_OutNetwork.Add(2, "76");     //Mail Order[Formulary]
                HashtableMailOrder_OutNetwork.Add(3, "82");     //Mail Order[Non Formulary]
                HashtableMailOrder_OutNetwork.Add(4, "884");    //Mail Order[Preferred Specialty]
                //HashtableMailOrder_OutNetwork.Add(5, "378");//Mail Order[Maximum Day Supply]
                #endregion

                #region MailOrder_Tier3
                Hashtable HashtableMailOrder_Tier3 = new Hashtable();
                HashtableMailOrder_Tier3.Add(1, "211");    //Mail Order[Generic]
                HashtableMailOrder_Tier3.Add(2, "76");     //Mail Order[Formulary]
                HashtableMailOrder_Tier3.Add(3, "82");     //Mail Order[Non Formulary]
                HashtableMailOrder_Tier3.Add(4, "884");    //Mail Order[Preferred Specialty]
                #endregion

                int tableNumber = 2;


                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    # region Priscription Drugs IN_Network

                    value = "";
                    Generic = "";
                    Formulary = "";
                    NonFormulary = "";
                    Maximum_Day_Supply = "";

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value; break;
                                            case 5: Maximum_Day_Supply = dr["value"].ToString(); break;
                                        }
                                    }
                                }
                            }

                            if (count == 1)
                            {
                                tableNumber = 2;
                            }
                            else if (count == 2)
                            {
                                tableNumber = 4;
                            }
                            else if (count == 3)
                            {
                                tableNumber = 6;
                            }
                            else if (count == 4)
                            {
                                tableNumber = 8;
                            }
                            else if (count == 5)
                            {
                                tableNumber = 10;
                            }
                            else if (count == 6)
                            {
                                tableNumber = 12;
                            }

                            oWordDoc.Tables[tableNumber].Cell(25, 1).Range.Text = "Prescription Drugs (Retail up to " + Maximum_Day_Supply + " day supply)";  //row 25
                            oWordDoc.Tables[tableNumber].Cell(26, colcount).Range.Text = Generic;             //row 26
                            oWordDoc.Tables[tableNumber].Cell(27, colcount).Range.Text = Formulary;           //row 27
                            oWordDoc.Tables[tableNumber].Cell(28, colcount).Range.Text = NonFormulary;        //row 28
                            oWordDoc.Tables[tableNumber].Cell(29, colcount).Range.Text = PreferredSpecialty;  //row 29

                            oWordDoc.Tables[tableNumber].Cell(26, colcount).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[tableNumber].Cell(27, colcount).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[tableNumber].Cell(28, colcount).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[tableNumber].Cell(29, colcount).Range.ListFormat.ApplyBulletDefault();
                    #endregion

                            # region Priscription Drugs Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";

                            foreach (int key in HashtablePrescriptionDrugs_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }

                            //if (count == 1)
                            //{
                            if (oWordDoc.Tables[tableNumber].Columns.Count > 2)
                            {
                                oWordDoc.Tables[tableNumber].Cell(26, 3).Range.Text = Generic;             //row 26
                                oWordDoc.Tables[tableNumber].Cell(27, 3).Range.Text = Formulary;           //row 27
                                oWordDoc.Tables[tableNumber].Cell(28, 3).Range.Text = NonFormulary;        //row 28
                                oWordDoc.Tables[tableNumber].Cell(29, 3).Range.Text = PreferredSpecialty;  //row 29

                                oWordDoc.Tables[tableNumber].Cell(26, 3).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(27, 3).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(28, 3).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(29, 3).Range.ListFormat.ApplyBulletDefault();
                            }
                            //}
                            //if (count == 2)
                            //{
                            //    if (oWordDoc.Tables[4].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[4].Cell(25, 3).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[4].Cell(26, 3).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[4].Cell(27, 3).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[4].Cell(28, 3).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[4].Cell(25, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(26, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(27, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(28, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 3)
                            //{
                            //    if (oWordDoc.Tables[6].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[6].Cell(25, 3).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[6].Cell(26, 3).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[6].Cell(27, 3).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[6].Cell(28, 3).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[6].Cell(25, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(26, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(27, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(28, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 4)
                            //{
                            //    if (oWordDoc.Tables[8].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[8].Cell(25, 3).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[8].Cell(26, 3).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[8].Cell(27, 3).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[8].Cell(28, 3).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[8].Cell(25, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(26, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(27, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(28, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 5)
                            //{
                            //    if (oWordDoc.Tables[10].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[10].Cell(25, 3).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[10].Cell(26, 3).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[10].Cell(27, 3).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[10].Cell(28, 3).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[10].Cell(25, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(26, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(27, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(28, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 6)
                            //{
                            //    if (oWordDoc.Tables[12].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[12].Cell(25, 3).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[12].Cell(26, 3).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[12].Cell(27, 3).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[12].Cell(28, 3).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[12].Cell(25, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(26, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(27, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(28, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}

                            #endregion

                            # region Priscription Drugs Tier 3

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";

                            foreach (int key in HashtablePrescriptionDrugs_Tier3.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnId_Tier3.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_Tier3[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }

                            //if (count == 1)
                            //{
                            if (oWordDoc.Tables[tableNumber].Columns.Count > 3)
                            {
                                oWordDoc.Tables[tableNumber].Cell(26, 4).Range.Text = Generic;             //row 26
                                oWordDoc.Tables[tableNumber].Cell(27, 4).Range.Text = Formulary;           //row 27
                                oWordDoc.Tables[tableNumber].Cell(28, 4).Range.Text = NonFormulary;        //row 28
                                oWordDoc.Tables[tableNumber].Cell(29, 4).Range.Text = PreferredSpecialty;  //row 29

                                oWordDoc.Tables[tableNumber].Cell(26, 4).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(27, 4).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(28, 4).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(29, 4).Range.ListFormat.ApplyBulletDefault();
                            }
                            //}
                            //if (count == 2)
                            //{
                            //    if (oWordDoc.Tables[4].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[4].Cell(25, 4).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[4].Cell(26, 4).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[4].Cell(27, 4).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[4].Cell(28, 4).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[4].Cell(25, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(26, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(27, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(28, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 3)
                            //{
                            //    if (oWordDoc.Tables[6].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[6].Cell(25, 4).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[6].Cell(26, 4).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[6].Cell(27, 4).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[6].Cell(28, 4).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[6].Cell(25, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(26, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(27, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(28, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 4)
                            //{
                            //    if (oWordDoc.Tables[8].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[8].Cell(25, 4).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[8].Cell(26, 4).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[8].Cell(27, 4).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[8].Cell(28, 4).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[8].Cell(25, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(26, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(27, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(28, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 5)
                            //{
                            //    if (oWordDoc.Tables[10].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[10].Cell(25, 4).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[10].Cell(26, 4).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[10].Cell(27, 4).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[10].Cell(28, 4).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[10].Cell(25, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(26, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(27, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(28, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 6)
                            //{
                            //    if (oWordDoc.Tables[12].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[12].Cell(25, 4).Range.Text = Generic;             //row 25
                            //        oWordDoc.Tables[12].Cell(26, 4).Range.Text = Formulary;           //row 26
                            //        oWordDoc.Tables[12].Cell(27, 4).Range.Text = NonFormulary;        //row 27
                            //        oWordDoc.Tables[12].Cell(28, 4).Range.Text = PreferredSpecialty;  //row 28

                            //        oWordDoc.Tables[12].Cell(25, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(26, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(27, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(28, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}

                            #endregion

                            #region Mail Order In_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";

                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            //if (count == 1)
                            //{
                            oWordDoc.Tables[tableNumber].Cell(31, 2).Range.Text = Generic;                //row 31
                            oWordDoc.Tables[tableNumber].Cell(32, 2).Range.Text = Formulary;              //row 32
                            oWordDoc.Tables[tableNumber].Cell(33, 2).Range.Text = NonFormulary;           //row 33
                            oWordDoc.Tables[tableNumber].Cell(34, 2).Range.Text = PreferredSpecialty;     //row 34

                            oWordDoc.Tables[tableNumber].Cell(31, 2).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[tableNumber].Cell(32, 2).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[tableNumber].Cell(33, 2).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[tableNumber].Cell(34, 2).Range.ListFormat.ApplyBulletDefault();
                            //}
                            //if (count == 2)
                            //{
                            //    oWordDoc.Tables[4].Cell(30, 2).Range.Text = Generic;                //row 30
                            //    oWordDoc.Tables[4].Cell(31, 2).Range.Text = Formulary;              //row 31
                            //    oWordDoc.Tables[4].Cell(32, 2).Range.Text = NonFormulary;           //row 32
                            //    oWordDoc.Tables[4].Cell(33, 2).Range.Text = PreferredSpecialty;     //row 33

                            //    oWordDoc.Tables[4].Cell(30, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[4].Cell(31, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[4].Cell(32, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[4].Cell(33, 2).Range.ListFormat.ApplyBulletDefault();
                            //}
                            //if (count == 3)
                            //{
                            //    oWordDoc.Tables[6].Cell(30, 2).Range.Text = Generic;                //row 30
                            //    oWordDoc.Tables[6].Cell(31, 2).Range.Text = Formulary;              //row 31
                            //    oWordDoc.Tables[6].Cell(32, 2).Range.Text = NonFormulary;           //row 32
                            //    oWordDoc.Tables[6].Cell(33, 2).Range.Text = PreferredSpecialty;     //row 33

                            //    oWordDoc.Tables[6].Cell(30, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[6].Cell(31, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[6].Cell(32, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[6].Cell(33, 2).Range.ListFormat.ApplyBulletDefault();
                            //}
                            //if (count == 4)
                            //{
                            //    oWordDoc.Tables[8].Cell(30, 2).Range.Text = Generic;                //row 30
                            //    oWordDoc.Tables[8].Cell(31, 2).Range.Text = Formulary;              //row 31
                            //    oWordDoc.Tables[8].Cell(32, 2).Range.Text = NonFormulary;           //row 32
                            //    oWordDoc.Tables[8].Cell(33, 2).Range.Text = PreferredSpecialty;     //row 33

                            //    oWordDoc.Tables[8].Cell(30, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[8].Cell(31, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[8].Cell(32, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[8].Cell(33, 2).Range.ListFormat.ApplyBulletDefault();
                            //}
                            //if (count == 5)
                            //{
                            //    oWordDoc.Tables[10].Cell(30, 2).Range.Text = Generic;                //row 30
                            //    oWordDoc.Tables[10].Cell(31, 2).Range.Text = Formulary;              //row 31
                            //    oWordDoc.Tables[10].Cell(32, 2).Range.Text = NonFormulary;           //row 32
                            //    oWordDoc.Tables[10].Cell(33, 2).Range.Text = PreferredSpecialty;     //row 33

                            //    oWordDoc.Tables[10].Cell(30, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[10].Cell(31, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[10].Cell(32, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[10].Cell(33, 2).Range.ListFormat.ApplyBulletDefault();
                            //}
                            //if (count == 6)
                            //{
                            //    oWordDoc.Tables[12].Cell(30, 2).Range.Text = Generic;                //row 30
                            //    oWordDoc.Tables[12].Cell(31, 2).Range.Text = Formulary;              //row 31
                            //    oWordDoc.Tables[12].Cell(32, 2).Range.Text = NonFormulary;           //row 32
                            //    oWordDoc.Tables[12].Cell(33, 2).Range.Text = PreferredSpecialty;     //row 33

                            //    oWordDoc.Tables[12].Cell(30, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[12].Cell(31, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[12].Cell(32, 2).Range.ListFormat.ApplyBulletDefault();
                            //    oWordDoc.Tables[12].Cell(33, 2).Range.ListFormat.ApplyBulletDefault();
                            //}
                            #endregion

                            #region Mail Order Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";

                            foreach (int key in HashtableMailOrder_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            //if (count == 1)
                            //{
                            if (oWordDoc.Tables[tableNumber].Columns.Count > 2)
                            {
                                oWordDoc.Tables[tableNumber].Cell(31, 3).Range.Text = Generic;                //row 31
                                oWordDoc.Tables[tableNumber].Cell(32, 3).Range.Text = Formulary;              //row 32
                                oWordDoc.Tables[tableNumber].Cell(33, 3).Range.Text = NonFormulary;           //row 33
                                oWordDoc.Tables[tableNumber].Cell(34, 3).Range.Text = PreferredSpecialty;     //row 34

                                oWordDoc.Tables[tableNumber].Cell(31, 3).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(32, 3).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(33, 3).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(34, 3).Range.ListFormat.ApplyBulletDefault();
                            }
                            //}
                            //if (count == 2)
                            //{
                            //    if (oWordDoc.Tables[4].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[4].Cell(30, 3).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[4].Cell(31, 3).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[4].Cell(32, 3).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[4].Cell(33, 3).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[4].Cell(30, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(31, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(32, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(33, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 3)
                            //{
                            //    if (oWordDoc.Tables[6].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[6].Cell(30, 3).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[6].Cell(31, 3).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[6].Cell(32, 3).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[6].Cell(33, 3).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[6].Cell(30, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(31, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(32, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(33, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 4)
                            //{
                            //    if (oWordDoc.Tables[8].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[8].Cell(30, 3).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[8].Cell(31, 3).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[8].Cell(32, 3).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[8].Cell(33, 3).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[8].Cell(30, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(31, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(32, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(33, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 5)
                            //{
                            //    if (oWordDoc.Tables[10].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[10].Cell(30, 3).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[10].Cell(31, 3).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[10].Cell(32, 3).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[10].Cell(33, 3).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[10].Cell(30, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(31, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(32, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(33, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 6)
                            //{
                            //    if (oWordDoc.Tables[12].Columns.Count > 2)
                            //    {
                            //        oWordDoc.Tables[12].Cell(30, 3).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[12].Cell(31, 3).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[12].Cell(32, 3).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[12].Cell(33, 3).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[12].Cell(30, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(31, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(32, 3).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(33, 3).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            #endregion

                            #region Mail Order Tier 3

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";

                            foreach (int key in HashtableMailOrder_Tier3.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnId_Tier3.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_Tier3[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            //if (count == 1)
                            //{
                            if (oWordDoc.Tables[tableNumber].Columns.Count > 3)
                            {
                                oWordDoc.Tables[tableNumber].Cell(31, 4).Range.Text = Generic;                //row 31
                                oWordDoc.Tables[tableNumber].Cell(32, 4).Range.Text = Formulary;              //row 32
                                oWordDoc.Tables[tableNumber].Cell(33, 4).Range.Text = NonFormulary;           //row 33
                                oWordDoc.Tables[tableNumber].Cell(34, 4).Range.Text = PreferredSpecialty;     //row 34

                                oWordDoc.Tables[tableNumber].Cell(31, 4).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(32, 4).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(33, 4).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[tableNumber].Cell(34, 4).Range.ListFormat.ApplyBulletDefault();
                            }
                            //}
                            //if (count == 2)
                            //{
                            //    if (oWordDoc.Tables[4].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[4].Cell(30, 4).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[4].Cell(31, 4).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[4].Cell(32, 4).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[4].Cell(33, 4).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[4].Cell(30, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(31, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(32, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[4].Cell(33, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 3)
                            //{
                            //    if (oWordDoc.Tables[6].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[6].Cell(30, 4).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[6].Cell(31, 4).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[6].Cell(32, 4).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[6].Cell(33, 4).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[6].Cell(30, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(31, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(32, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[6].Cell(33, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 4)
                            //{
                            //    if (oWordDoc.Tables[8].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[8].Cell(30, 4).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[8].Cell(31, 4).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[8].Cell(32, 4).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[8].Cell(33, 4).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[8].Cell(30, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(31, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(32, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[8].Cell(33, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 5)
                            //{
                            //    if (oWordDoc.Tables[10].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[10].Cell(30, 4).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[10].Cell(31, 4).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[10].Cell(32, 4).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[10].Cell(33, 4).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[10].Cell(30, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(31, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(32, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[10].Cell(33, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            //if (count == 6)
                            //{
                            //    if (oWordDoc.Tables[12].Columns.Count > 3)
                            //    {
                            //        oWordDoc.Tables[12].Cell(30, 4).Range.Text = Generic;                //row 30
                            //        oWordDoc.Tables[12].Cell(31, 4).Range.Text = Formulary;              //row 31
                            //        oWordDoc.Tables[12].Cell(32, 4).Range.Text = NonFormulary;           //row 32
                            //        oWordDoc.Tables[12].Cell(33, 4).Range.Text = PreferredSpecialty;     //row 33

                            //        oWordDoc.Tables[12].Cell(30, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(31, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(32, 4).Range.ListFormat.ApplyBulletDefault();
                            //        oWordDoc.Tables[12].Cell(33, 4).Range.ListFormat.ApplyBulletDefault();
                            //    }
                            //}
                            #endregion

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// 
        public void WriteMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS, string selectedColor = "", DataSet BenefitDS = null)
        {
            try
            {
                int DentalCount = 0;
                int VisionCount = 0;

                //Effective dates of Medical plans
                string Medicaleffective1 = "";
                string Medicaleffective2 = "";
                string Medicaleffective3 = "";
                string Medicaleffective4 = "";
                string Medicaleffective5 = "";
                string Medicaleffective6 = "";

                //Contribution frequency variables
                string FrequencyMEdical1 = "";
                string FrequencyMEdical2 = "";
                string FrequencyMEdical3 = "";
                string FrequencyMEdical4 = "";
                string FrequencyMEdical5 = "";
                string FrequencyMEdical6 = "";
                string FrequencyDental = "";
                string Frequencyvision = "";


                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan4_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan5_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan6_Rate");
                PremiumTableWriteMedical.Columns.Add("Contribution_Id");
                PremiumTableWriteMedical.Columns.Add("RateID");
                PremiumTableWriteMedical.Columns.Add("contributionValueID");
                PremiumTableWriteMedical.Columns.Add("PlanNumber");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");
                PremiumTableWriteDental.Columns.Add("Plan3_Rate");
                PremiumTableWriteDental.Columns.Add("Plan4_Rate");
                PremiumTableWriteDental.Columns.Add("Plan5_Rate");
                PremiumTableWriteDental.Columns.Add("Plan6_Rate");
                PremiumTableWriteDental.Columns.Add("Contribution_Id");
                PremiumTableWriteDental.Columns.Add("RateID");
                PremiumTableWriteDental.Columns.Add("contributionValueID");
                PremiumTableWriteDental.Columns.Add("PlanNumber");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");
                PremiumTableWriteVision.Columns.Add("Plan3_Rate");
                PremiumTableWriteVision.Columns.Add("Plan4_Rate");
                PremiumTableWriteVision.Columns.Add("Plan5_Rate");
                PremiumTableWriteVision.Columns.Add("Plan6_Rate");
                PremiumTableWriteVision.Columns.Add("Contribution_Id");
                PremiumTableWriteVision.Columns.Add("RateID");
                PremiumTableWriteVision.Columns.Add("contributionValueID");
                PremiumTableWriteVision.Columns.Add("PlanNumber");

                int premTableMedical1 = 3;
                int dentalTableNo = 15;
                int visionTableNo = 17;
                ArrayList arrContributionID = new ArrayList();
                ArrayList arrContributionID_Vision = new ArrayList();
                int columnNum = 1;
                int visionColumnNum = 1;
                string strPlan_Contri1 = "";
                string strPlan_Contri2 = "";
                int DentalTableRowCounter = 2;
                int VisionTableRowCounter = 2;

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("contributionValueID", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    PremiumTable.Columns.Add("PlanNumber", typeof(string));

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                        {
                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()) && ContributionDS.Tables["ContributionValueTable"].Rows[j]["contribution_number"].ToString() == PlanTable.Rows[index]["PlanNumber"].ToString())
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];//Plan Name
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();//Rate tier ID
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();//Contribution Description(like EE ,Spouse)
                                PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();//Contribution values
                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionValueID"].ToString();//Contribution ValueId
                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();//Frequency
                                PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString();//Contribution Id
                                PremiumTable.Rows[premium_row_counter][11] = PlanTable.Rows[index]["PlanNumber"].ToString();
                                premium_row_counter++;
                            }

                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId_2"].ToString()) && ContributionDS.Tables["ContributionValueTable"].Rows[j]["contribution_number"].ToString() == PlanTable.Rows[index]["PlanNumber"].ToString())
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];//Plan Name
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();//Rate tier ID
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();//Contribution Description(like EE ,Spouse)
                                PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();//Contribution values
                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionValueID"].ToString();//Contribution ValueId
                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();//Frequency
                                PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString();//Contribution Id
                                PremiumTable.Rows[premium_row_counter][11] = PlanTable.Rows[index]["PlanNumber"].ToString();
                                premium_row_counter++;
                            }
                        }
                    }

                    #endregion

                    //DataTable dt = new DataTable();

                    //PremiumTable.DefaultView.Sort = "[contributionValueID] asc";
                    //dt = PremiumTable.DefaultView.ToTable(true);

                    //// Commented the "monthlycost != 0" condition on the request of Nicole on 07 April 2015 

                    ////// The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                    ////for (int k = 0; k < dt.Rows.Count; k++)
                    ////{
                    ////    if (Convert.ToDecimal(dt.Rows[k]["monthlycost"]) == 0)
                    ////    {
                    ////        dt.Rows[k].Delete();
                    ////        k = k - 1;
                    ////    }
                    ////}

                    //PremiumTable = dt;

                    DataTable dt1 = new DataTable();

                    PremiumTable.DefaultView.Sort = "[contributionValueID] asc";
                    //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt1 = PremiumTable.DefaultView.ToTable(true);

                    for (int k = 0; k < dt1.Rows.Count; k++)
                    {
                        if (Convert.ToDecimal(dt1.Rows[k]["monthlycost"]) == 0)
                        {
                            dt1.Rows[k].Delete();
                            k = k - 1;
                        }
                    }

                    PremiumTable = dt1;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            Medicaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical1 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1, PremiumTableWriteMedical, Medicaleffective1, 1, selectedColor, Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()), Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }
                        if (index == 1)
                        {
                            Medicaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical2 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1 + 2, PremiumTableWriteMedical, Medicaleffective1, 2, selectedColor, Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()), Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }
                        if (index == 2)
                        {
                            Medicaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical3 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1 + 4, PremiumTableWriteMedical, Medicaleffective1, 3, selectedColor, Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()), Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }
                        if (index == 3)
                        {
                            Medicaleffective4 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical4 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1 + 6, PremiumTableWriteMedical, Medicaleffective1, 4, selectedColor, Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()), Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }
                        if (index == 4)
                        {
                            Medicaleffective5 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical5 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1 + 8, PremiumTableWriteMedical, Medicaleffective1, 5, selectedColor, Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()), Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }
                        if (index == 5)
                        {
                            Medicaleffective6 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical6 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            WriteMedicalContributionValues(oWordDoc, oWordApp, premTableMedical1 + 10, PremiumTableWriteMedical, Medicaleffective1, 6, selectedColor, Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()), Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }

                        //GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                    }
                    #endregion

                    # region FillTable Dental


                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()); ;
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        }
                        if (DentalCount == 0)
                        {
                            //oWordDoc.Tables[dentalTableNo].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString());
                            GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteDental);
                            WriteDentalContributionValues(oWordDoc, oWordApp, dentalTableNo, ref columnNum, PremiumTableWriteDental, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter);
                        }
                        if (DentalCount == 1)
                        {
                            //oWordDoc.Tables[dentalTableNo].Cell(1, 4).Range.Text = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString());
                            PremiumTableWriteDental.Clear();
                            GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteDental);
                            WriteDentalContributionValues(oWordDoc, oWordApp, dentalTableNo, ref columnNum, PremiumTableWriteDental, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter);
                        }
                        if (DentalCount == 2)
                        {
                            //oWordDoc.Tables[dentalTableNo].Cell(1, 6).Range.Text = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString());
                            PremiumTableWriteDental.Clear();
                            GetPlanContribution(PremiumTable, 3, ref PremiumTableWriteDental);
                            WriteDentalContributionValues(oWordDoc, oWordApp, dentalTableNo, ref columnNum, PremiumTableWriteDental, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter);
                        }
                        if (PremiumTable.Rows.Count > 0)
                        {
                            FrequencyDental = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                        }

                        //GetPlanContribution(PremiumTable, DentalCount + 1, ref PremiumTableWriteDental);

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    //columnNum = 1;
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";

                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()); ;
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        }

                        if (VisionCount == 0)
                        {
                            //oWordDoc.Tables[visionTableNo].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim();
                            GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteVision);
                            WriteVisionContributionValues(oWordDoc, oWordApp, visionTableNo, ref visionColumnNum, PremiumTableWriteVision, 1, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter);
                        }
                        if (VisionCount == 1)
                        {
                            //oWordDoc.Tables[visionTableNo].Cell(1, 3).Range.Text = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim();
                            PremiumTableWriteVision.Clear();
                            GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteVision);
                            WriteVisionContributionValues(oWordDoc, oWordApp, visionTableNo, ref visionColumnNum, PremiumTableWriteVision, 2, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter);
                        }
                        if (VisionCount == 2)
                        {
                            //oWordDoc.Tables[visionTableNo].Cell(1, 4).Range.Text = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim();
                            PremiumTableWriteVision.Clear();
                            GetPlanContribution(PremiumTable, 3, ref PremiumTableWriteVision);
                            WriteVisionContributionValues(oWordDoc, oWordApp, visionTableNo, ref visionColumnNum, PremiumTableWriteVision, 3, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter);
                        }
                        if (PremiumTable.Rows.Count > 0)
                        {
                            Frequencyvision = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                        }
                        //GetPlanContribution(PremiumTable, VisionCount + 1, ref PremiumTableWriteVision);
                        VisionCount++;
                    }
                    #endregion
                }

                #region Dental Monthly Premium
                //int currentPlanNo = 0;
                //int oldPlanNo = 0;
                //string currentPlanNumber = "";
                //string oldPlanNumber = "";
                //int mm = 0;
                if (PremiumTableWriteDental != null && PremiumTableWriteDental.Rows.Count > 0)
                {
                    //int DentalTableRowCounter = 2;
                    //for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                    //{
                    //    if (!arrContributionID.Contains(PremiumTableWriteDental.Rows[i]["RateId"].ToString()))
                    //    {
                    //        arrContributionID.Add(PremiumTableWriteDental.Rows[i]["RateId"].ToString());
                    //        oWordDoc.Tables[dentalTableNo].Rows.Add();
                    //        oWordDoc.Tables[dentalTableNo].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString(); // Row Desc
                    //        DentalTableRowCounter++;
                    //    }

                    //    currentPlanNo = Convert.ToInt32(PremiumTableWriteDental.Rows[i]["Contribution_Id"]);
                    //    if (currentPlanNo != oldPlanNo)
                    //    {
                    //        oldPlanNo = currentPlanNo;
                    //        if (i == 0)
                    //        {
                    //            columnNum++;
                    //        }
                    //        else
                    //        {
                    //            if (!string.IsNullOrEmpty(strDentalPlan1_Contri2) || !string.IsNullOrEmpty(strDentalPlan2_Contri2) || !string.IsNullOrEmpty(strDentalPlan3_Contri2))
                    //            {
                    //                columnNum++;
                    //            }
                    //            else
                    //            {
                    //                columnNum = columnNum + 2;
                    //            }
                    //        }

                    //        currentPlanNumber = Convert.ToString(PremiumTableWriteDental.Rows[i]["PlanNumber"]);
                    //        if (currentPlanNumber != oldPlanNumber)
                    //        {
                    //            oldPlanNumber = currentPlanNumber;
                    //            mm++;
                    //        }
                    //    }

                    //    for (int rowNum = 1; rowNum <= oWordDoc.Tables[dentalTableNo].Rows.Count; rowNum++)
                    //    {
                    //        for (int colNum = 1; colNum <= oWordDoc.Tables[dentalTableNo].Columns.Count; colNum++)
                    //        {
                    //            if (oWordDoc.Tables[dentalTableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteDental.Rows[i]["RateHeader"].ToString())
                    //            {
                    //                oWordDoc.Tables[dentalTableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWriteDental.Rows[i][mm].ToString(); //Contri Cost
                    //                break;
                    //            }
                    //        }
                    //    }
                    //}
                    oWordDoc.Tables[dentalTableNo].Rows.Last.Delete();
                    oWordDoc.Tables[dentalTableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[dentalTableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                }
                //if (PremiumTableWriteDental != null && PremiumTableWriteDental.Rows.Count > 0)
                //{
                //    int DentalTableRowCounter = 2;
                //    int kk = 0;

                //    for (int d = 0; d < PremiumTableWriteDental.Rows.Count; d++)
                //    {
                //        if (kk > 0)
                //        {
                //            oWordDoc.Tables[dentalTableNo].Rows.Add();
                //        }
                //        oWordDoc.Tables[dentalTableNo].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[d][0].ToString();
                //        oWordDoc.Tables[dentalTableNo].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[d][1].ToString();
                //        oWordDoc.Tables[dentalTableNo].Cell(DentalTableRowCounter, 3).Range.Text = PremiumTableWriteDental.Rows[d][2].ToString();
                //        oWordDoc.Tables[dentalTableNo].Cell(DentalTableRowCounter, 4).Range.Text = PremiumTableWriteDental.Rows[d][3].ToString();
                //        DentalTableRowCounter++;
                //        kk++;
                //    }

                //    oWordDoc.Tables[dentalTableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                //    oWordDoc.Tables[dentalTableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                //    oWordDoc.Tables[dentalTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                //    oWordDoc.Tables[dentalTableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                //    oWordDoc.Tables[dentalTableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                //}
                #endregion

                #region Vision Monthly Premium
                //ArrayList arrValues = new ArrayList();
                arrContributionID.Clear();
                //mm = 0;
                columnNum = 1;
                if (PremiumTableWriteVision != null && PremiumTableWriteVision.Rows.Count > 0)
                {
                    //int VisionTableRowCounter = 2;
                    //for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                    //{
                    //    if (!arrContributionID.Contains(PremiumTableWriteVision.Rows[i]["RateId"].ToString()))
                    //    {
                    //        arrContributionID.Add(PremiumTableWriteVision.Rows[i]["RateId"].ToString());
                    //        oWordDoc.Tables[visionTableNo].Rows.Add();
                    //        oWordDoc.Tables[visionTableNo].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString(); // Row Desc
                    //        VisionTableRowCounter++;
                    //    }
                    //}

                    //for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                    //{
                    //    currentPlanNo = Convert.ToInt32(PremiumTableWriteVision.Rows[i]["Contribution_Id"]);
                    //    if (currentPlanNo != oldPlanNo)
                    //    {
                    //        oldPlanNo = currentPlanNo;
                    //        //rowcount = 1;
                    //        columnNum++;
                    //        mm++;
                    //    }

                    //    for (int rowNum = 1; rowNum <= oWordDoc.Tables[visionTableNo].Rows.Count; rowNum++)
                    //    {
                    //        for (int colNum = 1; colNum <= oWordDoc.Tables[visionTableNo].Columns.Count; colNum++)
                    //        {
                    //            if (oWordDoc.Tables[visionTableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteVision.Rows[i]["RateHeader"].ToString())
                    //            {
                    //                oWordDoc.Tables[visionTableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWriteVision.Rows[i][mm].ToString(); //Contri Cost

                    //                arrValues.Add(PremiumTableWriteVision.Rows[i]["RateID"].ToString());
                    //                break;
                    //            }
                    //        }
                    //    }
                    //}
                    oWordDoc.Tables[visionTableNo].Rows.Last.Delete();
                    oWordDoc.Tables[visionTableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                    oWordDoc.Tables[visionTableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    oWordDoc.Tables[visionTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[visionTableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                    oWordDoc.Tables[visionTableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                }

                //if (PremiumTableWriteVision != null && PremiumTableWriteVision.Columns.Count > 0)
                //{
                //    int VisionTableRowCounter = 2;
                //    int kk = 0;

                //    for (int d = 0; d < PremiumTableWriteVision.Rows.Count; d++)
                //    {
                //        if (kk > 0)
                //        {
                //            oWordDoc.Tables[visionTableNo].Rows.Add();
                //        }
                //        oWordDoc.Tables[visionTableNo].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[d][0].ToString();
                //        oWordDoc.Tables[visionTableNo].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[d][1].ToString();
                //        oWordDoc.Tables[visionTableNo].Cell(VisionTableRowCounter, 3).Range.Text = PremiumTableWriteVision.Rows[d][2].ToString();
                //        oWordDoc.Tables[visionTableNo].Cell(VisionTableRowCounter, 4).Range.Text = PremiumTableWriteVision.Rows[d][3].ToString();
                //        VisionTableRowCounter++;
                //        kk++;
                //    }

                //    oWordDoc.Tables[visionTableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                //    oWordDoc.Tables[visionTableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                //    oWordDoc.Tables[visionTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                //    oWordDoc.Tables[visionTableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                //    oWordDoc.Tables[visionTableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                //}
                #endregion

                #region Merge Fields
                int iTotalFields1 = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields1++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Frequency_Contribution_Med1"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical1.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical1);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med2"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical2.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med3"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical3.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical3);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med4"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical4.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical4);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med5"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical5.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical5);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }

                        }
                        if (fieldName.Contains("Frequency_Contribution_Med6"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical6.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical6);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Det"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyDental.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyDental);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Vision"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Frequencyvision.Trim()))
                            {
                                oWordApp.Selection.TypeText(Frequencyvision);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("");
                            }
                        }
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void WriteDentalContributionValues(Word.Document oWordDoc, Word.Application oWordApp, int dentalTableNo, ref int columnNum, DataTable PremiumTableWriteDental, int colNumber, ref ArrayList arrContributionID, string strDentalPlan_Contri1, string strDentalPlan_Contri2, ref int DentalTableRowCounter)
        {
            try
            {
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                bool isFirstContributionTaken = false;

                for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                {
                    if (!arrContributionID.Contains(PremiumTableWriteDental.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteDental.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[dentalTableNo].Rows.Add();
                        oWordDoc.Tables[dentalTableNo].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString(); // Row Desc
                        DentalTableRowCounter++;
                    }

                    currentPlanNo = Convert.ToInt32(PremiumTableWriteDental.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        columnNum++;

                        if (isFirstContributionTaken == false)
                        {
                            oWordDoc.Tables[dentalTableNo].Cell(1, columnNum).Range.Text = strDentalPlan_Contri1;
                            isFirstContributionTaken = true;
                        }
                        else
                        {
                            oWordDoc.Tables[dentalTableNo].Cell(1, columnNum).Range.Text = strDentalPlan_Contri2;
                        }
                    }

                    for (int rowNum = 1; rowNum <= oWordDoc.Tables[dentalTableNo].Rows.Count; rowNum++)
                    {
                        for (int colNum = 1; colNum <= oWordDoc.Tables[dentalTableNo].Columns.Count; colNum++)
                        {
                            if (oWordDoc.Tables[dentalTableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteDental.Rows[i]["RateHeader"].ToString())
                            {
                                oWordDoc.Tables[dentalTableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWriteDental.Rows[i][colNumber].ToString(); //Contri Cost
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void WriteVisionContributionValues(Word.Document oWordDoc, Word.Application oWordApp, int visionTableNo, ref int columnNum, DataTable PremiumTableWriteVision, int colNumber, ref ArrayList arrContributionID, string strVisionPlan_Contri1, string strVisionPlan_Contri2, ref int VisionTableRowCounter)
        {
            try
            {
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                //int DentalTableRowCounter = 2;
                bool isFirstContributionTaken = false;

                for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                {
                    if (!arrContributionID.Contains(PremiumTableWriteVision.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteVision.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[visionTableNo].Rows.Add();
                        oWordDoc.Tables[visionTableNo].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString(); // Row Desc
                        VisionTableRowCounter++;
                    }

                    currentPlanNo = Convert.ToInt32(PremiumTableWriteVision.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        columnNum++;

                        if (isFirstContributionTaken == false)
                        {
                            oWordDoc.Tables[visionTableNo].Cell(1, columnNum).Range.Text = strVisionPlan_Contri1;
                            isFirstContributionTaken = true;
                        }
                        else
                        {
                            oWordDoc.Tables[visionTableNo].Cell(1, columnNum).Range.Text = strVisionPlan_Contri2;
                        }
                    }

                    for (int rowNum = 1; rowNum <= oWordDoc.Tables[visionTableNo].Rows.Count; rowNum++)
                    {
                        for (int colNum = 1; colNum <= oWordDoc.Tables[visionTableNo].Columns.Count; colNum++)
                        {
                            if (oWordDoc.Tables[visionTableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteVision.Rows[i]["RateHeader"].ToString())
                            {
                                oWordDoc.Tables[visionTableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWriteVision.Rows[i][colNumber].ToString(); //Contri Cost
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void WriteMedicalContributionValues(Word.Document oWordDoc, Word.Application oWordApp, int tableNo, DataTable PremiumTableWriteMedical, string MedicalEffectiveDate, int colNumber, string selectedColor, string contributionName, string contributionName_2)
        {
            try
            {
                int MediCalTableRowCounter = 2; //Start row 
                int kk = 1;
                int oldPlanNo = 0;
                int currentPlanNo = 0;
                ArrayList arrContributionID = new ArrayList();
                ArrayList arrValues = new ArrayList();

                for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                {
                    currentPlanNo = Convert.ToInt32(PremiumTableWriteMedical.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;

                        if (kk > 1)
                        {
                            oWordDoc.Tables[tableNo].Columns.Add();
                            oWordDoc.Tables[tableNo].Columns[3].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                            oWordDoc.Tables[tableNo].Cell(1, 3).Range.Text = contributionName_2 + "\n" + "Effective: " + MedicalEffectiveDate;//Header Part
                            oWordDoc.Tables[tableNo].Cell(1, 3).PreferredWidth = oWordApp.InchesToPoints(2.00f);
                        }
                        oWordDoc.Tables[tableNo].Cell(1, 2).Range.Text = contributionName + "\n" + "Effective: " + MedicalEffectiveDate;//Header Part
                        oWordDoc.Tables[tableNo].Cell(1, 2).PreferredWidth = oWordApp.InchesToPoints(2.00f);
                        kk++;
                    }

                    //oWordDoc.Tables[tableNo].Rows.Alignment = WdRowAlignment.wdAlignRowCenter;

                    if (!arrContributionID.Contains(PremiumTableWriteMedical.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteMedical.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[tableNo].Rows.Add();
                        oWordDoc.Tables[tableNo].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString(); // Row Desc
                        MediCalTableRowCounter++;
                    }
                }

                MediCalTableRowCounter = 2;
                kk = 1;
                int rowcount = 1;
                int columnNum = 2;
                string OldRateDesc = "";
                currentPlanNo = 0;
                oldPlanNo = 0;
                for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                {
                    currentPlanNo = Convert.ToInt32(PremiumTableWriteMedical.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;

                        if (kk > 1)
                        {
                            rowcount = 1;
                            columnNum = 3;
                        }
                        kk++;
                    }
                    if (OldRateDesc != PremiumTableWriteMedical.Rows[i]["RateHeader"].ToString())
                    {
                        rowcount++;

                        OldRateDesc = PremiumTableWriteMedical.Rows[i]["RateHeader"].ToString();
                    }

                    if (currentPlanNo == Convert.ToInt32(PremiumTableWriteMedical.Rows[i]["Contribution_Id"]))
                    {
                        oWordDoc.Tables[tableNo].Cell(rowcount, columnNum).Range.Text = PremiumTableWriteMedical.Rows[i][colNumber].ToString();
                    }
                }

                oWordDoc.Tables[tableNo].Rows.Last.Delete();
                oWordDoc.Tables[tableNo].PreferredWidth = oWordApp.InchesToPoints(7.01f);

                oWordDoc.Tables[tableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[tableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[tableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[tableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[tableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void GetPlanContribution(DataTable PremiumTable, int planNumber, ref DataTable PremiumTableWritePlan)
        {
            try
            {
                for (int i = 0; i < PremiumTable.Rows.Count; i++)
                {
                    int flag = 0;
                    if (PremiumTable.Rows[i][1].ToString() == "8")
                    {
                        for (int c = 0; c < PremiumTableWritePlan.Rows.Count; c++)
                        {
                            if ((PremiumTableWritePlan.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString()) && (PremiumTableWritePlan.Rows[c][7].ToString() == PremiumTable.Rows[i][7].ToString()))
                            {
                                PremiumTableWritePlan.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                flag = 1;
                                break;
                            }
                        }
                        if (flag == 0)
                        {
                            DataRow dr = PremiumTableWritePlan.NewRow();
                            dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                            dr["Plan1_Rate"] = "";
                            dr["Plan2_Rate"] = "";
                            dr["Plan3_Rate"] = "";
                            dr["Plan4_Rate"] = "";
                            dr["Plan5_Rate"] = "";
                            dr["Plan6_Rate"] = "";
                            dr["Plan" + planNumber + "_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                            dr["Contribution_Id"] = PremiumTable.Rows[i][7].ToString();
                            dr["RateId"] = PremiumTable.Rows[i][1].ToString();
                            dr["contributionValueID"] = PremiumTable.Rows[i][4].ToString();
                            dr["PlanNumber"] = PremiumTable.Rows[i][11].ToString();
                            PremiumTableWritePlan.Rows.Add(dr);
                        }
                    }
                    else
                    {
                        for (int c = 0; c < PremiumTableWritePlan.Rows.Count; c++)
                        {
                            if (PremiumTableWritePlan.Rows[c][7].ToString() == PremiumTable.Rows[i][7].ToString())
                            {
                                if (PremiumTableWritePlan.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWritePlan.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                {
                                    PremiumTableWritePlan.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                    flag = 1;
                                    break;
                                }
                            }
                        }
                        if (flag == 0)
                        {
                            DataRow dr = PremiumTableWritePlan.NewRow();
                            dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                            dr["Plan1_Rate"] = "";
                            dr["Plan2_Rate"] = "";
                            dr["Plan3_Rate"] = "";
                            dr["Plan4_Rate"] = "";
                            dr["Plan5_Rate"] = "";
                            dr["Plan6_Rate"] = "";
                            dr["Plan" + planNumber + "_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                            dr["Contribution_Id"] = PremiumTable.Rows[i][7].ToString();
                            dr["RateId"] = PremiumTable.Rows[i][1].ToString();
                            dr["contributionValueID"] = PremiumTable.Rows[i][4].ToString();
                            dr["PlanNumber"] = PremiumTable.Rows[i][11].ToString();
                            PremiumTableWritePlan.Rows.Add(dr);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /* Plz do not delete this function, when will ask for rate values only then we need to delete comments for this function
        public void WriteMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int Medicalindex = 1;
                int Dentalindex = 2;
                int DentalCount = 0;
                int VisionCount = 0;

                //Effective dates of Medical plans
                string Medicaleffective1 = "";
                string Medicaleffective2 = "";
                string Medicaleffective3 = "";

                //Effective dates of Dental plans
                string Dentaleffective1 = "";
                string Dentaleffective2 = "";
                string Dentaleffective3 = "";

                //Effective dates of Vision Plans
                string Visioneffective1 = "";
                string Visioneffective2 = "";




                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");


                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");
                PremiumTableWriteDental.Columns.Add("Plan3_Rate");


                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");


                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {

                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));


                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                        {
                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                            {

                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                }
                                else
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = 0;
                                }
                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                {
                                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    {
                                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                        break;
                                    }
                                }
                                premium_row_counter++;
                            }
                        }
                    }

                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);
                    PremiumTable = dt;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            Medicaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }

                        }
                        if (index == 1)
                        {
                            Medicaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (index == 2)
                        {

                            Medicaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }


                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            Dentaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            Dentaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (DentalCount == 2)
                        {
                            Dentaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();//effective date
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            Visioneffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            Visioneffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium

                int MediCalTableRowCounter = 0;
                for (int d = 1; d < PremiumTableWriteMedical.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        MediCalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[6].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[6].Rows.Add();
                                }
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[9].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective2;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[9].Rows.Add();
                                }
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[12].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective3;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[12].Rows.Add();
                                }

                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;

                            }
                        }
                    }
                }
                #endregion

                #region Dental Monthly Premium

                int DentalTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteDental.Columns.Count; d++)
                {

                    if (d == 1)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[14].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[14].Rows.Add();
                                }
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[16].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[16].Rows.Add();
                                }
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[18].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[18].Rows.Add();
                                }
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion

                #region Vision Monthly Premium

                int VisionTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteVision.Columns.Count; d++)
                {

                    if (d == 1)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[20].Cell(1, 2).Range.Text = "Effective: " + Visioneffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[20].Rows.Add();
                                }
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[22].Cell(1, 2).Range.Text = "Effective: " + Visioneffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[22].Rows.Add();
                                }
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        */

        /// <summary>
        /// Write Voluntary Life Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteVoluntaryLifeMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, string selectedColor = "")
        {
            try
            {
                int count = 1;
                DataTable PremiumTable = new DataTable();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));

                int tableNoVolLifeRates = 25;
                string dependent_child_rate_1 = " ";
                string dependent_child_rate_2 = " ";

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        PremiumTable.Clear();
                        premium_row_counter = 0;
                        if (count == 2)
                        {
                            tableNoVolLifeRates = 26;
                        }
                        int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }

                        #region For EE NonSmoker
                        oWordDoc.Tables[tableNoVolLifeRates].Cell(3, 1).Range.Text = "Under " + Start.ToString();
                        int StartValue = Start;
                        int RowCount = 4;
                        while (StartValue < End - 1)
                        {
                            oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                            if (StartValue == Start)
                            {
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                StartValue = Start + Interval;
                            }
                            else
                            {
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                StartValue = StartValue + Interval + 1;
                            }
                            RowCount++;
                        }
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                        oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                        oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount + 1, 1).Range.Text = "Composite";

                        int ColumnCount = 0;
                        DataTable dt = new DataTable();
                        bool isUniSmokerValueExists = false;
                        bool isSmokerValueExists = false;
                        bool isNonSmokerColumnInserted = false;

                        PremiumTable.DefaultView.Sort = "[ageBandIndex], [rateTierID] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 3;

                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                            {
                                isUniSmokerValueExists = true;
                                break;
                            }
                        }

                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (isUniSmokerValueExists == true)
                            {
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    isUniSmokerValueExists = true;
                                    ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 2).Range.Text = "Employee Uni-Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }
                            }
                            else if (isUniSmokerValueExists == false)
                            {
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE Smoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    ColumnCount = 2;
                                    isSmokerValueExists = true;
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 2).Range.Text = "Employee Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }

                                else if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE NonSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    // For inserting extra column
                                    if (isSmokerValueExists == true)
                                    {
                                        RowCount = RowCount - 1;
                                        ColumnCount = 3;
                                        if (isNonSmokerColumnInserted == false)
                                        {
                                            oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();
                                            oWordDoc.Tables[tableNoVolLifeRates].Columns[ColumnCount].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                            isNonSmokerColumnInserted = true;
                                        }
                                    }
                                    else
                                    {
                                        ColumnCount = 2;
                                    }

                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(1, ColumnCount).Range.Text = "Employee \n Non-Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }
                            }

                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Dependent Child Life")
                            {
                                if (count == 1)
                                {
                                    dependent_child_rate_1 = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                }
                                else if (count == 2)
                                {
                                    dependent_child_rate_2 = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                }
                            }
                        }
                        #endregion

                        #region For SpouseNonSmoker
                        /*  RowCount = 3;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse NonSmoker")
                            {
                                ColumnCount = 3;
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                RowCount++;
                            }

                        }*/
                        # endregion

                        oWordDoc.Tables[tableNoVolLifeRates].Range.Font.Color = comFunObj.font_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[2].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                        //oWordDoc.Tables[tableNoVolLifeRates].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                        if (isSmokerValueExists == true && isNonSmokerColumnInserted == true)
                        {

                            oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 2).Merge(oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 3));
                        }
                        oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 1).Merge(oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 1));
                        oWordDoc.Tables[tableNoVolLifeRates].PreferredWidth = oWordApp.InchesToPoints(3.44f);
                        count++;
                    }
                }

                #region merge fields
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Dependent Child Rate 1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dependent_child_rate_1);
                            continue;
                        }
                        if (fieldName.Contains("Dependent Child Rate 2"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dependent_child_rate_2);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary ADnD Rates Selected"))
                        {
                            if (count == 3)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteVoluntaryLifeToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, string selectedColor = "")
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string value = "";
                string EmployeeIssueAmt = "";
                string age = "";

                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(1, "188"); //Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(2, "187"); //Employee [Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(3, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(4, "518"); //Spouse[Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(5, "104"); //Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(6, "103"); //Child(ren)[Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(7, "2");   //age
                HashtableVoluntaryLifeADDBenifit.Add(8, "3");   //age
                HashtableVoluntaryLifeADDBenifit.Add(9, "4");   //age
                HashtableVoluntaryLifeADDBenifit.Add(10, "5");  //age

                #endregion
                string GuarenteeIssueAmtEmp = "";
                string GuarenteeIssueAmtSpouse = "";
                string GuarenteeIssueAmtChild = "";

                string OverallMaximumEmployee = "";
                string OverallMaximumSpouse = "";
                string OverallMaximumChild = "";

                bool isVolLife_Selected = false;
                bool isVolADnD_Selected = false;
                string planType = string.Empty;
                int tableNoVolLife = 24;

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoVolLife, selectedColor, cv.VoluntaryLifeADDLOC);
                oWordDoc.Tables[tableNoVolLife].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region VoluntaryLifeADDBenifitTable

                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                            {
                                isVolLife_Selected = true;
                                planType = cv.VoluntaryLifeADDLOC.ToLower().Trim().ToLower();
                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                            {
                                isVolADnD_Selected = true;
                                planType = cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower().Trim().ToLower();
                            }

                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == planType && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: OverallMaximumEmployee = value; break;
                                            case 2: GuarenteeIssueAmtEmp = value; break;
                                            case 3: OverallMaximumSpouse = value; break;
                                            case 4: GuarenteeIssueAmtSpouse = value; break;
                                            case 5: OverallMaximumChild = value; break;
                                            case 6: GuarenteeIssueAmtChild = value; break;
                                            case 187: EmployeeIssueAmt = value; break;
                                        }

                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                            case 3: if (value.Trim() != string.Empty) { age = "70"; } break;//70-74
                                            case 4: if (value.Trim() != string.Empty) { age = "75"; } break;//75-79
                                            case 5: if (value.Trim() != string.Empty) { age = "80"; } break;//80-84
                                            case 187: EmployeeIssueAmt = value; break;
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[tableNoVolLife].Cell(1, 1).Range.Text = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                            oWordDoc.Tables[tableNoVolLife].Cell(2, 1).Range.Text = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                            oWordDoc.Tables[tableNoVolLife].Cell(4, 2).Range.Text = OverallMaximumEmployee;
                            oWordDoc.Tables[tableNoVolLife].Cell(5, 2).Range.Text = GuarenteeIssueAmtEmp;

                            oWordDoc.Tables[tableNoVolLife].Cell(7, 2).Range.Text = OverallMaximumSpouse;
                            oWordDoc.Tables[tableNoVolLife].Cell(8, 2).Range.Text = GuarenteeIssueAmtSpouse;

                            oWordDoc.Tables[tableNoVolLife].Cell(10, 2).Range.Text = OverallMaximumChild;
                            oWordDoc.Tables[tableNoVolLife].Cell(11, 2).Range.Text = GuarenteeIssueAmtChild;

                            #endregion

                            count++;
                        }
                    }
                }

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("LifeADnD_Or_GroupTermLife_Or_ADnD_Selected"))
                        {
                            if (count > 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                        if (fieldName.Contains("delete volantary pagebreak bookmark"))
                        {
                            if (count > 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (fieldName.Contains("VoluntaryPlan1_Selected"))
                        {
                            if (count > 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                        if (isVolLife_Selected == true && isVolADnD_Selected == true)
                        {
                            if (fieldName.Contains("Voluntary Life and AD&D Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Voluntary Life and AD&D Insurance");
                                continue;
                            }
                        }
                        if (isVolLife_Selected == true && isVolADnD_Selected == false)
                        {
                            if (fieldName.Contains("Voluntary Life Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Voluntary Life Insurance");
                                continue;
                            }
                        }
                        if (isVolLife_Selected == false && isVolADnD_Selected == true)
                        {
                            if (fieldName.Contains("Voluntary AD&D Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Voluntary AD&D Insurance");
                                continue;
                            }
                        }
                        if (fieldName.Contains("Important Things to Consider"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Important Things to Consider");
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        /// <param name="GroupTermLifeBenefitColumnIdList">ArrayList GroupTermLifeBenefitColumnIdList contains Benefit ColumnId for Group Term Life (Optional Parameter).</param>
        /// <param name="ADDBenefitColumnIdList">ArrayList ADDBenefitColumnIdList contains Benefit ColumnId for ADD (Optional Parameter).</param>
        public void WriteLifeADDToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DataTable CarrierSpecific, string selectedColor = "", ArrayList GroupTermLifeBenefitColumnIdList = null, ArrayList ADDBenefitColumnIdList = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int iTotalFields = 0;

                int count = 0;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string value = "";

                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "186"); //Employee[Overall Maximum]

                #endregion

                string Life_and_ADND_Carrier1 = string.Empty;
                string Life_and_ADND_Carrier2 = string.Empty;
                string GroupTermLife_Carrier1 = string.Empty;
                string GroupTermLife_Carrier2 = string.Empty;
                string ADnD_Carrier1 = string.Empty;
                string ADnD_Carrier2 = string.Empty;

                string LifeAndADnD_SummaryName1 = string.Empty;
                string LifeAndADnD_SummaryName2 = string.Empty;
                string GroupTermLife_SummaryName1 = string.Empty;
                string GroupTermLife_SummaryName2 = string.Empty;
                string ADnD_SummaryName1 = string.Empty;
                string ADnD_SummaryName2 = string.Empty;

                int tableNoLifeADnD = 18;
                int tableNoGroupTermLife = 20;
                int tableNoADnDOnly = 22;

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoLifeADnD, selectedColor, cv.LifeADDLOC);
                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoLifeADnD + 1, selectedColor, cv.LifeADDLOC);
                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoGroupTermLife, selectedColor, cv.LifeADDLOC);
                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoGroupTermLife + 1, selectedColor, cv.LifeADDLOC);
                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoADnDOnly, selectedColor, cv.LifeADDLOC);
                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoADnDOnly + 1, selectedColor, cv.LifeADDLOC);
                oWordDoc.Tables[tableNoLifeADnD].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[tableNoLifeADnD + 1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[tableNoGroupTermLife].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[tableNoGroupTermLife + 1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[tableNoADnDOnly].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[tableNoADnDOnly + 1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {

                            #region GroupLifeADDBenifitTable
                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                }
                            }

                            if (count == 0)
                            {
                                if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                                {
                                    Life_and_ADND_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''"));
                                    LifeAndADnD_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    if (!string.IsNullOrEmpty(Life_and_ADND_Carrier1))
                                    {
                                        oWordDoc.Tables[tableNoLifeADnD].Cell(1, 1).Range.Text = Life_and_ADND_Carrier1;
                                    }
                                    oWordDoc.Tables[tableNoLifeADnD].Cell(2, 1).Range.Text = LifeAndADnD_SummaryName1;
                                    oWordDoc.Tables[tableNoLifeADnD].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                {
                                    GroupTermLife_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''"));
                                    GroupTermLife_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    if (!string.IsNullOrEmpty(GroupTermLife_Carrier1))
                                    {
                                        oWordDoc.Tables[tableNoGroupTermLife].Cell(1, 1).Range.Text = GroupTermLife_Carrier1;
                                    }
                                    oWordDoc.Tables[tableNoGroupTermLife].Cell(2, 1).Range.Text = GroupTermLife_SummaryName1;
                                    oWordDoc.Tables[tableNoGroupTermLife].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                {
                                    ADnD_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''"));
                                    ADnD_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    if (!string.IsNullOrEmpty(ADnD_Carrier1))
                                    {
                                        oWordDoc.Tables[tableNoADnDOnly].Cell(1, 1).Range.Text = ADnD_Carrier1;
                                    }
                                    oWordDoc.Tables[tableNoADnDOnly].Cell(2, 1).Range.Text = ADnD_SummaryName1;
                                    oWordDoc.Tables[tableNoADnDOnly].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                            }
                            else if (count == 1)
                            {
                                if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                                {
                                    Life_and_ADND_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''"));
                                    LifeAndADnD_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    if (!string.IsNullOrEmpty(Life_and_ADND_Carrier2))
                                    {
                                        oWordDoc.Tables[tableNoLifeADnD + 1].Cell(1, 1).Range.Text = Life_and_ADND_Carrier2;
                                    }
                                    oWordDoc.Tables[tableNoLifeADnD + 1].Cell(2, 1).Range.Text = LifeAndADnD_SummaryName2;
                                    oWordDoc.Tables[tableNoLifeADnD + 1].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                {
                                    GroupTermLife_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''"));
                                    GroupTermLife_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    if (!string.IsNullOrEmpty(GroupTermLife_Carrier2))
                                    {
                                        oWordDoc.Tables[tableNoGroupTermLife + 1].Cell(1, 1).Range.Text = GroupTermLife_Carrier2;
                                    }
                                    oWordDoc.Tables[tableNoGroupTermLife + 1].Cell(2, 1).Range.Text = GroupTermLife_SummaryName2;
                                    oWordDoc.Tables[tableNoGroupTermLife + 1].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                {
                                    ADnD_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''"));
                                    ADnD_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                    if (!string.IsNullOrEmpty(ADnD_Carrier2))
                                    {
                                        oWordDoc.Tables[tableNoADnDOnly + 1].Cell(1, 1).Range.Text = ADnD_Carrier2;
                                    }
                                    oWordDoc.Tables[tableNoADnDOnly + 1].Cell(2, 1).Range.Text = ADnD_SummaryName2;
                                    oWordDoc.Tables[tableNoADnDOnly + 1].Cell(3, 2).Range.Text = Convert.ToString(value);
                                }
                            }

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LifeADnD_Or_GroupTermLife_Or_ADnD_Selected"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }

                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                                    {
                                        if (fieldName.Contains("Life and Accidental Death & Dismemberment (AD&D) Insurance"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText("Life and Accidental Death & Dismemberment (AD&D) Insurance");
                                            continue;
                                        }
                                    }
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                    {
                                        if (fieldName.Contains("Group Term Life Insurance"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText("Group Term Life Insurance");
                                            continue;
                                        }
                                    }
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                    {
                                        if (fieldName.Contains("Group Accidental Death & Dismemberment (AD&D) Insurance"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText("Group Accidental Death & Dismemberment (AD&D) Insurance");
                                            continue;
                                        }
                                    }

                                    if (fieldName.Contains("Beneficiary"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Beneficiary");
                                        continue;
                                    }
                                }
                            }
                        }
                            #endregion
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        /// <param name="ddlLifeADD">DropDownList ddlLifeADD Object</param>
        /// <param name="ddlVoluntaryADD">DropDownList ddlVoluntaryADD Object</param>
        /// <param name="ddlMarketplaceCoverage">DropDownList ddlMarketplaceCoverage Object</param>
        /// <param name="ddlCreditableCoverage">DropDownList ddlCreditableCoverage Object</param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteNoticeSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlLifeADD, DropDownList ddlVoluntaryADD, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage, string selectedColor = "")
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                bool flag = false;
                bool flag1 = false;

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            //Added code by Vaibhav for Spanish
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlChipNotice.SelectedIndex >= 1)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Added by Vaibhav for spanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlChipNotice.SelectedIndex >= 1)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("Annual_Notice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                continue;
                            }
                        }

                        if (fieldName.Equals("OtherProducts"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("\f"); // For Inserting the page break before Annual Legal Notice
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }

                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (flag1 == true)
                                {
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    flag1 = false;
                                }

                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields
                // Comented by Vaibhav
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true, selectedColor, "Enrollment Summary");
                // Added by Vaibhav
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedColor, "Enrollment Summary");
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePlanCarrierTemplate3(Word.Document oWordDoc, Word.Application oWordApp)
        {
            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Plan_Carrier_Field"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(plan_carrier);
                    }
                }
            }

            #endregion
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="clientName">clientName contain selected client name</param>
        /// <param name="ddlHSAPlanName">ddlHSAPlanName contain selected HSA plan name</param>
        public void WriteHSASectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataTable CarrierSpecific, ArrayList HSABenefitColumnIdList, string clientName, DropDownList ddlHSAPlanName)
        {
            try
            {
                string carrier = string.Empty;
                string employeeOnlyCoverage = " ";
                string familyCoverage = " ";
                string employeesOver55 = " ";

                Hashtable HashtableHSABenifit = new Hashtable();

                string Max_Annual_Contribution_Individual1 = " ";
                string Max_Annual_Contribution_Family1 = " ";
                string value = "";

                #region HashtablHashtableHSA

                HashtableHSABenifit.Add(1, "635");     //General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSABenifit.Add(2, "636");     //General Plan Information – Maximum Annual Contribution/Family

                //HashtableHSABenifit.Add(1, "640");     //Employer Contributions – Individual
                //HashtableHSABenifit.Add(2, "644");     //Employer Contributions – Family
                #endregion

                // IRS
                DataTable dt_IRS = new DataTable();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            // Get the renewal year for taking the IRS table detail
                            string renewalDate = Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).Year);

                            dt_IRS = bp.GetIRCList(renewalDate);
                            carrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();

                            for (int j = 0; j < dt_IRS.Rows.Count; j++)
                            {
                                employeeOnlyCoverage = Convert.ToString(dt_IRS.Rows[j]["EmployeeOnlyCoverage"].ToString());

                                familyCoverage = Convert.ToString(dt_IRS.Rows[j]["FamilyCoverage"].ToString());
                                //employeesOver55 = Convert.ToString(dt_IRC.Rows[j]["EmployeesOver55"].ToString());
                            }

                            #region HSABenifitTable

                            foreach (int key in HashtableHSABenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.HSAPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSABenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Max_Annual_Contribution_Individual1 = value; break;
                                            case 2: Max_Annual_Contribution_Family1 = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion
                        }
                    }
                }



                #region merge fields
                int iTotalFields = 0;
                if (ddlHSAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("HSA Carrier"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(carrier))
                                {
                                    oWordApp.Selection.TypeText(carrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("IRS Employee Only coverage"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.TypeText(employeeOnlyCoverage);
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Individual1.Trim());
                                continue;
                            }
                            if (fieldName.Contains("IRS Family Coverage"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.TypeText(familyCoverage);
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Family1.Trim());
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlHRAPlanName">DropDownList ddlHRAPlanName Object</param>
        /// /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA Plan</param>
        public void WriteHRASectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlHRAPlanName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;
                string HRACarrier = string.Empty;

                #region HashtableHRA
                Hashtable HashtableHRA = new Hashtable();
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "239"); // Health Reimbursement Account Tier 2

                #endregion

                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_2 = string.Empty;

                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                HRACarrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();

                                foreach (int key in HashtableHRA.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                HRA_Tier_1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                HRA_Tier_2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #region merge fields
                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HRA Carrier Name"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRACarrier))
                                {
                                    oWordApp.Selection.TypeText(HRACarrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("HRA Tier One"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_1))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_1);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("HRA Tier Two"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_2))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_2);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        public void WriteFSASectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataTable PlanTypeSpecific, DataSet BenefitDS, ArrayList FSABenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                int count = 1;
                Hashtable HashtableFSA = new Hashtable();

                //DataRow[] foundPlanTypeRows = null;

                #region HashtableFSA
                HashtableFSA.Add(1, "354"); // Administration Services - Medical Spending Accounts - Maximum
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            //foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("FSA Plan Selected"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(" ");
                                                    continue;
                                                }
                                                if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                {
                                                    myMergeField.Select();
                                                    string administration_service_medicalspending = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                    if (administration_service_medicalspending.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(administration_service_medicalspending.Trim());
                                                    }
                                                    continue;
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP Plan</param>
        public void WriteEAPSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                Hashtable HashtableEAP = new Hashtable();

                #region HashtableEAP
                //HashtableEAP.Add(1, "384"); // Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("EAP Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("EAP Plan Selected"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEligibilityToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            string EmployeeType = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                    EmployeeType = Emp.Rows[0]["EmployeeTypes_type"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                //dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType

                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                    //{
                    //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                    //}
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("definition of employee"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus.Trim() + " " + EmployeeType.Trim() + " " + Working.Trim() + " " + UOM.Trim() + " " + Frequency.Trim());
                        else
                            myMergeField.Delete();
                        continue;
                    }

                    if (fieldName.Contains("unmarriedchildtoage"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("definitionofdomesticpartner"))
                    {
                        myMergeField.Select();
                        if (domesticPartner != string.Empty)
                            oWordApp.Selection.TypeText(domesticPartner);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("medicalplanwaitingperiod"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period.ToLower());
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }
    }
}
