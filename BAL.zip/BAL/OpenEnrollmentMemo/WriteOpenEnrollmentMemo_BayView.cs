﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using BenefitPointSummaryPortal.BAL.BenefitSummary;


namespace BenefitPointSummaryPortal.BAL.OpenEnrollmentMemo
{
    public class WriteOpenEnrollmentMemo_BayView
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        public enum ColorOptions { Grey, Black, Blue, USI_Blue, True_Blue, Green, Dark_Green, Bright_Green, Olive_Green, Red, Maroon, Dark_Red, Mustard, Orange, Purple, Light_Brown, Dark_Brown };
        public static List<string> ColorOptionList = new List<string>() { "Black", "Blue", "USI Blue", "True Blue", "Green", "Dark Green", "Bright Green", "Olive Green", "Red", "Maroon", "Dark Red", "Mustard", "Orange", "Purple", "Light Brown", "Dark Brown" };

        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }
        public void WriteCommonFieldsToOEMemo_BayView(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DateTime RenewalDate, DateTime OEStartDate, DateTime OEEndDate, string MobileAppCode)
        {
            try
            {
                int iTotalFields = 0;
                string RenwalYear = RenewalDate.Year.ToString();
                string RenewalMonthYearFormat = RenewalDate.ToString("MMMM yyyy");
                string CurrentDate = DateTime.Now.ToString("MMMM d, yyyy");
                string OEStartDateFormat = OEStartDate.ToString("MMMM d, yyyy");
                string OEEndDateFormat = OEEndDate.ToString("MMMM d, yyyy");

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;
                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("ClientName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ClientName))
                            {
                                oWordApp.Selection.TypeText(ClientName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("RenewalYear"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(RenwalYear))
                            {
                                oWordApp.Selection.TypeText(RenwalYear);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("CurrentDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(CurrentDate))
                            {
                                oWordApp.Selection.TypeText(CurrentDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("RenewalMonthYear"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(RenewalMonthYearFormat))
                            {
                                oWordApp.Selection.TypeText(RenewalMonthYearFormat);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("OEStartDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(OEStartDateFormat))
                            {
                                oWordApp.Selection.TypeText(OEStartDateFormat);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("OEEndDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(OEEndDateFormat))
                            {
                                oWordApp.Selection.TypeText(OEEndDateFormat);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("MobileAppCode"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MobileAppCode))
                            {
                                oWordApp.Selection.TypeText(MobileAppCode);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public void WriteBRCFieldsToOEMemo_BayView(Word.Document oWordDoc, Word.Application oWordApp, BRCData BRCData)
        {
            try
            {
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;
                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("BRCTimeZoneHours"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(BRCData.BRCDayHours.Trim()))
                            {
                                oWordApp.Selection.TypeText(BRCData.BRCDayHours.Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("BRCPhoneNumber"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(BRCData.BRCPhone.Trim()))
                            {
                                oWordApp.Selection.TypeText(BRCData.BRCPhone.Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("BRCEmail"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(BRCData.BRCEmail.Trim()))
                            {
                                oWordApp.Selection.TypeText(BRCData.BRCEmail.Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        public void WriteHeaderFieldToOEMemo_BayView(Word.Document oWordDoc, Word.Application oWordApp, DateTime RenewalYear)
        {
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("RenewalYear"))
                            {
                                field.Select();
                                if (!string.IsNullOrEmpty(RenewalYear.Year.ToString()))
                                {
                                    oWordApp.Selection.TypeText(RenewalYear.Year.ToString());
                                }
                                else
                                {
                                    field.Delete();
                                }
                                continue;
                            }
                        }
                    }
                }
            }
        }
        public void WriteFooterFieldToOEMemo_BayView(Word.Document oWordDoc, Word.Application oWordApp, DateTime RenewalYear)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("RenewalYear"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(RenewalYear.Year.ToString());
                                continue;
                            }
                        }
                    }
                }
            }
        }
        public void WriteContactInfoFieldToOEMemo_BayView(Word.Document oWordDoc, Word.Application oWordApp, string ContactName, string ContactPhoneNumber, string ContactEmail)
        {
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;
                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("ContactName"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(ContactName))
                        {
                            oWordApp.Selection.TypeText(ContactName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }
                    if (fieldName.Contains("ContactPhoneNumber"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(ContactPhoneNumber))
                        {
                            oWordApp.Selection.TypeText(ContactPhoneNumber);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }
                    if (fieldName.Contains("ContactEmail"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(ContactEmail))
                        {
                            oWordApp.Selection.TypeText(ContactEmail);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }
                }
            }

        }
        public void FillTextColor(Word.Document oWordDoc, Word.Application oWordApp, Word.WdColor TextBoxColor, Word.WdColor FontColor, Word.WdColor CellColor, DateTime RenewalYear, bool isHeaderFontColorChange = true)
        {
            foreach (Word.Shape shape in oWordDoc.Sections[1].Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Shapes)
            {
                shape.Select();

                if (shape.Name == "HeadBar")
                {
                    shape.Fill.ForeColor.RGB = (int)TextBoxColor;

                    #region Renewal year writing
                    foreach (Word.Field field in oWordApp.Selection.Range.Fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("RenewalYear"))
                            {
                                if (isHeaderFontColorChange == true)
                                {
                                    oWordApp.Selection.Range.Font.Color = FontColor;
                                }
                                field.Select();
                                oWordApp.Selection.TypeText(RenewalYear.Year.ToString());
                                continue;
                            }
                        }
                    }
                    #endregion
                }
                if (shape.Name == "SideBar")
                {
                    shape.Fill.ForeColor.RGB = (int)CellColor;
                }
                //oWordApp.Selection.Range.Font.Color = FontColor;
            }
            //oWordDoc.Content.Font.Color = WdColor.wdColorBlue;


            foreach (Word.Field field in oWordDoc.Fields)
            {
                Word.Range rngFieldCode = field.Code;
                string fieldText = rngFieldCode.Text;
                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Your Responsibilities During Open Enrollment"))
                    {
                        field.Select();
                        oWordApp.Selection.Range.Font.Color = FontColor;
                        oWordApp.Selection.TypeText("Your Responsibilities During Open Enrollment");
                        continue;
                    }
                    if (fieldName.Contains("Where to Find More Information"))
                    {
                        field.Select();
                        oWordApp.Selection.Range.Font.Color = FontColor;
                        oWordApp.Selection.TypeText("Where to Find More Information");
                        continue;
                    }
                    if (fieldName.Contains("USI Mobile App"))
                    {
                        field.Select();
                        oWordApp.Selection.Range.Font.Color = FontColor;
                        oWordApp.Selection.TypeText("USI Mobile App");
                        continue;
                    }
                    if (fieldName.Contains("Benefit Resource Center"))
                    {
                        field.Select();
                        oWordApp.Selection.Range.Font.Color = FontColor;
                        oWordApp.Selection.TypeText("Benefit Resource Center");
                        continue;
                    }
                    if (fieldName.Contains("Questions"))
                    {
                        field.Select();
                        oWordApp.Selection.Range.Font.Color = FontColor;
                        oWordApp.Selection.TypeText("Questions");
                        continue;
                    }
                }
            }

            if (oWordDoc.Bookmarks.Exists("headerfont"))
            {
                oWordDoc.Bookmarks["headerfont"].Range.Font.Color = FontColor;
            }

        }

        public WriteOpenEnrollmentMemo_BayView.ColorOptions CovertToColorOption(string ColorOption)
        {
            WriteOpenEnrollmentMemo_BayView.ColorOptions returnValue = ColorOptions.Grey;
            switch (ColorOption)
            {
                case "Gray(default)":
                    returnValue = ColorOptions.Grey;
                    break;
                case "Black":
                    returnValue = ColorOptions.Black;
                    break;
                case "Blue":
                    returnValue = ColorOptions.Blue;
                    break;
                case "USI Blue":
                    returnValue = ColorOptions.USI_Blue;
                    break;
                case "True Blue":
                    returnValue = ColorOptions.True_Blue;
                    break;
                case "Green":
                    returnValue = ColorOptions.Green;
                    break;
                case "Dark Green":
                    returnValue = ColorOptions.Dark_Green;
                    break;
                case "Bright Green":
                    returnValue = ColorOptions.Bright_Green;
                    break;
                case "Olive Green":
                    returnValue = ColorOptions.Olive_Green;
                    break;
                case "Red":
                    returnValue = ColorOptions.Red;
                    break;
                case "Maroon":
                    returnValue = ColorOptions.Maroon;
                    break;
                case "Dark Red":
                    returnValue = ColorOptions.Dark_Red;
                    break;
                case "Mustard":
                    returnValue = ColorOptions.Mustard;
                    break;
                case "Orange":
                    returnValue = ColorOptions.Orange;
                    break;
                case "Purple":
                    returnValue = ColorOptions.Purple;
                    break;
                case "Light Brown":
                    returnValue = ColorOptions.Light_Brown;
                    break;
                case "Dark Brown":
                    returnValue = ColorOptions.Dark_Brown;
                    break;
            }
            return returnValue;
        }
        public Word.WdColor GetTextBoxColor(WriteOpenEnrollmentMemo_BayView.ColorOptions color)
        {
            Color returnValue = Color.FromArgb(119, 119, 119);
            switch (color)
            {
                case ColorOptions.Grey:
                    returnValue = Color.FromArgb(119, 119, 119);
                    break;
                case ColorOptions.Black:
                    returnValue = Color.FromArgb(0, 0, 0);
                    break;
                case ColorOptions.Blue:
                    returnValue = Color.FromArgb(79, 128, 189);
                    break;
                case ColorOptions.USI_Blue:
                    returnValue = Color.FromArgb(9, 84, 155);
                    break;
                case ColorOptions.True_Blue:
                    returnValue = Color.FromArgb(0, 0, 255);
                    break;
                case ColorOptions.Green:
                    returnValue = Color.FromArgb(21, 95, 33);
                    break;
                case ColorOptions.Dark_Green:
                    returnValue = Color.FromArgb(0, 102, 0);
                    break;
                case ColorOptions.Bright_Green:
                    returnValue = Color.FromArgb(0, 153, 0);
                    break;
                case ColorOptions.Olive_Green:
                    returnValue = Color.FromArgb(131, 141, 9);
                    break;
                case ColorOptions.Red:
                    returnValue = Color.FromArgb(204, 0, 0);
                    break;
                case ColorOptions.Maroon:
                    returnValue = Color.FromArgb(105, 29, 29);
                    break;
                case ColorOptions.Dark_Red:
                    returnValue = Color.FromArgb(128, 0, 0);
                    break;
                case ColorOptions.Mustard:
                    returnValue = Color.FromArgb(212, 160, 15);
                    break;
                case ColorOptions.Orange:
                    returnValue = Color.FromArgb(255, 165, 0);
                    break;
                case ColorOptions.Purple:
                    returnValue = Color.FromArgb(102, 0, 102);
                    break;
                case ColorOptions.Light_Brown:
                    returnValue = Color.FromArgb(153, 102, 51);
                    break;
                case ColorOptions.Dark_Brown:
                    returnValue = Color.FromArgb(102, 51, 0);
                    break;
            }

            int rgb_textbox = ColorTranslator.ToOle(returnValue);
            Word.WdColor wdColor_textbox = (Word.WdColor)rgb_textbox;
            return wdColor_textbox;
        }
        public Word.WdColor GetTextBoxColor(string strColor)
        {
            WriteOpenEnrollmentMemo_BayView.ColorOptions color = CovertToColorOption(strColor);
            return GetTextBoxColor(color);
        }
        public Word.WdColor GetFontColor(WriteOpenEnrollmentMemo_BayView.ColorOptions color)
        {
            Color returnValue = Color.FromArgb(84, 84, 84);
            switch (color)
            {
                case ColorOptions.Grey:
                    returnValue = Color.FromArgb(84, 84, 84);
                    break;
                case ColorOptions.Black:
                    returnValue = Color.FromArgb(38, 38, 38);
                    break;
                case ColorOptions.Blue:
                    returnValue = Color.FromArgb(0, 68, 123);
                    break;
                case ColorOptions.USI_Blue:
                    returnValue = Color.FromArgb(6, 58, 106);
                    break;
                case ColorOptions.True_Blue:
                    returnValue = Color.FromArgb(0, 0, 192);
                    break;
                case ColorOptions.Green:
                    returnValue = Color.FromArgb(14, 62, 22);
                    break;
                case ColorOptions.Dark_Green:
                    returnValue = Color.FromArgb(0, 66, 0);
                    break;
                case ColorOptions.Bright_Green:
                    returnValue = Color.FromArgb(0, 96, 0);
                    break;
                case ColorOptions.Olive_Green:
                    returnValue = Color.FromArgb(63, 68, 4);
                    break;
                case ColorOptions.Red:
                    returnValue = Color.FromArgb(150, 0, 0);
                    break;
                case ColorOptions.Maroon:
                    returnValue = Color.FromArgb(63, 17, 17);
                    break;
                case ColorOptions.Dark_Red:
                    returnValue = Color.FromArgb(84, 0, 0);
                    break;
                case ColorOptions.Mustard:
                    returnValue = Color.FromArgb(118, 89, 8);
                    break;
                case ColorOptions.Orange:
                    returnValue = Color.FromArgb(172, 94, 0);
                    break;
                case ColorOptions.Purple:
                    returnValue = Color.FromArgb(100, 9, 125);
                    break;
                case ColorOptions.Light_Brown:
                    returnValue = Color.FromArgb(81, 54, 27);
                    break;
                case ColorOptions.Dark_Brown:
                    returnValue = Color.FromArgb(84, 42, 0);
                    break;
            }

            int rgb_textbox = ColorTranslator.ToOle(returnValue);
            Word.WdColor wdColor_font = (Word.WdColor)rgb_textbox;
            return wdColor_font;
        }
        public Word.WdColor GetFontColor(string strColor)
        {
            WriteOpenEnrollmentMemo_BayView.ColorOptions color = CovertToColorOption(strColor);
            return GetFontColor(color);
        }
        public Word.WdColor GetCellColor(WriteOpenEnrollmentMemo_BayView.ColorOptions color)
        {
            Color returnValue = Color.FromArgb(196, 196, 196);
            switch (color)
            {
                case ColorOptions.Grey:
                    returnValue = Color.FromArgb(196, 196, 196);
                    break;
                case ColorOptions.Black:
                    returnValue = Color.FromArgb(217, 217, 217);
                    break;
                case ColorOptions.Blue:
                    returnValue = Color.FromArgb(211, 223, 238);
                    break;
                case ColorOptions.USI_Blue:
                    returnValue = Color.FromArgb(140, 197, 248);
                    break;
                case ColorOptions.True_Blue:
                    returnValue = Color.FromArgb(163, 197, 251);
                    break;
                case ColorOptions.Green:
                    returnValue = Color.FromArgb(192, 239, 175);
                    break;
                case ColorOptions.Dark_Green:
                    returnValue = Color.FromArgb(0, 188, 0);
                    break;
                case ColorOptions.Bright_Green:
                    returnValue = Color.FromArgb(121, 255, 121);
                    break;
                case ColorOptions.Olive_Green:
                    returnValue = Color.FromArgb(223, 247, 147);
                    break;
                case ColorOptions.Red:
                    returnValue = Color.FromArgb(255, 143, 143);
                    break;
                case ColorOptions.Maroon:
                    returnValue = Color.FromArgb(237, 177, 177);
                    break;
                case ColorOptions.Dark_Red:
                    returnValue = Color.FromArgb(255, 125, 125);
                    break;
                case ColorOptions.Mustard:
                    returnValue = Color.FromArgb(245, 210, 11);
                    break;
                case ColorOptions.Orange:
                    returnValue = Color.FromArgb(255, 199, 97);
                    break;
                case ColorOptions.Purple:
                    returnValue = Color.FromArgb(224, 183, 255);
                    break;
                case ColorOptions.Light_Brown:
                    returnValue = Color.FromArgb(217, 178, 139);
                    break;
                case ColorOptions.Dark_Brown:
                    returnValue = Color.FromArgb(200, 144, 48);
                    break;
            }

            int rgb_textbox = ColorTranslator.ToOle(returnValue);
            Word.WdColor wdColor_font = (Word.WdColor)rgb_textbox;
            return wdColor_font;
        }
        public Word.WdColor GetCellColor(string strColor)
        {
            WriteOpenEnrollmentMemo_BayView.ColorOptions color = CovertToColorOption(strColor);
            return GetCellColor(color);
        }

        public void InsertImageToTemplateValue(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlImageOption, DropDownList ddlBRC, DropDownList ddlMobileAppStatus)
        {
            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Picture1"))
                    {
                        myMergeField.Delete();
                        Word.InlineShape inline_shape = null;

                        // Format the picture.
                        if (ddlMobileAppStatus.SelectedValue == "New")
                        {
                            inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 1", 2.07f, 1.51f);
                        }
                        else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code" || ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                        {
                            inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 2.07f, 1.51f);
                        }


                        if (inline_shape != null)
                        {
                            Word.Shape shape = inline_shape.ConvertToShape();

                            ////// Wrap text around the picture's square.
                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                            // make the realtive postion to page margin's.
                            shape.RelativeHorizontalPosition = WdRelativeHorizontalPosition.wdRelativeHorizontalPositionMargin;
                            // shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionMargin;

                            //Align picture to Bottom - Left
                            //shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                            shape.Top = (float)oWordApp.InchesToPoints(0.18f);
                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;


                        }
                        continue;
                    }
                    //if (fieldName.Contains("Picture2"))
                    //{
                    //    myMergeField.Delete();

                    //    // IF Both are not included then, - No need to insert pictre 2. since the document contains only 1 page
                    //    if (ddlIsMobileAppOffered.SelectedValue == "Yes" || ddlBRC.SelectedValue == "Yes")
                    //    {
                    //        // Format the picture.
                    //        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 2.07f, 1.51f);
                    //        if (inline_shape != null)
                    //        {
                    //            Word.Shape shape = inline_shape.ConvertToShape();

                    //            // Wrap text around the picture's square.
                    //            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                    //            // make the realtive postion to page margin's.
                    //            shape.RelativeHorizontalPosition = WdRelativeHorizontalPosition.wdRelativeHorizontalPositionMargin;
                    //            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionMargin;

                    //            //Align picture to TOP - Right
                    //            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                    //            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                    //        }
                    //    }

                    //    continue;
                    //}

                }
            }
        }

        public void InsertImageToTemplateEnrollment(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlImageOption, DropDownList ddlBRC, DropDownList ddlMobileAppStatus)
        {
            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Picture1"))
                    {
                        myMergeField.Delete();
                        Word.InlineShape inline_shape = null;

                        // Format the picture.
                        if (ddlMobileAppStatus.SelectedValue == "New")
                        {
                            inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 1", 2.31f, 1.58f);
                        }
                        else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code" || ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                        {
                            inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 2.31f, 1.58f);
                        }

                        if (inline_shape != null)
                        {
                            Word.Shape shape = inline_shape.ConvertToShape();

                            ////// Wrap text around the picture's square.
                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                            // make the realtive postion to page margin's.
                            shape.RelativeHorizontalPosition = WdRelativeHorizontalPosition.wdRelativeHorizontalPositionMargin;
                            //shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionMargin;

                            //Align picture to Bottom - Left
                            //shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                            //shape.Left = (float)Word.WdShapePosition.wdShapeRight;

                            shape.Top = (float)oWordApp.InchesToPoints(0.15f);
                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;


                        }
                        continue;
                    }
                    //if (fieldName.Contains("Picture2"))
                    //{
                    //    myMergeField.Delete();

                    //    // IF Both are not included then, - No need to insert pictre 2. since the document contains only 1 page
                    //    if (ddlIsMobileAppOffered.SelectedValue == "Yes" || ddlBRC.SelectedValue == "Yes")
                    //    {
                    //        // Format the picture.
                    //        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 2.31f, 1.58f);
                    //        if (inline_shape != null)
                    //        {
                    //            Word.Shape shape = inline_shape.ConvertToShape();

                    //            // Wrap text around the picture's square.
                    //            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                    //            // make the realtive postion to page margin's.
                    //            shape.RelativeHorizontalPosition = WdRelativeHorizontalPosition.wdRelativeHorizontalPositionMargin;
                    //            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionMargin;

                    //            //Align picture to TOP - Right
                    //            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                    //            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                    //        }
                    //    }

                    //    continue;
                    //}

                }
            }
        }

    }
}