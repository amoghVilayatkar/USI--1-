﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate5 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="Client">Seleted Client Id</param>
        /// <param name="AccountDS">Dataset AccountDS contain Account information for selected Client.</param>
        public void WriteFieldToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, string Client, DataSet AccountDS)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Client.ToString().Trim());
                                    }
                                    if (fieldName.Contains("Client Address 1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_street1"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Client Address 2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_street2"].ToString().Trim());
                                    }

                                    if (fieldName.Contains("Client City"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_city"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Client State"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_state"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Client Zip"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_zip"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Client Country"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_country"].ToString());
                                    }
                                    if (fieldName.Contains("Client Phone Number"))
                                    {
                                        int phone_num = 0;
                                        for (int i = 0; i < AccountDS.Tables["AccountCustomFieldValuesTable"].Rows.Count; i++)
                                        {
                                            //customFieldValues_customFieldID "16799" for client Phone. no.
                                            if (AccountDS.Tables["AccountCustomFieldValuesTable"].Rows[i]["customFieldValues_customFieldID"].ToString() == "16799")
                                            {
                                                phone_num = i;
                                            }
                                        }
                                        string phone = AccountDS.Tables["AccountCustomFieldValuesTable"].Rows[phone_num]["customFieldValues_valueText"].ToString();
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(phone);
                                    }
                                    if (fieldName.Contains("Client Fax"))
                                    {
                                        int fax_num = 0;
                                        for (int i = 0; i < AccountDS.Tables["AccountCustomFieldValuesTable"].Rows.Count; i++)
                                        {
                                            //customFieldValues_customFieldID "16800" for client Fax no.
                                            if (AccountDS.Tables["AccountCustomFieldValuesTable"].Rows[i]["customFieldValues_customFieldID"].ToString() == "16800")
                                            {
                                                fax_num = i;
                                            }
                                        }
                                        string fax = AccountDS.Tables["AccountCustomFieldValuesTable"].Rows[fax_num]["customFieldValues_valueText"].ToString();
                                        myMergeField.Select();
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(fax);
                                    }
                                    if (fieldName.Contains("Renewal Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[rowindex]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.Year.ToString().Trim());
                                    }
                                    if (fieldName.Contains("medicalplanwaitingperiod"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[rowindex]["item"].ToString().Trim());
                                        }
                                    }

                                    if (BRCindex > -1)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRCPhoneContact"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText("\nPhone: " + BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRCEmailContact"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" | " + BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                        }

                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRC Name"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCName.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCName.Trim());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteFSASectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableFSA = new Hashtable();
                DataRow[] foundRows = null;

                #region HashtableFSA
                HashtableFSA.Add(1, "150");//Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "592");//Administration Services – Grace Period
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString().Trim() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                }
                                                if (fieldName.Contains("Administration Services – Dependent Care Accounts-Maximum"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString().Trim() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                }
                                                if (fieldName.Contains("FSA Plan Carrier"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("Flexible Spending" + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                                }
                                                if (foundRows.Count() > 0)
                                                {
                                                    if (fieldName.Contains("FSA Carrier Website"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                                    }

                                                    if (fieldName.Contains("FSA Carrier Phone"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        ///  Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteEAPSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataTable CarrierSpecific)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;
                DataRow[] foundRows = null;
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("EAP Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                    }
                                    if (fieldName.Contains("EAP Carrier Contact"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Employee Assistance" + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }
                                    if (foundRows.Count() > 0)
                                    {
                                        if (fieldName.Contains("EAP Carrier Website"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                        }
                                        if (fieldName.Contains("EAP Carrier Phone"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                        }
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteSTDSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DataTable CarrierSpecific)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableSTD
                HashtableSTD.Add(1, "8");//STD General Information – Elimination Period – Accident
                HashtableSTD.Add(2, "71");//STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(3, "569");//STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(4, "350");//STD General Information – Maximum Period of Payment


                #endregion

                string EliminationPeriodAccident = "";
                string BenefitPercentage = "";
                string WeeklyBenefitMaximum = "";
                string MaximumPeriodofPayment = "";
                string value = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region STD
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1:
                                                EliminationPeriodAccident = dr["value"].ToString() + " day ";
                                                break;
                                            case 2: BenefitPercentage = value; break;
                                            case 3: WeeklyBenefitMaximum = value; break;
                                            case 4: MaximumPeriodofPayment = dr["value"].ToString() + " " + dr["UOM"].ToString(); break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("STD General Plan Information – Benefit Percentage"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitPercentage.Trim());
                                    }
                                    if (fieldName.Contains("STD General Information – Weekly Benefit Maximum"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(WeeklyBenefitMaximum.Trim());
                                    }
                                    if (fieldName.Contains("STD General Information – Elimination Period – Accident"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(EliminationPeriodAccident.Trim());
                                    }
                                    if (fieldName.Contains("STD General Information – Maximum Period of Payment"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(MaximumPeriodofPayment.Trim());
                                    }
                                    if (fieldName.Contains("Disability Plan Carrier STD"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Disability" + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }

                                    if (foundRows.Count() > 0)
                                    {
                                        if (fieldName.Contains("Disability Carrier Website STD"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                        }
                                        if (fieldName.Contains("Disability Carrier Phone STD"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                        }
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">LTDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteLTDSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DataTable CarrierSpecific, DropDownList ddlSTDNoOfPlan, DropDownList ddlSTDPlanName)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                DataRow[] foundRows = null;
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableLTD

                HashtableLTD.Add(1, "71");//LTD General Plan Information – Benefit Percentage
                HashtableLTD.Add(2, "374");//LTD General Plan Information – Monthly Benefit Maximum


                #endregion

                string BenefitPercentage = "";
                string MonthlyBenefitMaximum = "";

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region LTD
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: BenefitPercentage = value; break;
                                            case 2: MonthlyBenefitMaximum = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LTD General Plan Information – Benefit Percentage"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitPercentage.Trim());
                                    }
                                    if (fieldName.Contains("LTD General Plan Information – Monthly Benefit Maximum"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(MonthlyBenefitMaximum.Trim());
                                    }

                                    if (fieldName.Contains("Disability Plan Carrier LTD"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Disability " + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("LTD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }
                                    if (foundRows.Count() > 0)
                                    {
                                        if (fieldName.Contains("Disability Carrier Website LTD"))
                                        {
                                            myMergeField.Select();
                                            if (ddlSTDNoOfPlan.SelectedIndex > 0)
                                            {
                                                if (ddlSTDPlanName.SelectedItem.Text.Contains(PlanTable.Rows[rowindex]["Carrier"].ToString()))
                                                {
                                                    oWordApp.Selection.TypeText(" ");
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                                }
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                            }
                                        }
                                        if (fieldName.Contains("Disability Carrier Phone LTD"))
                                        {
                                            myMergeField.Select();
                                            if (ddlSTDNoOfPlan.SelectedIndex > 0)
                                            {
                                                if (ddlSTDPlanName.SelectedItem.Text.Contains(PlanTable.Rows[rowindex]["Carrier"].ToString()))
                                                {
                                                    oWordApp.Selection.TypeText(" ");
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                                }
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, DataTable CarrierSpecific)
        {
            try
            {
                Hashtable HashtableVisionBenefit = new Hashtable();
                Hashtable HashtableVisionBenefit_TBL = new Hashtable();

                #region HastableVisionBenefit

                HashtableVisionBenefit.Add(1, "194");   //Vision General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefit.Add(2, "309");   //Vision General Plan Information – Benefit Frequency – Lenses[Express]
                //  HashtableVisionBenefit.Add(2, "310");//Vision General Plan Information – Benefit Frequency – Lenses[Core]
                HashtableVisionBenefit.Add(3, "207");   //Vision General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefit.Add(4, "122");   //Vision General Plan Information – Benefit Frequency – Contacts


                HashtableVisionBenefit_TBL.Add(1, "195");   //General Plan Information – Copay – Examination Deductible ---
                HashtableVisionBenefit_TBL.Add(2, "344");  //General Plan Information – Copay – Material Deductible ---
                HashtableVisionBenefit_TBL.Add(3, "194");   //General Plan Information – Benefit Frequency – Examination ---
                HashtableVisionBenefit_TBL.Add(4, "309");   //General Plan Information – Benefit Frequency –Lenses ---
                HashtableVisionBenefit_TBL.Add(5, "207");   //General Plan Information – Benefit Frequency – Frames ---
                HashtableVisionBenefit_TBL.Add(6, "208");  //Covered Services – Frames ---
                HashtableVisionBenefit_TBL.Add(7, "122");   //General Plan Information – Benefit Frequency – Contacts ---
                HashtableVisionBenefit_TBL.Add(8, "356");  //Covered Services – Contact Lenses – Medically Necessary ---
                HashtableVisionBenefit_TBL.Add(9, "178");  //Covered Services – Contact Lenses - Elective ---

                #endregion

                int iTotalFields = 0;
                int count = 2;
                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                string BenefitFrequencyExamination = "";
                string BenefitFrequencyLenses = "";
                string BenefitFrequencyFrames = "";
                string BenefitFrequencyContacts = "";

                string Copay_Examination = string.Empty;
                string Copay_Materials = string.Empty;
                string Ben_Freq_Examination = string.Empty;
                string Ben_Freq_Lenses = string.Empty;
                string Ben_Freq_Frames = string.Empty;
                string Covered_Services_Frames = string.Empty;
                string Ben_Freq_Contacts = string.Empty;
                string Covered_Services_Medically_Necessary = string.Empty;
                string Covered_Services_Elective = string.Empty;
                string value = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            oWordDoc.Tables[3].Cell(1, 2).Select();
                            oWordDoc.Tables[3].Cell(1, 2).Range.Text = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            # region VisionBenefitTable

                            foreach (int key in HashtableVisionBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: BenefitFrequencyExamination = value; break;
                                            case 2: BenefitFrequencyLenses = value; break;
                                            case 3: BenefitFrequencyFrames = value; break;
                                            case 4: BenefitFrequencyContacts = value; break;
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableVisionBenefit_TBL.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit_TBL[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Copay_Examination = value; break;
                                            case 2: Copay_Materials = value; break;
                                            case 3: Ben_Freq_Examination = value; break;
                                            case 4: Ben_Freq_Lenses = value; break;
                                            case 5: Ben_Freq_Frames = value; break;
                                            case 6: Covered_Services_Frames = value; break;
                                            case 7: Ben_Freq_Contacts = value; break;
                                            case 8: Covered_Services_Medically_Necessary = value; break;
                                            case 9: Covered_Services_Elective = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Vision Plan Benefit Summary"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString().Trim());
                                    }

                                    if (fieldName.Contains("Vision Benefit Frequency – Examination"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitFrequencyExamination.Trim());
                                    }
                                    if (fieldName.Contains("Vision Benefit Frequency –Lenses"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitFrequencyLenses.Trim());
                                    }

                                    if (fieldName.Contains("Vision Benefit Frequency – Frames"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitFrequencyFrames.Trim());
                                    }

                                    if (fieldName.Contains("Vision Benefit Frequency – Contacts"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitFrequencyContacts.Trim());
                                    }
                                    if (fieldName.Contains("Vision Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                    }
                                    if (fieldName.Contains("Vision Carrier Contact"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Vision " + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString());
                                    }
                                    if (foundRows.Count() > 0)
                                    {
                                        if (fieldName.Contains("Vision Carrier Website"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                        }
                                        if (fieldName.Contains("Vision Carrier Phone"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                        }
                                    }

                                    // Find fields for Vision Table newly added fields on 01 July 2014 -- Sugessted by client starts here
                                    if (fieldName.Contains("General Plan Info – Copay – Examination"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Copay_Examination);
                                    }
                                    if (fieldName.Contains("General Plan Info – Benefit Frequency – Materials"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Copay_Materials.Trim());
                                    }
                                    if (fieldName.Contains("General Plan Info – Benefit Frequency – Examination"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Ben_Freq_Examination.Trim());
                                    }
                                    if (fieldName.Contains("General Plan Info – Benefit Frequency – Lenses"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Ben_Freq_Lenses.Trim());
                                    }
                                    if (fieldName.Contains("General Plan Info – Benefit Frequency – Frames"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Ben_Freq_Frames.Trim());
                                    }
                                    if (fieldName.Contains("Covered Services – Frames"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Covered_Services_Frames.Trim());
                                    }
                                    if (fieldName.Contains("General Plan Info – Benefit Frequency – Contacts"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Ben_Freq_Contacts.Trim());
                                    }
                                    if (fieldName.Contains("Covered Services – Contact Lenses – Medically Necessary"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Covered_Services_Medically_Necessary.Trim());
                                    }
                                    if (fieldName.Contains("Covered Services – Contact Lenses - Elective"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Covered_Services_Elective);
                                    }
                                    // Find fields for Vision Table newly added fields on 01 July 2014 -- Sugessted by client ends here
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteLifeADDToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                int count = 1;
                DataRow[] foundRows = null;
                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string value = "";
                string OverallMaximum = "";

                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "188");//Employee[Overall Maximum]


                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region GroupLifeADDBenifitTable
                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: OverallMaximum = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Life and AD&D Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Life and AD&D Carrier Contact"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Life" + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Life ADD General Plan Information – Overall Maximum – Employee"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(OverallMaximum.Trim());
                                    }
                                    if (foundRows.Count() > 0)
                                    {
                                        if (fieldName.Contains("Life Carrier Website"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                        }
                                        if (fieldName.Contains("Life Carrier Phone"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());

                                        }
                                    }
                                    if (fieldName.Contains("Life and ADD"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Life and AD&D Plan ");
                                    }
                                }
                            }
                        }
                            #endregion
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;
                int count = 1;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string value = "";

                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(1, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(2, "188");//Employee[Overall Maximum]

                HashtableVoluntaryLifeADDBenifit.Add(3, "516");//Spouse[Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(4, "519"); //Spouse[Overall Maximum]

                HashtableVoluntaryLifeADDBenifit.Add(5, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(6, "104");//Child(ren)[Overall Maximum]

                #endregion

                string BenefitAmountEmployee = "";
                string BenefitAmountSpouse = "";
                string BenefitAmountChild = "";

                string OverallMaximumEmployee = "";
                string OverallMaximumSpouse = "";
                string OverallMaximumChild = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region VoluntaryLifeADDBenifitTable
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: BenefitAmountEmployee = value; break;
                                            case 2: OverallMaximumEmployee = value; break;
                                            case 3: BenefitAmountSpouse = value; break;
                                            case 4: OverallMaximumSpouse = value; break;
                                            case 5: BenefitAmountChild = value; break;
                                            case 6: OverallMaximumChild = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Voluntary Life Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Voluntary General Plan Information – Benefit Amount – Employee"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitAmountEmployee.Trim());
                                    }
                                    if (fieldName.Contains("Voluntary General Plan information – Overall Maximum – Employee"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(OverallMaximumEmployee.Trim());
                                    }
                                    if (fieldName.Contains("Voluntary General Plan Information – Benefit Amount –Spouse"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitAmountSpouse.Trim());
                                    }
                                    if (fieldName.Contains("Voluntary General Plan information – Overall Maximum – Spouse"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(OverallMaximumSpouse.Trim());
                                    }
                                    if (fieldName.Contains("Voluntary General Plan Information – Benefit Amount – Child(ren)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitAmountChild.Trim());
                                    }
                                    if (fieldName.Contains("Voluntary General Plan information – Overall Maximum – Child(ren)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(OverallMaximumChild.Trim());
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="DentalBenefitColumnIdOutNetworkList">DentalBenefitColumnIdOutNetworkList contain out Network Benefit ColumnId for Dental Plan</param>
        public void WriteDentalSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(3, "45");//Calendar Year Deductible
                HashtableDentalInNetwork.Add(4, "55");//Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(5, "164");//Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(6, "64");//Basic Restorative Care	
                HashtableDentalInNetwork.Add(7, "336");//Major Restorative Care
                HashtableDentalInNetwork.Add(8, "392");//Orthodontic Services

                #endregion
                #region HashtableDentalOutNetwork
                Hashtable HashtableDentalOutNetwork = new Hashtable();
                HashtableDentalOutNetwork.Add(3, "45");//Calendar Year Deductible
                HashtableDentalOutNetwork.Add(4, "55");//Calendar Year Benefit Maximum
                HashtableDentalOutNetwork.Add(5, "164");//Preventive & Diagnostic Care
                HashtableDentalOutNetwork.Add(6, "64");//Basic Restorative Care	
                HashtableDentalOutNetwork.Add(7, "336");//Major Restorative Care
                HashtableDentalOutNetwork.Add(8, "392");//Orthodontic Services

                #endregion
                int count = 1;

                string AnnualDeductible = "";
                string BenefitMaximum = "";
                string DiagnosticCare = "";
                string value = "";
                string Dentalcarrier = "";
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region DentalTable
                            oWordDoc.Tables[2].Cell(1, count + 1).Select();
                            oWordDoc.Tables[2].Cell(1, count + 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];

                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 3: AnnualDeductible = value; break;
                                                case 4: BenefitMaximum = value; break;
                                                case 5: DiagnosticCare = value; break;
                                            }
                                            //  oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            if (key == 4)
                                            {
                                                if (BenefitMaximum.Trim() != "")
                                                {
                                                    oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "per person";
                                                }
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            if (key == 4)
                                            {
                                                if (BenefitMaximum.Trim() != "")
                                                {
                                                    oWordDoc.Tables[2].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "per person";
                                                }
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[2].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                    }
                                }
                            }
                            foreach (int key in HashtableDentalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 4)
                                            {
                                                oWordDoc.Tables[2].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "per person";
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[2].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            if (key == 4)
                                            {
                                                oWordDoc.Tables[2].Cell(key, count + 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "per person";
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[2].Cell(key, count + 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Plan Carrier" + count.ToString()))
                                    {
                                        if (count == 1)
                                        {
                                            myMergeField.Select();
                                            if (Dentalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText("Dental " + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            myMergeField.Select();
                                            if (Dentalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                            }
                                        }
                                    }
                                    if (fieldName.Contains("Dental Plan Benefit Summary"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString().Trim());
                                    }

                                    if (fieldName.Contains("Dental General Information – Annual Deductible/ Individual"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AnnualDeductible.Trim());
                                    }
                                    if (fieldName.Contains("Dental waived for diagnostic and preventative care"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(DiagnosticCare.Trim());
                                    }
                                    if (fieldName.Contains("Denetal General Plan Information – Annual Plan Maximum"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(BenefitMaximum.Trim());
                                    }
                                    if (fieldName.Contains("Dental Carrier Phone" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (Dentalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                        {
                                            if (foundRows.Count() > 0)
                                            {
                                                oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                            }
                                        }
                                    }
                                    if (fieldName.Contains("Dental Carrier Website" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (Dentalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                        {
                                            if (foundRows.Count() > 0)
                                            {
                                                oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString().Trim());
                                            }
                                        }
                                    }

                                    if (fieldName.Contains("Dental Plan Table"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Plan");
                                    }
                                }
                            }

                            #endregion

                            Dentalcarrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork = new Hashtable();
                //HashtableMedicalInNetwork.Add(3, "44");//Calendar Year Deductible
                //HashtableMedicalInNetwork.Add(4, "52");//Calendar Year Out of Pocket Maximum
                HashtableMedicalInNetwork.Add(3, "45");//Calendar Year Deductible [Individual]
                HashtableMedicalInNetwork.Add(4, "53");//Calendar Year Out of Pocket Maximum [Individual]
                HashtableMedicalInNetwork.Add(55, "295");//Inpatient Hospitalization
                HashtableMedicalInNetwork.Add(5, "386");//Physician Office Visit
                HashtableMedicalInNetwork.Add(6, "414");//Specialists Office Visit
                HashtableMedicalInNetwork.Add(7, "16");//Preventive Care
                HashtableMedicalInNetwork.Add(8, "971");            //Other Services[Complex Radiology]
                HashtableMedicalInNetwork.Add(9, "295");//Inpatient Hospitalization
                HashtableMedicalInNetwork.Add(10, "555");//Urgent Care
                HashtableMedicalInNetwork.Add(11, "184");//Emergency Room


                #endregion
                #region HashtableMedicalOutNetwork
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                //HashtableMedicalOutNetwork.Add(3, "44");//Calendar Year Deductible
                //HashtableMedicalOutNetwork.Add(4, "52");//Calendar Year Out of Pocket Maximum
                HashtableMedicalOutNetwork.Add(3, "45");//Calendar Year Deductible [Individual]
                HashtableMedicalOutNetwork.Add(4, "53");//Calendar Year Out of Pocket Maximum [Individual]
                // HashtableMedicalOutNetwork.Add(55, "295");
                HashtableMedicalOutNetwork.Add(5, "386");//Physician Office Visit
                HashtableMedicalOutNetwork.Add(6, "414");//Specialists Office Visit
                HashtableMedicalOutNetwork.Add(7, "16");//Preventive Care
                HashtableMedicalOutNetwork.Add(8, "971");            //Other Services[Complex Radiology]
                HashtableMedicalOutNetwork.Add(9, "295");//Inpatient Hospitalization
                HashtableMedicalOutNetwork.Add(10, "555");//Urgent Care
                HashtableMedicalOutNetwork.Add(11, "184");//Emergency Room

                #endregion

                int count = 1;
                string AnnualDeductible = "";
                string OfficeVisit = "";
                string medicalcarrier = "";

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region MedicalTable

                            oWordDoc.Tables[1].Cell(1, count + 1).Select();
                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];

                            foreach (int key in HashtableMedicalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 55)
                                            {
                                                //OfficeVisit = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                            else
                                            {
                                                if (key == 5)
                                                {
                                                    //oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "\n" + OfficeVisit;
                                                    oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                    OfficeVisit = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                }
                                                else
                                                {
                                                    if (key == 3)
                                                    {
                                                        AnnualDeductible = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                    }
                                                    oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                }
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            if (key == 55)
                                            {
                                                //OfficeVisit = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                            else
                                            {
                                                if (key == 5)
                                                {
                                                    //oWordDoc.Tables[1].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "\n" + OfficeVisit;
                                                    oWordDoc.Tables[1].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                }
                                                else
                                                {
                                                    if (key == 3)
                                                    {
                                                        AnnualDeductible = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                    }
                                                    oWordDoc.Tables[1].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableMedicalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {

                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[1].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[1].Cell(key, count + 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region MergeField

                            int iTotalFields = 0;
                            string MedicalPlan2 = "";

                            if (count == 2)
                            {
                                MedicalPlan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString() + "– The " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " plan features " + AnnualDeductible + " deductible, a " + OfficeVisit + "office visit copay for most care authorized by your Primary Care Physician (PCP) and unlimited benefits. Preventive care services are covered at 100%. This plan requires you to select a PCP from the Cigna network of physicians to coordinate all of your needed care.";
                            }
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    // Previously client suggested the renewal date now it is effective date
                                    //if (fieldName.Contains("Renewal Date"))
                                    //{
                                    //    myMergeField.Select();
                                    //    string renewal = PlanTable.Rows[rowindex]["Renewal"].ToString();
                                    //    DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                    //    oWordApp.Selection.TypeText(renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString());
                                    //}

                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effective = PlanTable.Rows[rowindex]["Effective"].ToString();
                                        DateTime effectDate = Convert.ToDateTime(effective);
                                        oWordApp.Selection.TypeText(effectDate.ToString("M").Replace(" 0", " ").ToString() + ", " + effectDate.Year.ToString());
                                    }

                                    if (fieldName.Contains("Medical Plan Carrier" + count.ToString()))
                                    {
                                        if (count == 1)
                                        {
                                            myMergeField.Select();
                                            if (medicalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText("Medical " + "\n" + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            myMergeField.Select();
                                            if (medicalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                            }
                                        }
                                    }
                                    if (fieldName.Contains("Medical Plan Benefit Summary"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Medical Plan Type"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Medical General Information – Annual Deductible/Individual"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AnnualDeductible.Trim());
                                    }
                                    if (fieldName.Contains("Number of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(NumberofPlan);
                                    }
                                    if (fieldName.Contains("Medical General Plan Information – Office Visit/Exam"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(OfficeVisit.Trim());
                                    }
                                    if (fieldName.Contains("Medical Carrier Phone" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (medicalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                        {
                                            if (foundRows.Count() > 0)
                                            {
                                                oWordApp.Selection.TypeText("\nPhone: " + foundRows[0]["PhoneNumber"].ToString().Trim());
                                            }
                                        }
                                    }
                                    if (fieldName.Contains("Medical Carrier Website" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (medicalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                        {
                                            if (foundRows.Count() > 0)
                                            {
                                                oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString());
                                            }
                                        }
                                    }
                                    if (fieldName.Contains("MedicalPlan_2"))
                                    {
                                        myMergeField.Select();
                                        if (count == 2)
                                        {
                                            oWordApp.Selection.TypeText(MedicalPlan2);
                                        }
                                    }
                                }
                            }
                            #endregion
                            medicalcarrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Prescription Drugs Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        public void WritePrescriptionDrugsSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string Preferred_Specialty = "";

                int rowcount = 12;
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();
                Hashtable HashtablePrescriptionDrugs_OutNetwork = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");//Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");//Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");//Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "380");//Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs.Add(5, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region HashtablePrescriptionDrugs_OutNetwork
                HashtablePrescriptionDrugs_OutNetwork.Add(1, "213");//Prescription Categories[Generic]
                HashtablePrescriptionDrugs_OutNetwork.Add(2, "78");//Prescription Categories[Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(3, "84");//Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(4, "380");//Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs_OutNetwork.Add(5, "881");   //Prescription Categories[Preferred Specialty]

                #endregion
                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();
                Hashtable HashtableMailOrder_OutNetwork = new Hashtable();
                HashtableMailOrder.Add(1, "211");//Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");//Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");//Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "378");//Mail Order[Maximum Day Supply]
                HashtableMailOrder.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion
                #region MailOrder_OutNetwork
                HashtableMailOrder_OutNetwork.Add(1, "211");//Mail Order[Generic]
                HashtableMailOrder_OutNetwork.Add(2, "76");//Mail Order[Formulary]
                HashtableMailOrder_OutNetwork.Add(3, "82");//Mail Order[Non Formulary]
                HashtableMailOrder_OutNetwork.Add(4, "378");//Mail Order[Maximum Day Supply]
                HashtableMailOrder_OutNetwork.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region PrescriptionDrugs IN_Network
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic:  " + value + "\n"; break;
                                            case 2: Formulary = "Formulary:  " + value + "\n"; break;
                                            case 3: NonFormulary = "Non Formulary:  " + value + "\n"; break;
                                            case 4: if (count == 1)
                                                {
                                                    oWordDoc.Tables[1].Cell(rowcount, 1).Range.Text = "Retail Prescriptions " + value;
                                                } break;
                                            case 5: Preferred_Specialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                oWordDoc.Tables[1].Cell(rowcount, count + 1).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[1].Cell(rowcount, count + 2).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            #endregion

                            #region PrescriptionDrugs OUT_Network
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                            foreach (int key in HashtablePrescriptionDrugs_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic:  " + value + "\n"; break;
                                            case 2: Formulary = "Formulary:  " + value + "\n"; break;
                                            case 3: NonFormulary = "Non Formulary:  " + value + "\n"; break;
                                            case 5: Preferred_Specialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                oWordDoc.Tables[1].Cell(rowcount, count + 2).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[1].Cell(rowcount, count + 3).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            #endregion

                            #region MailOrder_Innetwork
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic:  " + value + "\n"; break;
                                            case 2: Formulary = "Formulary:  " + value + "\n"; break;
                                            case 3: NonFormulary = "Non Formulary:  " + value + "\n"; break;
                                            case 4: if (count == 1)
                                                {
                                                    oWordDoc.Tables[1].Cell(rowcount + 1, 1).Range.Text = "Mail Order Prescriptions " + value;
                                                }
                                                break;
                                            case 5: Preferred_Specialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                oWordDoc.Tables[1].Cell(rowcount + 1, count + 1).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[1].Cell(rowcount + 1, count + 2).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }
                            #endregion

                            #region MailOrder_Outnetwork
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";

                            foreach (int key in HashtableMailOrder_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic:  " + value + "\n"; break;
                                            case 2: Formulary = "Formulary:  " + value + "\n"; break;
                                            case 3: NonFormulary = "Non Formulary:  " + value + "\n"; break;
                                            case 5: Preferred_Specialty = "Preferred Specialty: " + value; break;
                                                break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                oWordDoc.Tables[1].Cell(rowcount + 1, count + 2).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[1].Cell(rowcount + 1, count + 3).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            #endregion

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Plan name to Template.
        /// </summary>
        /// <param name="Medicalindex">Medical Plan is selected.</param>
        /// <param name="Dentalindex">Dental Plan is selected.</param>
        /// <param name="EAPindex">EAP Plan is selected.</param>
        /// <param name="FSAindex">FSA Plan is selected.</param>
        /// <param name="STDindex">STD Plan is selected.</param>
        /// <param name="LTDindex">LTD Plan is selected.</param>
        /// <param name="Lifeindex">Life AD&D Plan is selected.</param>
        /// <param name="Voluntaryindex">Voluntary life Plan is selected.</param>
        /// <param name="Visionindex"></param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        public void WritePlanNameToTemplate5(int Medicalindex, int Dentalindex, int EAPindex, int FSAindex, int STDindex, int LTDindex, int Lifeindex, int Voluntaryindex, int Visionindex, Word.Document oWordDoc, Word.Application oWordApp)
        {
            int iTotalFields = 0;
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();
                    if (fieldName.Contains("Medical Plan Option"))
                    {
                        myMergeField.Select();
                        if (Medicalindex > 0)
                        {
                            oWordApp.Selection.TypeText("Medical Plan Option");
                        }
                    }
                    if (fieldName.Contains("FSA Plan"))
                    {
                        if (FSAindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("FSA Plan");
                        }
                    }
                    if (fieldName.Contains("EAP Plan"))
                    {
                        if (EAPindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("EAP Plan");
                        }
                    }
                    if (fieldName.Contains("STD Plan"))
                    {
                        if (STDindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("STD Plan");
                        }
                    }
                    if (fieldName.Contains("LTD Plan"))
                    {
                        if (LTDindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("LTD Plan");
                        }
                    }
                    if (fieldName.Contains("Vision Plans"))
                    {
                        if (Visionindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Vision Plan");
                        }
                    }
                    if (fieldName.Contains("Life and ADD"))
                    {
                        if (Lifeindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Life and AD&D Plan ");
                        }
                    }
                    if (fieldName.Contains("Voluntary Life"))
                    {
                        if (Voluntaryindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Voluntary Life");
                        }
                    }
                    if (fieldName.Contains("Dental Plans"))
                    {
                        if (Dentalindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Dental Plan Option");
                        }
                    }

                    if (fieldName.Contains("Additional Benefits"))
                    {
                        if (Visionindex > 0 || Lifeindex > 0 || Voluntaryindex > 0 || STDindex > 0 || LTDindex > 0 || EAPindex > 0 || FSAindex > 0)
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Additional Benefits");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int Medicalindex = 1;
                int Dentalindex = 2;
                int DentalCount = 0;

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {

                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    // PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(int));
                    // PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    // PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    // PremiumTable.Columns.Add("summaryname", typeof(string));
                    //PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    // PremiumTable.Columns.Add("contributionid", typeof(string));
                    // PremiumTable.Columns.Add("rateid", typeof(string));
                    //PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    PremiumTable.Columns.Add("contributionDescription", typeof(string));

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                        {
                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()))
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                premium_row_counter++;
                            }
                        }
                    }


                    /*
                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                        {
                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                            {

                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                }
                                else
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = 0;
                                }
                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                {
                                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    {
                                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                        break;
                                    }

                                }
                                premium_row_counter++;
                            }
                        }
                    }
                    */
                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);

                    // Commented the "monthlycost != 0" condition on the request of Nicole on 07 April 2015 

                    //// The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                    //for (int k = 0; k < dt.Rows.Count; k++)
                    //{
                    //    if (Convert.ToDecimal(dt.Rows[k]["contributioncost"]) == 0)
                    //    {
                    //        dt.Rows[k].Delete();
                    //        k = k - 1;
                    //    }
                    //}

                    PremiumTable = dt;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }
                        }
                        if (index == 1)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        DentalCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium

                int MediCalTableRowCounter = 15;
                oWordDoc.Tables[Medicalindex].Rows.Add();
                oWordDoc.Tables[Medicalindex].Cell(14, 1).Range.Text = "Cost Per Month";

                for (int d = 0; d < PremiumTableWriteMedical.Rows.Count; d++)
                {
                    oWordDoc.Tables[Medicalindex].Rows.Add();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[d][0].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[d][1].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 4).Range.Text = PremiumTableWriteMedical.Rows[d][2].ToString();
                    MediCalTableRowCounter++;
                }
                #endregion

                #region Dental Monthly Premium

                int DentalTableRowCounter = 10;
                oWordDoc.Tables[Dentalindex].Rows.Add();
                oWordDoc.Tables[Dentalindex].Cell(9, 1).Range.Text = "Cost Per Month";

                for (int d = 0; d < PremiumTableWriteDental.Rows.Count; d++)
                {
                    oWordDoc.Tables[Dentalindex].Rows.Add();
                    oWordDoc.Tables[Dentalindex].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[d][0].ToString();
                    oWordDoc.Tables[Dentalindex].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[d][1].ToString();
                    oWordDoc.Tables[Dentalindex].Cell(DentalTableRowCounter, 4).Range.Text = PremiumTableWriteDental.Rows[d][2].ToString();
                    DentalTableRowCounter++;
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate5(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();


                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (flag == true)
                                {
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    flag = false;
                                }
                                //For word page break-02 July 2014
                                // r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_1_5.doc"), missing, true, missing, missing);
                            }
                            // code added by vaibhav and shravan for spanish chip notice
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (flag == true)
                                {
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    flag = false;
                                }
                                //For word page break-02 July 2014
                                // r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlChipNotice.SelectedIndex >= 1)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            // Added by Vaibhav for spaninsh template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlChipNotice.SelectedIndex >= 1)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;


                // Call common function to write the contact information page fields
                //COmmented by Vaibhav
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
                //Added by Vaibhav
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}

