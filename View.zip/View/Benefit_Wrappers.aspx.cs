﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using BenefitPointSummaryPortal.BAL.Reports;

namespace BenefitPointSummaryPortal.View
{
    public partial class Benefit_Wrappers : System.Web.UI.Page
    {
        #region Global Variable
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        DataSet AccountDS = new DataSet();
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        static DataSet AccountTeamMemberDS = new DataSet();
        DataSet EligibilityDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        ConstantValue cv = new ConstantValue();
        List<string> lstPlanNames = new List<string>();

        List<Eligibility> lstEligibilityNames = new List<Eligibility>();

        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        static DataTable PlanInfoTable = new DataTable();
        static DataTable dtPlanContactInfo = new DataTable();

        //static List<int> MedicalPlanTypeList = new List<int>();
        //static List<int> DentalPlanTypeList = new List<int>();
        //static List<int> VisionPlanTypeList = new List<int>();
        //static List<int> LifeADDPlanTypeList = new List<int>();
        //static List<int> STDPlanTypeList = new List<int>();
        //static List<int> LTDPlanTypeList = new List<int>();
        //static List<int> VoluntaryLifeADDPlanTypeList = new List<int>();
        //static List<int> EAPPlanTypeList = new List<int>();
        //static List<int> FSAPlanTypeList = new List<int>();
        //static List<int> HRAPlanTypeList = new List<int>();
        //static List<int> HSAPlanTypeList = new List<int>();
        //static List<int> WellnessPlanTypeList = new List<int>();
        //static List<int> GroupTermLifePlanTypeList = new List<int>();
        //static List<int> ADNDPlanTypeList = new List<int>();
        //static List<int> AdditionalProductsPlanTypeList = new List<int>();
        SummaryDetail sd = new SummaryDetail();
        string selectedColor = string.Empty;

        #region Added by vinod : storing the activity logs
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        //        SummaryDetail sdd = new SummaryDetail();
        List<Contact> ContactList = new List<Contact>();
        BPBusiness bpp = new BPBusiness();
        #endregion

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btnSummary);

                if (!IsPostBack)
                {
                    div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                    TitleSpan.InnerText = "Benefit Wrappers";

                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }
                    Session["DeliverableCategory"] = "Employee Communications";
                    Activity = "Benefit Wrappers";
                    Activity_Group = "Communications";

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    txtsearch.Focus();
                    mvBenefitSummary.ActiveViewIndex = 0;
                    btnPrevious.Visible = false;

                    btnSummary.Visible = false;

                    DictDepartment = sd.getDepartmentDetails();
                    GetData();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();
                SessionId = Session["SessionId"].ToString();
                ddlClient.Items.Clear();
                ddlBRC.SelectedIndex = 0;
                ddlSummaryStyle.SelectedIndex = 0;
                ddlColor.SelectedValue = "Gray";
                ddlColor.Items[0].Text = "Grey (Default)";
                ddlColor.Enabled = true;
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {

                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlEligibility.DataSource = null;
                ddlEligibility.DataBind();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

                ddlBRC.SelectedIndex = 0;
                ddlSummaryStyle.SelectedIndex = 0;
                ddlColor.SelectedValue = "Gray";
                ddlColor.Items[0].Text = "Grey (Default)";
                ddlColor.Enabled = true;
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                ddlHRContact.Items.Clear();

            }
            catch (Exception ex)
            {

                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {

            if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0 || ddlHRContact.SelectedIndex == 0 || ddlBRC.SelectedIndex == 0 || ddlSummaryStyle.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "Validate", "<script>Validate();</script>", false);
                return;
            }

            if (mvBenefitSummary.ActiveViewIndex == 0)
            {
                mvBenefitSummary.ActiveViewIndex = 1;
                btnPrevious.Visible = true;
                btnSummary.Visible = false;
                if (grdPlans.Rows.Count > 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                }

            }
            else if (mvBenefitSummary.ActiveViewIndex == 1)
            {
                DataTable PlanInfoTable = GetPlanInfoTable();
                bool isMedicalSelected = false;

                foreach (DataRow row in PlanInfoTable.Rows)
                {
                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(row["ProductTypeId"])))
                    {
                        isMedicalSelected = true;
                        break;
                    }
                }

                if (isMedicalSelected)
                {
                    mvBenefitSummary.ActiveViewIndex = 2;
                    btnPrevious.Visible = true;
                    btnSummary.Visible = false;
                    dvPlanContacts.Visible = false;

                }
                else
                {
                    if (grdPlans.Rows.Count > 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                    }

                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Please select a medical plan');", true);
                }

            }
            else if (mvBenefitSummary.ActiveViewIndex == 2)
            {
                mvBenefitSummary.ActiveViewIndex = 3;
                btnPrevious.Visible = true;
                btnSummary.Visible = true;
                btnNext.Visible = false;

            }
            else if (mvBenefitSummary.ActiveViewIndex == 3)
            {
                mvBenefitSummary.ActiveViewIndex = 4;
                btnNext.Visible = false;
                btnSummary.Visible = true;
                btnPrevious.Visible = true;
            }

        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {

            if (mvBenefitSummary.ActiveViewIndex == 3)
            {
                mvBenefitSummary.ActiveViewIndex = 2;
                btnPrevious.Visible = true;
                btnNext.Visible = true;
                btnSummary.Visible = false;

            }
            else if (mvBenefitSummary.ActiveViewIndex == 2)
            {
                mvBenefitSummary.ActiveViewIndex = 1;
                btnPrevious.Visible = true;
                btnNext.Visible = true;
                btnSummary.Visible = false;
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);

            }
            else if (mvBenefitSummary.ActiveViewIndex == 1)
            {
                mvBenefitSummary.ActiveViewIndex = 0;
                btnPrevious.Visible = false;
                btnNext.Visible = true;
                btnSummary.Visible = false;
            }



        }

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                Hashtable htSortedPlanList = new Hashtable();

                htSortedPlanList = BenifitWrapper_planList();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                List<Plan> PlanList = new List<Plan>();
                List<Plan> commonPlanList = new List<Plan>();
                Session["PlanList"] = null;
                SessionId = Session["SessionId"].ToString();
                if (ddlClient.SelectedIndex > 0)
                {
                    PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                }
                Session["PlanList"] = PlanList;

                if (PlanList != null)
                {
                    if (PlanList.Count > 0)
                    {
                        if (rdlPlan.SelectedIndex == 0)
                        {

                            foreach (Plan item in PlanList)
                            {
                                if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                {
                                    if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                    {
                                        commonPlanList.Add(item);
                                    }
                                }
                            }

                        }
                        if (rdlPlan.SelectedIndex == 1)
                        {
                            foreach (Plan item in PlanList)
                            {
                                if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                {
                                    commonPlanList.Add(item);
                                }
                            }
                        }

                        //  commonPlanList.OrderBy(a => a.ProductTypeId);
                        List<Plan> lstPlanList = new List<Plan>();
                        lstPlanList = (from l in commonPlanList
                                       orderby l.ProductTypeId ascending
                                       select l).ToList();

                        objCommFun.LoadPlanTypeIds();

                        foreach (Plan plan in lstPlanList)
                        {
                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(plan.ProductTypeId) || plan.ProductTypeId == 320 || plan.ProductTypeId == 340)
                            {
                                plan.SummaryName = "";
                            }
                        }

                        grdPlans.DataSource = lstPlanList;
                        grdPlans.DataBind();

                        if (commonPlanList.Count > 0)
                        {
                            //pnlPlans.Visible = true;
                            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                            ChkBoxHeader.Checked = true;
                            foreach (GridViewRow row in grdPlans.Rows)
                            {
                                System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                                ChkBoxRows.Checked = true;
                            }
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }
                        else
                        {
                            string script = "alert(\"No active plans.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }
                    else
                    {
                        string script = "alert(\"No plans for selected client.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }
                }
                else
                {
                    string script = "alert(\"No plans for selected client.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                }


                List<Eligibility> EligibilityList = new List<Eligibility>();
                Eligibility eligibilityItem = new Eligibility();
                string _PlanName = string.Empty;
                string selected_Value = string.Empty;


                foreach (Plan plan in commonPlanList)
                {
                    if (Check_PlanIs_Medical_Dental_Vision(plan.ProductTypeId))
                    {
                        EligibilityList = bp.FindEligibility(plan.ProductId, SessionId);

                        foreach (var item in EligibilityList)
                        {
                            eligibilityItem = new Eligibility();
                            eligibilityItem.EligibilityId = item.EligibilityId;
                            eligibilityItem.EligibilityDescription = plan.ProductTypeDescription + " - " + Convert.ToString(plan.PolicyNumber) + " - " + item.EligibilityDescription;

                            if (!lstEligibilityNames.Equals(eligibilityItem.EligibilityDescription))
                            {
                                lstEligibilityNames.Add(eligibilityItem);
                            }
                        }
                    }
                }

                if (ddlEligibility != null)
                {
                    selected_Value = Convert.ToString(ddlEligibility.SelectedValue);
                }
                ddlEligibility.DataSource = lstEligibilityNames;
                ddlEligibility.DataBind();
                ddlEligibility.Items.Insert(0, new ListItem("Select", string.Empty));
                if (ddlEligibility != null)
                {
                    ddlEligibility.SelectedIndex = ddlEligibility.Items.IndexOf(ddlEligibility.Items.FindByValue(selected_Value));
                }


            }//tryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {

                string mynewfile = "";
                List<BRCData> BRCList = new List<BRCData>();

                DataTable PlanInfoTable = GetPlanInfoTable();

                SessionId = Session["SessionId"].ToString();

                sd.BuildAccountTable();
                sd.BuildBenefitSummaryTable();
                sd.BuildBenifitSummaryStructureTable();
                sd.BuildContributionTable();
                sd.BuildEligibilityRuleTable();
                sd.BuildProductTable();

                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }

                #region GET BRC DETAILS

                if (!string.IsNullOrEmpty(Account_Office))
                {

                    BRCList = bp.GetBRCDetails(Account_Office);

                    if (BRCList.Count <= 0)
                    {
                        BRCData brcData = new BRCData();
                        brcData.BRCId = 0;
                        brcData.BRCName = "";
                        brcData.BRCLocation = "";
                        brcData.BRCEmail = "";
                        brcData.BRCPhone = "";
                        brcData.BRCFax = "";
                        brcData.BRCTimezone = "";
                        brcData.BRCDayHours = "";
                        BRCList.Add(brcData);
                    }
                }
                #endregion

                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                {
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                }
                EligibilityDS = sd.GetEligibilityRule(PlanInfoTable, SessionId, EleigibilityRuleId);

                if (ddlSummaryStyle.SelectedValue == "WrapperBayView")
                {
                    mynewfile = CreateTemplate_WrapperBayView(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }
                if (ddlSummaryStyle.SelectedValue == "WrapperMosaic")
                {
                    mynewfile = CreateTemplate_WrapperMosaic(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }
                if (ddlSummaryStyle.SelectedValue == "WrapperSummerHealth")
                {
                    mynewfile = CreateTemplate_WrapperSummerHealth(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }
                if (ddlSummaryStyle.SelectedValue == "WrapperEnrollmentSummary")
                {
                    mynewfile = CreateTemplate_WrapperEnrollmentSummary(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }
                if (ddlSummaryStyle.SelectedValue == "WrapperBlueTile")
                {
                    mynewfile = CreateTemplate_WrapperBlueTile(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }
                if (ddlSummaryStyle.SelectedValue == "WrapperMountain")
                {
                    mynewfile = CreateTemplate_WrapperMountain(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }
                //WrapperSpringField
                if (ddlSummaryStyle.SelectedValue == "WrapperSpringField")
                {
                    mynewfile = CreateTemplate_WrapperSpringField(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }

                if (ddlSummaryStyle.SelectedValue == "WrapperSpotLight")
                {
                    mynewfile = CreateTemplate_WrapperSpotLight(AccountDS, EligibilityDS, BRCList, PlanInfoTable);
                }
                if (ddlSummaryStyle.SelectedValue == "WrapperTabs")
                {
                    mynewfile = CreateTemplate_WrapperTabs(BRCList, PlanInfoTable);
                }

                if (mynewfile != "")
                {
                    DownloadFileNew(mynewfile);
                }
                InsertLog(ddlSummaryStyle.SelectedItem.Text);


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<Contact> ContactList = new List<Contact>();
                SessionId = Session["SessionId"].ToString();
                if (ddlClient.SelectedItem.Text != "Select" && ddlClient.SelectedItem.Text.Trim() != "")
                {
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
                }

                Session["Contact"] = ContactList;
                ddlHRContact.DataSource = ContactList;
                ddlHRContact.DataBind();

                ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlHRContact.Items.Insert(1, new ListItem("None", "-1"));

                ddlBRC.SelectedIndex = 0;
                ddlSummaryStyle.SelectedIndex = 0;
                ddlColor.SelectedValue = "Gray";
                ddlColor.Items[0].Text = "Grey (Default)";
                ddlColor.Enabled = true;
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                ddlEligibility.Items.Clear();
                ddlAnnualLegalNotice.SelectedIndex = 0;
                ddlCreditableCoverage.SelectedIndex = 0;
                ddlChipNotice.SelectedIndex = 0;
                ddlMarketplaceCoverage.SelectedIndex = 0;
                ddlPlanContacts.SelectedIndex = 1;
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlSummaryStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlColor.SelectedIndex = 0;
            ddlColor.Items[0].Text = "Grey (Default)";
            ddlColor.Enabled = true;
            if (ddlSummaryStyle.SelectedValue == "WrapperMosaic" || (ddlSummaryStyle.SelectedValue == "WrapperSummerHealth") || ddlSummaryStyle.SelectedValue == "WrapperBayView" || ddlSummaryStyle.SelectedValue == "WrapperBlueTile" || ddlSummaryStyle.SelectedValue == "WrapperMountain" || ddlSummaryStyle.SelectedValue == "WrapperSpringField" || ddlSummaryStyle.SelectedValue == "WrapperSpotLight" || ddlSummaryStyle.SelectedValue == "WrapperTabs")
            {
                ddlColor.Items[0].Text = "Standard (Default)";
                ddlColor.Enabled = false;
            }
        }

        protected void ddlPlanContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    BindPlanContactGrid();

                    //if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                    //{
                    //    string[] TobeDistinct = { "ProductId" };
                    //    //dt = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct);
                    //    dvPlanContacts.DataSource = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct); ;
                    //    dvPlanContacts.DataBind();
                    //}
                }
                else
                {
                    lblPlanContactMessage.Text = "";
                    dvPlanContacts.DataSource = null;
                    dvPlanContacts.DataBind();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void dvPlanContacts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblProductID = (e.Row.FindControl("lblProductID") as Label);
                Label lblName = (e.Row.FindControl("lblName") as Label);
                DropDownList ddlItemPlanContact = (e.Row.FindControl("ddlItemPlanContact") as DropDownList);

                var name = (from a in PlanInfoTable.AsEnumerable()
                            where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                            select a.Field<string>("Name")).FirstOrDefault();

                var carrier = (from a in PlanInfoTable.AsEnumerable()
                               where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                               select a.Field<string>("Carrier")).FirstOrDefault();

                lblName.Text = name;

                var planContact = (from n in dtPlanContactInfo.AsEnumerable()
                                   where n.Field<int>("ProductId") == Convert.ToInt32(lblProductID.Text)
                                   select new { ContactId = (n.Field<int>("ContactId")), ContactName = (n.Field<string>("ContactName")), ContactPhoneNumber = (n.Field<string>("ContactWorkPhone")), ContactEmail = (n.Field<string>("ContactEmail")) });

                foreach (var item in planContact.ToList())
                {
                    ListItem li = new ListItem();
                    li.Text = item.ContactName + " - " + carrier;
                    li.Value = Convert.ToString(item.ContactId);
                    //li.Attributes.Add("ContactPhoneNumber", Convert.ToString(item.ContactPhoneNumber));
                    ddlItemPlanContact.Items.Add(li);
                }

                //Add Default Item in the DropDownList
                ddlItemPlanContact.Items.Insert(0, new ListItem("Select"));
                ddlItemPlanContact.Items.Insert(1, new ListItem("None"));
            }
        }

        protected void ddlAnnualLegalNotice_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlAnnualLegalNotice.SelectedIndex == 1)
                {
                    trAnual.Visible = true;
                    trNoticeOptions.Visible = true;
                }
                else
                {
                    trAnual.Visible = false;
                    trNoticeOptions.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected string CreateTemplate_WrapperBayView(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = " ";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WrapperBayView wr = new WriteTemplate_WrapperBayView();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperBayView")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperBayView"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_BayView_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperBayView/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToBayViewWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "Brc");

                }


                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanInfoTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                wr.Write_ContactsToWapperBayView(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, dtPlanContactDetails, SessionId);
                wr.Write_CommonFieldToBayViewWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, AccountTeamMemberDS, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact, ddlClient, PlanInfoTable);
                wr.WriteNoticeSectionToWapperBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlMarketplaceCoverage.SelectedValue == "Not Included")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperMosaic(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = "";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");

            WriteTemplate_WrapperMosaic wr = new WriteTemplate_WrapperMosaic();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperMosaic")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperMosaic"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_Mosaic_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperMosaic/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToMosaicWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }

                wr.Write_CommonFieldToMosaicWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact);

                wr.Write_ContactsToMosaicWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, SessionId);

                ///************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToMosaicWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlMarketplaceCoverage.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperSummerHealth(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = "";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WapperSummerHealth wr = new WriteTemplate_WapperSummerHealth();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperSummerHealth")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperSummerHealth"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_SummerHealth_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperSummerHealth/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToWapperSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }

                wr.Write_CommonFieldToWapperSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, AccountTeamMemberDS, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact);

                wr.Write_ContactsToWapperSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, SessionId);


                ///************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToWapperSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlMarketplaceCoverage.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperEnrollmentSummary(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = ddlColor.SelectedValue;
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WrapperEnrollmentSummary wr = new WriteTemplate_WrapperEnrollmentSummary();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperEnrollmentSummary")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperEnrollmentSummary"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_EnrollmentSummary_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperEnrollmentSummary/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToEnrollmentSummaryWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList, color);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "Brc");

                }


                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanInfoTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                wr.Write_ContactsToWapperEnrollmentSummary(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, dtPlanContactDetails, SessionId, color);
                wr.Write_CommonFieldToEnrollmentSummaryWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, AccountTeamMemberDS, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact, ddlClient, PlanInfoTable, color);
                wr.WriteNoticeSectionToWapperEnrollmentSummary(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included" )
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperBlueTile(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = "";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WrapperBlueTile wr = new WriteTemplate_WrapperBlueTile();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperBlueTile")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperBlueTile"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_BlueTile_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperBlueTile/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToBlueTileWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "Brc");
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "Brc2");
                }
                wr.WriteContactinformationToBlueTileWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, SessionId, ddlClient, ContactList, arrAcctContact);
                wr.Write_CommonFieldToBlueTileWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact, ddlClient, PlanInfoTable);
                wr.WriteNoticeSectionToBlueTileWrapper(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlCreditableCoverage.SelectedValue == "Not Included")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperMountain(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = "";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WapperMountain wr = new WriteTemplate_WapperMountain();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperMountain")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperMountain"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_Mountain_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperMountain/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToWapperMountain(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }

                wr.Write_CommonFieldToWapperMountain(wobj.office.oWordDoc, wobj.office.oWordApp, AccountTeamMemberDS, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact);

                wr.Write_ContactsToWapperMountain(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, SessionId);


                ///************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToWapperMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                string flag = "true";
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperSpringField(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = "";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WapperSpringField wr = new WriteTemplate_WapperSpringField();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Downloads"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit_Wrapper_SpringField.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Downloads/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToWapperSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }

                wr.Write_CommonFieldToWapperSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, AccountTeamMemberDS, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact);

                wr.Write_ContactsToWapperSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, SessionId);


                ///************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToWapperSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                string flag = "true";
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlMarketplaceCoverage.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }
                //chipnotices
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "chipnotices");
                }
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperSpotLight(DataSet AccountDS, DataSet EligibilityDS, List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = "";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WrapperSpotLight wr = new WriteTemplate_WrapperSpotLight();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperSpotLight")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperSpotLight"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_SpotLight_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperSpotLight/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToWapperSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }

                wr.Write_CommonFieldToWapperSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, AccountTeamMemberDS, EligibilityDS, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact);

                wr.Write_ContactsToWapperSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, SessionId);


                ///************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToWapperSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                string flag = "true";
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateTemplate_WrapperTabs(List<BRCData> BRCList, DataTable PlanInfoTable)
        {
            string color = " ";
            Object missing = System.Reflection.Missing.Value;
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
            WriteTemplate_WapperTabs wr = new WriteTemplate_WapperTabs();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperTabs")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/WrapperTabs"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Wrapper_Tabs_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/WrapperTabs/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DataTable EmployeeTypeTable = new DataTable();
                EmployeeTypeTable = GetEmployeeTypeDetail_AccountProfileSummeryDetails(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                DataTable EligibilityDs = new DataTable();
                EligibilityDs = sd.GetEligibilityRule_BenefitSummary(PlanInfoTable, SessionId, EleigibilityRuleId);

                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);


                if (ddlBRC.SelectedValue == "YES")
                {
                    wr.Write_BRCToWapperTabs(wobj.office.oWordDoc, wobj.office.oWordApp, BRCList);
                }
                else if (ddlBRC.SelectedValue == "NO")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "Brc");

                }


                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanInfoTable, (DataTable)Session["DataTable_PlanContactInfo"]);

                wr.Write_CommonFieldToWapperTabs(wobj.office.oWordDoc, wobj.office.oWordApp, AccountTeamMemberDS, EmployeeTypeTable, EligibilityDs, ddlHRContact, ContactList, Emp, AccountDS, arrAcctContact);

                wr.Write_ContactsToWapperTabs(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlClient, SessionId);
                wr.WriteNoticeSectionToTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //  Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        public DataTable GetEmployeeTypeDetail_AccountProfileSummeryDetails(int account_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();

            DataSet AccountDS = new DataSet();

            DataTable accountEmployeeTypesValues_table = new DataTable();
            int account_row_counter = 0;

            int accountEmployeeType_row_counter = 0;
            #region EmployeeTypes Table
            accountEmployeeTypesValues_table.Columns.Add("accountID", typeof(Int32));  // Row 0
            accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_employeeTypeID", typeof(string));  // Row 1
            accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_status", typeof(string));  // Row 2
            accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_type", typeof(string));  // Row 3
            accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_value", typeof(string));  // Row 4
            accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_unitOfMeasureSpecified", typeof(string));  // Row 4
            accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_frequency", typeof(string));  // Row 4
            #endregion
            try
            {

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;
                new_account = new_connection.getAccount(account_id);
                string website = string.Empty;

                if (new_account != null)
                {

                    #region EmployeeType Table
                    if (new_account.groupAccountInfo.employeeTypes != null)
                    {
                        if (new_account.groupAccountInfo.employeeTypes.Count() > 0)
                        {
                            foreach (BP_BrokerConnectV4.EmployeeType cfv in new_account.groupAccountInfo.employeeTypes)
                            {
                                accountEmployeeTypesValues_table.Rows.Add();
                                accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][0] = new_account.accountID;
                                if (cfv.employeeTypeID != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][1] = cfv.employeeTypeID;
                                if (cfv.status != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][2] = cfv.status;
                                if (cfv.type != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][3] = cfv.type;
                                if (cfv.value != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][4] = cfv.value;
                                if (cfv.unitOfMeasureSpecified != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][5] = cfv.unitOfMeasure;
                                if (cfv.frequency != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][6] = cfv.frequency;
                                accountEmployeeType_row_counter++;
                            }
                        }
                    }
                    #endregion

                    account_row_counter++;
                }



            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return accountEmployeeTypesValues_table;
        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
        /// <returns></returns>
        private DataTable GetPlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
            objCommFun.LoadPlanTypeIds_Pilot();
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 5))
                        {
                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            }
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 then it gives an error 'You are not authorized to access the requested information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = Convert.ToString(grRow.Cells[9].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = " ";
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.StopLossPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.StopLoss;
                            }
                            if (CommonFunctionsBS.FeesForServicePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FeesForService;
                            }
                            rowCount++;
                        }
                    }//Foreach Close

                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        public string GetPlanName(int PlanTypeId)
        {
            string _planName = string.Empty;

            try
            {
                // Medical
                foreach (var item in CommonFunctionsBS.MedicalPlanTypeList)
                {
                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.MedicalLOC;
                    }
                }

                // Dental
                foreach (var item in CommonFunctionsBS.DentalPlanTypeList)
                {
                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.DentalLOC;
                    }
                }

                // Vision
                foreach (var item in CommonFunctionsBS.VisionPlanTypeList)
                {
                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VisionLOC;
                    }
                }

                // Life and AD&D
                foreach (var item in CommonFunctionsBS.LifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LifeADDLOC;
                    }
                }

                // STD
                foreach (var item in CommonFunctionsBS.STDPlanTypeList)
                {
                    if (CommonFunctionsBS.STDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.STDLOC;
                    }
                }

                // Voluntary Life and AD&D
                foreach (var item in CommonFunctionsBS.VoluntaryLifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VoluntaryLifeADDLOC + "/" + cv.ADNDPlanType_CommonCriteria;
                    }
                }

                // LTD
                foreach (var item in CommonFunctionsBS.LTDPlanTypeList)
                {
                    if (CommonFunctionsBS.LTDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LTDLOC;
                    }
                }

                // EAP
                foreach (var item in CommonFunctionsBS.EAPPlanTypeList)
                {
                    if (CommonFunctionsBS.EAPPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.EAPPlanType_CommonCriteria;
                    }
                }

                // FSA
                foreach (var item in CommonFunctionsBS.FSAPlanTypeList)
                {
                    if (CommonFunctionsBS.FSAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.FSAPlanType_CommonCriteria;
                    }
                }

                // HRA
                foreach (var item in CommonFunctionsBS.HRAPlanTypeList)
                {
                    if (CommonFunctionsBS.HRAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.HRAPlanType_CommonCriteria;
                    }
                }

                // HSA
                foreach (var item in CommonFunctionsBS.HSAPlanTypeList)
                {
                    if (CommonFunctionsBS.HSAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.HSAPlanType_CommonCriteria;
                    }
                }

                // Wellness
                foreach (var item in CommonFunctionsBS.WellnessPlanTypeList)
                {
                    if (CommonFunctionsBS.WellnessPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.Wellness;
                    }
                }

                //// Group Term Life
                //foreach (var item in GroupTermLifePlanTypeList)
                //{
                //    if (GroupTermLifePlanTypeList.Contains(PlanTypeId))
                //    {
                //        return cv.GroupTermLifePlanType;
                //    }
                //}

                //// AD&D
                //foreach (var item in LifeADDPlanTypeList)
                //{
                //    if (LifeADDPlanTypeList.Contains(PlanTypeId))
                //    {
                //        return cv.ADD;
                //    }
                //}

                // Additional Products
                foreach (var item in CommonFunctionsBS.AdditionalProductsPlanTypeList)
                {
                    if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.AdditionalProducts;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _planName;
        }

        protected void GetData()
        {
            try
            {
                //Office.
                Session["OffieceTable"] = null;
                Session["BRCList"] = null;
                BPBusiness bp = new BPBusiness();
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();
                dt = bp.GetOfficeList();
                Session["OffieceTable"] = dt;
                //ddlOffice.DataSource = dt;
                //ddlOffice.DataBind();
                //ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));
                //ddlOffice.SelectedIndex = 2;
                /////** Office Dropdown Enabled=False by Amogh*/
                //ddlOffice.Enabled = false;

                // BRC
                /*****Code Commented by Mr. Amogh Vilayatkar *****/

                ////List<BRC> BRCList = new List<BRC>();
                ////BRCList = bp.GetBRC_Region();
                ////Session["BRCList"] = BRCList;
                ////ddlBRC.DataSource = BRCList;
                ////ddlBRC.DataBind();
                ddlBRC.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlBRC.Items.Insert(1, new ListItem("Yes", "YES"));
                ddlBRC.Items.Insert(2, new ListItem("No", "NO"));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private Hashtable BenifitWrapper_planList()
        {
            // Get all the ProductTypeId's in one variable to show only those plans which are present under these ProductTypeId's
            //List<int> plansProductTypeIds = new List<int>();
            //objCommFun.LoadPlanTypeIds();
            //plansProductTypeIds.Clear();
            //plansProductTypeIds.AddRange(CommonFunctionsBS.MedicalPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.DentalPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.VisionPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.HSAPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.HRAPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.FSAPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.LifeADDPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.VoluntaryLifeADDPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.STDPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.LTDPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.EAPPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.WellnessPlanTypeList);
            //plansProductTypeIds.AddRange(CommonFunctionsBS.AdditionalProductsPlanTypeList);

            Hashtable htSortedPlanList = new Hashtable();

            htSortedPlanList.Add(1, 100);   // Medical
            htSortedPlanList.Add(2, 110);   // Medical
            htSortedPlanList.Add(3, 120);   // Medical
            htSortedPlanList.Add(4, 140);   // Medical
            htSortedPlanList.Add(5, 150);   // Medical
            htSortedPlanList.Add(6, 160);   // Medical
            htSortedPlanList.Add(7, 170);   // Medical

            htSortedPlanList.Add(8, 180);   // Dental
            htSortedPlanList.Add(9, 190);   // Dental
            htSortedPlanList.Add(10, 200);   // Dental
            htSortedPlanList.Add(11, 210);   // Dental

            htSortedPlanList.Add(12, 230);   // Vision

            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life

            htSortedPlanList.Add(15, 260);   // Voluntary Life
            htSortedPlanList.Add(16, 270);   // AD&D
            htSortedPlanList.Add(17, 280);   // Voluntary AD&D
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            //htSortedPlanList.Add(20, 330);   // Section 125

            htSortedPlanList.Add(21, 130);   // Medical
            //htSortedPlanList.Add(22, 310);   // EAP
            htSortedPlanList.Add(23, 178);   // HRA
            htSortedPlanList.Add(24, 179);   // HSA
            /**************************** AS PER NICOLE - [Client Revenue Summary - Issue #3 - Update plans list] please update the Available Plans list to include the Plan type, Stop Loss***/
            htSortedPlanList.Add(25, 235);    //Stop Loss
            htSortedPlanList.Add(26, 340);   //401(k)
            htSortedPlanList.Add(27, 294);	 //Hawaii TDI
            htSortedPlanList.Add(28, 410);	 //International Bundled Plan (3-Tier)
            htSortedPlanList.Add(29, 233);	 //Limited Benefit 2-Tier
            htSortedPlanList.Add(30, 293);	 //New Jersey TDB
            htSortedPlanList.Add(31, 292);	 //New York DBL
            htSortedPlanList.Add(32, 173);	 //Prescription Drug (Carve-Out)
            htSortedPlanList.Add(33, 320);	 //Business Travel Accident (BTA)
            //htSortedPlanList.Add(26, 1108);   //Fees for Service
            //htSortedPlanList.Add(22, 1116);   // Medical Plan Riders

            //for (int i = 0; i < plansProductTypeIds.Count ; i++)
            //{
            //     htSortedPlanList.Add(i+1, plansProductTypeIds[i]);  
            //}

            return htSortedPlanList;
        }

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        protected bool Check_PlanIs_Medical_Dental_Vision(int PlanTypeId)
        {
            bool _IsMDV = false;
            objCommFun.LoadPlanTypeIds();
            try
            {
                // Medical
                foreach (var item in CommonFunctionsBS.MedicalPlanTypeList)
                {
                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }

                // Dental
                foreach (var item in CommonFunctionsBS.DentalPlanTypeList)
                {
                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }

                // Vision
                foreach (var item in CommonFunctionsBS.VisionPlanTypeList)
                {
                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _IsMDV;
        }

        private void BindPlanContactGrid()
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    List<int> lstProductIds = new List<int>();
                    PlanInfoTable = GetPlanInfoTable();

                    // Additional Products
                    if (PlanInfoTable != null)
                    {
                        if (PlanInfoTable.Rows.Count > 0)
                        {
                            for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                            {
                                lstProductIds.Add(Convert.ToInt32(PlanInfoTable.Rows[i]["ProductId"]));
                            }
                        }
                    }

                    try
                    {
                        //if (sessionProductIdList == null)
                        //{
                        //    Session["ProductIdList"] = lstProductIds;
                        dtPlanContactInfo.Clear();

                        dtPlanContactInfo = sd.GetPlanContactInformation(lstProductIds, Session["SessionId"].ToString());
                        //}
                        //else if (sessionProductIdList.Count != lstProductIds.Count)
                        //{
                        //    Session["ProductIdList"] = lstProductIds;
                        //    dtPlanContactInfo = sd.GetPlanContactInformation(lstProductIds, Session["SessionId"].ToString());
                        //}
                        Session["DataTable_PlanContactInfo"] = dtPlanContactInfo;
                    }
                    catch (Exception ex)
                    {
                        dtPlanContactInfo.Clear();
                        Session["DataTable_PlanContactInfo"] = null;
                    }

                    if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                    {
                        string[] TobeDistinct = { "ProductId" };
                        //dt = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct);

                        dvPlanContacts.Visible = true;
                        dvPlanContacts.DataSource = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct);
                        dvPlanContacts.DataBind();

                    }
                    else
                    {
                        lblPlanContactMessage.Text = "No contacts found for the selected Plans/Products.";
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public DataTable GetDataTableFromGridView_ForContactDetails(GridView dtg, DataTable PlanTable, DataTable dtPlanContactInfo)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            string carriername = "";
            string plantype = "";
            string ProductTypeDesc = "";
            string ProductId = "";

            string carrier = string.Empty;
            string description_Policy = string.Empty;
            string website_phone = string.Empty;

            // add the columns to the datatable            
            dt.Columns.Add(new System.Data.DataColumn("PlanName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactId", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactPhoneNumber", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ProductId", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactEmail", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("Contact_FirstName", typeof(string)));
            dt.Columns.Add(new System.Data.DataColumn("Contact_LastName", typeof(string)));
            dt.Columns.Add(new System.Data.DataColumn("Contact_Address", typeof(string)));

            //  add each of the data rows to the table
            foreach (GridViewRow row in dtg.Rows)
            {
                Label lblName = (Label)row.FindControl("lblName");
                DropDownList ddlItemPlanContact = (DropDownList)row.FindControl("ddlItemPlanContact");
                Label lblProductID = (Label)row.FindControl("lblProductID");

                if (ddlItemPlanContact.SelectedItem.Text != "Select" && ddlItemPlanContact.SelectedItem.Text != "None")
                {
                    dr = dt.NewRow();
                    dr[0] = Convert.ToString(lblName.Text).Replace(" ", "");
                    dr[1] = Convert.ToString(ddlItemPlanContact.SelectedItem.Value);
                    dr[2] = Convert.ToString(ddlItemPlanContact.SelectedItem.Text);
                    dr[4] = Convert.ToString(lblProductID.Text);

                    var planContactPhone = (from n in dtPlanContactInfo.AsEnumerable()
                                            where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                            select n.Field<string>("ContactWorkPhone")).FirstOrDefault();

                    dr[3] = Convert.ToString(planContactPhone);

                    var planEmail = (from n in dtPlanContactInfo.AsEnumerable()
                                     where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                     select n.Field<string>("ContactEmail")).FirstOrDefault();

                    var firstName = (from n in dtPlanContactInfo.AsEnumerable()
                                     where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                     select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                    var lastName = (from n in dtPlanContactInfo.AsEnumerable()
                                    where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                    select n.Field<string>("Contact_LastName")).FirstOrDefault();

                    var address = (from n in dtPlanContactInfo.AsEnumerable()
                                   where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                   select n.Field<string>("Contact_Address")).FirstOrDefault();

                    dr[5] = Convert.ToString(planEmail);
                    dr[6] = Convert.ToString(firstName);
                    dr[7] = Convert.ToString(lastName);
                    dr[8] = Convert.ToString(address);

                    dt.Rows.Add(dr);
                }
            }

            DataTable dtDetailContacts = new DataTable();
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("PlanName", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("PlanType", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ProductTypeDesc", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactName", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactPhoneNumber", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactEmail", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactId", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ProductId", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("Contact_FirstName", typeof(string)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("Contact_LastName", typeof(string)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("Contact_Address", typeof(string)));

            for (int i = 0; i < PlanTable.Rows.Count; i++)
            {
                dr = dtDetailContacts.NewRow();

                if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["Name"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                {
                    ProductId = PlanTable.Rows[i]["ProductId"].ToString();
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    carriername = PlanTable.Rows[i]["Carrier"].ToString();
                    ProductTypeDesc = PlanTable.Rows[i]["Name"].ToString();

                    var planEmail = (from n in dt.AsEnumerable()
                                     where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                     select n.Field<string>("ContactEmail")).FirstOrDefault();
                    var planContactPhone = (from n in dt.AsEnumerable()
                                            where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                            select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();
                    var planContactName = (from n in dt.AsEnumerable()
                                           where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                           select n.Field<string>("ContactName")).FirstOrDefault();
                    var ContactId = (from n in dt.AsEnumerable()
                                     where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                     select n.Field<string>("ContactId")).FirstOrDefault();

                    var firstName = (from n in dt.AsEnumerable()
                                     where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                     select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                    var lastName = (from n in dt.AsEnumerable()
                                    where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                    select n.Field<string>("Contact_LastName")).FirstOrDefault();

                    var address = (from n in dt.AsEnumerable()
                                   where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                   select n.Field<string>("Contact_Address")).FirstOrDefault();

                    dr[0] = Convert.ToString(carriername);
                    dr[1] = Convert.ToString(plantype);
                    dr[2] = Convert.ToString(ProductTypeDesc);
                    dr[3] = Convert.ToString(planContactName);
                    dr[4] = Convert.ToString(planContactPhone);
                    dr[5] = Convert.ToString(planEmail);

                    dr[6] = Convert.ToString(ContactId);
                    dr[7] = Convert.ToString(ProductId);
                    dr[8] = Convert.ToString(firstName);
                    dr[9] = Convert.ToString(lastName);
                    dr[10] = Convert.ToString(address);
                    dtDetailContacts.Rows.Add(dr);
                }
            }

            return dtDetailContacts;
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void InsertLog(string Criteria1 = "", string Criteria2 = "", string Criteria3 = "", string Criteria4 = "")
        {
            DicActivityLog.Clear();
            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Criteria1, Criteria2, Criteria3, Criteria4);

        }

    }
}