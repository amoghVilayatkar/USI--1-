﻿using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI.WebControls;
using System;


using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.UI;

using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;


namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{

    public class Flyers_OpenEnrollmentMobileApp
    {
        int iTotalFields = 0;
        ConstantValue cv = new ConstantValue();
        string value = string.Empty;
        BPBusiness bp = new BPBusiness();

        internal void WriteField_FlyerMobileAppRequestForm(Microsoft.Office.Interop.Word.Document oWordDoc, Microsoft.Office.Interop.Word.Application oWordApp, DataTable dtFlyer_OpenEnroll)
        {
            #region MergeField

            for (int i = 0; i < dtFlyer_OpenEnroll.Rows.Count; i++)
            {
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        //int i = 0;
                        //for (i = 0; i < dtFlyer_OpenEnroll.Rows.Count; i++)
                        //{
                        if (fieldName.Equals("ClientName" + (i + 1)))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Convert.ToString(dtFlyer_OpenEnroll.Rows[i][0]));
                            continue;
                        }
                        if (fieldName.Equals("MobileAccessCode" + (i + 1)))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Convert.ToString(dtFlyer_OpenEnroll.Rows[i][1]));
                            continue;
                        }
                        //}
                    }
                }
            }

            #endregion

        }

        public void DeleteSpecialPage(Word.Document oWordDoc, Word.Application oWordApp)
        {

            Object missing = System.Reflection.Missing.Value;
            //Word.Application wordapp = null;
            //wordapp = new Word.Application();
            oWordApp.Visible = false;
            Word.WdStatistic stat = Word.WdStatistic.wdStatisticPages;
            int num = oWordDoc.ComputeStatistics(stat, ref missing);

            //for (int i = 6; i >= 3; i--)
            //{

            Word.Range rngD = oWordDoc.GoTo(Word.WdGoToItem.wdGoToPage, Word.WdGoToDirection.wdGoToAbsolute, 3, Type.Missing);
            //oWordApp.Selection.Delete(); 
            rngD.Bookmarks["\\Page"].Range.Delete();
            Word.WdStatistic stat1 = Word.WdStatistic.wdStatisticPages;
            int num1 = oWordDoc.ComputeStatistics(stat1, ref missing);
            //}
            //Word.Range rngD1 = oWordDoc.GoTo(Word.WdGoToItem.wdGoToPage, Word.WdGoToDirection.wdGoToAbsolute, 3, Type.Missing);
            //rngD1.Bookmarks["\\Page"].Range.Delete();


        }

        internal void WriteField_FlyerMobileAppRequestForm_Option2(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddlClients, DataTable dtFlyer_OpenEnroll)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;



            objSlides = objPres.Slides;

            for (int k = 0; k < dtFlyer_OpenEnroll.Rows.Count; k++)
            {
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;

                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                        {
                            if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {

                            }
                        }
                        else
                        {
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            int count = k + 1;
                            if (txtRange.Text.Contains("<<Client Name" + count + ">>"))
                            {
                                txtRange.Replace("<<Client Name" + count + ">>", ddlClients.SelectedItem.Text.ToString());
                            }
                            if (txtRange.Text.Contains("<<Mobile App Code" + count + ">>"))
                            {
                                txtRange.Replace("<<Mobile App Code" + count + ">>", Convert.ToString(dtFlyer_OpenEnroll.Rows[k][1]));
                            }

                            if (txtRange.Text.Contains("<<Delete_Slide" + count + ">>"))
                            {
                                txtRange.Replace("<<Delete_Slide" + count + ">>", " ");
                            }
                        }
                    }
                }
            }


        }

        public void DeleteUnwantedSectionFromFlyerOption2(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            Microsoft.Office.Interop.PowerPoint.Shape oShape = null;

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            #region merge fields
            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
            objSlides = objPres.Slides;
            for (int sldNum = 1; sldNum <= objSlides.Count; sldNum++)
            {
                objShapes = objSlides[sldNum].Shapes;

                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                for (int shp = 1; shp <= objShapes.Count; shp++)
                {
                    oShape = objShapes[shp];

                    if (oShape.Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoGroup || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoPicture || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoTable || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoLine || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                    {

                    }
                    else
                    {
                        txtFrame = objShapes[shp].TextFrame;
                        txtRange = txtFrame.TextRange;
                        if (txtRange.Text.Contains("<<Delete_Slide1>>") || txtRange.Text.Contains("<<Delete_Slide2>>") || txtRange.Text.Contains("<<Delete_Slide3>>") || txtRange.Text.Contains("<<Delete_Slide4>>") || txtRange.Text.Contains("<<Delete_Slide5>>") || txtRange.Text.Contains("<<Delete_Slide6>>") || txtRange.Text.Contains("<<Delete_Slide7>>") || txtRange.Text.Contains("<<Delete_Slide8>>") || txtRange.Text.Contains("<<Delete_Slide9>>") || txtRange.Text.Contains("<<Delete_Slide10>>") || txtRange.Text.Contains("<<Delete_Slide11>>") || txtRange.Text.Contains("<<Delete_Slide12>>"))
                        {
                            //mySlide.Delete();
                            objSlides[sldNum].Delete();
                            sldNum = sldNum - 1;
                            break;
                        }
                    }
                }
            }
            #endregion

        }

        internal void WriteField_BRC(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, List<BRCData> BRCList)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;
            objSlides = objPres.Slides;
            #region MergeField

            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
            for (int i = 1; i <= objSlides.Count; i++)
            {
                //objShapes = mySlide.Shapes;
                objShapes = objSlides[i].Shapes;

                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                for (int j = 1; j <= objShapes.Count; j++)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                    {
                    }
                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {
                    }
                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                    {

                    }
                    else
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<BRCPhone>>"))
                        {
                            txtRange.Replace("<<BRCPhone>>", BRCList[0].BRCPhone);
                        }
                        if (txtRange.Text.Contains("<<BRCEmail>>"))
                        {
                            txtRange.Replace("<<BRCEmail>>", BRCList[0].BRCEmail);
                        }
                        if (txtRange.Text.Contains("<<BRCTimezone>>"))
                        {
                            txtRange.Replace("<<BRCTimezone>>", BRCList[0].BRCTimezone);
                        }
                    }
                }
            }

            #endregion
        }


        internal void WriteField_BRC_V1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, List<BRCData> BRCList)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;
            objSlides = objPres.Slides;
            #region MergeField

            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
            for (int i = 1; i <= objSlides.Count; i++)
            {
                //objShapes = mySlide.Shapes;
                objShapes = objSlides[i].Shapes;

                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                for (int j = 1; j <= objShapes.Count; j++)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                    {
                    }
                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {
                    }
                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                    {

                    }
                    else
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<BRCPhone>>"))
                        {
                            txtRange.Replace("<<BRCPhone>>", BRCList[0].BRCPhone);
                        }
                        if (txtRange.Text.Contains("<<BRCEmail>>"))
                        {
                            txtRange.Replace("<<BRCEmail>>", BRCList[0].BRCEmail);
                        }
                        if (txtRange.Text.Contains("<<BRCTimezone>>"))
                        {
                            txtRange.Replace("<<BRCTimezone>>", BRCList[0].BRCDayHours);
                        }
                    }
                }
            }

            #endregion
        }
        /********************CODE DONE  BY SHAVAN  ADDED BY AMOGH */
        internal void WriteField_Flyer_OE_SpotLight(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string ddlClients, string RenewalYear)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }
                else
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;
                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients.ToString());
                    }
                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear);
                    }
                }
            }
        }

        internal void WriteField_Flyer_OE_Tabs(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string ddlClients, string RenewalYear, string OEDate, string OELocation)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }

                else
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;
                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients);
                    }
                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear);
                    }
                    if (txtRange.Text.Contains("<<OE Date>>"))
                    {
                        txtRange.Replace("<<OE Date>>", OEDate);
                    }
                    if (txtRange.Text.Contains("<<OE Location>>"))
                    {
                        txtRange.Replace("<<OE Location>>", OELocation);
                    }
                }
            }
        }

        internal void WriteField_Flyer_OE_SpringField(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string ddlClients, string RenewalYear, string OEDate, string OELocation, string OETime)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }

                else
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;
                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients);
                    }
                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear);
                    }
                    if (txtRange.Text.Contains("<<OE Date>>"))
                    {
                        txtRange.Replace("<<OE Date>>", OEDate);
                    }
                    if (txtRange.Text.Contains("<<OE Location>>"))
                    {
                        txtRange.Replace("<<OE Location>>", OELocation);
                    }
                    if (txtRange.Text.Contains("<<OE Time>>"))
                    {
                        txtRange.Replace("<<OE Time>>", OETime);
                    }
                }
            }
        }

        internal void WriteField_Flyer_OE_Mountain(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                }
                else
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;

                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients.Trim());
                    }
                }
            }
        }

        internal void WriteField_Flyer_OE_BasicBlue(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string OpenEnrollMeetingDate, string OpenEnrollMeetingTime, string OpenEnrollMeetingLocation)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                }
                else
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;

                    if (txtRange.Text.Contains("<<Meeting Date>>"))
                    {
                        txtRange.Replace("<<Meeting Date>>", OpenEnrollMeetingDate.Trim());
                    }
                    if (txtRange.Text.Contains("<<Meeting Time>>"))
                    {
                        txtRange.Replace("<<Meeting Time>>", OpenEnrollMeetingTime.Trim());
                    }
                    if (txtRange.Text.Contains("<<Meeting Location>>"))
                    {
                        txtRange.Replace("<<Meeting Location>>", OpenEnrollMeetingLocation.Trim());
                    }
                }
            }
        }

        internal void WriteField_Flyer_OE_BayView(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, int RenewalYear, string MeetingDate, string MeetingLocation, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                }
                else
                {
                    try
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear.ToString());
                        }
                        if (txtRange.Text.Contains("<<Client Name>>"))
                        {
                            txtRange.Replace("<<Client Name>>", ddlClients.Trim());
                        }
                        if (txtRange != null && txtRange.Text.Contains("<<Meeting Date>>"))
                        {
                            txtRange.Replace("<<Meeting Date>>", MeetingDate.Trim());
                        }
                        if (txtRange != null && txtRange.Text.Contains("<<Meeting Location>>"))
                        {
                            txtRange.Replace("<<Meeting Location>>", MeetingLocation.Trim());
                        }
                    }
                    catch (Exception ex)
                    {
                        txtFrame = null;
                        txtRange = null;
                    }


                }
            }
        }

        internal void WriteField_Flyer_OE_Mosaic(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, int RenewalYear, string MeetingDate, string MeetingLocation, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                    #region Group Year printing code
                    //Search Groups
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                    {
                        foreach (Microsoft.Office.Interop.PowerPoint.Shape childshape in objShapes[j].GroupItems)
                        {
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (childshape.Name == "Ryear")
                            {
                                childshape.TextFrame.TextRange.Replace("<<year>>", RenewalYear.ToString());
                            }
                        }
                    }
                    #endregion
                }
                else
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;

                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear.ToString());
                    }
                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients.Trim());
                    }
                    if (txtRange.Text.Contains("<<Meeting Date>>"))
                    {
                        txtRange.Replace("<<Meeting Date>>", MeetingDate.Trim());
                    }
                    if (txtRange.Text.Contains("<<Meeting Location>>"))
                    {
                        txtRange.Replace("<<Meeting Location>>", MeetingLocation.Trim());
                    }
                }
            }
        }

        internal void WriteField_Flyer_OE_SummerHealth(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string MeetingDate, int RenewalYear, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                }
                else
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;

                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients.Trim());
                    }
                    if (txtRange.Text.Contains("<<Meeting Date>>"))
                    {
                        txtRange.Replace("<<Meeting Date>>", MeetingDate.Trim());
                    }
                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear.ToString());
                    }
                    if (txtRange.Text.Contains("<<Renewal Year – 1>>"))
                    {
                        txtRange.Replace("<<Renewal Year – 1>>", (RenewalYear - 1).ToString());
                    }
                }

            }
        }

        internal void WriteField_Flyer_OE_FallOption1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string MeetingDate, string MeetingTime, string MeetingLocation, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                }
                else
                {
                    try
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<Client Name>>"))
                        {
                            txtRange.Replace("<<Client Name>>", ddlClients.Trim());
                        }
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear.ToString());
                        }
                        if (txtRange.Text.Contains("<<Meeting Date>>"))
                        {
                            txtRange.Replace("<<Meeting Date>>", MeetingDate.Trim());
                        }
                        if (txtRange.Text.Contains("<<Meeting Time>>"))
                        {
                            txtRange.Replace("<<Meeting Time>>", MeetingTime.Trim());
                        }
                        if (txtRange.Text.Contains("<<Meeting Location>>"))
                        {
                            txtRange.Replace("<<Meeting Location>>", MeetingLocation.Trim());
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                }

            }
        }
        internal void WriteField_Flyer_OE_FallOption2(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string MeetingDate, string MeetingTime, string MeetingLocation, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                }
                else
                {
                    try
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<Client Name>>"))
                        {
                            txtRange.Replace("<<Client Name>>", ddlClients.Trim());
                        }
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear.ToString());
                        }
                        if (txtRange.Text.Contains("<<Meeting Date>>"))
                        {
                            txtRange.Replace("<<Meeting Date>>", MeetingDate.Trim());
                        }
                        if (txtRange.Text.Contains("<<Meeting Time>>"))
                        {
                            txtRange.Replace("<<Meeting Time>>", MeetingTime.Trim());
                        }
                        if (txtRange.Text.Contains("<<Meeting Location>>"))
                        {
                            txtRange.Replace("<<Meeting Location>>", MeetingLocation.Trim());
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                }

            }
        }

        //Added By Vinod
        internal void WriteField_Flyer_OE_Winter(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, int RenewalYear, string MeetingDate, string MeetingTime, string MeetingLocation, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;

            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                    #region Group Year printing code
                    //Search Groups
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                    {
                        foreach (Microsoft.Office.Interop.PowerPoint.Shape childshape in objShapes[j].GroupItems)
                        {
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (childshape.Name == "Ryear")
                            {
                                childshape.TextFrame.TextRange.Replace("<<year>>", RenewalYear.ToString());
                            }
                        }
                    }
                    #endregion
                }
                else
                {
                    try
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear.ToString());
                        }
                        if (txtRange.Text.Contains("<<Client Name >>"))
                        {
                            txtRange.Replace("<<Client Name >>", ddlClients.Trim());
                        }
                        if (txtRange != null && txtRange.Text.Contains("<<Meeting Date>>"))
                        {
                            txtRange.Replace("<<Meeting Date>>", MeetingDate.Trim());
                        }
                        if (txtRange != null && txtRange.Text.Contains("<<Meeting Time>>"))
                        {
                            txtRange.Replace("<<Meeting Time>>", MeetingTime.Trim());
                        }
                        if (txtRange != null && txtRange.Text.Contains("<<Meeting Location>>"))
                        {
                            txtRange.Replace("<<Meeting Location>>", MeetingLocation.Trim());
                        }
                    }
                    catch (Exception ex)
                    {
                        txtFrame = null;
                        txtRange = null;
                    }


                }
            }
        }

        #region Population Health Mgmt and Appointment Reminder Function
        internal void WriteField_Flyer_PHM_AppointmentReminder(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string fromDueDate)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }
                else
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Form Due Date>>"))
                        {
                            txtRange.Replace("<<Form Due Date>>", fromDueDate);
                        }
                    }

                }
            }
        }
        internal void WriteField_Flyer_PHM_StepsWellness(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string ProgramStartDate)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }
                else
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Start Date>>"))
                        {
                            txtRange.Replace("<<Start Date>>", ProgramStartDate);
                        }
                    }

                }
            }
        }
        internal void WriteField_Flyer_PHM_WellnessFamily(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }
                else
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Plan Effective Date>>"))
                        {
                            txtRange.Replace("<<Plan Effective Date>>", PlanEffectiveDate);
                        }
                        if (txtRange.Text.Contains("<<Client Name>>"))
                        {
                            txtRange.Replace("<<Client Name>>", ddlClients);
                        }
                        if (txtRange.Text.Contains("<<Start Date>>"))
                        {
                            txtRange.Replace("<<Start Date>>", ProgramStartDate);
                        }
                        if (txtRange.Text.Contains("<<End Date>>"))
                        {
                            txtRange.Replace("<<End Date>>", ProgramEndDate);
                        }
                        if (txtRange.Text.Contains("<<RenewalYear>>"))
                        {
                            txtRange.Replace("<<RenewalYear>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Current Year>>"))
                        {
                            txtRange.Replace("<<Current Year>>", Convert.ToString(System.DateTime.Now.Year));
                        }

                    }

                }
            }
        }
        internal void WriteField_Flyer_PHM_Wellness_Outdoors(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }
                else
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Plan Effective Date>>"))
                        {
                            txtRange.Replace("<<Plan Effective Date>>", PlanEffectiveDate);
                        }
                        if (txtRange.Text.Contains("<<Client Name>>"))
                        {
                            txtRange.Replace("<<Client Name>>", ddlClients);
                        }
                        if (txtRange.Text.Contains("<<Start Date>>"))
                        {
                            txtRange.Replace("<<Start Date>>", ProgramStartDate);
                        }
                        if (txtRange.Text.Contains("<<End Date>>"))
                        {
                            txtRange.Replace("<<End Date>>", ProgramEndDate);
                        }
                        if (txtRange.Text.Contains("<<RenewalYear>>"))
                        {
                            txtRange.Replace("<<RenewalYear>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Current Year>>"))
                        {
                            txtRange.Replace("<<Current Year>>", Convert.ToString(System.DateTime.Now.Year));
                        }

                    }

                }
            }
        }
        internal void WriteField_Flyer_PHM_WellnessPhysician(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }
                else
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Plan Effective Date>>"))
                        {
                            txtRange.Replace("<<Plan Effective Date>>", PlanEffectiveDate);
                        }
                        if (txtRange.Text.Contains("<<Client Name>>"))
                        {
                            txtRange.Replace("<<Client Name>>", ddlClients);
                        }
                        if (txtRange.Text.Contains("<<Start Date>>"))
                        {
                            txtRange.Replace("<<Start Date>>", ProgramStartDate);
                        }
                        if (txtRange.Text.Contains("<<End Date>>"))
                        {
                            txtRange.Replace("<<End Date>>", ProgramEndDate);
                        }
                        if (txtRange.Text.Contains("<<RenewalYear>>"))
                        {
                            txtRange.Replace("<<RenewalYear>>", RenewalYear);
                        }
                        if (txtRange.Text.Contains("<<Current Year>>"))
                        {
                            txtRange.Replace("<<Current Year>>", Convert.ToString(System.DateTime.Now.Year));
                        }

                    }

                }
            }
        }
        internal void WriteField_Flyer_PHM_PreventiveCare(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string fromDueDate, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {
                if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                    {

                    }
                }
                else
                {
                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        txtFrame = objShapes[j].TextFrame;
                        txtRange = txtFrame.TextRange;
                        if (txtRange.Text.Contains("<<Client Name>>"))
                        {
                            txtRange.Replace("<<Client Name>>", ddlClients);
                        }
                        if (txtRange.Text.Contains("<<Form Due Date>>"))
                        {
                            txtRange.Replace("<<Form Due Date>>", fromDueDate);
                        }
                        if (txtRange.Text.Contains("<<Renewal Year>>"))
                        {
                            txtRange.Replace("<<Renewal Year>>", RenewalYear);
                        }
                    }

                }
            }
        }

        internal void WriteField_Flyer_PHM_StepsSavings(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {

                if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoTrue)
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;
                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear);
                    }
                    if (txtRange.Text.Contains("<<Plan Effective Date>>"))
                    {
                        txtRange.Replace("<<Plan Effective Date>>", PlanEffectiveDate);
                    }
                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients);
                    }
                    if (txtRange.Text.Contains("<<Start Date>>"))
                    {
                        txtRange.Replace("<<Start Date>>", ProgramStartDate);
                    }
                    if (txtRange.Text.Contains("<<End Date>>"))
                    {
                        txtRange.Replace("<<End Date>>", ProgramEndDate);
                    }
                    if (txtRange.Text.Contains("<<RenewalYear>>"))
                    {
                        txtRange.Replace("<<RenewalYear>>", RenewalYear);
                    }
                    if (txtRange.Text.Contains("<<Current Year>>"))
                    {
                        txtRange.Replace("<<Current Year>>", Convert.ToString(System.DateTime.Now.Year));
                    }

                }


            }
        }
        internal void WriteField_Flyer_PHM_WellnessOthers(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, string RenewalYear, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, string ddlClients)
        {

            objSlides = null;
            objShapes = null;
            txtFrame = null;
            txtRange = null;


            objSlides = objPres.Slides;
            objShapes = objSlides[1].Shapes;
            for (int j = 1; j <= objShapes.Count; j++)
            {

                if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoTrue)
                {
                    txtFrame = objShapes[j].TextFrame;
                    txtRange = txtFrame.TextRange;
                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear);
                    }
                    if (txtRange.Text.Contains("<<Renewal Year>>"))
                    {
                        txtRange.Replace("<<Renewal Year>>", RenewalYear);
                    }
                    if (txtRange.Text.Contains("<<Plan Effective Date>>"))
                    {
                        txtRange.Replace("<<Plan Effective Date>>", PlanEffectiveDate);
                    }
                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClients);
                    }
                    if (txtRange.Text.Contains("<<Start Date>>"))
                    {
                        txtRange.Replace("<<Start Date>>", ProgramStartDate);
                    }
                    if (txtRange.Text.Contains("<<End Date>>"))
                    {
                        txtRange.Replace("<<End Date>>", ProgramEndDate);
                    }
                    if (txtRange.Text.Contains("<<RenewalYear>>"))
                    {
                        txtRange.Replace("<<RenewalYear>>", RenewalYear);
                    }
                    if (txtRange.Text.Contains("<<Current Year>>"))
                    {
                        txtRange.Replace("<<Current Year>>", Convert.ToString(System.DateTime.Now.Year));
                    }

                }


            }
        }
        #endregion
    }
}