﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class Contribution
    {
        #region Variable
        private int _contributionId;
        private string _description;
        private string _planName;
        private int _planType;
        private string _planNumber;
        #endregion
        #region Properties

        /// <summary>
        /// Get and Set PlanNumber
        /// </summary>
        public string PlanNumber
        {
            get
            {
                return _planNumber;
            }
            set
            {
                _planNumber = value;
            }
        }

        /// <summary>
        /// Get and Set PlanType
        /// </summary>
        public int PlanType
        {
            get
            {
                return _planType;
            }
            set
            {
                _planType = value;
            }
        }

        /// <summary>
        /// Get and Set ContributionId
        /// </summary>
        public int ContributionId
        {
            get
            {
                return _contributionId;
            }
            set
            {
                _contributionId = value;
            }
        }
        /// <summary>
        /// Get and Set ContributionDescription
        /// </summary>
        public string ContributionDescription
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

        /// <summary>
        /// Get and Set PlanName
        /// </summary>
        public string ContributionPlanName
        {
            get
            {
                return _planName;
            }
            set
            {
                _planName = value;
            }
        }
        #endregion

    }
}