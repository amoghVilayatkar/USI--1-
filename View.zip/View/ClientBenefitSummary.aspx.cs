﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.Common.ViewModels;
using BenefitPointSummaryPortal.BAL.ClientBenefitSummary;
using System.Data;

namespace BenefitPointSummaryPortal.View
{
    public partial class ClientBenefitSummary : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        public ConstantValue cv = new ConstantValue();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        private static string Activity = "";
        private static string Activity_Group = "";
        enum AccessKeys { SessionID, DeliverableCategory, AvailablePlanList, AvailableProductList, SelectedSummaries, SelectedProducts, BenefitSummaryOptionDataSource, IsDescriptionHide, VisitedCriteriaPages, IsPlanProductViewed };
        enum ContentOptions { Select, Trifold };
        enum PlanStatus { Pending, Current, ArchivedPriorYear };
        enum CriteriaViews { viewPlanBenefitSummary, viewBenefitSummarySelection, viewMobileAppLegalNotice };

        #region Page Properties
        public bool IsDescriptionHide
        {
            get
            {
                bool HideDescription = false;
                HideDescription = Session[AccessKeys.IsDescriptionHide.ToString()] == null ? false : bool.Parse(Session[AccessKeys.IsDescriptionHide.ToString()].ToString());
                return HideDescription;
            }
            set
            {
                Session[AccessKeys.IsDescriptionHide.ToString()] = value;
            }
        }
        string SessionId
        {
            get
            {
                return Session[AccessKeys.SessionID.ToString()].ToString();
            }
            set
            {
                Session[AccessKeys.SessionID.ToString()] = value;
            }
        }
        List<int> ApplicablePlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> AllPlans = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        AllPlans = TrifoldSummary.Trifold_AllPlans;
                        break;
                }
                return AllPlans;
            }
        }
        List<int> ApplicableProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> AllProducts = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        AllProducts = TrifoldSummary.Trifold_AllProducts;
                        break;
                }
                return AllProducts;
            }
        }
        List<Plan> AvailablePlans
        {
            get
            {
                List<Plan> tempPlans = new List<Plan>();
                if (Session[AccessKeys.AvailablePlanList.ToString()] != null)
                    tempPlans = Session[AccessKeys.AvailablePlanList.ToString()] as List<Plan>;
                return tempPlans;
            }
            set
            {
                Session[AccessKeys.AvailablePlanList.ToString()] = value;
            }
        }
        List<Plan> AvailableProducts
        {
            get
            {
                List<Plan> tempPlans = new List<Plan>();
                if (Session[AccessKeys.AvailableProductList.ToString()] != null)
                    tempPlans = Session[AccessKeys.AvailableProductList.ToString()] as List<Plan>;
                return tempPlans;
            }
            set
            {
                Session[AccessKeys.AvailableProductList.ToString()] = value;
            }
        }
        List<string> CriteriaPages
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<string> tempCriteriaPages = new List<string>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        tempCriteriaPages = TrifoldSummary.CriteriaPages;
                        break;
                }
                return tempCriteriaPages;
            }

        }
        ClientBenefitSummaryUIViewModel ViewConfig
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();

                ClientBenefitSummaryUIViewModel viewPlanBenefitSummary = new ClientBenefitSummaryUIViewModel();
                viewPlanBenefitSummary.IsNextButtonVisibles = false;
                viewPlanBenefitSummary.IsPreviousButtonVisibles = false;
                viewPlanBenefitSummary.IsCreateButtonVisibles = false;

                viewPlanBenefitSummary.NextButtonText = "Selected Summary Options >>";
                viewPlanBenefitSummary.PreviousButtonText = "";
                viewPlanBenefitSummary.CreateButtonText = "";
                viewPlanBenefitSummary.CriteraPageIndexText = "1 of 1";
                viewPlanBenefitSummary.IsDeliverableDescriptionVisible = true;
                viewPlanBenefitSummary.IsCriteriaInformarionVisible = false;

                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        viewPlanBenefitSummary = TrifoldSummary.ViewConfig[mvMainContainer.GetActiveView().ID];
                        break;

                }
                return viewPlanBenefitSummary;
            }

        }
        public bool IsPlanProductViewed
        {
            get
            {
                return Session[AccessKeys.IsPlanProductViewed.ToString()] == null?false : bool.Parse(Session[AccessKeys.IsPlanProductViewed.ToString()].ToString());
            }
            set
            {
                Session[AccessKeys.IsPlanProductViewed.ToString()] = value;
            }
        }

        #region Plans TypeIds
        List<int> MedicalPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> MedicalPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        MedicalPlanTypes = TrifoldSummary.TrifoldPlanType_MedicalPlan.Union(TrifoldSummary.TrifoldPlanType_MedicalRxPlan).ToList();
                        break;
                }
                return MedicalPlanTypes;
            }
        }
        List<int> DentalPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> DentalPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        DentalPlanTypes = TrifoldSummary.TrifoldPlanType_Dental;
                        break;
                }
                return DentalPlanTypes;
            }
        }
        List<int> VisionPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> VisionPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        VisionPlanTypes = TrifoldSummary.TrifoldPlanType_Vision;
                        break;
                }
                return VisionPlanTypes;
            }
        }
        List<int> HSAPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> HSAPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        HSAPlanTypes = TrifoldSummary.TrifoldPlanType_HealthSavingAccounts;
                        break;
                }
                return HSAPlanTypes;
            }
        }
        List<int> HRAPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> HRAPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        HRAPlanTypes = TrifoldSummary.TrifoldPlanType_HealthReimbursementArrangement;
                        break;
                }
                return HRAPlanTypes;
            }
        }
        List<int> LifeADDPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> LifeADDPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        LifeADDPlanTypes = TrifoldSummary.TrifoldPlanType_LifeADD;
                        break;
                }
                return LifeADDPlanTypes;
            }
        }
        List<int> GroupTermPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> TrifoldPlanType_GroupTermLife = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        TrifoldPlanType_GroupTermLife = TrifoldSummary.TrifoldPlanType_GroupTermLife;
                        break;
                }
                return TrifoldPlanType_GroupTermLife;
            }
        }
        List<int> ADDPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> ADDPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        ADDPlanTypes = TrifoldSummary.TrifoldPlanType_ADD;
                        break;
                }
                return ADDPlanTypes;
            }
        }
        List<int> VoluntaryLifePlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> VoluntaryLifeADDPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        VoluntaryLifeADDPlanTypes = TrifoldSummary.TrifoldPlanType_VoluntaryLife;
                        break;
                }
                return VoluntaryLifeADDPlanTypes;
            }
        }
        List<int> VoluntaryADDPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> VoluntaryADDPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        VoluntaryADDPlanTypes = TrifoldSummary.TrifoldPlanType_VoluntaryADD;
                        break;
                }
                return VoluntaryADDPlanTypes;
            }
        }
        List<int> STDPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> STDPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        STDPlanTypes = TrifoldSummary.TrifoldPlanType_ShortTermDisability;
                        break;
                }
                return STDPlanTypes;
            }
        }
        List<int> LTDPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> LTDPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        LTDPlanTypes = TrifoldSummary.TrifoldPlanType_LongTermDisablity;
                        break;
                }
                return LTDPlanTypes;
            }
        }
        List<int> EAPPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> EAPPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        EAPPlanTypes = TrifoldSummary.TrifoldPlanType_EmployeeAssistanceProgram;
                        break;
                }
                return EAPPlanTypes;
            }
        }
        List<int> FSAPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> FSAPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        FSAPlanTypes = TrifoldSummary.TrifoldPlanType_FlexibleSpendingAccount;
                        break;
                }
                return FSAPlanTypes;
            }
        }
        List<int> WellnessPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> WellnessPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        WellnessPlanTypes = TrifoldSummary.TrifoldPlanType_Wellness;
                        break;
                }
                return WellnessPlanTypes;
            }
        }
        List<int> PlnaTypes401K
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> PlnaTypes401K = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        PlnaTypes401K = TrifoldSummary.TrifoldPlanType_401K;
                        break;
                }
                return PlnaTypes401K;
            }
        }
        List<int> StopLossPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> StopLossPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        StopLossPlanTypes = TrifoldSummary.TrifoldPlanType_StopLoss;
                        break;
                }
                return StopLossPlanTypes;
            }
        }
        List<int> InternationalBundledPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> InternationalBundledPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        InternationalBundledPlanTypes = TrifoldSummary.TrifoldPlanType_InternationalBundledsPlan_3_Tier;
                        break;
                }
                return InternationalBundledPlanTypes;
            }
        }
        List<int> BTAPlanTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> BTAPlanTypes = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        BTAPlanTypes = TrifoldSummary.TrifoldPlanType_BussinessTravelAccident;
                        break;
                }
                return BTAPlanTypes;
            }
        }
        #endregion

        #region Product TypeIds
        List<int> TelemedicineProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> TelemedicineProductTypeIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        TelemedicineProductTypeIds = TrifoldSummary.TrifoldProductType_Telemedicine.ToList();
                        break;
                }
                return TelemedicineProductTypeIds;
            }
        }
        List<int> PatientAdvocacyProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> PatientAdvocacyProductTypeIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        PatientAdvocacyProductTypeIds = TrifoldSummary.TrifoldProductType_PatientAdvocacy;
                        break;
                }
                return PatientAdvocacyProductTypeIds;
            }
        }
        List<int> HospitalizationProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> HospitalizationProductTypesIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        HospitalizationProductTypesIds = TrifoldSummary.TrifoldProductType_Hospitalization;
                        break;
                }
                return HospitalizationProductTypesIds;
            }
        }
        List<int> AccidentProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> AccidentProductTypesIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        AccidentProductTypesIds = TrifoldSummary.TrifoldProductType_Accident;
                        break;
                }
                return AccidentProductTypesIds;
            }
        }
        List<int> CriticalIllnesssProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> CriticalIllnesssProductTypesIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        CriticalIllnesssProductTypesIds = TrifoldSummary.TrifoldProductType_CriticalIllnesss;
                        break;
                }
                return CriticalIllnesssProductTypesIds;
            }
        }
        List<int> VoluntaryCancerProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> VoluntaryCancerTypeIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        VoluntaryCancerTypeIds = TrifoldSummary.TrifoldProductType_VoluntaryCancer;
                        break;
                }
                return VoluntaryCancerTypeIds;
            }
        }
        List<int> LifeADDProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> LifeADDProductTypesIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        LifeADDProductTypesIds = TrifoldSummary.TrifoldProductType_LifeADD;
                        break;
                }
                return LifeADDProductTypesIds;
            }
        }
        List<int> AbsenseMasnagementProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> AbsenseMasnagementProductTypesIds = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        AbsenseMasnagementProductTypesIds = TrifoldSummary.TrifoldProductType_AbsenseMasnagement;
                        break;
                }
                return AbsenseMasnagementProductTypesIds;
            }
        }
        List<int> PetInsuranceProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> PetInsurance = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        PetInsurance = TrifoldSummary.TrifoldProductType_PetInsurance;
                        break;
                }
                return PetInsurance;
            }
        }
        List<int> CobraAdministrationProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> CobraAdministration = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        CobraAdministration = TrifoldSummary.TrifoldProductType_CobraAdministration;
                        break;
                }
                return CobraAdministration;
            }
        }
        List<int> FinancialProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> FinancialProduct = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        FinancialProduct = TrifoldSummary.TrifoldProductType_FinancialProduct;
                        break;
                }
                return FinancialProduct;
            }
        }
        List<int> ExecutiveBenefitProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> ExecutiveBenefit = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        ExecutiveBenefit = TrifoldSummary.TrifoldProductType_ExecutiveBenefit;
                        break;
                }
                return ExecutiveBenefit;
            }
        }
        List<int> Filling500ProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> Product500Filling = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        Product500Filling = TrifoldSummary.TrifoldProductType_500Filling;
                        break;
                }
                return Product500Filling;
            }
        }
        List<int> TransitParkingAdminProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> TransitParkingAdmin = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        TransitParkingAdmin = TrifoldSummary.TrifoldProductType_TransitParkingAdmin;
                        break;
                }
                return TransitParkingAdmin;
            }
        }
        List<int> LegalServicesProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> LegalServices = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        LegalServices = TrifoldSummary.TrifoldProductType_LegalServices;
                        break;
                }
                return LegalServices;
            }
        }
        List<int> IdentifyTheftProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> IdentifyTheft = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        IdentifyTheft = TrifoldSummary.TrifoldProductType_IdentifyTheft;
                        break;
                }
                return IdentifyTheft;
            }
        }
        List<int> ShortTermMedicalProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> ShortTermMedical = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        ShortTermMedical = TrifoldSummary.TrifoldProductType_ShortTermMedical;
                        break;
                }
                return ShortTermMedical;
            }
        }
        List<int> WholeLifeIndividualProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> WholeLifeIndividual = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        WholeLifeIndividual = TrifoldSummary.TrifoldProductType_WholeLifeIndividual;
                        break;
                }
                return WholeLifeIndividual;
            }
        }
        List<int> DiseaseManagementProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> DiseaseManagement = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        DiseaseManagement = TrifoldSummary.TrifoldProductType_DiseaseManagement;
                        break;
                }
                return DiseaseManagement;
            }
        }
        List<int> TobaccoPolicyProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> TobaccoPolicy = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        TobaccoPolicy = TrifoldSummary.TrifoldProductType_TobaccoPolicy;
                        break;
                }
                return TobaccoPolicy;
            }
        }
        List<int> GroupHomeAndAutoProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> GroupHomeAndAuto = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        GroupHomeAndAuto = TrifoldSummary.TrifoldProductType_GroupHomeAndAuto;
                        break;
                }
                return GroupHomeAndAuto;
            }
        }
        List<int> MinimumEssentialCoverageProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> MinimumEssentialCoverage = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        MinimumEssentialCoverage = TrifoldSummary.TrifoldProductType_MinimumEssentialCoverage;
                        break;
                }
                return MinimumEssentialCoverage;
            }
        }
        List<int> IND_INDIV_LONG_TERM_CAREProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> IND_INDIV_LONG_TERM_CARE = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        IND_INDIV_LONG_TERM_CARE = TrifoldSummary.TrifoldProductType_IND_INDIV_LONG_TERM_CARE;
                        break;
                }
                return IND_INDIV_LONG_TERM_CARE; ;
            }
        }
        List<int> IndividualDisabilityProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> IndividualDisability = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        IndividualDisability = TrifoldSummary.TrifoldProductType_IndividualDisability;
                        break;
                }
                return IndividualDisability; ;
            }
        }
        List<int> MedicareSupplementProductProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> MedicareSupplement = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        MedicareSupplement = TrifoldSummary.TrifoldProductType_MedicareSupplement;
                        break;
                }
                return MedicareSupplement; ;
            }
        }
        List<int> FeeForService_ConsultingProjectProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> FeeForService_Consulting_Project = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        FeeForService_Consulting_Project = TrifoldSummary.TrifoldProductType_FeeForService_Consulting_Project;
                        break;
                }
                return FeeForService_Consulting_Project; ;
            }
        }
        List<int> FeeForService_PBMConsultingProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> FeeForService_PBMConsulting = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        FeeForService_PBMConsulting = TrifoldSummary.TrifoldProductType_FeeForService_PBMConsulting;
                        break;
                }
                return FeeForService_PBMConsulting;
            }
        }
        List<int> FeeForService_HR_Ben_Admin_ServicesProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> FeeForService_HR_Ben_Admin_Services = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        FeeForService_HR_Ben_Admin_Services = TrifoldSummary.TrifoldProductType_FeeForService_HR_Ben_Admin_Services;
                        break;
                }
                return FeeForService_HR_Ben_Admin_Services;
            }
        }
        List<int> LongTermCareProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> LongTermCare = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        LongTermCare = TrifoldSummary.TrifoldProductType_LongTermCare;
                        break;
                }
                return LongTermCare;
            }
        }
        List<int> MedicalPlanRidersProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> MedicalPlanRiders = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        MedicalPlanRiders = TrifoldSummary.TrifoldProductType_MedicalPlanRiders;
                        break;
                }
                return MedicalPlanRiders;
            }
        }
        List<int> OnsiteMedicenterProductTypes
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<int> OnsiteMedicenter = new List<int>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        OnsiteMedicenter = TrifoldSummary.TrifoldProductType_OnsiteMedicenter;
                        break;
                }
                return OnsiteMedicenter;
            }
        }
        #endregion

        List<BenefitSummaryStructure> BenefitSummaryStructureMap
        {
            get
            {
                ContentOptions SelectedOption = GetContentOptions();
                List<BenefitSummaryStructure> BenefitSummaryStructureMap = new List<BenefitSummaryStructure>();
                switch (SelectedOption)
                {
                    case ContentOptions.Trifold:
                        BenefitSummaryStructureMap = TrifoldSummary.BenefitSummarySelectionMap;
                        break;
                }
                return BenefitSummaryStructureMap;
            }
        }
        /// <summary>
        /// Return Selected Plans/Benefit Summarys
        /// </summary>
        List<SummarySelectionViewModel> SelectedPlansBenefitSummary
        {
            get
            {
                List<SummarySelectionViewModel> lstSelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
                lstSelectedPlansBenefitSummary = Session[AccessKeys.SelectedSummaries.ToString()] == null ? lstSelectedPlansBenefitSummary : Session[AccessKeys.SelectedSummaries.ToString()] as List<SummarySelectionViewModel>;
                return lstSelectedPlansBenefitSummary;
            }
            set
            {
                Session[AccessKeys.SelectedSummaries.ToString()] = value;
            }
        }
        /// <summary>
        /// Return Selected Products
        /// </summary>
        List<SummarySelectionViewModel> SelectedProducts
        {
            get
            {
                List<SummarySelectionViewModel> lstSelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
                lstSelectedPlansBenefitSummary = Session[AccessKeys.SelectedProducts.ToString()] == null ? lstSelectedPlansBenefitSummary : Session[AccessKeys.SelectedProducts.ToString()] as List<SummarySelectionViewModel>;
                return lstSelectedPlansBenefitSummary;
            }
            set
            {
                Session[AccessKeys.SelectedProducts.ToString()] = value;
            }
        }
        List<SummaryOptionItemViewModel> BenefitSummaryOptionDataSource
        {
            get
            {
                List<SummaryOptionItemViewModel> DataSource = new List<SummaryOptionItemViewModel>();
                DataSource = Session[AccessKeys.BenefitSummaryOptionDataSource.ToString()] == null ? DataSource : Session[AccessKeys.BenefitSummaryOptionDataSource.ToString()] as List<SummaryOptionItemViewModel>;
                return DataSource;
            }
            set
            {
                Session[AccessKeys.BenefitSummaryOptionDataSource.ToString()] = value;
            }
        }

        #endregion

        #region UI Event Handler
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.MaintainScrollPositionOnPostBack = true;
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                IsDescriptionHide = true;
                ShowHideDescriptionPanel();
                mvMainContainer.ActiveViewIndex = 0;
                SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                objCommFun.GetUserDetails();
                Activity_Group = "Analytics";
                Activity = TitleSpan.InnerText;
                Session[AccessKeys.DeliverableCategory.ToString()] = "Analytics";
                ddlcontents.SelectedValue = ContentOptions.Trifold.ToString();
                ddlcontents_SelectedIndexChanged(null, null);
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlcontents_SelectedIndexChanged(object sender, EventArgs e)
        {
            spnClientDescription.InnerText = "";
            ContentOptions SelectedContent = GetContentOptions();

            IsDescriptionHide = true;

            ddlStyle.SelectedValue = "Select";
            ddlStyle.Visible = false;
            lblStyleLabel.Visible = false;

            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            trAccountContact.Style.Add("display", "none");

            ddlStyle_SelectedIndexChanged(null, null);
            ddlClient_SelectedIndexChanged(null, null);
            switch (SelectedContent)
            {
                case ContentOptions.Trifold:
                    spnClientDescription.InnerText = "Indicate which BenefitPoint client you would like to create a Trifold for.";
                    ddlStyle.Visible = true;
                    lblStyleLabel.Visible = true;
                    trAccountContact.Style.Add("display", "none");
                    break;

            }
            SetCriteriaPage();
        }
        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            int ActivePageIndex = int.Parse(hdnCriteriaPageIndex.Value);
            hdnCriteriaPageIndex.Value = (ActivePageIndex - 1).ToString();
            string CurrentViewName = mvMainContainer.GetActiveView().ID;
            System.Web.UI.WebControls.View PrevView = GetCriteriaPage();
            switch (CurrentViewName)
            {
                case "viewPlanBenefitSummary":
                    break;
                case "viewBenefitSummarySelection":
                    UpdateBenefitSummaryOptionDataSource();
                    break;
                case "viewMobileAppLegalNotice":

                    break;
            }
            mvMainContainer.SetActiveView(PrevView);
            SetCriteriaPage();
        }
        protected void btnNext_Click(object sender, EventArgs e)
        {
            bool IsSuccess = false;
            int ActivePageIndex = int.Parse(hdnCriteriaPageIndex.Value);
            string CurrentViewName = mvMainContainer.GetActiveView().ID;

            switch (CurrentViewName)
            {
                case "viewPlanBenefitSummary":
                    AddSelctedPlanBenefitSummaryToSessions();
                    AddSelectedProductsToSession();
                    if (ValidatePlanBenefitSummaryView())
                    {
                        if (IsValidSelectedBenefitSummaries())
                        {
                            BindEligibilities();
                            BuildSummarySelectionGrid();
                            IsSuccess = true;
                        }
                    }
                    break;
                case "viewBenefitSummarySelection":
                    if (ValidateBenefitSummarySelectionView())
                    {
                        UpdateBenefitSummaryOptionDataSource();
                        IsSuccess = IsValidSelectedBenefitSummaryOptions();
                    }
                    break;
                case "viewMobileAppLegalNotice":
                    IsSuccess = true;
                    break;
            }

            if (IsSuccess)
            {
                hdnCriteriaPageIndex.Value = (ActivePageIndex + 1).ToString();
                System.Web.UI.WebControls.View NextView = GetCriteriaPage();
                mvMainContainer.SetActiveView(NextView);
                SetCriteriaPage();
            }
        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ddlClient.Focus();
                return;
            }
            LoadPlansAndProducts();
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();
            HidePlansGrid();
            ClearProductGrid();
            HideProductGrid();
            tblPlanProductCriteria.Style.Add("display", "none");
            rdlPlanStatus.SelectedValue = PlanStatus.Pending.ToString();
            SelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
            SelectedProducts = new List<SummarySelectionViewModel>();
            BenefitSummaryOptionDataSource = null;
            ddlAccountContact.Items.Clear();
            ddlEligibilityRule.Items.Clear();
            ddlEligibilityRule.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlMobileAppOptions.SelectedValue = "NOT_INCLUDED";
            ddlMobileAppOptions_SelectedIndexChanged(null, null);
            if (ddlClient.SelectedIndex > 0)
            {
                tblPlanProductCriteria.Style.Add("display", "");
                BindAccountContact();
            }
        }
        protected void rdlPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            HidePlansGrid();
            HideProductGrid();
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void gvPlanBernefitSummaryOptions_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            SummaryOptionItemViewModel objItemViewModel = e.Row.DataItem as SummaryOptionItemViewModel;
            if (objItemViewModel != null)
            {

                DropDownList ddlPlanBenefitSummary = e.Row.FindControl("ddlPlanBenefitSummary") as DropDownList;
                Label lblBenefitSummary = e.Row.FindControl("lblBenefitSummary") as Label;

                ddlPlanBenefitSummary.Items.Clear();
                ddlPlanBenefitSummary.DataSource = objItemViewModel.SummaryDataSource;
                ddlPlanBenefitSummary.DataTextField = "Text";
                ddlPlanBenefitSummary.DataValueField = "Value";
                ddlPlanBenefitSummary.DataBind();
                ddlPlanBenefitSummary.Items.Insert(0, new ListItem("Select", "0"));
                lblBenefitSummary.Visible = false;
                if (objItemViewModel.SummaryDataSource.Count == 1)
                {
                    ddlPlanBenefitSummary.SelectedValue = objItemViewModel.SummaryDataSource.First().Value;
                    ddlPlanBenefitSummary.Visible = false;
                    lblBenefitSummary.Text = objItemViewModel.SummaryDataSource.First().Text;
                    lblBenefitSummary.Visible = true;
                }
                else
                {
                    if (objItemViewModel.SummaryId != 0)
                    {
                        ddlPlanBenefitSummary.SelectedValue = objItemViewModel.PlanId + "@" + objItemViewModel.SummaryId;
                    }
                }

                if (objItemViewModel.SummaryApplicable)
                {
                    if ((objItemViewModel.MaxBenefitSummaries > 1) || (objItemViewModel.ContributionApplicable == true || objItemViewModel.RateApplicable == true))
                        e.Row.Style.Add("display", "");
                    else
                        e.Row.Style.Add("display", "none");
                }
                else
                {
                    e.Row.Style.Add("display", "none");
                }
                
            }

        }
        protected void ddlPlanBenefitSummary_SelectedIndexChanged(object sender, EventArgs e)
        {
            BPBusiness bp = new BPBusiness();
            DropDownList ddlPlanBenefitSummary = sender as DropDownList;
            string[] IdParts = ddlPlanBenefitSummary.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);

            Label lblContributionRate = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("lblContributionRate") as Label;
            DropDownList ddlContribution1 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("ddlContribution1") as DropDownList;
            DropDownList ddlContribution2 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("ddlContribution2") as DropDownList;
            HiddenField hdnContributionId1 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnContributionId1") as HiddenField;
            HiddenField hdnContributionApplicable = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnContributionApplicable") as HiddenField;
            HiddenField hdnMaxContributionCount = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnMaxContributionCount") as HiddenField;

            DropDownList ddlRates1 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("ddlRates1") as DropDownList;
            DropDownList ddlRates2 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("ddlRates2") as DropDownList;
            HiddenField hdnRateId1 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnRateId1") as HiddenField;
            HiddenField hdnRateApplicable = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnRateApplicable") as HiddenField;
            HiddenField hdnMaxRateCount = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnMaxRateCount") as HiddenField;

            HiddenField hdnPlnaId = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnPlnaId") as HiddenField;
            HiddenField hdnSummaryId = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnSummaryId") as HiddenField;

            hdnPlnaId.Value = "0";
            hdnSummaryId.Value = "0";


            if (ddlPlanBenefitSummary.SelectedValue != "0")
            {
                string PlanID_BenefitSummaryId = ddlPlanBenefitSummary.SelectedValue;
                string[] PlanID_BenefitSummaryIdParts = PlanID_BenefitSummaryId.Split('@');
                hdnPlnaId.Value = PlanID_BenefitSummaryIdParts[0];
                hdnSummaryId.Value = PlanID_BenefitSummaryIdParts[1];
            }

            ddlContribution1.Items.Clear();
            ddlContribution1.Visible = false;

            ddlContribution2.Items.Clear();
            ddlContribution2.Visible = false;

            ddlRates1.Items.Clear();
            ddlRates1.Visible = false;

            ddlRates2.Items.Clear();
            ddlRates2.Visible = false;
            lblContributionRate.Visible = false;

            if (bool.Parse(hdnContributionApplicable.Value))
            {
                List<Contribution> ContributionList = new List<Contribution>();
                ddlContribution1.Visible = true;
                if (int.Parse(hdnPlnaId.Value) > 0)
                {
                    ContributionList = bp.FindContributions(int.Parse(hdnPlnaId.Value), SessionId);//(4765506);
                    ddlContribution1.DataSource = ContributionList;
                    ddlContribution1.DataBind();
                    ddlContribution2.DataSource = ContributionList;
                    ddlContribution2.DataBind();

                    if (ContributionList.Count == 0)
                    {
                        ddlContribution1.Visible = false;
                        lblContributionRate.Visible = true;
                        lblContributionRate.Text = "There are no contribution schedules";

                    }
                }
            }
            else if (bool.Parse(hdnRateApplicable.Value))
            {
                ddlRates1.Visible = true;
                List<Rate> RateList = new List<Rate>();
                if (int.Parse(hdnPlnaId.Value) > 0)
                {
                    RateList = bp.FindRates(int.Parse(hdnPlnaId.Value), SessionId);
                    ddlRates1.DataSource = RateList;
                    ddlRates1.DataBind();
                    ddlRates2.DataSource = RateList;
                    ddlRates2.DataBind();
                    if (RateList.Count == 0)
                    {
                        ddlRates1.Visible = false;
                        lblContributionRate.Visible = true;
                        lblContributionRate.Text = "There are no rate structures";
                    }
                }
            }
            else
            {
                lblContributionRate.Text = "Rate or Contribution not applicable";
                lblContributionRate.Visible = true;
            }


            ddlContribution1.Items.Insert(0, new ListItem("Do Not Include", "0"));
            if (hdnContributionId1.Value != "-1")
                ddlContribution1.SelectedValue = hdnContributionId1.Value;
            else
            {
                if (ddlContribution1.Items.Count == 2)
                {
                    ddlContribution1.Items[1].Selected = true;
                }
            }
            hdnContributionId1.Value = "-1";
            ddlContribution2.Items.Insert(0, new ListItem("No Additional Contribution Selected", "0"));
            ddlRates1.Items.Insert(0, new ListItem("Do Not Include", "0"));
            if (hdnRateId1.Value != "-1")
                ddlRates1.SelectedValue = hdnRateId1.Value;
            else
            {
                if (ddlRates1.Items.Count == 2)
                {
                    ddlRates1.Items[1].Selected = true;
                }
            }
            hdnRateId1.Value = "-1";
            ddlRates2.Items.Insert(0, new ListItem("No Additional Rate Selected", "0"));

            if (bool.Parse(hdnContributionApplicable.Value))
            {
                ddlContributionRate1_SelectedIndexChanged(ddlContribution1, null);
            }
            else if (bool.Parse(hdnRateApplicable.Value))
            {
                ddlContributionRate1_SelectedIndexChanged(ddlRates1, null);
            }
            else
            {
                ddlContributionRate1_SelectedIndexChanged(ddlContribution1, null);
            }
        }
        protected void ddlContributionRate1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlContributionRate1 = sender as DropDownList;
            string[] IdParts = ddlContributionRate1.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);

            DropDownList ddlContribution2 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("ddlContribution2") as DropDownList;
            HiddenField hdnContributionApplicable = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnContributionApplicable") as HiddenField;
            HiddenField hdnMaxContributionCount = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnMaxContributionCount") as HiddenField;
            HiddenField hdnContributionId2 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnContributionId2") as HiddenField;

            DropDownList ddlRates2 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("ddlRates2") as DropDownList;
            HiddenField hdnRateApplicable = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnRateApplicable") as HiddenField;
            HiddenField hdnMaxRateCount = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnMaxRateCount") as HiddenField;
            HiddenField hdnRateId2 = gvPlanBernefitSummaryOptions.Rows[RowIndex].FindControl("hdnRateId2") as HiddenField;

            ddlRates2.Visible = false;
            ddlRates2.SelectedValue = hdnRateId2.Value;
            hdnRateId2.Value = "0";

            ddlContribution2.Visible = false;
            ddlContribution2.SelectedValue = hdnContributionId2.Value;
            hdnContributionId2.Value = "0";

            if (bool.Parse(hdnContributionApplicable.Value))
            {
                if (ddlContributionRate1.SelectedValue != "0")
                {
                    if (ddlContributionRate1.Items.Count > 2 && int.Parse(hdnMaxContributionCount.Value) > 1)
                        ddlContribution2.Visible = true;
                }
            }
            else if (bool.Parse(hdnRateApplicable.Value))
            {
                if (ddlContributionRate1.SelectedValue != "0")
                {
                    if (ddlContributionRate1.Items.Count > 2 && int.Parse(hdnMaxRateCount.Value) > 1)
                        ddlRates2.Visible = true;
                }
            }
        }
        protected void chkPlanHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanHeaderSelect = sender as CheckBox;
            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox chkItemSelect = row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                    chkItemSelect.Checked = chkPlanHeaderSelect.Checked;
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>SetPlanProductGridRowSelected();SetGridViewRowStyle();MaintainPlanGridScrollPosition();</script>", false);
        }
        protected void chkPlanSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanSelect = sender as CheckBox;
            AddSelctedPlanBenefitSummaryToSessions();
            if (chkPlanSelect.Checked)
            {
                if (!IsValidSelectedBenefitSummaries(false))
                {
                    chkPlanSelect.Checked = false;
                    AddSelctedPlanBenefitSummaryToSessions();

                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>SetPlanProductGridRowSelected();SetGridViewRowStyle();MaintainPlanGridScrollPosition();</script>", false);
        }
        protected void chkProductHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanHeaderSelect = sender as CheckBox;
            foreach (GridViewRow row in grdProducts.Rows)
            {
                CheckBox chkItemSelect = row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                    chkItemSelect.Checked = chkPlanHeaderSelect.Checked;
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>SetPlanProductGridRowSelected();SetGridViewRowStyle();MaintainPlanGridScrollPosition();</script>", false);
        }
        protected void ddlMobileAppOptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtMobileAppCode.Text = string.Empty;
            switch (ddlMobileAppOptions.SelectedValue)
            {
                case "NOT_INCLUDED":
                    dvMobileAppTextBox.Style.Add("display", "none");
                    break;
                case "INCLUDED":
                    dvMobileAppTextBox.Style.Add("display", "");
                    break;
                default:
                    dvMobileAppTextBox.Style.Add("display", "none");
                    break;
            }
        }
        protected void ddlStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStyle.SelectedIndex == 0)
            {
                IsDescriptionHide = true;
                lblDescription.Text = string.Empty;
            }
            else
            {
                lblDescription.Text = "Description for " + ddlStyle.SelectedItem.Text;
            }
            ShowHideDescriptionPanel();

        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            if (ValidateMobileAppLegalNoticeView())
            {
            }
        }
        protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            Plan objItemViewModel = e.Row.DataItem as Plan;
            if (objItemViewModel != null)
            {
                if (objItemViewModel.ProductStatus == PlanStatus.Current.ToString())
                {
                    //e.Row.Style.Add("color", "#0000FF");
                    e.Row.Cells[4].Style.Add("color", "#0000FF");
                }
                if (objItemViewModel.ProductStatus == PlanStatus.ArchivedPriorYear.ToString())
                {
                    //e.Row.Style.Add("color", "#8B0000");
                    e.Row.Cells[4].Style.Add("color", "#8B0000");
                }
                if (objItemViewModel.ProductStatus == PlanStatus.Pending.ToString())
                {
                }
                CheckBox chkItemSelect = e.Row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                {
                    SummarySelectionViewModel prevSelectedSummary = SelectedPlansBenefitSummary.Where(p => p.ProductId == objItemViewModel.ProductId && p.SummaryId == objItemViewModel.SummaryID).FirstOrDefault();
                    if (prevSelectedSummary != null)
                    {
                        chkItemSelect.Checked = true;
                    }
                }
            }
        }
        protected void grdProducts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            Plan objItemViewModel = e.Row.DataItem as Plan;
            if (objItemViewModel != null)
            {
                if (objItemViewModel.ProductStatus == PlanStatus.Current.ToString())
                {
                    e.Row.Cells[4].Style.Add("color", "#0000FF");
                }
                if (objItemViewModel.ProductStatus == PlanStatus.ArchivedPriorYear.ToString())
                {
                    e.Row.Cells[4].Style.Add("color", "#8B0000");
                }
                if (objItemViewModel.ProductStatus == PlanStatus.Pending.ToString())
                {
                }
                CheckBox chkItemSelect = e.Row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                {
                    SummarySelectionViewModel prevSelectedSummary = SelectedProducts.Where(p => p.ProductId == objItemViewModel.ProductId).FirstOrDefault();
                    if (prevSelectedSummary != null)
                    {
                        chkItemSelect.Checked = true;
                    }
                }
            }
        }
        #endregion

        #region functions
        private void BindEligibilities()
        {
            List<Eligibility> lstEligibilityNames = new List<Eligibility>();
            string PreviousSlectedValue = string.Empty;
            try
            {
                PreviousSlectedValue = ddlEligibilityRule.SelectedValue;
            }
            catch (Exception ex)
            {

            }
            ddlEligibilityRule.Items.Clear();
            List<Eligibility> EligibilityList = new List<Eligibility>();
            foreach (SummarySelectionViewModel plan in SelectedPlansBenefitSummary)
            {
                if (MedicalPlanTypes.Contains(plan.ProductTypeId) || DentalPlanTypes.Contains(plan.ProductTypeId) || VisionPlanTypes.Contains(plan.ProductTypeId))
                {
                    EligibilityList = bp.FindEligibility(plan.ProductId, SessionId);

                    foreach (var item in EligibilityList)
                    {
                        Eligibility eligibilityItem = new Eligibility();
                        eligibilityItem.EligibilityId = item.EligibilityId;
                        eligibilityItem.EligibilityDescription = plan.ProductTypeDescription + " - " + Convert.ToString(plan.PolicyNumber) + " - " + item.EligibilityDescription;

                        if (!lstEligibilityNames.Equals(eligibilityItem.EligibilityDescription))
                        {
                            lstEligibilityNames.Add(eligibilityItem);
                        }
                    }
                }
            }
            ddlEligibilityRule.DataSource = lstEligibilityNames;
            ddlEligibilityRule.DataBind();
            ddlEligibilityRule.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlEligibilityRule.SelectedIndex = ddlEligibilityRule.Items.IndexOf(ddlEligibilityRule.Items.FindByValue(PreviousSlectedValue));
        }
        private void BindAccountContact()
        {
            bool BindContact = false;
            ContentOptions SelectedContent = GetContentOptions();
            switch (SelectedContent)
            {
                case ContentOptions.Trifold:
                    BindContact = true;
                    break;
            }
            if (BindContact)
            {
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
                Session["Contact"] = ContactList;
                ddlAccountContact.DataSource = ContactList;
                ddlAccountContact.DataBind();
                ddlAccountContact.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlAccountContact.Items.Insert(1, new ListItem("None", "-1"));
            }
        }
        private ContentOptions GetContentOptions()
        {
            ContentOptions SelectedContent = ContentOptions.Select;
            switch (ddlcontents.SelectedValue)
            {
                case "Trifold":
                    SelectedContent = ContentOptions.Trifold;
                    break;
            }
            return SelectedContent;
        }
        private void SetCriteriaPage()
        {

            ClientBenefitSummaryUIViewModel UIConfig = ViewConfig;

            pnlFormDescription.Visible = UIConfig.IsDeliverableDescriptionVisible;
            pnlCriteriaInformation.Visible = UIConfig.IsCriteriaInformarionVisible;
            lblCriteriaPageIndex.Text = UIConfig.CriteraPageIndexText;

            btnNext.Visible = UIConfig.IsNextButtonVisibles;
            btnNext.Text = UIConfig.NextButtonText;

            btnSummary.Visible = UIConfig.IsCreateButtonVisibles;
            btnSummary.Text = UIConfig.CreateButtonText;

            btnPrevious.Visible = UIConfig.IsPreviousButtonVisibles;
            btnPrevious.Text = UIConfig.PreviousButtonText;

            FillCriteriaInformation();
            //ShowHideDescriptionPanel();
            int ActivePageIndex = int.Parse(hdnCriteriaPageIndex.Value);
            if (ActivePageIndex > 0)
                tblDesignLayoutOPtions.Style.Add("display", "none");
            else
                tblDesignLayoutOPtions.Style.Add("display", "");
        }
        private void FillCriteriaInformation()
        {
            lblSelectedClient.Text = ddlClient.SelectedIndex > 0 ? ddlClient.SelectedItem.Text : string.Empty;
            lblSelectedContentOption.Text = ddlcontents.SelectedItem.Text;
            lblSelectedStyle.Text = ddlStyle.SelectedItem.Text;

        }
        private void LoadPlansAndProducts()
        {
            AddSelctedPlanBenefitSummaryToSessions();
            AddSelectedProductsToSession();
            IsPlanProductViewed = true;
            BenefitSummaryOptionDataSource = null;
            List<Plan> PlanList = new List<Plan>();
            PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
            LoadPlans(PlanList);
            LoadProducts(PlanList);
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>SetGridViewRowStyle();SetPlanProductGridRowSelected();</script>", false);
        }
        private void LoadPlans(List<Plan> PlanList)
        {
            ClearPlanGrid();
            List<Plan> FilteredPlanList = new List<Plan>();
            List<string> lstStatuses = new List<string>();
            if (PlanList != null)
            {
                if (PlanList.Count > 0)
                {
                    foreach (ListItem item in rdlPlanStatus.Items)
                    {
                        if (item.Selected)
                            lstStatuses.Add(item.Value);
                    }
                    bool CanAdd = false;

                    foreach (Plan item in PlanList)
                    {
                        CanAdd = false;
                        if (lstStatuses.Contains(PlanStatus.Pending.ToString()))
                        {
                            if (item.EffectiveDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                    item.ProductStatus = PlanStatus.Pending.ToString();
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.Current.ToString()))
                        {
                            if (item.EffectiveDate.Date < System.DateTime.Now.Date && item.RenewalDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                {
                                   CanAdd = true;
                                    item.ProductStatus = PlanStatus.Current.ToString();
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.ArchivedPriorYear.ToString()))
                        {
                            if (item.RenewalDate.Date == System.DateTime.Now.Date || (item.RenewalDate.Date > System.DateTime.Now.AddYears(-1).Date && item.RenewalDate.Date <= DateTime.Now.Date))
                            {
                                if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                    item.ProductStatus = PlanStatus.ArchivedPriorYear.ToString();
                                }
                            }
                        }

                       

                        if (MedicalPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.MedicalLOC;
                        }
                        if (DentalPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.DentalLOC;
                        }
                        if (VisionPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.VisionLOC;
                        }
                        if (HSAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.HSALOC;
                        }
                        if (HRAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.HRALOC;
                        }
                        if (LifeADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.LifeADDLOC;
                        }
                        if (GroupTermPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.GroupTermLifePlanType_CommonCriteria;
                        }
                        if (ADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.ADNDPlanType_CommonCriteria;
                        }
                        if (VoluntaryLifePlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.VoluntaryLife;
                        }
                        if (VoluntaryADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.Voluntary_ADNDPlanType_CommonCriteria;
                        }
                        if (STDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.STDLOC;
                        }
                        if (LTDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.LTDLOC;
                        }
                        if (EAPPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.EAPLOC;
                        }
                        if (FSAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.FSAPlanType;
                        }
                        if (WellnessPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.Wellness;
                        }
                        if (StopLossPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.StopLoss;
                        }

                        if (PlnaTypes401K.Contains(item.ProductTypeId))
                        {
                            item.LOC = "401K";
                        }
                        if (BTAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = "BTA";
                        }
                        if (CanAdd)
                            FilteredPlanList.Add(item);
                    }
                }
            }

            FilteredPlanList = SortPlans(FilteredPlanList);

            grdPlans.DataSource = FilteredPlanList;
            grdPlans.DataBind();

            SelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
            trPlanContainer.Style.Add("display", "");

            if (FilteredPlanList.Count > 0)
            {
                grdPlans.Style.Add("display", "");
            }
            else
            {
                tblEmptyPlanTemplate.Style.Add("display", "");
            }

            AvailablePlans = FilteredPlanList;
        }
        private void HidePlansGrid()
        {
            IsPlanProductViewed = false;
            trPlanContainer.Style.Add("display", "none");
            tblEmptyPlanTemplate.Style.Add("display", "none");
            grdPlans.Style.Add("display", "none");
        }
        private void ClearPlanGrid()
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            AvailablePlans = null;
            BenefitSummaryOptionDataSource = null;

        }
        private void LoadProducts(List<Plan> PlanList)
        {
            ClearProductGrid();
            List<Plan> FilteredPlanList = new List<Plan>();
            List<string> lstStatuses = new List<string>();
            if (PlanList != null)
            {
                if (PlanList.Count > 0)
                {
                    foreach (ListItem item in rdlPlanStatus.Items)
                    {
                        if (item.Selected)
                            lstStatuses.Add(item.Value);
                    }
                    bool CanAdd = false;
                    foreach (Plan item in PlanList)
                    {
                        CanAdd = false;
                        item.SummaryID = 0;
                        item.SummaryName = string.Empty;
                        if (lstStatuses.Contains(PlanStatus.Pending.ToString()))
                        {
                            if (item.EffectiveDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                    item.ProductStatus = PlanStatus.Pending.ToString();
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.Current.ToString()))
                        {
                            if (item.EffectiveDate.Date < System.DateTime.Now.Date && item.RenewalDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                    item.ProductStatus = PlanStatus.Current.ToString();
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.ArchivedPriorYear.ToString()))
                        {
                            if (item.RenewalDate.Date == System.DateTime.Now.Date || (item.RenewalDate.Date > System.DateTime.Now.AddYears(-1).Date && item.RenewalDate.Date <= DateTime.Now.Date))
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                    item.ProductStatus = PlanStatus.ArchivedPriorYear.ToString();
                                }
                            }
                        }
                        if (CanAdd)
                            FilteredPlanList.Add(item);
                    }
                }
            }
            FilteredPlanList = (from l in FilteredPlanList
                                orderby l.ProductTypeId ascending
                                select l).ToList();

            grdProducts.DataSource = FilteredPlanList;
            grdProducts.DataBind();

            SelectedProducts = new List<SummarySelectionViewModel>();
            trProductContainer.Style.Add("display", "");
            if (FilteredPlanList.Count > 0)
            {
               grdProducts.Style.Add("display", "");
            }
            else
            {
                tblEmptyProductTemplate.Style.Add("display", "");
            }

            AvailableProducts = FilteredPlanList;
        }
        private void HideProductGrid()
        {
            IsPlanProductViewed = false;
            trProductContainer.Style.Add("display", "none");
            tblEmptyProductTemplate.Style.Add("display", "none");
            grdProducts.Style.Add("display", "none");
        }
        private void ClearProductGrid()
        {
            grdProducts.DataSource = null;
            grdProducts.DataBind();
            AvailableProducts = null;
        }
        private void ResetForm()
        {
            #region Criteria Page 1
            BenefitSummaryOptionDataSource = null;
            ddlcontents.SelectedValue = ContentOptions.Select.ToString();
            ddlStyle.SelectedValue = "Select";
            txtsearch.Text = "";
            rdlClient.SelectedIndex = 0;
            ddlClient.Items.Clear();
            ddlClient.Items.Add(new ListItem("Select", ""));
            rdlPlanStatus.SelectedValue = PlanStatus.Pending.ToString();
            SelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
            SelectedProducts = new List<SummarySelectionViewModel>();
            #endregion
            #region Criteria Page 2
            ddlEligibilityRule.Items.Clear();
            ddlEligibilityRule.Items.Add(new ListItem("Select", string.Empty));
            #endregion
            #region Criteria Page 3
            ddlMobileAppOptions.SelectedValue = "NOT_INCLUDED";
            txtMobileAppCode.Text = string.Empty;
            #endregion
            ddlcontents_SelectedIndexChanged(null, null);
            ddlClient_SelectedIndexChanged(null, null);
            ddlMobileAppOptions_SelectedIndexChanged(null, null);
        }
        private void AddSelctedPlanBenefitSummaryToSessions()
        {
            ConstantValue cv = new ConstantValue();
            List<SummarySelectionViewModel> lstSelectedSummaries = new List<SummarySelectionViewModel>();
            SelectedPlansBenefitSummary = lstSelectedSummaries;
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true)
                        {
                            SummarySelectionViewModel BenefitSummaryItem = new SummarySelectionViewModel();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                BenefitSummaryItem.ProductTypeDescription = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeDescription = string.Empty;
                            }
                            // For SummaryName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                BenefitSummaryItem.SummaryName = Convert.ToString(grRow.Cells[1].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryName = string.Empty;
                            }
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                BenefitSummaryItem.CarrierName = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.CarrierName = string.Empty;
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                BenefitSummaryItem.EffectiveDate = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.EffectiveDate = string.Empty;
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                BenefitSummaryItem.RenewalDate = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.RenewalDate = string.Empty;
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                BenefitSummaryItem.PolicyNumber = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.PolicyNumber = string.Empty;
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                BenefitSummaryItem.ProductId = int.Parse(grRow.Cells[6].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductId = 0;
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                BenefitSummaryItem.ProductName = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductName = string.Empty;
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 the 'You are not authorized to access the requesn it gives an errorted information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    BenefitSummaryItem.ProductTypeId = int.Parse((grRow.Cells[8].Text));
                                }
                                else
                                {
                                    BenefitSummaryItem.ProductTypeId = 0;
                                }
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
                            {
                                BenefitSummaryItem.SummaryId = int.Parse((grRow.Cells[9].Text));
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryId = 0;
                            }

                            if (MedicalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.MedicalLOC;
                            }
                            if (DentalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.DentalLOC;
                            }
                            if (VisionPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.VisionLOC;
                            }
                            if (LifeADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LifeADDLOC;
                            }
                            if (GroupTermPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.GroupTermLifePlanType_CommonCriteria;
                            }
                            if (ADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.ADNDPlanType_CommonCriteria;
                            }
                            if (VoluntaryLifePlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.VoluntaryLife;
                            }
                            if (VoluntaryADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.Voluntary_ADNDPlanType_CommonCriteria;
                            }
                            if (LTDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LTDLOC;
                            }

                            if (STDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.STDLOC;
                            }

                            if (EAPPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.EAPLOC;
                            }

                            if (FSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.FSAPlanType;
                            }
                            if (HSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.HSALOC;
                            }
                            if (HRAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.HRALOC;
                            }
                            if (StopLossPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.StopLoss;
                            }
                            if (WellnessPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.Wellness;
                            }
                            if (PlnaTypes401K.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = "401K";
                            }
                            if (BTAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = "BTA";
                            }
                            lstSelectedSummaries.Add(BenefitSummaryItem);
                            rowCount++;
                        }
                    }//Foreach Close
                    SelectedPlansBenefitSummary = lstSelectedSummaries;
                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private void AddSelectedProductsToSession()
        {
            ConstantValue cv = new ConstantValue();
            List<SummarySelectionViewModel> lstSelectedSummaries = new List<SummarySelectionViewModel>();
            SelectedProducts = lstSelectedSummaries;
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdProducts != null)
                {
                    foreach (GridViewRow grRow in grdProducts.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true)
                        {
                            SummarySelectionViewModel BenefitSummaryItem = new SummarySelectionViewModel();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                BenefitSummaryItem.ProductTypeDescription = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeDescription = string.Empty;
                            }
                            // For SummaryName
                            BenefitSummaryItem.SummaryName = string.Empty;
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                BenefitSummaryItem.CarrierName = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.CarrierName = string.Empty;
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                BenefitSummaryItem.EffectiveDate = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.EffectiveDate = string.Empty;
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                BenefitSummaryItem.RenewalDate = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.RenewalDate = string.Empty;
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                BenefitSummaryItem.PolicyNumber = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.PolicyNumber = string.Empty;
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                BenefitSummaryItem.ProductId = int.Parse(grRow.Cells[6].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductId = 0;
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                BenefitSummaryItem.ProductName = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductName = string.Empty;
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.ProductTypeId = int.Parse((grRow.Cells[8].Text));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeId = 0;
                            }

                            BenefitSummaryItem.SummaryId = 0;

                            if (TelemedicineProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.TelemedicineLOC;
                            }
                            if (PatientAdvocacyProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.PatientAdvocacyLOC;
                            }
                            if (HospitalizationProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.HospitalizationLOC;
                            }
                            if (AccidentProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.AccidentLOC;
                            }
                            if (CriticalIllnesssProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.CriticalIllnessLOC;
                            }
                            if (VoluntaryCancerProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.VoluntaryCancerLOC;
                            }
                            if (LifeADDProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LifeADDProductLOC;
                            }
                            if (AbsenseMasnagementProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.AbsenceManagementProductLOC;
                            }
                            if (PetInsuranceProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.PetInsuranceLOC;
                            }
                            if (CobraAdministrationProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.COBRAAdministrationLOC;
                            }
                            if (FinancialProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.FinancialProductsAllOthersLOC;
                            }
                            if (ExecutiveBenefitProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.ExecutiveBenefitsLOC;
                            }
                            if (Filling500ProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.Filling500ProductLOC;
                            }
                            if (TransitParkingAdminProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.TransitParkingAdminLOC;
                            }
                            if (LegalServicesProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LegalServicesLOC;
                            }
                            if (IdentifyTheftProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.IdentityTheftLOC;
                            }
                            if (ShortTermMedicalProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.ShortTermMedicalLOC;
                            }
                            if (WholeLifeIndividualProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.WholeLifeIndividualLOC;
                            }
                            if (DiseaseManagementProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.DiseaseManagementLOC;
                            }
                            if (TobaccoPolicyProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.TobacoPolicyLOC;
                            }
                            if (GroupHomeAndAutoProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.GroupHomeAutoLOC;
                            }
                            if (MinimumEssentialCoverageProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.MinimumEssentialCoverageLOC;
                            }
                            if (IND_INDIV_LONG_TERM_CAREProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.IND_INDIV_LONG_TERM_CARE_LOC;
                            }
                            if (IndividualDisabilityProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.IndividualDisabilityLOC;
                            }
                            if (MedicareSupplementProductProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.MedicareSupplementLOC;
                            }
                            if (FeeForService_ConsultingProjectProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.FeeForService_ConsultingProjecLOC;
                            }
                            if (FeeForService_HR_Ben_Admin_ServicesProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.FeeForService_HRBENAdminServiceLOC;
                            }
                            if (FeeForService_PBMConsultingProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.FeeForService_PBMConsultingLOC;
                            }
                            if (LongTermCareProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LongTermCareLOC;
                            }
                            if (MedicalPlanRidersProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.MedicalPlanRidersLOC;
                            }
                            if (OnsiteMedicenterProductTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.OnsiteMedicalCenterLOC;
                            }
                            lstSelectedSummaries.Add(BenefitSummaryItem);
                            rowCount++;
                        }
                    }//Foreach Close
                    SelectedProducts = lstSelectedSummaries;
                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private bool IsValidSelectedBenefitSummaries(bool IsPostback = true)
        {
            string Scripts = "";
            ValidationViewModel objValidationResult = new ValidationViewModel();
            objValidationResult.IsSuccess = true;
            bool IsSuccess = true;
            ContentOptions SelectedOption = GetContentOptions();
            if (SelectedOption == ContentOptions.Trifold)
            {
                objValidationResult = TrifoldSummary.ValidateSelectedSummaries(SelectedPlansBenefitSummary);
            }
            
                
                if (IsPostback)
                {
                    if (objValidationResult.IsSuccess == false)
                    {
                        IsSuccess = false; 
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('" + objValidationResult.ErrorMessage + "');" + Scripts + "</script>");
                    }
                }
                else
                {
                    Scripts += "MaintainPlanGridScrollPosition();SetPlanProductGridRowSelected();SetGridViewRowStyle();";
                    if (objValidationResult.IsSuccess == false)
                    {
                        IsSuccess = false;
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>alert('" + objValidationResult.ErrorMessage + "');" + Scripts + "</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>" + Scripts + "</script>", false);
                    }
                }
            
            return IsSuccess;
        }
        private bool IsValidSelectedBenefitSummaryOptions()
        {
            string DescriptionBoxScipt = "";
            bool IsSuccess = true;
            ContentOptions SelectedOption = GetContentOptions();
            if (SelectedOption == ContentOptions.Trifold)
            {
                ValidationViewModel objValidationResult = TrifoldSummary.ValidateBenefitSummaryOptions(BenefitSummaryOptionDataSource);
                if (objValidationResult.IsSuccess == false)
                {
                    IsSuccess = false;
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('" + objValidationResult.ErrorMessage + "');" + DescriptionBoxScipt + "</script>");
                }
            }
            return IsSuccess;
        }
        public bool ValidatePlanBenefitSummaryView()
        {
            string DescriptionBoxScipt = "";
            if (ddlcontents.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Content.');" + DescriptionBoxScipt + "</script>");
                ddlcontents.Focus();
                return false;
            }
            if (ddlStyle.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Style.');" + DescriptionBoxScipt + "</script>");
                ddlStyle.Focus();
                return false;
            }
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.');" + DescriptionBoxScipt + "</script>");
                ddlClient.Focus();
                return false;
            }
            if (IsPlanProductViewed == false)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please click on View button to select Benefit Summary.');" + DescriptionBoxScipt + "</script>");
                return false;
            }
            if (SelectedPlansBenefitSummary.Count == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select atleast one Benefit Summary.');" + DescriptionBoxScipt + "</script>");
                return false;
            }
            return true;
        }
        public bool ValidateBenefitSummarySelectionView()
        {
            string DescriptionBoxScipt = "";
            if (ddlEligibilityRule.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Eligibility Rule.');" + DescriptionBoxScipt + "</script>");
                ddlEligibilityRule.Focus();
                return false;
            }
            return true;
        }
        private bool ValidateMobileAppLegalNoticeView()
        {
            string DescriptionBoxScipt = "";
            if (ddlMobileAppOptions.SelectedValue == "INCLUDED")
            {
                if (txtMobileAppCode.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter 6-Digit Mobile App Code.');" + DescriptionBoxScipt + "</script>");
                    txtMobileAppCode.Focus();
                    return false;
                }
                if (txtMobileAppCode.Text.Trim().Length < 6)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Mobile App Code must have 6 digits.');" + DescriptionBoxScipt + "</script>");
                    txtMobileAppCode.Focus();
                    return false;
                }
            }
            return true;
        }
        private void BuildSummarySelectionGrid()
        {
            List<SummaryOptionItemViewModel> lstSummaryOptionDataSource = new List<SummaryOptionItemViewModel>();
            #region Create New Data Source
            foreach (BenefitSummaryStructure item in BenefitSummaryStructureMap)
            {
                int count = 0;
                List<SummarySelectionViewModel> lstBenefitSummaryViewModel = new List<SummarySelectionViewModel>();
                List<BenefitSummaryDropDownViewModel> lstSummaryDataSource = new List<BenefitSummaryDropDownViewModel>();

                if (item.LOC == cv.LifeADDLOC)
                {
                    count = SelectedPlansBenefitSummary.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).Count();
                    lstBenefitSummaryViewModel = SelectedPlansBenefitSummary.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).ToList();
                }
                else if (item.LOC == cv.VoluntaryLifeADDLOC)
                {
                    count = SelectedPlansBenefitSummary.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).Count();
                    lstBenefitSummaryViewModel = SelectedPlansBenefitSummary.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).ToList();
                }
                else
                {
                    count = SelectedPlansBenefitSummary.Where(r => r.LOC == item.LOC).Count();
                    lstBenefitSummaryViewModel = SelectedPlansBenefitSummary.Where(r => r.LOC == item.LOC).ToList();
                }
                lstSummaryDataSource = new List<BenefitSummaryDropDownViewModel>();
                foreach (SummarySelectionViewModel SummaryItem in lstBenefitSummaryViewModel)
                {
                    BenefitSummaryDropDownViewModel DropDownItem = new BenefitSummaryDropDownViewModel();
                    DropDownItem.Text = SummaryItem.ProductTypeDescription + " | " + SummaryItem.SummaryName + " | " + SummaryItem.CarrierName + " | " + SummaryItem.EffectiveDate;
                    DropDownItem.Value = SummaryItem.ProductId + "@" + SummaryItem.SummaryId;
                    lstSummaryDataSource.Add(DropDownItem);
                }
                if (count > 0)
                {
                    if (item.LOC != cv.LifeADDLOC && item.LOC != cv.VoluntaryLifeADDLOC)
                    {
                        for (int ItemCount = 1; ItemCount <= count; ItemCount++)
                        {
                            SummaryOptionItemViewModel objItem = new SummaryOptionItemViewModel();
                            objItem.OrderText = item.MaxBenefitSummary > 1 ? item.LOC + " " + ItemCount.ToString() : item.LOC;
                            objItem.OrderNumber = ItemCount;
                            objItem.LOC = item.LOC;
                            objItem.SummaryApplicable = item.BenefitSummaryApplicable;
                            objItem.MaxBenefitSummaries = item.MaxBenefitSummary;
                            objItem.SummaryText = string.Empty;
                            objItem.SummaryId = 0;
                            objItem.PlanId = 0;

                            objItem.ContributionApplicable = item.ContributionApplicable;
                            objItem.ContributionId1 = -1;
                            objItem.ContributionText1 = string.Empty;
                            objItem.ContributionId2 = 0;
                            objItem.ContributionText2 = string.Empty;
                            objItem.MaxContributionCount = item.MaxContributionPerSummary;

                            objItem.RateApplicable = item.RateApplicable;
                            objItem.RateId1 = -1;
                            objItem.RateText1 = string.Empty;
                            objItem.RateId2 = 0;
                            objItem.RateText2 = string.Empty;
                            objItem.MaxRateCount = item.MaxRatePerBenefitSummary;
                            objItem.SummaryDataSource = lstSummaryDataSource;
                            lstSummaryOptionDataSource.Add(objItem);
                        }
                    }
                    else if (item.LOC == cv.LifeADDLOC)
                    {
                        for (int ItemCount = 1; ItemCount <= count; ItemCount++)
                        {
                            SummaryOptionItemViewModel objItem = new SummaryOptionItemViewModel();
                            objItem.OrderText = count > 1 ? item.LOC + " " + ItemCount.ToString() : item.LOC;
                            objItem.OrderNumber = ItemCount;
                            objItem.LOC = lstBenefitSummaryViewModel[ItemCount - 1].LOC;
                            objItem.SummaryApplicable = item.BenefitSummaryApplicable;
                            objItem.MaxBenefitSummaries = item.MaxBenefitSummary;
                            objItem.SummaryText = string.Empty;
                            objItem.SummaryId = 0;
                            objItem.PlanId = 0;

                            objItem.ContributionApplicable = item.ContributionApplicable;
                            objItem.ContributionId1 = -1;
                            objItem.ContributionText1 = string.Empty;
                            objItem.ContributionId2 = 0;
                            objItem.ContributionText2 = string.Empty;
                            objItem.MaxContributionCount = item.MaxContributionPerSummary;

                            objItem.RateApplicable = item.RateApplicable;
                            objItem.RateId1 = -1;
                            objItem.RateText1 = string.Empty;
                            objItem.RateId2 = 0;
                            objItem.RateText2 = string.Empty;
                            objItem.MaxRateCount = item.MaxRatePerBenefitSummary;
                            objItem.SummaryDataSource = lstSummaryDataSource;
                            lstSummaryOptionDataSource.Add(objItem);
                        }
                    }
                    else if (item.LOC == cv.VoluntaryLifeADDLOC)
                    {
                        for (int ItemCount = 1; ItemCount <= count; ItemCount++)
                        {
                            SummaryOptionItemViewModel objItem = new SummaryOptionItemViewModel();
                            objItem.OrderText = count > 1 ? item.LOC + " " + ItemCount.ToString() : item.LOC;
                            objItem.OrderNumber = ItemCount;
                            objItem.LOC = lstBenefitSummaryViewModel[ItemCount - 1].LOC;
                            objItem.SummaryApplicable = item.BenefitSummaryApplicable;
                            objItem.MaxBenefitSummaries = item.MaxBenefitSummary;
                            objItem.SummaryText = string.Empty;
                            objItem.SummaryId = 0;
                            objItem.PlanId = 0;

                            objItem.ContributionApplicable = item.ContributionApplicable;
                            objItem.ContributionId1 = -1;
                            objItem.ContributionText1 = string.Empty;
                            objItem.ContributionId2 = 0;
                            objItem.ContributionText2 = string.Empty;
                            objItem.MaxContributionCount = item.MaxContributionPerSummary;

                            objItem.RateApplicable = item.RateApplicable;
                            objItem.RateId1 = -1;
                            objItem.RateText1 = string.Empty;
                            objItem.RateId2 = 0;
                            objItem.RateText2 = string.Empty;
                            objItem.MaxRateCount = item.MaxRatePerBenefitSummary;
                            objItem.SummaryDataSource = lstSummaryDataSource;
                            lstSummaryOptionDataSource.Add(objItem);
                        }
                    }
                }
            }
            #endregion

            List<SummaryOptionItemViewModel> merged = MergeWithExistingSelection(lstSummaryOptionDataSource);
            gvPlanBernefitSummaryOptions.DataSource = merged;
            gvPlanBernefitSummaryOptions.DataBind();
            BenefitSummaryOptionDataSource = merged;
            foreach (GridViewRow row in gvPlanBernefitSummaryOptions.Rows)
            {
                DropDownList ddlPlanBenefitSummary = row.FindControl("ddlPlanBenefitSummary") as DropDownList;
                ddlPlanBenefitSummary_SelectedIndexChanged(ddlPlanBenefitSummary, null);
            }
        }
        private void UpdateBenefitSummaryOptionDataSource()
        {
            List<SummaryOptionItemViewModel> tempDataSource = BenefitSummaryOptionDataSource;
            int count = 0;
            foreach (GridViewRow row in gvPlanBernefitSummaryOptions.Rows)
            {
                DropDownList ddlPlanBenefitSummary = row.FindControl("ddlPlanBenefitSummary") as DropDownList;
                DropDownList ddlContribution1 = row.FindControl("ddlContribution1") as DropDownList;
                DropDownList ddlContribution2 = row.FindControl("ddlContribution2") as DropDownList;
                DropDownList ddlRates1 = row.FindControl("ddlRates1") as DropDownList;
                DropDownList ddlRates2 = row.FindControl("ddlRates2") as DropDownList;
                tempDataSource[count].PlanId = 0;
                tempDataSource[count].SummaryId = 0;
                if (ddlPlanBenefitSummary.SelectedValue != "0")
                {
                    string PlanID_BenefitSummaryId = ddlPlanBenefitSummary.SelectedValue;
                    string[] PlanID_BenefitSummaryIdParts = PlanID_BenefitSummaryId.Split('@');
                    tempDataSource[count].PlanId = int.Parse(PlanID_BenefitSummaryIdParts[0]);
                    tempDataSource[count].SummaryId = int.Parse(PlanID_BenefitSummaryIdParts[1]);
                }

                tempDataSource[count].ContributionId1 = int.Parse(ddlContribution1.SelectedValue);
                tempDataSource[count].ContributionText1 = ddlContribution1.SelectedItem.Text.Trim();
                tempDataSource[count].ContributionId2 = int.Parse(ddlContribution2.SelectedValue);
                tempDataSource[count].ContributionText2 = ddlContribution2.SelectedItem.Text.Trim();

                tempDataSource[count].RateId1 = int.Parse(ddlRates1.SelectedValue);
                tempDataSource[count].RateText1 = ddlRates1.SelectedItem.Text.Trim();
                tempDataSource[count].RateId2 = int.Parse(ddlRates2.SelectedValue);
                tempDataSource[count].RateText2 = ddlRates2.SelectedItem.Text.Trim();
                count++;
            }
            BenefitSummaryOptionDataSource = tempDataSource;

        }
        private List<SummaryOptionItemViewModel> MergeWithExistingSelection(List<SummaryOptionItemViewModel> CurrentDataSource)
        {
            List<SummaryOptionItemViewModel> PreviousSelection = BenefitSummaryOptionDataSource;
            if (PreviousSelection.Count == 0)
                return CurrentDataSource;

            List<SummaryOptionItemViewModel> lstCurrentLOCItems = new List<SummaryOptionItemViewModel>();
            List<SummaryOptionItemViewModel> lstPreviousLOCItems = new List<SummaryOptionItemViewModel>();
            foreach (BenefitSummaryStructure item in TrifoldSummary.BenefitSummarySelectionMap)
            {
                if (item.LOC == cv.LifeADDLOC)
                {
                    lstCurrentLOCItems = CurrentDataSource.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).ToList();
                    lstPreviousLOCItems = PreviousSelection.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).ToList();
                }
                else if (item.LOC == cv.VoluntaryLifeADDLOC)
                {
                    lstCurrentLOCItems = CurrentDataSource.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).ToList();
                    lstPreviousLOCItems = PreviousSelection.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).ToList();
                }
                else
                {
                    lstCurrentLOCItems = CurrentDataSource.Where(r => r.LOC == item.LOC).ToList();
                    lstPreviousLOCItems = PreviousSelection.Where(r => r.LOC == item.LOC).ToList();
                }
                // Prev count > Current Count ==> Remove previous plans which are not in current selection
                if (lstPreviousLOCItems.Count() > 0 && lstCurrentLOCItems.Count() > 0 && lstPreviousLOCItems.Count > lstCurrentLOCItems.Count)
                {
                    List<BenefitSummaryDropDownViewModel> lstPrevSource = lstPreviousLOCItems.First().SummaryDataSource;
                    List<BenefitSummaryDropDownViewModel> lstCurrentSource = lstCurrentLOCItems.First().SummaryDataSource;

                    foreach (BenefitSummaryDropDownViewModel prevItem in lstPrevSource)
                    {
                        if (lstCurrentSource.Where(r => r.Text == prevItem.Text && r.Value == prevItem.Value).Count() == 0)
                        {
                            string[] strParts = prevItem.Value.Split('@');
                            SummaryOptionItemViewModel deleteItem = lstPreviousLOCItems.Where(r => r.PlanId == int.Parse(strParts[0]) && r.SummaryId == int.Parse(strParts[1])).FirstOrDefault();
                            if (deleteItem != null)
                                lstPreviousLOCItems.RemoveAll(r => r.PlanId == int.Parse(strParts[0]) && r.SummaryId == int.Parse(strParts[1]));
                        }
                    }

                    int count = 1;
                    foreach (SummaryOptionItemViewModel prvItem in lstPreviousLOCItems)
                    {
                        prvItem.OrderNumber = count++;
                    }
                }

                foreach (SummaryOptionItemViewModel prvItem in lstPreviousLOCItems)
                {
                    if (prvItem.SummaryId != 0)
                    {
                        string SummaryPlanID = prvItem.PlanId + "@" + prvItem.SummaryId;
                        BenefitSummaryDropDownViewModel PreviousSelectedSummmary = prvItem.SummaryDataSource.Where(r => r.Value == SummaryPlanID).First();
                        SummaryOptionItemViewModel updateItem = lstCurrentLOCItems.Where(r => r.OrderNumber == prvItem.OrderNumber).FirstOrDefault();

                        if (updateItem != null && updateItem.SummaryDataSource.Where(r => r.Text == PreviousSelectedSummmary.Text && r.Value == PreviousSelectedSummmary.Value).Count() > 0)
                        {
                            updateItem.PlanId = prvItem.PlanId;
                            updateItem.SummaryId = prvItem.SummaryId;
                            updateItem.ContributionId1 = prvItem.ContributionId1;
                            updateItem.ContributionText1 = prvItem.ContributionText1;
                            updateItem.ContributionId2 = prvItem.ContributionId2;
                            updateItem.ContributionText2 = prvItem.ContributionText2;
                            updateItem.RateId1 = prvItem.RateId1;
                            updateItem.RateText1 = prvItem.RateText1;
                            updateItem.RateId2 = prvItem.RateId2;
                            updateItem.RateText2 = prvItem.RateText2;
                        }
                    }
                }


            }
            return CurrentDataSource;
        }
        private System.Web.UI.WebControls.View GetCriteriaPage()
        {
            int CurrentIndex = int.Parse(hdnCriteriaPageIndex.Value);
            string NextViewName = string.Empty;
            NextViewName = CriteriaPages[CurrentIndex];
            System.Web.UI.WebControls.View view = viewPlanBenefitSummary;
            CriteriaViews NextViewItem = ConvertToCriteriaView(NextViewName);
            switch (NextViewItem)
            {
                case CriteriaViews.viewPlanBenefitSummary:
                    view = viewPlanBenefitSummary;
                    break;
                case CriteriaViews.viewBenefitSummarySelection:
                    view = viewBenefitSummarySelection;
                    break;
                case CriteriaViews.viewMobileAppLegalNotice:
                    view = viewMobileAppLegalNotice;
                    break;

            }

            return view;
        }
        private CriteriaViews ConvertToCriteriaView(string ViewName)
        {
            CriteriaViews view = CriteriaViews.viewPlanBenefitSummary;
            switch (ViewName)
            {
                case "viewPlanBenefitSummary":
                    view = CriteriaViews.viewPlanBenefitSummary;
                    break;
                case "viewBenefitSummarySelection":
                    view = CriteriaViews.viewBenefitSummarySelection;
                    break;
                case "viewMobileAppLegalNotice":
                    view = CriteriaViews.viewMobileAppLegalNotice;
                    break;
            }
            return view;
        }
        private List<Plan> SortPlans(List<Plan> lstPlans)
        {
            List<Plan> lstSortedPlan = new List<Plan>();
            foreach (BenefitSummaryStructure item in BenefitSummaryStructureMap)
            {
                List<Plan> lstLOCPlans = new List<Plan>();
                List<BenefitSummaryDropDownViewModel> lstSummaryDataSource = new List<BenefitSummaryDropDownViewModel>();
                if (item.LOC == cv.LifeADDLOC)
                {

                    lstLOCPlans = lstPlans.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).ToList();
                }
                else if (item.LOC == cv.VoluntaryLifeADDLOC)
                {
                    lstLOCPlans = lstPlans.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).ToList();
                }
                else
                {
                    lstLOCPlans = lstPlans.Where(r => r.LOC == item.LOC).ToList();
                }
                lstLOCPlans = (from l in lstLOCPlans
                               orderby l.ProductTypeDescription, l.SummaryName, l.CarrierName, l.RenewalDate ascending
                               select l).ToList();

                lstSortedPlan.AddRange(lstLOCPlans);

            }
            return lstSortedPlan;

        }
        #endregion

        protected void btnDescriptionHeader_Click(object sender, EventArgs e)
        {
            IsDescriptionHide = !IsDescriptionHide;
            ShowHideDescriptionPanel();
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>SetGridViewRowStyle();SetPlanProductGridRowSelected();</script>", false);
        }
        private void ShowHideDescriptionPanel()
        {
            if (IsDescriptionHide)
            {
                trDescriptionBox.Style.Add("display", "none");
                btnDescriptionHeader.Text = "Guide >>";
            }
            else
            {
                trDescriptionBox.Style.Add("display", "");
                btnDescriptionHeader.Text = "Guide <<";
            }
        }

        

    }
}