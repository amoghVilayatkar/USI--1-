﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;
using BenefitPointSummaryPortal.Common.BenefitSummary;

namespace BenefitPointSummaryPortal.BAL.Pilot
{
    public class WriteINBR_Calculator : System.Web.UI.Page
    {

        public void Write_INBRCalculator(Excel.Application myExcelApp,string ClientName, string SessionId, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SelectedContactId)
        {
            Excel.Worksheet myWorksheet = null;
            string AccountContactName = string.Empty;
            string AccountContactTitle = string.Empty;
            string Address = string.Empty;
            string CityState = string.Empty;

            myWorksheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets["Welcome"];

            Contact contact = ContactList.SingleOrDefault(c => c.ContactId.ToString() == SelectedContactId);

            DataRow row = AccountDS.Tables[1].Rows[0];
            Address= row["mainAddress_street1"].ToString();
            CityState = row["mainAddress_city"].ToString() + ", " + row["mainAddress_state"].ToString() + ", " + row["mainAddress_zip"].ToString();

            #region Template Writing

            myWorksheet.Cells[3][7] = ClientName;
            myWorksheet.Cells[3][8] = contact.First_Name+" "+contact.Last_Name;
            myWorksheet.Cells[3][9] = contact.Title;
            myWorksheet.Cells[3][10] = Address;
            myWorksheet.Cells[3][11] = CityState;
            #endregion

        }
    }
}