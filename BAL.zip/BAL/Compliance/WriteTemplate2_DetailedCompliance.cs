﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using StringTrimmer;
using System.Reflection;

namespace BenefitPointSummaryPortal.BAL.Compliance
{
    public class WriteTemplate2_DetailedCompliance : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        // Function to get the header of each of the selected topics
        private void GetSourceDocumentWithHeader(Word.ApplicationClass wordApp, Word.Document oWordDoc, Word.Range r, string sourcefileName)
        {
            Object fileName;
            Object readOnly = true;
            Object isVisible = false;
            object missing = System.Type.Missing;
            Range sourceRngHeader;
            string path = "~/Files/Compliance/Documents/Templates/DetailedCompliance/";
            _Document sourceDocument;

            try
            {
                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                //r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                foreach (Section hdr in oWordDoc.Sections)
                {
                    hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                    //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                }

                // r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                //r.InsertFile(Server.MapPath(path + "02 General COBRA Requirements.docx"), missing, true, missing, missing);

                //fileName = Server.MapPath(path + "02 General COBRA Requirements.docx");
                fileName = Server.MapPath(path + sourcefileName);

                sourceDocument = wordApp.Documents.Open(ref fileName,
                                       ref missing, ref readOnly,
                                       ref missing, ref missing, ref missing,
                                       ref missing, ref missing, ref missing,
                                       ref missing, ref missing, ref isVisible,
                                       ref missing, ref missing, ref missing, ref missing);

                sourceDocument.Activate(); // This is the document I am copying from 
                sourceDocument.Application.Selection.WholeStory();
                sourceDocument.Application.Selection.Copy();
                r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                foreach (Section section in r.Sections)
                {
                    // Get headers and footers from target section
                    Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                    // Copy header
                    sourceRngHeader.Copy();
                    targetRngHeader.Paste();
                }
                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                sourceDocument.Close(true, missing, missing);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteFieldToTemplate2_DetailedCompliance(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, string SessionId, DropDownList ddlOffice, CheckBoxList chkComplianceTopics)
        {
            Word.ApplicationClass wordApp = null;
            object missing = System.Type.Missing;

            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                #region MergeField
                string effectiveDate = string.Empty;
                string path = "~/Files/Compliance/Documents/Templates/DetailedCompliance/";

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Cover Image"))
                        {
                            myMergeField.Delete();
                            Word.Range r = oWordDoc.Range();
                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                            if (ddlOffice.SelectedItem.Text == "USI")
                            {
                                r.InsertFile(Server.MapPath(path + "CoverPage_USI.docx"), missing, true, missing, missing);
                            }
                            else if (ddlOffice.SelectedItem.Text == "Kibble & Prentice")
                            {
                                r.InsertFile(Server.MapPath(path + "CoverPage_KnP.docx"), missing, true, missing, missing);
                            }
                            //r.InlineShapes.AddPicture(Server.MapPath("~/Files/Compliance/Images/DetailedComp_USI.jpg"), false, true);
                            continue;
                        }


                        if (fieldName.Contains("Topics"))
                        {
                            myMergeField.Delete();
                            Word.Range r = oWordDoc.Range();
                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                            wordApp = new ApplicationClass();
                            wordApp.DisplayAlerts = WdAlertLevel.wdAlertsNone;

                            int chkSelectedCount = 0;

                            int numSelected = 0;
                            foreach (ListItem li in chkComplianceTopics.Items)
                            {
                                if (li.Selected)
                                {
                                    numSelected = numSelected + 1;
                                }
                            }
                            // oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                            for (int i = chkComplianceTopics.Items.Count - 1; i >= 0; i--)
                            {
                                if (chkComplianceTopics.Items[i].Selected == true)
                                {
                                    Object fileName;
                                    Object readOnly = true;
                                    Object isVisible = false;
                                    _Document sourceDocument;
                                    chkSelectedCount = chkSelectedCount + 1;
                                    //r.Application.ActiveDocument.Styles[0].NoSpaceBetweenParagraphsOfSameStyle = false;
                                    if (numSelected == 1)
                                    { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                    switch (i)
                                    {
                                        case 0:
                                            //GetSourceDocumentWithHeader(wordApp, oWordDoc, r, "01 General ERISA Requirements.docx");
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            foreach (Section hdr in oWordDoc.Sections)
                                            {

                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            //r.InsertFile(Server.MapPath(path + "01 General ERISA Requirements.docx"), missing, missing, missing, missing);

                                            fileName = Server.MapPath(path + "01 General ERISA Requirements.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 

                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            Range sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }

                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 1:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////    r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            //r.InsertFile(Server.MapPath(path + "02 General COBRA Requirements.docx"), missing, true, missing, missing);

                                            fileName = Server.MapPath(path + "02 General COBRA Requirements.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 2:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //r.InsertFile(Server.MapPath(path + "03 HIPAA Portability.docx"), missing, true, missing, missing); 

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            //r.InsertFile(Server.MapPath(path + "03 HIPAA Portability.docx"), missing, true, missing, missing);

                                            fileName = Server.MapPath(path + "03 HIPAA Portability.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 3:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "04 Other Group Health Plan Mandates.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            fileName = Server.MapPath(path + "04 Other Group Health Plan Mandates.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);


                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            // // r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 4:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "05 ACA Requirements.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            fileName = Server.MapPath(path + "05 ACA Requirements.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 5:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "06 Federal Tax Code Requirements.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                            fileName = Server.MapPath(path + "06 Federal Tax Code Requirements.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 6:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "07 Medicare Requrements.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            fileName = Server.MapPath(path + "07 Medicare Requrements.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 7:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "08 State Law.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                            fileName = Server.MapPath(path + "08 State Law.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 8:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "09 HIPAA Privacy Security and Breach.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            fileName = Server.MapPath(path + "09 HIPAA Privacy Security and Breach.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 9:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "10 Federal Employment Law.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            fileName = Server.MapPath(path + "10 Federal Employment Law.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 10:
                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "11 Wellness Programs.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            fileName = Server.MapPath(path + "11 Wellness Programs.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            //// r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;
                                        case 11:

                                            if (chkSelectedCount > 1)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            //    r.InsertFile(Server.MapPath(path + "12 Health Savings Account.docx"), missing, true, missing, missing); break;

                                            foreach (Section hdr in oWordDoc.Sections)
                                            {
                                                hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                                //hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                            }

                                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                            fileName = Server.MapPath(path + "12 Health Savings Account.docx");

                                            sourceDocument = wordApp.Documents.Open(ref fileName,
                                                                   ref missing, ref readOnly,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref missing,
                                                                   ref missing, ref missing, ref isVisible,
                                                                   ref missing, ref missing, ref missing, ref missing);

                                            sourceDocument.Activate(); // This is the document I am copying from 
                                            sourceDocument.Application.Selection.WholeStory();
                                            sourceDocument.Application.Selection.Copy();
                                            r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
                                            sourceRngHeader = sourceDocument.Sections[1].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                                            foreach (Section section in r.Sections)
                                            {
                                                // Get headers and footers from target section
                                                Range targetRngHeader = section.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                                // Copy header
                                                sourceRngHeader.Copy();
                                                targetRngHeader.Paste();
                                            }
                                            if (numSelected != chkSelectedCount)
                                            { r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }
                                            ////r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            sourceDocument.Close(true, missing, missing);
                                            break;

                                    }
                                    //if (numSelected == 1)
                                    //{ r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage); }

                                }
                            }
                        }

                        if (fieldName.Contains("Last Page Content"))
                        {
                            myMergeField.Delete();
                            Word.Range r = oWordDoc.Range();
                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                            if (ddlOffice.SelectedItem.Text == "USI")
                            {
                                r.InsertFile(Server.MapPath(path + "Last_Page USI.docx"), missing, true, missing, missing);
                            }
                            else if (ddlOffice.SelectedItem.Text == "Kibble & Prentice")
                            {
                                r.InsertFile(Server.MapPath(path + "Last_Page K&P.docx"), missing, true, missing, missing);
                            }
                            continue;
                        }
                    }
                }
                #endregion

                if (wordApp != null)
                {
                    wordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(wordApp);
                    wordApp = null;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (wordApp != null)
                {
                    wordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(wordApp);
                    wordApp = null;
                }
            }
        }

        // Function for showing the page number on the content page for the selected topics
        public void ShowPageNumberOnContentPage_For_SelectedTopic_Old(Word.Application oWordApp, Word.Document oWordDoc, CheckBoxList chkComplianceTopics)
        {
            try
            {
                string headerInfo = string.Empty;
                int pageNum = 0;
                int contentRowCnt = 3;
                int chkItem = 0;

                ArrayList allTopics = new ArrayList();

                int Pagecount = 0;
                int OldPagecount = 0;
                int InitialPageNum = 0;
                int cntInitialPageNum = 0;
                bool isFirstTopicTaken = false;
                Hashtable hsTopics = new Hashtable();

                int currentPageNum;
                int sectionNumber = 0;
                int oldSectionNumber = 0;
                long totalPageNum = oWordApp.ActiveDocument.ComputeStatistics(Microsoft.Office.Interop.Word.WdStatistic.wdStatisticPages);

                for (int i = 1; i < oWordDoc.Sections.Count; i++)
                {

                    if (i > 3)
                    {
                        headerInfo = Convert.ToString(((oWordDoc.Sections[i].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary]).Range).Text.ToString()).Trim_String();
                        if (!allTopics.Contains((headerInfo).Trim().Trim_String()))
                        {
                            //string abc = Convert.ToString(oWordDoc.Sections[i].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].PageNumbers);
                            allTopics.Add(Convert.ToString((headerInfo).Trim()).Trim_String());
                            //pageNum = Convert.ToInt16(oWordDoc.Sections[i].Range.Information[WdInformation.wdActiveEndPageNumber]);
                            //pageNum = Convert.ToInt16(oWordDoc.Sections[i - 1].Range.Information[WdInformation.wdActiveEndPageNumber]);
                            hsTopics.Add(i, headerInfo);


                            for (int j = chkItem; j < chkComplianceTopics.Items.Count; j++)
                            {
                                if (chkComplianceTopics.Items[j].Selected == true)
                                {
                                    cntInitialPageNum++;
                                    if (isFirstTopicTaken == false)
                                    {
                                        InitialPageNum = 8;
                                    }

                                    if (pageNum == 0)
                                    {
                                        pageNum = InitialPageNum;
                                        isFirstTopicTaken = true;
                                    }

                                    pageNum = pageNum + OldPagecount;

                                    do
                                    {
                                        currentPageNum = Convert.ToInt32(oWordApp.Selection.get_Information(Microsoft.Office.Interop.Word.WdInformation.wdActiveEndPageNumber));
                                        if (currentPageNum > 7)
                                        {
                                            sectionNumber = Convert.ToInt32(oWordApp.Selection.get_Information(WdInformation.wdActiveEndSectionNumber));

                                            if (oldSectionNumber != sectionNumber)
                                            {
                                                oldSectionNumber = sectionNumber;
                                                // pageCount = 0;
                                            }

                                            for (int k = 0; k < hsTopics.Count; k++)
                                            {
                                                //if (allTopics[k].ToString() == Convert.ToString(((oWordDoc.Sections[sectionNumber].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary]).Range).Text.ToString()).Trim_String())
                                                if (hsTopics.Contains(sectionNumber))
                                                {
                                                    if (hsTopics[sectionNumber].ToString() == Convert.ToString(((oWordDoc.Sections[sectionNumber].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary]).Range).Text.ToString()).Trim_String())
                                                    {
                                                        OldPagecount++;
                                                        break;
                                                    }
                                                }
                                                else
                                                {
                                                    hsTopics.Remove(sectionNumber - 1);
                                                }
                                            }

                                        }
                                        oWordApp.Selection.GoToNext(Microsoft.Office.Interop.Word.WdGoToItem.wdGoToPage);
                                        if (hsTopics.Count == 0)
                                        {
                                            break;
                                        }
                                        // add your code here
                                    } while (currentPageNum < totalPageNum);

                                    ////OldPagecount = Convert.ToInt32(oWordDoc.Sections[i].Range.Information[WdInformation.wdActiveEndPageNumber]) - Convert.ToInt32(oWordDoc.Sections[i - 1].Range.Information[WdInformation.wdActiveEndPageNumber]);
                                    //int ActiveSection = Convert.ToInt32(oWordDoc.Sections[i].Range.Information[WdInformation.wdActiveEndSectionNumber]);
                                    //int prevSection = ActiveSection - 1;

                                    //dynamic ActiveSectionPageCount = oWordDoc.Sections[ActiveSection].Range.Information[WdInformation.wdActiveEndPageNumber];
                                    //dynamic prevSectionPageCount = oWordDoc.Sections[prevSection].Range.Information[WdInformation.wdActiveEndPageNumber];
                                    ////Pagecount = Convert.ToInt16(oWordDoc.Sections[i].Range.Information[WdInformation.wdActiveEndPageNumber]);
                                    ////OldPagecount = Convert.ToInt16(oWordDoc.Sections[i-1].Range.Information[WdInformation.wdActiveEndPageNumber]);

                                    //OldPagecount = ActiveSectionPageCount - prevSectionPageCount;

                                    //int a = Pagecount - OldPagecount;
                                    //pageNum = pageNum + Pagecount;

                                    oWordDoc.Tables[1].Rows.Add();

                                    switch (j)
                                    {
                                        // 	General ERISA Requirements
                                        case 0:
                                            //pageNum = pageNum + 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "...............................";
                                            break;
                                        // General COBRA Requirements
                                        case 1:
                                            //pageNum = pageNum + 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..............................";
                                            break;
                                        //	HIPAA Portability Requirements
                                        case 2:
                                            //pageNum = pageNum - 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..........................";
                                            break;
                                        // 	Other Group Health Plan Mandates
                                        case 3:
                                            //pageNum = pageNum - 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "......................";
                                            break;
                                        // 	Affordable Care Act Requirements
                                        case 4:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "........................";
                                            break;
                                        // 	Federal Tax Code Requirements
                                        case 5:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "............................";
                                            break;
                                        // 	Medicare Requirements
                                        case 6:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".........................................";
                                            break;
                                        // 	State Laws
                                        case 7:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..............................................................";
                                            break;
                                        // 	HIPAA Privacy, Security and Breach
                                        case 8:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".....................";
                                            break;
                                        // 	Federal Employment Law
                                        case 9:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "......................................";
                                            break;
                                        // 	Wellness Programs
                                        case 10:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".................................................";
                                            break;
                                        // 	Health Savings Accounts 
                                        case 11:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "........................................";
                                            break;
                                    }

                                    chkItem++;

                                    break;
                                }
                                chkItem++;
                            }

                            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = headerInfo;
                            if (pageNum.ToString().Length == 1)
                            {
                                if (cntInitialPageNum == 1)
                                {
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page 0" + InitialPageNum);
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page 0" + pageNum);
                                }
                            }
                            else
                            {
                                if (cntInitialPageNum == 1)
                                {
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page " + InitialPageNum);
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page " + pageNum);
                                }
                            }
                            contentRowCnt++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Function for showing the page number on the content page for the selected topics
        //public void ShowPageNumberOnContentPage_For_SelectedTopic(Word.Application oWordApp, Word.Document oWordDoc, CheckBoxList chkComplianceTopics)
        //{
        //    try
        //    {
        //        string headerInfo = string.Empty;
        //        int pageNum = 0;
        //        int contentRowCnt = 3;
        //        int chkItem = 0;

        //        ArrayList allTopics = new ArrayList();
        //        Hashtable hsTopics = new Hashtable();

        //        int InitialPageNum = 0;
        //        int cntInitialPageNum = 0;
        //        bool isFirstTopicTaken = false;

        //        int currentPageNum;
        //        int sectionNumber = 0;
        //        int oldPageCount = 0;
        //        long totalPageNum = oWordApp.ActiveDocument.ComputeStatistics(Microsoft.Office.Interop.Word.WdStatistic.wdStatisticPages);

        //        for (int i = 1; i < oWordDoc.Sections.Count; i++)
        //        {
        //            pageNum = 0;
        //            if (i > 3)
        //            {
        //                headerInfo = Convert.ToString(((oWordDoc.Sections[i].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary]).Range).Text.ToString()).Trim_String();
        //                if (!allTopics.Contains((headerInfo).Trim().Trim_String()))
        //                {
        //                    allTopics.Add(Convert.ToString((headerInfo).Trim()).Trim_String());
        //                    hsTopics.Add(i, headerInfo);

        //                    for (int j = chkItem; j < chkComplianceTopics.Items.Count; j++)
        //                    {
        //                        if (chkComplianceTopics.Items[j].Selected == true)
        //                        {
        //                            cntInitialPageNum++;
        //                            if (isFirstTopicTaken == false)
        //                            {
        //                                InitialPageNum = 8;
        //                            }

        //                            if (pageNum == 0)
        //                            {
        //                                pageNum = InitialPageNum;
        //                                isFirstTopicTaken = true;
        //                            }

        //                            pageNum = pageNum + oldPageCount;

        //                            do
        //                            {
        //                                currentPageNum = Convert.ToInt32(oWordApp.Selection.get_Information(Microsoft.Office.Interop.Word.WdInformation.wdActiveEndPageNumber));
        //                                if (currentPageNum > 7)
        //                                {
        //                                    sectionNumber = Convert.ToInt32(oWordApp.Selection.get_Information(WdInformation.wdActiveEndSectionNumber));

        //                                    for (int k = 0; k < hsTopics.Count; k++)
        //                                    {
        //                                        if (hsTopics.Contains(sectionNumber))
        //                                        {
        //                                            if (hsTopics[sectionNumber].ToString() == Convert.ToString(((oWordDoc.Sections[sectionNumber].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary]).Range).Text.ToString()).Trim_String())
        //                                            {
        //                                                oldPageCount++;
        //                                                break;
        //                                            }
        //                                        }
        //                                        else
        //                                        {
        //                                            hsTopics.Remove(sectionNumber - 1);
        //                                            oWordApp.Selection.GoToPrevious(Microsoft.Office.Interop.Word.WdGoToItem.wdGoToPage);
        //                                        }
        //                                    }

        //                                }
        //                                oWordApp.Selection.GoToNext(Microsoft.Office.Interop.Word.WdGoToItem.wdGoToPage);
        //                                if (hsTopics.Count == 0)
        //                                {
        //                                    break;
        //                                }
        //                                // add your code here
        //                            } while (currentPageNum < totalPageNum);

        //                            oWordDoc.Tables[1].Rows.Add();

        //                            switch (j)
        //                            {
        //                                // 	General ERISA Requirements
        //                                case 0:
        //                                    //pageNum = pageNum + 1;
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "...............................";
        //                                    break;
        //                                // General COBRA Requirements
        //                                case 1:
        //                                    //pageNum = pageNum + 1;
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..............................";
        //                                    break;
        //                                //	HIPAA Portability Requirements
        //                                case 2:
        //                                    //pageNum = pageNum - 1;
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..........................";
        //                                    break;
        //                                // 	Other Group Health Plan Mandates
        //                                case 3:
        //                                    //pageNum = pageNum - 1;
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "......................";
        //                                    break;
        //                                // 	Affordable Care Act Requirements
        //                                case 4:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "........................";
        //                                    break;
        //                                // 	Federal Tax Code Requirements
        //                                case 5:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "............................";
        //                                    break;
        //                                // 	Medicare Requirements
        //                                case 6:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".........................................";
        //                                    break;
        //                                // 	State Laws
        //                                case 7:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..............................................................";
        //                                    break;
        //                                // 	HIPAA Privacy, Security and Breach
        //                                case 8:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".....................";
        //                                    break;
        //                                // 	Federal Employment Law
        //                                case 9:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "......................................";
        //                                    break;
        //                                // 	Wellness Programs
        //                                case 10:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".................................................";
        //                                    break;
        //                                // 	Health Savings Accounts 
        //                                case 11:
        //                                    headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "........................................";
        //                                    break;
        //                            }

        //                            chkItem++;
        //                            break;
        //                        }
        //                        chkItem++;
        //                    }

        //                    oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = headerInfo;
        //                    if (pageNum.ToString().Length == 1)
        //                    {
        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page 0" + pageNum);
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page " + pageNum);
        //                    }
        //                    contentRowCnt++;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}
        public void ShowPageNumberOnContentPage_For_SelectedTopic(Word.Application oWordApp, Word.Document oWordDoc, CheckBoxList chkComplianceTopics)
        {
            try
            {
                string headerInfo = string.Empty;
                int pageNum = 0;
                int contentRowCnt = 3;
                int chkItem = 0;

                ArrayList allTopics = new ArrayList();
                Hashtable hsTopics = new Hashtable();

                int InitialPageNum = 0;
                int cntInitialPageNum = 0;
                bool isFirstTopicTaken = false;

                int currentPageNum;
                int sectionNumber = 0;
                int oldPageCount = 0;
                long totalPageNum = oWordApp.ActiveDocument.ComputeStatistics(Microsoft.Office.Interop.Word.WdStatistic.wdStatisticPages);

                for (int i = 1; i < oWordDoc.Sections.Count; i++)
                {
                    pageNum = 0;
                    if (i > 3)
                    {
                        #region Added by vinod
                        Dictionary<int, string> dictLetterCarriersValue = new Dictionary<int, string>();
                        #region Final Code : Added by vinod

                        dictLetterCarriersValue[0] = "first";
                        dictLetterCarriersValue[1] = "second";
                        dictLetterCarriersValue[2] = "three";
                        dictLetterCarriersValue[3] = "four";
                        dictLetterCarriersValue[4] = "General ERISA Requirements";
                        dictLetterCarriersValue[5] = "General COBRA Requirements";
                        dictLetterCarriersValue[6] = "HIPAA Portability Requirements";
                        dictLetterCarriersValue[7] = "Other Group Health Plan Mandates";
                        dictLetterCarriersValue[8] = "Affordable Care Act Requirements";
                        dictLetterCarriersValue[9] = "Federal Tax Code Requirements";
                        dictLetterCarriersValue[10] = "Medicare Requirements";
                        dictLetterCarriersValue[11] = "State Laws";
                        dictLetterCarriersValue[12] = "HIPAA Privacy, Security and Breach";
                        dictLetterCarriersValue[13] = "Federal Employment Law";
                        dictLetterCarriersValue[14] = "Wellness Programs";
                        dictLetterCarriersValue[15] = "Health Savings Accounts";
                        dictLetterCarriersValue[16] = "Wellness Programs";
                        dictLetterCarriersValue[17] = "Health Savings Accounts";

                        #endregion
                        #endregion

                        #region Commened by vinod
                        //headerInfo = Convert.ToString(((oWordDoc.Sections[i].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary]).Range).Text.ToString()).Trim_String();
                        #endregion
                        #region Added by vinod
                        headerInfo = dictLetterCarriersValue[i];
                        #endregion

                        if (!allTopics.Contains((headerInfo).Trim().Trim_String()))
                        {
                            allTopics.Add(Convert.ToString((headerInfo).Trim()).Trim_String());
                            hsTopics.Add(i, headerInfo);

                            for (int j = chkItem; j < chkComplianceTopics.Items.Count; j++)
                            {
                                if (chkComplianceTopics.Items[j].Selected == true)
                                {
                                    cntInitialPageNum++;
                                    if (isFirstTopicTaken == false)
                                    {
                                        InitialPageNum = 8;
                                    }

                                    if (pageNum == 0)
                                    {
                                        pageNum = InitialPageNum;
                                        isFirstTopicTaken = true;
                                    }

                                    pageNum = pageNum + oldPageCount;

                                    do
                                    {
                                        currentPageNum = Convert.ToInt32(oWordApp.Selection.get_Information(Microsoft.Office.Interop.Word.WdInformation.wdActiveEndPageNumber));
                                        if (currentPageNum > 7)
                                        {
                                            sectionNumber = Convert.ToInt32(oWordApp.Selection.get_Information(WdInformation.wdActiveEndSectionNumber));

                                            for (int k = 0; k < hsTopics.Count; k++)
                                            {
                                                if (hsTopics.Contains(sectionNumber))
                                                {
                                                    //if (hsTopics[sectionNumber].ToString() == Convert.ToString(((oWordDoc.Sections[sectionNumber].Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary]).Range).Text.ToString()).Trim_String())
                                                    //{
                                                    if (hsTopics[sectionNumber].ToString() == dictLetterCarriersValue[sectionNumber])
                                                    {
                                                        oldPageCount++;
                                                        break;
                                                    }
                                                }
                                                else
                                                {
                                                    hsTopics.Remove(sectionNumber - 1);
                                                    oWordApp.Selection.GoToPrevious(Microsoft.Office.Interop.Word.WdGoToItem.wdGoToPage);
                                                }
                                            }

                                        }
                                        oWordApp.Selection.GoToNext(Microsoft.Office.Interop.Word.WdGoToItem.wdGoToPage);
                                        if (hsTopics.Count == 0)
                                        {
                                            break;
                                        }
                                        // add your code here
                                    } while (currentPageNum < totalPageNum);

                                    oWordDoc.Tables[1].Rows.Add();

                                    switch (j)
                                    {
                                        // 	General ERISA Requirements
                                        case 0:
                                            //pageNum = pageNum + 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "...............................";
                                            break;
                                        // General COBRA Requirements
                                        case 1:
                                            //pageNum = pageNum + 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..............................";
                                            break;
                                        //	HIPAA Portability Requirements
                                        case 2:
                                            //pageNum = pageNum - 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..........................";
                                            break;
                                        // 	Other Group Health Plan Mandates
                                        case 3:
                                            //pageNum = pageNum - 1;
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "......................";
                                            break;
                                        // 	Affordable Care Act Requirements
                                        case 4:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "........................";
                                            break;
                                        // 	Federal Tax Code Requirements
                                        case 5:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "............................";
                                            break;
                                        // 	Medicare Requirements
                                        case 6:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".........................................";
                                            break;
                                        // 	State Laws
                                        case 7:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "..............................................................";
                                            break;
                                        // 	HIPAA Privacy, Security and Breach
                                        case 8:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".....................";
                                            break;
                                        // 	Federal Employment Law
                                        case 9:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "......................................";
                                            break;
                                        // 	Wellness Programs
                                        case 10:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + ".................................................";
                                            break;
                                        // 	Health Savings Accounts 
                                        case 11:
                                            headerInfo = Convert.ToString((headerInfo).Trim()).Trim_String() + "........................................";
                                            break;
                                    }

                                    chkItem++;
                                    break;
                                }
                                chkItem++;
                            }

                            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = headerInfo;
                            if (pageNum.ToString().Length == 1)
                            {
                                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page 0" + pageNum);
                            }
                            else
                            {
                                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString("Page " + pageNum);
                            }
                            contentRowCnt++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// This function is used to delete or keep the respective Bookmarks from the generated report file
        /// </summary>
        /// <param name="oWordApp"></param>
        /// <param name="ddlQuestion1">Is this client a MEWA?</param>
        /// <param name="ddlQuestion2">Does this client have a Federally Qualified HMO?</param>
        /// <param name="ddlQuestion3">What is this clients Grandfathered status?</param>
        /// <param name="ddlQuestion4">Has this client filed over 250 W-2 forms?</param>
        /// <param name="ddlQuestion5">Does this client offer Retiree Health plans?</param>
        /// <param name="ddlQuestion6">Is this client a Non Profit Religious organization? </param>
        /// <param name="ddlQuestion8">Does this client have any employees in: HI, MA, VT or the City/County of San Francisco, CA?</param>
        /// <param name="ddlQuestion9">Does this client have any employees in: California, Hawaii, New Jersey, New York, Rhode Island or Puerto Rico?</param>
        /// <param name="ddlQuestion10">Are children age 26 or older allowed to participate in medical plans? </param>
        /// <param name="ddlQuestion11">Does this client offer a Wellness program?</param>
        /// <param name="isMedicalPlanSelected">bool isMedicalPlanSelected is used to check whether any medical plan is selected from the GridView or not</param>
        /// <param name="isFTE_Greater_Or_Equal_To_100">bool isFTE_Greater_Or_Equal_To_100 is used to check if any selected medical plan's FTE >= 100</param>
        /// <param name="isFTE_Less_Than_100">bool isFTE_Less_Than_100 is used to check if any selected medical plan's FTE less than 100</param>
        /// <param name="isFSA_Plan_Selected">bool isFSA_Plan_Selected is used to check if any FSA plan is selected from the GridView</param>
        /// <param name="isHRA_Plan_Selected">bool isHRA_Plan_Selected is used to check if any HRA plan is selected from the GridView</param>
        /// <param name="isFundingType_Self_Insured">bool isFundingType_Self_Insured any selected medical plan from GridView is having FundingType = Self Insured</param>
        /// <param name="isFTE_Greater_Or_Equal_To_50">bool isFTE_Greater_Or_Equal_To_50 any selected medical plan from GridView is having FTE >=50 </param>
        /// <param name="isFundingType_Fully_Insured">bool isFundingType_Fully_Insured any selected medical plan from GridView is having FundingType = Fully Insured</param>
        /// <param name="isFTE_Greater_Or_Equal_To_20">bool isFTE_Greater_Or_Equal_To_20 any selected medical plan from GridView is having FTE >=20 </param>
        /// <param name="isHSA_Plan_Selected">bool isHSA_Plan_Selected is used to check if any HSA plan is selected from the GridView</param>
        /// <param name="isSTD_Plan_Selected">bool isSTD_Plan_Selected is used to check if any STD plan is selected from the GridView</param>
        /// <param name="isLTD_Plan_Selected">bool isLTD_Plan_Selected is used to check if any LTD plan is selected from the GridView</param>
        /// <param name="isAnySelectedPlan_FundingType_Self_Insured">bool isAnySelectedPlan_FundingType_Self_Insured any selected plan from GridView is having FundingType = Self Insured</param>
        public void Delete_Or_Keep_Bookmarks(Word.Application oWordApp, DropDownList ddlQuestion1, DropDownList ddlQuestion2, DropDownList ddlQuestion3, DropDownList ddlQuestion4, DropDownList ddlQuestion5, DropDownList ddlQuestion6, DropDownList ddlQuestion8, DropDownList ddlQuestion9, DropDownList ddlQuestion10, DropDownList ddlQuestion11, bool isMedicalPlanSelected, bool isFTE_Greater_Or_Equal_To_100, bool isFTE_Less_Than_100, bool isFSA_Plan_Selected, bool isHRA_Plan_Selected, bool isFundingType_Self_Insured, bool isFTE_Greater_Or_Equal_To_50, bool isFundingType_Fully_Insured, bool isFTE_Greater_Or_Equal_To_20, bool isHSA_Plan_Selected, bool isSTD_Plan_Selected, bool isLTD_Plan_Selected, bool isAnySelectedPlan_FundingType_Self_Insured, bool isFTE_LT_50)
        {
            try
            {
                foreach (Word.Bookmark bookmark in oWordApp.ActiveDocument.Bookmarks)
                {
                    #region Topic 01 General ERISA Requirements conditions - Starts here
                    // Condition for Topic 01 General ERISA Requirements conditions
                    if (ddlQuestion1.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "Multiple_Employers_in_ERISA_Plan_01")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }

                    }

                    if (isMedicalPlanSelected == false)
                    {
                        if (bookmark.Name == "If_Medical_Plan_Is_Selected_01")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isFTE_Greater_Or_Equal_To_100 == false)
                    {
                        if (ddlQuestion1.SelectedItem.Text == "No")
                        {
                            if (bookmark.Name == "Form_5500_01")
                            {
                                bookmark.Range.Delete();
                                continue;
                            }
                            if (bookmark.Name == "Summary_Annual_Report_SAR_01")
                            {
                                bookmark.Range.Delete();
                                continue;
                            }
                        }

                        if (bookmark.Name == "SPD_Text_2_FTE_GT_100_01")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isFTE_Less_Than_100 == false)
                    {
                        if (bookmark.Name == "SPD_Text_2_FTE_LT_100_01")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 01 General ERISA Requirements conditions - Ends here

                    #region Topic 02 General COBRA Requirements conditions - Starts here
                    // Condition for Topic 01 General ERISA Requirements conditionsif (isFTE_Less_Than_100 == false)
                    if (isFSA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "COBRA_And_Health_FSA_02")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isHRA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "COBRA_And_HRA_02")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isFundingType_Self_Insured == false && (isHRA_Plan_Selected == false || isHRA_Plan_Selected == true))
                    {
                        if (bookmark.Name == "Applicable_Premium_SI_Or_HRA_02")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 02 General COBRA Requirements conditions - Ends here

                    #region Topic 03 HIPAA Portability conditions - Starts here
                    // Condition for Topic 03 HIPAA Portability conditions
                    if (ddlQuestion11.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "HIPAA_Prg_Exception_03")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 03 HIPAA Portability conditions - Ends here

                    #region Topic 04 Other Group Health Plan Mandates conditions - Starts here
                    // Condition for Topic 04 Other Group Health Plan Mandates conditions
                    if (ddlQuestion10.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "Michellel_Law_Q10_04")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFTE_Greater_Or_Equal_To_50 == false)
                    {
                        if (bookmark.Name == "MPAEA_FTE_GT_50_04")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ddlQuestion2.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "HMO_Nondiscrimination_Q2_04")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 04 Other Group Health Plan Mandates conditions - Ends here

                    #region Topic 05 ACA Requirements conditions - Starts here
                    // Condition for Topic 05 ACA Requirements conditions
                    if (ddlQuestion3.SelectedItem.Text == "Non-Grandfathered")
                    {
                        if (bookmark.Name == "Grandfathered_Status_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ddlQuestion3.SelectedItem.Text == "Grandfathered")
                    {
                        if (bookmark.Name == "PrevCare_NonGrandFather_Both_Banner_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "Preventive_Care_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }

                        if (bookmark.Name == "Claims_Appeals_and_External_Review_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        ////////Commented by Vaibhav 
                        //if (bookmark.Name == "Eligible_Organizations_05")
                        //{
                        //    bookmark.Range.Delete();
                        //    continue;
                        //}
                        if (bookmark.Name == "Health_Plan_Nondiscrimination_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "Small_Group_Insurance_Market_Rules_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        //////
                    }
                    if ((ddlQuestion3.SelectedItem.Text == "Non-Grandfathered" || ddlQuestion3.SelectedItem.Text == "Both"))
                    {
                        if (isFundingType_Fully_Insured == true)
                        { }
                        else
                        {
                            if (bookmark.Name == "Health_Plan_Nondiscrimination_05")
                            {
                                bookmark.Range.Delete();
                                continue;
                            }
                        }

                        if (isFTE_Less_Than_100 == true)
                        { }
                        else
                        {
                            if (bookmark.Name == "Small_Group_Insurance_Market_Rules_05")
                            {
                                bookmark.Range.Delete();
                                continue;
                            }
                        }
                    }
                    if (isHRA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "HRA_Integration_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFundingType_Fully_Insured == false)
                    {
                        if (bookmark.Name == "Medical_Loss_Ratio_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "Health_Insurer_Tax_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFTE_Greater_Or_Equal_To_50 == false)
                    {
                        if (bookmark.Name == "Employer_Shared_Responsibility_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "Identify_ACA_FTEs_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    //Added by Vaibhav
                    if (isFTE_LT_50 == false)
                    {
                        if (bookmark.Name == "QSEHRAs_FTE_LT_50")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFundingType_Self_Insured == false)
                    {
                        if (bookmark.Name == "MEC_Reporting_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "Reinsurance_Fee_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "HPID_Certification_of_Compliance_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isMedicalPlanSelected == true) //&& ddlQuestion4.SelectedItem.Text == "Yes")
                    {
                    }
                    else
                    {
                        if (bookmark.Name == "W2_Health_Care_Reporting_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFSA_Plan_Selected == false && isHRA_Plan_Selected == false && isHSA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "Tax_Favored_Accounts_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isHSA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "HSA_NonQualified_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFSA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "Health_FSA_Limit_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isMedicalPlanSelected == false)
                    {
                        if (bookmark.Name == "High_Cost_Plan_Excise_Tax_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ddlQuestion5.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "Medicare_Part_D_Subsidy_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isAnySelectedPlan_FundingType_Self_Insured == false)
                    {
                        if (bookmark.Name == "PCORI_Fee_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isFundingType_Self_Insured == true) //|| (isMedicalPlanSelected == true && ddlQuestion4.SelectedItem.Text == "Yes"))
                    { }
                    else
                    {
                        if (bookmark.Name == "C_Other_ACA_Related_Reporting_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }


                    if (isFSA_Plan_Selected == true || isHRA_Plan_Selected == true || isHSA_Plan_Selected == true || isAnySelectedPlan_FundingType_Self_Insured == true
                        || isFundingType_Fully_Insured == true || isFundingType_Self_Insured == true || isMedicalPlanSelected == true)
                    { }
                    else
                    {
                        if (bookmark.Name == "D_Taxes_And_Fees_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ddlQuestion5.SelectedItem.Text == "Yes" || isFundingType_Self_Insured == true)
                    {
                    }
                    else
                    {
                        if (bookmark.Name == "E_Miscellaneous_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (ddlQuestion6.SelectedItem.Text == "Yes")
                    { }
                    else
                    {
                        if (bookmark.Name == "Eligible_Organizations_05")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 05 ACA Requirements conditions - Ends here

                    #region Topic 06 Federal Tax Code Requirements conditions - Starts here
                    // Condition for Topic 06 Federal Tax Code Requirements conditions
                    if (isFundingType_Self_Insured == false)
                    {
                        if (bookmark.Name == "Self_Insured_Group_Health_Sec_105_06")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    else if (isFundingType_Self_Insured == true && (isFSA_Plan_Selected == false && isHRA_Plan_Selected == false))
                    {
                        if (bookmark.Name == "Self_Insured_Group_Health_Sec_105_06")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isFSA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "Health_FSA_06") // Not exists
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "Care_FSA_Plan_330")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                        if (bookmark.Name == "Health_FSA_Plan_330")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isHRA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "HRA_06")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isHSA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "HSA_06")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isSTD_Plan_Selected == false && isLTD_Plan_Selected == false)
                    {
                        if (bookmark.Name == "Disability_Coverage_STD_Or_LTD_06")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }

                    if (isFTE_Greater_Or_Equal_To_50 == true)
                    {
                        if (bookmark.Name == "QSEHRA_06")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }


                    #endregion Topic 06 Federal Tax Code Requirements conditions - Ends here

                    #region Topic 07 Medicare Requrements conditions - Starts here
                    // Condition for Topic 07 Medicare Requrements conditions
                    if (isFTE_Greater_Or_Equal_To_20 == false)
                    {
                        if (bookmark.Name == "MSP_Rules_FTE_GT_20_07")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ddlQuestion5.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "Medicare_Part_Retiree_Drug_Subsidy_Q5_07")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isHSA_Plan_Selected == false)
                    {
                        if (bookmark.Name == "Medicare_and_HSA_Eligibility_07")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 07 Medicare Requrements conditions - Ends here

                    #region Topic 08 State Law conditions - Starts here
                    // Condition for Topic 08 State Law conditions
                    if (ddlQuestion8.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "State_and_City_Requirements_Q8_08")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ddlQuestion9.SelectedItem.Text == "No")
                    {
                        if (bookmark.Name == "State_Mandated_Disability_Q9_08")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFundingType_Self_Insured == false)
                    {
                        if (bookmark.Name == "Surcharges_SI_08")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (isFundingType_Fully_Insured == false)
                    {
                        if (bookmark.Name == "State_Insurance_Mandates_FI_08")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 08 State Law conditions - Ends here

                    #region Topic 09 HIPAA Privacy Security and Breach conditions - Starts here
                    // Condition for Topic 09 HIPAA Privacy Security and Breach conditions
                    if (isFundingType_Self_Insured == false)
                    {
                        if (bookmark.Name == "EDI_Requirements_SI_09")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 09 HIPAA Privacy Security and Breach conditions - Ends here

                    #region Topic 10 Federal Employment Law conditions - Starts here
                    // Condition for Topic 10 Federal Employment Law conditions
                    if (isFTE_Greater_Or_Equal_To_50 == false)
                    {
                        if (bookmark.Name == "FMLA_FTE_GT_50_10")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    #endregion Topic 10 Federal Employment Law conditions - Ends here
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


    }
}