﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_Acquisition_Transmittal_Form : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        public void WriteFieldToAcquisitionForm(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Wf_Contact> ContactList, string SessionId, ArrayList arrAcctContact)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();

                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;
                string SalesLead_EMail = string.Empty;
                string SalesLead_WorkPhone = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_EMail = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string AnalyticalSupport_FirstName = string.Empty;
                string AnalyticalSupport_LastName = string.Empty;
                string AnalyticalSupport_EMail = string.Empty;
                string AnalyticalSupport_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Required_5500 = string.Empty;
                string Broker_Of_Record = string.Empty;
                string Primary_Industry = string.Empty;
                string Num_Of_FTE = string.Empty;
                string Num_Of_FTE_AS_Of = string.Empty;
                string Num_Of_FTEquivalents = string.Empty;
                string Num_Of_FTEquivalents_AS_Of = string.Empty;
                string Num_Of_Retiree = string.Empty;
                string Num_Of_Retiree_As_Of = string.Empty;
                string BRC_Status = string.Empty;
                string BRC_Date_Implemented = string.Empty;
                string BenefitPoint_InternalID = string.Empty;

                List<string> MedicalPlanTypeList = new List<string>();

                MedicalPlanTypeList.Add("100");
                MedicalPlanTypeList.Add("110");
                MedicalPlanTypeList.Add("120");
                MedicalPlanTypeList.Add("130");
                MedicalPlanTypeList.Add("140");
                MedicalPlanTypeList.Add("150");
                MedicalPlanTypeList.Add("160");
                MedicalPlanTypeList.Add("170");
                MedicalPlanTypeList.Add("1116");

                //Added By Amogh 
                BenefitPoint_InternalID = ddlClient.SelectedValue.Trim();

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0)
                    {
                        for (int n = 0; n < AccountDS.Tables[0].Rows.Count; n++)
                        {
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "16799")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    MainPhone = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                    continue;
                                }
                            }


                        }
                    }
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                            {
                                Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"])))
                            {
                                Num_Of_FTEquivalents = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"]), out dateValue) == true)
                                {
                                    Num_Of_FTEquivalents_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])).ToString("MM/dd/yyyy");
                                }
                            }


                        }
                    }




                    // MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region MergeField
                string effectiveDate = string.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                        break;
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }



                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                oWordApp.Selection.TypeText(MainAddress);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainPhone))
                            {
                                oWordApp.Selection.TypeText(MainPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("5500 Required"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Required_5500))
                            {
                                oWordApp.Selection.TypeText(Required_5500);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }


                        //Data Entry Support Transmittal Form - Add Account ID to document - By Nicole
                        if (fieldName.Contains("BenefitPointInternalID"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(BenefitPoint_InternalID))
                            {
                                oWordApp.Selection.TypeText(BenefitPoint_InternalID);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Full Time Employees"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTE) && !(string.IsNullOrEmpty(Num_Of_FTE_AS_Of)) && Num_Of_FTE_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTE = Convert.ToDecimal(Num_Of_FTE);
                                //oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                                oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0"));

                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTE) && (string.IsNullOrEmpty(Num_Of_FTE_AS_Of)))
                            {
                                if (Num_Of_FTE == "0" && string.IsNullOrEmpty(Num_Of_FTE_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTE);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Full Time Equivalents"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && !(string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)) && Num_Of_FTEquivalents_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTEquivalents = Convert.ToDecimal(Num_Of_FTEquivalents);
                                oWordApp.Selection.TypeText(Number_Of_FTEquivalents.ToString("#,##0") + " as of " + Num_Of_FTEquivalents_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && (string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)))
                            {
                                if (Num_Of_FTEquivalents == "0" && string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTEquivalents);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }


                    }
                }
                #endregion

                #region Write Table of Account Contacts
                Tools_Constant tc = new Tools_Constant();
                string accountInfo = string.Empty;
                int clmCnt = 1;
                string name = string.Empty;
                string title = string.Empty;
                string email = string.Empty;
                string phoneNumber = string.Empty;
                bool PrimaryFlag = false;
                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                    //{
                                    ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                    //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                    //{
                                    if (clmCnt > 1)
                                    {
                                        //oWordDoc.Tables[2].Columns.Add();
                                        oWordDoc.Tables[2].Rows.Add();
                                    }

                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }
                                    if (ContactList[i].PrimaryFlag != null)
                                    {
                                        PrimaryFlag = ContactList[i].PrimaryFlag;
                                    }
                                    else
                                    {
                                        PrimaryFlag = false;
                                    }
                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }

                                    if (ContactList[i].Email != null)
                                    {
                                        email = ContactList[i].Email;
                                    }
                                    else
                                    {
                                        email = " ";
                                    }

                                    if (ContactList[i].Phone.Count > 0)
                                    {
                                        phoneNumber = ContactList[i].Phone[0];
                                    }
                                    else
                                    {
                                        phoneNumber = " ";
                                    }
                                    //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                    //oWordDoc.Tables[2].Cell(1, clmCnt).Range.Text = "Client Contact:";
                                    //oWordDoc.Tables[2].Cell(2, clmCnt).Range.Text = accountInfo;
                                    //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);
                                    if (PrimaryFlag == false)
                                    {
                                        oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = name;
                                    }
                                    else if (PrimaryFlag == true)
                                    {
                                        //oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = name + "\n" + "Primary Contact";
                                        oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = name;
                                        //Added by Amogh [Acquisition Transmittal Form - remove checkbox, replace text By Nicole]
                                        oWordDoc.Tables[2].Cell(j + 2, 1).Range.Text = "X";
                                    }

                                    oWordDoc.Tables[2].Cell(j + 2, 3).Range.Text = title;
                                    oWordDoc.Tables[2].Cell(j + 2, 4).Range.Text = phoneNumber;
                                    oWordDoc.Tables[2].Cell(j + 2, 5).Range.Text = email;
                                    oWordDoc.Tables[2].Cell(j + 2, 5).Range.Font.Size = 9;
                                    oWordDoc.Tables[2].Cell(j + 2, 5).Range.Font.Name = "calibri";
                                    //CallAccountContact_CheckboxLoop(oWordDoc, j + 2, 2);
                                    CallAccountContact_StatusLoop(oWordDoc, j + 2, 2);
                                    oWordDoc.Tables[2].Cell(j + 2, 6).Range.Font.Size = 9;
                                    oWordDoc.Tables[2].Cell(j + 2, 6).Range.Font.Name = "calibri";
                                    clmCnt++;

                                    //if (clmCnt > 3)
                                    //{
                                    //    break;
                                    //}
                                    //}
                                    //}
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion

                #region Write Table of PLans
                ArrayList PlanTypeList = new ArrayList();
                ArrayList CarrerNameList = new ArrayList();
                ArrayList PolicyNumberlist = new ArrayList();
                ArrayList effectiveList = new ArrayList();
                ArrayList RenewalList = new ArrayList();
                ArrayList Benefit_DescList = new ArrayList();
                ArrayList ContributionMethodList = new ArrayList();
                ArrayList FundingTypeList = new ArrayList();
                ArrayList NumberOfEmpList = new ArrayList();
                #endregion

                #region Plan Infor Code
                int rowCnt = 4;
                int m = 1;
                string PlanType = "";
                int rowCnt1 = 4;
                int m1 = 1;

                int PlanCnt = 0;
                int ProductCnt = 0;


                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    PlanType = dr["Name"].ToString().Replace("\r", "").Replace("\a", "").Trim();
                    BenefitSummaryList.Clear();
                    if (dr["ProductTypeId"].ToString().Length == 3)
                    {
                        PlanCnt++;
                        #region Plan Info Code
                        PlanTypeList.Add(PlanType);
                        CarrerNameList.Add(dr["Carrier"].ToString().Trim());
                        PolicyNumberlist.Add(dr["PolicyNumber"].ToString().Trim());
                        effectiveList.Add(dr["Effective"].ToString().Trim());
                        RenewalList.Add(dr["Renewal"].ToString().Trim());

                        if (rowCnt > 4)
                        {
                            oWordDoc.Tables[3].Rows.Add();
                            oWordDoc.Tables[3].Rows.Add();
                            oWordDoc.Tables[3].Rows.Add();
                            oWordDoc.Tables[3].Rows.Add();

                            oWordDoc.Tables[3].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineStyle = Word.WdLineStyle.wdLineStyleSingle;
                            oWordDoc.Tables[3].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineWidth = Word.WdLineWidth.wdLineWidth225pt;
                        }
                        oWordDoc.Tables[3].Cell(m, 1).Range.Text = dr["Name"].ToString().Trim();

                        oWordDoc.Tables[3].Cell(m, 2).Range.Text = "Carrier";
                        oWordDoc.Tables[3].Cell(m, 2).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m, 3).Range.Text = "Group Number";
                        oWordDoc.Tables[3].Cell(m, 3).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m, 4).Range.Text = "Effective Date";
                        oWordDoc.Tables[3].Cell(m, 4).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m, 4).Range.Font.Size = 9;

                        oWordDoc.Tables[3].Cell(m + 1, 2).Range.Text = dr["Carrier"].ToString().Trim();
                        oWordDoc.Tables[3].Cell(m + 1, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 1, 3).Range.Text = dr["PolicyNumber"].ToString().Trim();
                        oWordDoc.Tables[3].Cell(m + 1, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 1, 4).Range.Text = Convert.ToDateTime(dr["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                        oWordDoc.Tables[3].Cell(m + 1, 4).Range.Font.Size = 9;


                        oWordDoc.Tables[3].Cell(m + 2, 2).Range.Text = "How Many Plans Offered";
                        oWordDoc.Tables[3].Cell(m + 2, 2).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m + 2, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 2, 3).Range.Text = "Contribution Method";
                        oWordDoc.Tables[3].Cell(m + 2, 3).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m + 2, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 2, 4).Range.Text = "Plan Funding Type";
                        oWordDoc.Tables[3].Cell(m + 2, 4).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m + 2, 4).Range.Font.Size = 9;
                        CallPlans_OfferedLoop(oWordDoc, m + 3, 3);
                        CallContribution_MethodLoop(oWordDoc, m + 3, 3, 3);
                        CallPlan_FundingTypeLoop(oWordDoc, m + 3, 3);
                        m = m + 4;

                        rowCnt++;
                        #endregion
                    }
                    else
                    {
                        ProductCnt++;
                        #region Product Info Code
                        PlanTypeList.Add(PlanType);
                        CarrerNameList.Add(dr["Carrier"].ToString().Trim());
                        PolicyNumberlist.Add(dr["PolicyNumber"].ToString().Trim());
                        effectiveList.Add(dr["Effective"].ToString().Trim());
                        RenewalList.Add(dr["Renewal"].ToString().Trim());

                        if (rowCnt1 > 4)
                        {
                            oWordDoc.Tables[4].Rows.Add();
                            oWordDoc.Tables[4].Rows.Add();
                            oWordDoc.Tables[4].Rows.Add();
                            oWordDoc.Tables[4].Rows.Add();

                            oWordDoc.Tables[4].Rows[m1].Borders[Word.WdBorderType.wdBorderTop].LineStyle = Word.WdLineStyle.wdLineStyleSingle;
                            oWordDoc.Tables[4].Rows[m1].Borders[Word.WdBorderType.wdBorderTop].LineWidth = Word.WdLineWidth.wdLineWidth225pt;
                        }
                        oWordDoc.Tables[4].Cell(m1, 1).Range.Text = dr["Name"].ToString().Trim();

                        oWordDoc.Tables[4].Cell(m1, 2).Range.Text = "Carrier";
                        oWordDoc.Tables[4].Cell(m1, 2).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1, 3).Range.Text = "Group Number";
                        oWordDoc.Tables[4].Cell(m1, 3).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1, 4).Range.Text = "Effective Date";
                        oWordDoc.Tables[4].Cell(m1, 4).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1, 4).Range.Font.Size = 9;

                        oWordDoc.Tables[4].Cell(m1 + 1, 2).Range.Text = dr["Carrier"].ToString().Trim();
                        oWordDoc.Tables[4].Cell(m1 + 1, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 1, 3).Range.Text = dr["PolicyNumber"].ToString().Trim();
                        oWordDoc.Tables[4].Cell(m1 + 1, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 1, 4).Range.Text = Convert.ToDateTime(dr["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                        oWordDoc.Tables[4].Cell(m1 + 1, 4).Range.Font.Size = 9;


                        oWordDoc.Tables[4].Cell(m1 + 2, 2).Range.Text = "Contribution Method";
                        oWordDoc.Tables[4].Cell(m1 + 2, 2).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1 + 2, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 2, 3).Range.Text = "Who is Paying to Provide Product";
                        oWordDoc.Tables[4].Cell(m1 + 2, 3).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1 + 2, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 2, 4).Range.Text = "Plan Funding Type";
                        oWordDoc.Tables[4].Cell(m1 + 2, 4).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1 + 2, 4).Range.Font.Size = 9;
                        // CallPlans_OfferedLoop(oWordDoc, m1 + 3, 4);
                        CallContribution_MethodLoop(oWordDoc, m1 + 3, 4, 2);
                        CallProductPayingOption(oWordDoc, m1 + 3, 4);
                        CallPlan_FundingTypeLoop(oWordDoc, m1 + 3, 4);
                        // CallPlans_OfferedLoop(oWordDoc, m1 + 3);


                        m1 = m1 + 4;

                        rowCnt1++;
                        #endregion
                    }
                }


                #endregion

                #region Code for Merging the rows for Plan Listing

                //Color rowsColor_4 = Color.FromArgb(242, 242, 242);
                //int rgb_Rows4 = ColorTranslator.ToOle(rowsColor_4);
                //Word.WdColor wdColor_rows4 = (Word.WdColor)rgb_Rows4;

                //// oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = textbox_color(color);

                //int cnt = 5;
                //for (int rowNum = 5; rowNum <= oWordDoc.Tables[3].Rows.Count; rowNum++)
                //{
                //    //oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //    if (cnt <= rowNum)
                //    {
                //        oWordDoc.Tables[3].Rows[cnt].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        oWordDoc.Tables[3].Rows[cnt + 1].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        oWordDoc.Tables[3].Rows[cnt + 2].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        oWordDoc.Tables[3].Rows[cnt + 3].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        rowNum = rowNum + 7;
                //        cnt = rowNum + 1;
                //    }
                //}

                int rowCntVar = oWordDoc.Tables[3].Rows.Count;
                /*For First Coloumn*/
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[3].Rows.Count; rowNum++)
                {
                    // Check the remainder for the rownumber to merge
                    if (rowNum % 4 == 0)
                    {
                        oWordDoc.Tables[3].Cell(rowNum, 1).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 1));
                        oWordDoc.Tables[3].Cell(rowNum - 1, 1).Merge(oWordDoc.Tables[3].Cell(rowNum - 2, 1));
                        oWordDoc.Tables[3].Cell(rowNum - 2, 1).Merge(oWordDoc.Tables[3].Cell(rowNum - 3, 1));
                    }
                }
                //int rowCntVar = oWordDoc.Tables[4].Rows.Count;



                for (int rowNum = 2; rowNum <= rowCntVar; rowNum++)
                {
                    // Check the remainder for the rownumber to merge


                    oWordDoc.Tables[3].Cell(rowNum, 2).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 2));

                    oWordDoc.Tables[3].Cell(rowNum, 3).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 3));
                    oWordDoc.Tables[3].Cell(rowNum, 4).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 4));
                    //    oWordDoc.Tables[3].Cell(rowNum, 5).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 5));

                    rowCntVar = oWordDoc.Tables[3].Rows.Count;
                }



                /*For Second Coloumn*/
                //for (int rowNum = 1; rowNum <= rowCntVar; rowNum++)
                //{
                //    string strBenefitSummaryDescription = oWordDoc.Tables[3].Cell(rowNum, 2).Range.Text;
                //    if (strBenefitSummaryDescription == "\r\a")
                //    {
                //        oWordDoc.Tables[3].Cell(rowNum, 2).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 2));

                //    }

                //}
                #endregion
                #region Code for Merging the rows for Product Listing



                int rowCntVar1 = oWordDoc.Tables[4].Rows.Count;
                /*For First Coloumn*/
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                {
                    // Check the remainder for the rownumber to merge
                    if (rowNum % 4 == 0)
                    {
                        oWordDoc.Tables[4].Cell(rowNum, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 1));
                        oWordDoc.Tables[4].Cell(rowNum - 1, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 2, 1));
                        oWordDoc.Tables[4].Cell(rowNum - 2, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 3, 1));
                    }
                }
                //int rowCntVar = oWordDoc.Tables[4].Rows.Count;



                for (int rowNum = 2; rowNum <= rowCntVar1; rowNum++)
                {
                    // Check the remainder for the rownumber to merge


                    oWordDoc.Tables[4].Cell(rowNum, 2).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 2));

                    oWordDoc.Tables[4].Cell(rowNum, 3).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 3));
                    oWordDoc.Tables[4].Cell(rowNum, 4).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 4));
                    //    oWordDoc.Tables[3].Cell(rowNum, 5).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 5));

                    rowCntVar1 = oWordDoc.Tables[4].Rows.Count;
                }



                /*For Second Coloumn*/
                //for (int rowNum = 1; rowNum <= rowCntVar1; rowNum++)
                //{
                //    string strBenefitSummaryDescription = oWordDoc.Tables[4].Cell(rowNum, 2).Range.Text;
                //    if (strBenefitSummaryDescription == "\r\a")
                //    {
                //        oWordDoc.Tables[4].Cell(rowNum, 2).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 2));

                //    }

                //}
                #endregion

                foreach (Word.Bookmark bookmark in oWordApp.ActiveDocument.Bookmarks)
                {
                    if (PlanCnt == 0)
                    {
                        if (bookmark.Name == "PlanListing")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ProductCnt == 0)
                    {

                        if (bookmark.Name == "ProductListing")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteFieldToAcquisitionForm_V2(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();

                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;
                string SalesLead_EMail = string.Empty;
                string SalesLead_WorkPhone = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_EMail = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string AnalyticalSupport_FirstName = string.Empty;
                string AnalyticalSupport_LastName = string.Empty;
                string AnalyticalSupport_EMail = string.Empty;
                string AnalyticalSupport_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Required_5500 = string.Empty;
                string Broker_Of_Record = string.Empty;
                string Primary_Industry = string.Empty;
                string Num_Of_FTE = string.Empty;
                string Num_Of_FTE_AS_Of = string.Empty;
                string Num_Of_FTEquivalents = string.Empty;
                string Num_Of_FTEquivalents_AS_Of = string.Empty;
                string Num_Of_Retiree = string.Empty;
                string Num_Of_Retiree_As_Of = string.Empty;
                string BRC_Status = string.Empty;
                string BRC_Date_Implemented = string.Empty;
                string BenefitPoint_InternalID = string.Empty;

                List<string> MedicalPlanTypeList = new List<string>();

                MedicalPlanTypeList.Add("100");
                MedicalPlanTypeList.Add("110");
                MedicalPlanTypeList.Add("120");
                MedicalPlanTypeList.Add("130");
                MedicalPlanTypeList.Add("140");
                MedicalPlanTypeList.Add("150");
                MedicalPlanTypeList.Add("160");
                MedicalPlanTypeList.Add("170");
                MedicalPlanTypeList.Add("1116");


                //Added By Amogh 
                BenefitPoint_InternalID = ddlClient.SelectedValue.Trim();

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0)
                    {
                        for (int n = 0; n < AccountDS.Tables[0].Rows.Count; n++)
                        {
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "16799")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    MainPhone = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                    continue;
                                }
                            }


                        }
                    }
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                            {
                                Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"])))
                            {
                                Num_Of_FTEquivalents = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"]), out dateValue) == true)
                                {
                                    Num_Of_FTEquivalents_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])).ToString("MM/dd/yyyy");
                                }
                            }


                        }
                    }




                    // MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region MergeField
                string effectiveDate = string.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                        break;
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }



                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                oWordApp.Selection.TypeText(MainAddress);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainPhone))
                            {
                                oWordApp.Selection.TypeText(MainPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("5500 Required"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Required_5500))
                            {
                                oWordApp.Selection.TypeText(Required_5500);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        //Data Entry Support Transmittal Form - Add Account ID to document - By Nicole
                        if (fieldName.Contains("BenefitPointInternalID"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(BenefitPoint_InternalID))
                            {
                                oWordApp.Selection.TypeText(BenefitPoint_InternalID);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }


                        if (fieldName.Contains("Number of Full Time Employees"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTE) && !(string.IsNullOrEmpty(Num_Of_FTE_AS_Of)) && Num_Of_FTE_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTE = Convert.ToDecimal(Num_Of_FTE);
                                //oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                                oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0"));

                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTE) && (string.IsNullOrEmpty(Num_Of_FTE_AS_Of)))
                            {
                                if (Num_Of_FTE == "0" && string.IsNullOrEmpty(Num_Of_FTE_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTE);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Full Time Equivalents"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && !(string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)) && Num_Of_FTEquivalents_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTEquivalents = Convert.ToDecimal(Num_Of_FTEquivalents);
                                oWordApp.Selection.TypeText(Number_Of_FTEquivalents.ToString("#,##0") + " as of " + Num_Of_FTEquivalents_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && (string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)))
                            {
                                if (Num_Of_FTEquivalents == "0" && string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTEquivalents);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }


                    }
                }
                #endregion

                #region Write Table of Account Contacts
                Tools_Constant tc = new Tools_Constant();
                string accountInfo = string.Empty;
                int clmCnt = 1;
                string name = string.Empty;
                string title = string.Empty;
                string email = string.Empty;
                string phoneNumber = string.Empty;
                bool PrimaryFlag = false;
                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                    //{
                                    ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                    //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                    //{
                                    if (clmCnt > 1)
                                    {
                                        //oWordDoc.Tables[2].Columns.Add();
                                        oWordDoc.Tables[2].Rows.Add();
                                    }

                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }
                                    if (ContactList[i].PrimaryFlag != null)
                                    {
                                        PrimaryFlag = ContactList[i].PrimaryFlag;
                                    }
                                    else
                                    {
                                        PrimaryFlag = false;
                                    }
                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }

                                    if (ContactList[i].Email != null)
                                    {
                                        email = ContactList[i].Email;
                                    }
                                    else
                                    {
                                        email = " ";
                                    }

                                    if (ContactList[i].Phone.Count > 0)
                                    {
                                        phoneNumber = ContactList[i].Phone[0];
                                    }
                                    else
                                    {
                                        phoneNumber = " ";
                                    }
                                    //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                    //oWordDoc.Tables[2].Cell(1, clmCnt).Range.Text = "Client Contact:";
                                    //oWordDoc.Tables[2].Cell(2, clmCnt).Range.Text = accountInfo;
                                    //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);
                                    if (PrimaryFlag == false)
                                    {
                                        oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = name;
                                    }
                                    else if (PrimaryFlag == true)
                                    {
                                        //oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = name + "\n" + "Primary Contact";
                                        oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = name;
                                        //Added by Amogh [Acquisition Transmittal Form - remove checkbox, replace text By Nicole]
                                        oWordDoc.Tables[2].Cell(j + 2, 1).Range.Text = "X";
                                    }

                                    oWordDoc.Tables[2].Cell(j + 2, 3).Range.Text = title;
                                    oWordDoc.Tables[2].Cell(j + 2, 4).Range.Text = phoneNumber;
                                    oWordDoc.Tables[2].Cell(j + 2, 5).Range.Text = email;
                                    oWordDoc.Tables[2].Cell(j + 2, 5).Range.Font.Size = 9;
                                    oWordDoc.Tables[2].Cell(j + 2, 5).Range.Font.Name = "calibri";
                                    //CallAccountContact_CheckboxLoop(oWordDoc, j + 2, 2);
                                    CallAccountContact_StatusLoop(oWordDoc, j + 2, 2);
                                    oWordDoc.Tables[2].Cell(j + 2, 6).Range.Font.Size = 9;
                                    oWordDoc.Tables[2].Cell(j + 2, 6).Range.Font.Name = "calibri";
                                    clmCnt++;

                                    //if (clmCnt > 3)
                                    //{
                                    //    break;
                                    //}
                                    //}
                                    //}
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion

                #region Write Table of PLans
                ArrayList PlanTypeList = new ArrayList();
                ArrayList CarrerNameList = new ArrayList();
                ArrayList PolicyNumberlist = new ArrayList();
                ArrayList effectiveList = new ArrayList();
                ArrayList RenewalList = new ArrayList();
                ArrayList Benefit_DescList = new ArrayList();
                ArrayList ContributionMethodList = new ArrayList();
                ArrayList FundingTypeList = new ArrayList();
                ArrayList NumberOfEmpList = new ArrayList();
                #endregion

                #region Plan Infor Code
                int rowCnt = 4;
                int m = 1;
                string PlanType = "";
                int rowCnt1 = 4;
                int m1 = 1;

                int PlanCnt = 0;
                int ProductCnt = 0;


                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    PlanType = dr["Name"].ToString().Replace("\r", "").Replace("\a", "").Trim();
                    BenefitSummaryList.Clear();
                    if (dr["ProductTypeId"].ToString().Length == 3)
                    {
                        PlanCnt++;
                        #region Plan Info Code
                        PlanTypeList.Add(PlanType);
                        CarrerNameList.Add(dr["Carrier"].ToString().Trim());
                        PolicyNumberlist.Add(dr["PolicyNumber"].ToString().Trim());
                        effectiveList.Add(dr["Effective"].ToString().Trim());
                        RenewalList.Add(dr["Renewal"].ToString().Trim());

                        if (rowCnt > 4)
                        {
                            oWordDoc.Tables[3].Rows.Add();
                            oWordDoc.Tables[3].Rows.Add();
                            oWordDoc.Tables[3].Rows.Add();
                            oWordDoc.Tables[3].Rows.Add();

                            oWordDoc.Tables[3].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineStyle = Word.WdLineStyle.wdLineStyleSingle;
                            oWordDoc.Tables[3].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineWidth = Word.WdLineWidth.wdLineWidth225pt;
                        }
                        oWordDoc.Tables[3].Cell(m, 1).Range.Text = dr["Name"].ToString().Trim();

                        oWordDoc.Tables[3].Cell(m, 2).Range.Text = "Carrier";
                        oWordDoc.Tables[3].Cell(m, 2).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m, 3).Range.Text = "Group Number";
                        oWordDoc.Tables[3].Cell(m, 3).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m, 4).Range.Text = "Effective Date";
                        oWordDoc.Tables[3].Cell(m, 4).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m, 4).Range.Font.Size = 9;

                        oWordDoc.Tables[3].Cell(m + 1, 2).Range.Text = dr["Carrier"].ToString().Trim();
                        oWordDoc.Tables[3].Cell(m + 1, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 1, 3).Range.Text = dr["PolicyNumber"].ToString().Trim();
                        oWordDoc.Tables[3].Cell(m + 1, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 1, 4).Range.Text = Convert.ToDateTime(dr["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                        oWordDoc.Tables[3].Cell(m + 1, 4).Range.Font.Size = 9;


                        oWordDoc.Tables[3].Cell(m + 2, 2).Range.Text = "How Many Plans Offered";
                        oWordDoc.Tables[3].Cell(m + 2, 2).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m + 2, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 2, 3).Range.Text = "Contribution Method";
                        oWordDoc.Tables[3].Cell(m + 2, 3).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m + 2, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[3].Cell(m + 2, 4).Range.Text = "Plan Funding Type";
                        oWordDoc.Tables[3].Cell(m + 2, 4).Range.Bold = 1;
                        oWordDoc.Tables[3].Cell(m + 2, 4).Range.Font.Size = 9;
                        CallPlans_OfferedLoop(oWordDoc, m + 3, 3);
                        CallContribution_MethodLoop(oWordDoc, m + 3, 3, 3);
                        CallPlan_FundingTypeLoop(oWordDoc, m + 3, 3);
                        m = m + 4;

                        rowCnt++;
                        #endregion
                    }
                    else
                    {
                        ProductCnt++;
                        #region Product Info Code
                        PlanTypeList.Add(PlanType);
                        CarrerNameList.Add(dr["Carrier"].ToString().Trim());
                        PolicyNumberlist.Add(dr["PolicyNumber"].ToString().Trim());
                        effectiveList.Add(dr["Effective"].ToString().Trim());
                        RenewalList.Add(dr["Renewal"].ToString().Trim());

                        if (rowCnt1 > 4)
                        {
                            oWordDoc.Tables[4].Rows.Add();
                            oWordDoc.Tables[4].Rows.Add();
                            oWordDoc.Tables[4].Rows.Add();
                            oWordDoc.Tables[4].Rows.Add();

                            oWordDoc.Tables[4].Rows[m1].Borders[Word.WdBorderType.wdBorderTop].LineStyle = Word.WdLineStyle.wdLineStyleSingle;
                            oWordDoc.Tables[4].Rows[m1].Borders[Word.WdBorderType.wdBorderTop].LineWidth = Word.WdLineWidth.wdLineWidth225pt;
                        }
                        oWordDoc.Tables[4].Cell(m1, 1).Range.Text = dr["Name"].ToString().Trim();

                        oWordDoc.Tables[4].Cell(m1, 2).Range.Text = "Carrier";
                        oWordDoc.Tables[4].Cell(m1, 2).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1, 3).Range.Text = "Group Number";
                        oWordDoc.Tables[4].Cell(m1, 3).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1, 4).Range.Text = "Effective Date";
                        oWordDoc.Tables[4].Cell(m1, 4).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1, 4).Range.Font.Size = 9;

                        oWordDoc.Tables[4].Cell(m1 + 1, 2).Range.Text = dr["Carrier"].ToString().Trim();
                        oWordDoc.Tables[4].Cell(m1 + 1, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 1, 3).Range.Text = dr["PolicyNumber"].ToString().Trim();
                        oWordDoc.Tables[4].Cell(m1 + 1, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 1, 4).Range.Text = Convert.ToDateTime(dr["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                        oWordDoc.Tables[4].Cell(m1 + 1, 4).Range.Font.Size = 9;


                        oWordDoc.Tables[4].Cell(m1 + 2, 2).Range.Text = "Contribution Method";
                        oWordDoc.Tables[4].Cell(m1 + 2, 2).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1 + 2, 2).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 2, 3).Range.Text = "Who is Paying to Provide Product";
                        oWordDoc.Tables[4].Cell(m1 + 2, 3).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1 + 2, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m1 + 2, 4).Range.Text = "Plan Funding Type";
                        oWordDoc.Tables[4].Cell(m1 + 2, 4).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m1 + 2, 4).Range.Font.Size = 9;
                        // CallPlans_OfferedLoop(oWordDoc, m1 + 3, 4);
                        CallContribution_MethodLoop(oWordDoc, m1 + 3, 4, 2);
                        CallProductPayingOption(oWordDoc, m1 + 3, 4);
                        CallPlan_FundingTypeLoop(oWordDoc, m1 + 3, 4);
                        // CallPlans_OfferedLoop(oWordDoc, m1 + 3);


                        m1 = m1 + 4;

                        rowCnt1++;
                        #endregion
                    }
                }


                #endregion

                #region Code for Merging the rows for Plan Listing

                //Color rowsColor_4 = Color.FromArgb(242, 242, 242);
                //int rgb_Rows4 = ColorTranslator.ToOle(rowsColor_4);
                //Word.WdColor wdColor_rows4 = (Word.WdColor)rgb_Rows4;

                //// oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = textbox_color(color);

                //int cnt = 5;
                //for (int rowNum = 5; rowNum <= oWordDoc.Tables[3].Rows.Count; rowNum++)
                //{
                //    //oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //    if (cnt <= rowNum)
                //    {
                //        oWordDoc.Tables[3].Rows[cnt].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        oWordDoc.Tables[3].Rows[cnt + 1].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        oWordDoc.Tables[3].Rows[cnt + 2].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        oWordDoc.Tables[3].Rows[cnt + 3].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                //        rowNum = rowNum + 7;
                //        cnt = rowNum + 1;
                //    }
                //}

                int rowCntVar = oWordDoc.Tables[3].Rows.Count;
                /*For First Coloumn*/
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[3].Rows.Count; rowNum++)
                {
                    // Check the remainder for the rownumber to merge
                    if (rowNum % 4 == 0)
                    {
                        oWordDoc.Tables[3].Cell(rowNum, 1).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 1));
                        oWordDoc.Tables[3].Cell(rowNum - 1, 1).Merge(oWordDoc.Tables[3].Cell(rowNum - 2, 1));
                        oWordDoc.Tables[3].Cell(rowNum - 2, 1).Merge(oWordDoc.Tables[3].Cell(rowNum - 3, 1));
                    }
                }
                //int rowCntVar = oWordDoc.Tables[4].Rows.Count;



                for (int rowNum = 2; rowNum <= rowCntVar; rowNum++)
                {
                    // Check the remainder for the rownumber to merge


                    oWordDoc.Tables[3].Cell(rowNum, 2).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 2));

                    oWordDoc.Tables[3].Cell(rowNum, 3).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 3));
                    oWordDoc.Tables[3].Cell(rowNum, 4).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 4));
                    //    oWordDoc.Tables[3].Cell(rowNum, 5).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 5));

                    rowCntVar = oWordDoc.Tables[3].Rows.Count;
                }



                /*For Second Coloumn*/
                //for (int rowNum = 1; rowNum <= rowCntVar; rowNum++)
                //{
                //    string strBenefitSummaryDescription = oWordDoc.Tables[3].Cell(rowNum, 2).Range.Text;
                //    if (strBenefitSummaryDescription == "\r\a")
                //    {
                //        oWordDoc.Tables[3].Cell(rowNum, 2).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 2));

                //    }

                //}
                #endregion
                #region Code for Merging the rows for Product Listing



                int rowCntVar1 = oWordDoc.Tables[4].Rows.Count;
                /*For First Coloumn*/
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                {
                    // Check the remainder for the rownumber to merge
                    if (rowNum % 4 == 0)
                    {
                        oWordDoc.Tables[4].Cell(rowNum, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 1));
                        oWordDoc.Tables[4].Cell(rowNum - 1, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 2, 1));
                        oWordDoc.Tables[4].Cell(rowNum - 2, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 3, 1));
                    }
                }
                //int rowCntVar = oWordDoc.Tables[4].Rows.Count;



                for (int rowNum = 2; rowNum <= rowCntVar1; rowNum++)
                {
                    // Check the remainder for the rownumber to merge


                    oWordDoc.Tables[4].Cell(rowNum, 2).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 2));

                    oWordDoc.Tables[4].Cell(rowNum, 3).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 3));
                    oWordDoc.Tables[4].Cell(rowNum, 4).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 4));
                    //    oWordDoc.Tables[3].Cell(rowNum, 5).Merge(oWordDoc.Tables[3].Cell(rowNum - 1, 5));

                    rowCntVar1 = oWordDoc.Tables[4].Rows.Count;
                }



                /*For Second Coloumn*/
                //for (int rowNum = 1; rowNum <= rowCntVar1; rowNum++)
                //{
                //    string strBenefitSummaryDescription = oWordDoc.Tables[4].Cell(rowNum, 2).Range.Text;
                //    if (strBenefitSummaryDescription == "\r\a")
                //    {
                //        oWordDoc.Tables[4].Cell(rowNum, 2).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 2));

                //    }

                //}
                #endregion

                foreach (Word.Bookmark bookmark in oWordApp.ActiveDocument.Bookmarks)
                {
                    if (PlanCnt == 0)
                    {
                        if (bookmark.Name == "PlanListing")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    if (ProductCnt == 0)
                    {

                        if (bookmark.Name == "ProductListing")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void CallAccountContact_CheckboxLoop(Word.Document oWordDoc, int i, int tableNumber)
        {
            Word.Range range2 = oWordDoc.Tables[tableNumber].Cell(i, 1).Range;
            range2.FormFields.Add(range2, Word.WdFieldType.wdFieldFormCheckBox);

            //Word.FormField checkBox = oWordDoc.FormFields.Add(oWordDoc.Tables[tableNumber].Cell(i, 1).Range, Word.WdFieldType.wdFieldFormCheckBox);




            //Word.ContentControl checkbox = oWordDoc.Tables[tableNumber].Cell(i, 1).Range.ContentControls.Add(Word.WdContentControlType.wdContentControlCheckBox);
        }

        public void CallPlans_OfferedLoop(Word.Document oWordDoc, int i, int tableNumber)
        {
            Word.Range range2 = oWordDoc.Tables[tableNumber].Cell(i, 2).Range;
            oWordDoc.Tables[tableNumber].Cell(i, 2).Range.Font.Size = 9;
            oWordDoc.Tables[tableNumber].Cell(i, 2).Range.Font.Name = "calibri";
            range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);

            range2.Font.Size = 9;
            range2.Font.Name = "calibri";
            foreach (Word.ContentControl dropdown in range2.ContentControls)
            {
                dropdown.DropdownListEntries.Clear();
                dropdown.DropdownListEntries.Add("Select", "Select", 1);

                dropdown.DropdownListEntries.Add("1", "first", 2);
                dropdown.DropdownListEntries.Add("2", "second", 3);
                dropdown.DropdownListEntries.Add("3", "third", 4);
                dropdown.DropdownListEntries.Add("4", "fourth", 5);
                dropdown.DropdownListEntries.Add("5", "five", 6);
                dropdown.DropdownListEntries.Add("6", "six", 7);
                dropdown.DropdownListEntries.Add("7", "seven", 8);
                dropdown.DropdownListEntries.Add("8", "eight", 9);
                dropdown.DropdownListEntries.Add("9", "nine", 10);
                dropdown.DropdownListEntries.Add("10", "ten", 11);


            }
        }
        public void CallContribution_MethodLoop(Word.Document oWordDoc, int i, int tableNumber, int ColumnNumber)
        {
            Word.Range range2 = oWordDoc.Tables[tableNumber].Cell(i, ColumnNumber).Range;
            oWordDoc.Tables[tableNumber].Cell(i, 3).Range.Font.Size = 9;
            oWordDoc.Tables[tableNumber].Cell(i, 3).Range.Font.Name = "calibri";
            range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
            range2.Font.Size = 9;
            range2.Font.Name = "calibri";
            foreach (Word.ContentControl dropdown in range2.ContentControls)
            {
                dropdown.DropdownListEntries.Clear();
                dropdown.DropdownListEntries.Add("Select", "Select", 1);
                dropdown.DropdownListEntries.Add("100% EmployER Paid", "first", 2);
                dropdown.DropdownListEntries.Add("100% EmployEE Paid", "second", 3);
                dropdown.DropdownListEntries.Add("Both ER and EE Contributes", "third", 4);

            }
        }

        public void CallPlan_FundingTypeLoop(Word.Document oWordDoc, int i, int tableNumber)
        {
            Word.Range range2 = oWordDoc.Tables[tableNumber].Cell(i, 4).Range;
            oWordDoc.Tables[tableNumber].Cell(i, 4).Range.Font.Size = 9;
            oWordDoc.Tables[tableNumber].Cell(i, 4).Range.Font.Name = "calibri";
            range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
            range2.Font.Size = 9;
            range2.Font.Name = "calibri";
            foreach (Word.ContentControl dropdown in range2.ContentControls)
            {
                dropdown.DropdownListEntries.Clear();
                dropdown.DropdownListEntries.Add("Select", "Select", 1);
                dropdown.DropdownListEntries.Add("Fully Insured", "first", 2);
                dropdown.DropdownListEntries.Add("Self Funded", "second", 3);
                //dropdown.DropdownListEntries.Add("Both ER and EE Contributes", "third", 3);
                // dropdown.DropdownListEntries.Add("4", "fourth", 4);

            }
        }

        public void CallAccountContact_StatusLoop(Word.Document oWordDoc, int i, int tableNumber)
        {
            Word.Range range2 = oWordDoc.Tables[tableNumber].Cell(i, 6).Range;
            oWordDoc.Tables[tableNumber].Cell(i, 6).Range.Font.Size = 9;
            oWordDoc.Tables[tableNumber].Cell(i, 6).Range.Font.Name = "calibri";
            range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
            range2.Font.Size = 9;
            range2.Font.Name = "calibri";
            foreach (Word.ContentControl dropdown in range2.ContentControls)
            {
                dropdown.DropdownListEntries.Clear();
                dropdown.DropdownListEntries.Add("No Change", "No Change", 1);
                dropdown.DropdownListEntries.Add("Delete", "Delete", 2);
                dropdown.DropdownListEntries.Add("Update", "Update", 3);
                //dropdown.DropdownListEntries.Add("Both ER and EE Contributes", "third", 3);
                // dropdown.DropdownListEntries.Add("4", "fourth", 4);

            }
        }

        public void CallProductPayingOption(Word.Document oWordDoc, int i, int tableNumber)
        {
            Word.Range range2 = oWordDoc.Tables[tableNumber].Cell(i, 3).Range;
            oWordDoc.Tables[tableNumber].Cell(i, 3).Range.Font.Size = 9;
            oWordDoc.Tables[tableNumber].Cell(i, 3).Range.Font.Name = "calibri";
            range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
            range2.Font.Size = 9;
            range2.Font.Name = "calibri";
            foreach (Word.ContentControl dropdown in range2.ContentControls)
            {
                dropdown.DropdownListEntries.Clear();
                dropdown.DropdownListEntries.Add("Select", "Select", 1);
                dropdown.DropdownListEntries.Add("Client Only", "first", 2);
                dropdown.DropdownListEntries.Add("USI Only", "second", 3);
                dropdown.DropdownListEntries.Add("Both Client and USI ", "Third", 4);

                //dropdown.DropdownListEntries.Add("Both ER and EE Contributes", "third", 3);
                // dropdown.DropdownListEntries.Add("4", "fourth", 4);

            }
        }

    }
}