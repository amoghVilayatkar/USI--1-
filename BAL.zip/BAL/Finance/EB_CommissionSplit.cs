﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using System.Drawing;
using StringTrimmer;
using Microsoft.Office.Core;
using BenefitPointSummaryPortal.BAL.BenefitSummary;

namespace BenefitPointSummaryPortal.BAL.Finance
{
    public class EB_CommissionSplit : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        public void WriteFinanceForm_CommissionSplitRequest(Word.Document oWordDoc, Word.Application oWordApp, string CommisionSpliteDate, string Account_Office, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, string SessionId, string IsCommissionSplit, string ClientName, int TotalAssociates)
        {
            try
            {
                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                int iTotalFields = 0;

                Color rowsColor_4 = Color.FromArgb(242, 242, 242);
                int rgb_Rows4 = ColorTranslator.ToOle(rowsColor_4);
                Word.WdColor wdColor_rows4 = (Word.WdColor)rgb_Rows4;


                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);

                                    }
                                }
                            }
                        }
                    }
                }

                #endregion

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();


                        if (fieldName.Contains("Primary Sales Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Commission Split Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(CommisionSpliteDate))
                            {
                                oWordApp.Selection.TypeText(CommisionSpliteDate);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("OfficeStreet"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Account_Office))
                            {
                                oWordApp.Selection.TypeText(Account_Office);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }
                #endregion

                #region Add rows to COMMISSION SPLIT table
                oWordDoc.Tables[2].Cell(2, 1).Range.Text = SalesLead_FirstName + " " + SalesLead_LastName;
              //  oWordDoc.Tables[2].Cell(2, 1).Range.Font.Shading.BackgroundPatternColor = Word.WdColor.wdColorBrightGreen;
                for (int k = 1; k < TotalAssociates; k++)
                {
                    oWordDoc.Tables[2].Rows.Add();
                }
                //code added by shravan "FEEDBACK 3: New Deliverables Module Request - Finance Forms for Sagitta"
                if (TotalAssociates > 1)
                {
                    oWordDoc.Tables[6].Rows[1].Range.Copy();
                    for (int k = 1; k < TotalAssociates; k++)
                    {
                        oWordDoc.Tables[6].Rows[1].Range.Paste();
                    }
                }
                #endregion

                #region Writing plan table
                int i = 2;
                if (PlanInfoTable != null)
                    foreach (DataRow dr in PlanInfoTable.Rows)
                    {

                        // oWordDoc.Tables[4].Cell(i, 1).Range.Text = dr["PlanType"].ToString(); // Value change to Plan Name as per Catherine request on Feedback 2: New Deliverable Module Request - Finance Form
                        oWordDoc.Tables[4].Cell(i, 1).Range.Text = dr["Name"].ToString();
                        oWordDoc.Tables[4].Cell(i, 2).Range.Text = dr["Carrier"].ToString();
                        oWordDoc.Tables[4].Cell(i, 3).Range.Text = dr["PolicyNumber"].ToString();

                        //Setting green background
                        //for (int l = 1; l < 4; l++)
                        //{
                        //    oWordDoc.Tables[4].Cell(i, l).Range.Font.Shading.BackgroundPatternColor = Word.WdColor.wdColorBrightGreen;
                        //}

                        //Adding rows and setting even row style 
                        if (PlanInfoTable.Rows.Count > i - 1)
                        {
                            oWordDoc.Tables[4].Rows.Add();
                        }
                        if (i % 2 == 0)
                            oWordDoc.Tables[4].Rows[i].Shading.BackgroundPatternColor = wdColor_rows4;
                        i++;
                    }
                #endregion

                #region Delete Bookmarks
                foreach (Word.Bookmark bookmark in oWordApp.ActiveDocument.Bookmarks)
                {
                    if (IsCommissionSplit == "Yes")
                    {
                        if (bookmark.Name == "USILinesNO")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                    else if (IsCommissionSplit == "No")
                    {
                        if (bookmark.Name == "USILinesYES")
                        {
                            bookmark.Range.Delete();
                            continue;
                        }
                    }
                }

                #endregion

                Write_Field_Header(oWordDoc, oWordApp, ClientName);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_Field_Header(Word.Document oWordDoc, Word.Application oWordApp, string ClientName)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Client Name"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(ClientName.Trim());
                                continue;
                            }

                        }
                    }
                }
            }

        }
    }
}