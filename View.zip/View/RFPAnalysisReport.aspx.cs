﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.Common.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using BenefitPointSummaryPortal.BAL.AnalysisTemplate;
using BenefitPointSummaryPortal.BAL.RFPReports;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace BenefitPointSummaryPortal.View
{
    public partial class RFPAnalysisReport : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        string Activity = "Ancillary LOC Templates";
        string Activity_Group = "Analytics";

        string SessionId = "";
        List<int> ApplicablePlanTypeIds = new List<int>();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        Dictionary<string, string> dictOrientationOption = new Dictionary<string, string>();
        #region Analysis Type Plan Types
        List<string> lstAnalysisLOCOptions = new List<string>() { "Dental", "Vision", "Life and AD&D", "Voluntary L/AD&D", "Short Term Disability", "Voluntary STD", "STD Statutory", "Long Term Disability", "Voluntary LTD", "EAP", "Absence Management" };
        List<int> AnalysisType_Dental = new List<int>() { 180, 190, 200, 210 };
        List<int> AnalysisType_DentalDual = new List<int>() { 180, 190, 200, 210 };
        List<int> AnalysisType_DentalDHMO = new List<int>() { 180, 210 };
        List<int> AnalysisType_DentalASO = new List<int>() { 180, 190, 200, 210 };
        List<int> AnalysisType_DentalASODual = new List<int>() { 180, 190, 200, 210 };

        List<int> AnalysisType_Vision = new List<int>() { 230 };
        List<int> AnalysisType_VisionDual = new List<int>() { 230 };
        List<int> AnalysisType_VisionASO = new List<int>() { 230 };
        List<int> AnalysisType_VisionASODual = new List<int>() { 230 };

        List<int> AnalysisType_LADD = new List<int>() { 250, 1150, 240, 1230, 270 };
        List<int> AnalysisType_LADDClasses = new List<int>() { 250, 1150, 240, 1230, 270 };

        List<int> AnalysisType_VolLADD_VOL = new List<int>() { 260, 280, 240, 270 };// Keep this for voluntary and removed 260 and 280

        List<int> AnalysisType_STDSingle = new List<int>() { 290 }; // Excluded 290 
        List<int> AnalysisType_STDClasses = new List<int>() { 290 };// Excluded 290 

        List<int> AnalysisType_STDVol = new List<int>() { 290 };

        List<int> AnalysisType_STDStatutory = new List<int>() { 292, 293, 294, 295, 296, 297 };

        List<int> AnalysisType_LTDSingle = new List<int>() { 300 };
        List<int> AnalysisType_LTDClasses = new List<int>() { 300 };
        List<int> AnalysisType_LTDVol = new List<int>() { 300 };

        List<int> AnalysisType_AbsenceManagement = new List<int>() { 5330 };
        List<int> AnalysisType_EAP = new List<int>() { 310 };
        #endregion
        #region Analysis Types
        List<string> lstDentalAnalysisType = new List<string>() { "Dental", "Dental Dual", "Dental ASO", "Dental ASO Dual", "Dental DHMO" };
        List<string> lstVisionAnalysisType = new List<string>() { "Vision", "Vision Dual", "Vision ASO", "Vision ASO Dual" };
        List<string> lstLifeADDAnalysisType = new List<string>() { "LADD", "LADD Classes" }; // removed vol ldd
        List<string> lstShortTermDisablityAnalysisType = new List<string>() { "STD Single", "STD Classes" }; // Removed Vol STD
        List<string> lstLongTermDisablityAnalysisType = new List<string>() { "LTD Single", "LTD Classes" };
        List<string> lstAbsenseAnalysisType = new List<string>() { "Absence Management" };
        List<string> lstEAPAnalysisType = new List<string>() { "EAP" };
        List<string> lstVolLADDAnalysisType = new List<string>() { "LADD Vol" };
        List<string> lstVolSTDAnalysisType = new List<string>() { "STD Vol" };
        List<string> lstVolLTDAnalysisType = new List<string>() { "LTD Vol" };
        List<string> lstSTDStatutoryAnalysisType = new List<string>() { "STD Statutory" };
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                LoadOrientationOptions();
                if (!IsPostBack)
                {
                    BindState();
                    ddlcontents.SelectedValue = "Ancillary_Analysis";
                    ddlcontents_SelectedIndexChanged(null, null);
                    mvRFPReport.ActiveViewIndex = 0;
                    btnSummary.OnClientClick = "javascript:return ValidateCriteriaPage1();";
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            }
        }
        #region functions
        private void Handle_ClientChange()
        {
            if (ddlcontents.SelectedValue == "0")
            {
                gvAncillaryAnalysisPlans.DataSource = null;
                gvAncillaryAnalysisPlans.DataBind();
                ddlAncillayAnalysisAdditionLOC.SelectedValue = "0";

            }
            if (ddlcontents.SelectedValue == "Ancillary_Analysis")
            {
                gvAncillaryAnalysisPlans.DataSource = null;
                gvAncillaryAnalysisPlans.DataBind();
                ddlAncillayAnalysisAdditionLOC.SelectedValue = "0";
                txtAncillaryAnalysisRenewalDate.Text = "";
                rdlAncillaryAnalysisPlanStatus.SelectedIndex = 0;
                if (ddlClient.SelectedIndex > 0)
                {
                    AnalysisTemplate_BindPlanGrid();
                }
            }
        }
        private void LoadOrientationOptions()
        {
            dictOrientationOption["Ancillary_Analysis"] = "all";
            dictOrientationOption["Ancillary_Unpopulated"] = "all";
        }
        private void BindState()
        {
            //USI State
            DataTable dtOfficeState = new DataTable();
            dtOfficeState = bp.GetOfficeStateList();
            ddlUSI_State.DataSource = dtOfficeState;
            ddlUSI_State.DataBind();
            ddlUSI_State.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlUSI_State.SelectedIndex = 0;
            ddlUSI_State_SelectedIndexChanged(null, null);
        }
        private void LoadPlanTypeIds()
        {
            //if (ddlcontents.SelectedValue == "Ancillary_Intake_Form_REP")
            //{
            //    ApplicablePlanTypeIds.Add(180);
            //    ApplicablePlanTypeIds.Add(210);
            //    ApplicablePlanTypeIds.Add(190);
            //    ApplicablePlanTypeIds.Add(200);
            //    ApplicablePlanTypeIds.Add(230);
            //    ApplicablePlanTypeIds.Add(250);
            //    ApplicablePlanTypeIds.Add(1150);
            //    ApplicablePlanTypeIds.Add(240);
            //    ApplicablePlanTypeIds.Add(1230);
            //    ApplicablePlanTypeIds.Add(270);
            //    ApplicablePlanTypeIds.Add(260);
            //    ApplicablePlanTypeIds.Add(280);
            //    ApplicablePlanTypeIds.Add(290);
            //    ApplicablePlanTypeIds.Add(294);
            //    ApplicablePlanTypeIds.Add(297);
            //    ApplicablePlanTypeIds.Add(295);
            //    ApplicablePlanTypeIds.Add(293);
            //    ApplicablePlanTypeIds.Add(1190);
            //    ApplicablePlanTypeIds.Add(292);
            //    ApplicablePlanTypeIds.Add(300);
            //    ApplicablePlanTypeIds.Add(1180);
            //    ApplicablePlanTypeIds.Add(5330);
            //    ApplicablePlanTypeIds.Add(310);
            //    ApplicablePlanTypeIds.Add(1400);
            //    ApplicablePlanTypeIds.Add(5060);
            //    ApplicablePlanTypeIds.Add(1160);
            //    ApplicablePlanTypeIds.Add(5500);
            //}
            if (ddlcontents.SelectedValue == "Ancillary_Analysis")
            {
                ApplicablePlanTypeIds.Add(180);
                ApplicablePlanTypeIds.Add(190);
                ApplicablePlanTypeIds.Add(200);
                ApplicablePlanTypeIds.Add(210);
                ApplicablePlanTypeIds.Add(230);
                ApplicablePlanTypeIds.Add(240);
                ApplicablePlanTypeIds.Add(250);
                ApplicablePlanTypeIds.Add(260);
                ApplicablePlanTypeIds.Add(270);
                ApplicablePlanTypeIds.Add(280);
                ApplicablePlanTypeIds.Add(290);
                ApplicablePlanTypeIds.Add(292);
                ApplicablePlanTypeIds.Add(293);
                ApplicablePlanTypeIds.Add(294);
                ApplicablePlanTypeIds.Add(295);
                ApplicablePlanTypeIds.Add(297);
                ApplicablePlanTypeIds.Add(300);
                ApplicablePlanTypeIds.Add(310);
                ApplicablePlanTypeIds.Add(1150);
                ApplicablePlanTypeIds.Add(1230);
                ApplicablePlanTypeIds.Add(5330);

            }


        }
        private void LoadPlans()
        {
            List<Plan> PlanList = new List<Plan>();
            DataTable dtblPlan = CreatePlanInfoTable();
            if (Convert.ToString(Session["Summary"]) == "RFPAnalysisReport")
            {
                LoadPlanTypeIds();
                List<Plan> TempPlan = new List<Plan>();
                Session["PlanList"] = TempPlan;
                SessionId = Session["SessionId"].ToString();
                if (ddlClient.SelectedIndex > 0)
                {
                    TempPlan = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId, "RFPReport");

                    foreach (Plan objPlan in TempPlan)
                    {
                        if (ApplicablePlanTypeIds.Contains(objPlan.ProductTypeId))
                        {
                            PlanList.Add(objPlan);
                            DataRow drNewRow = dtblPlan.NewRow();
                            drNewRow["Carrier"] = objPlan.CarrierName;
                            drNewRow["Name"] = objPlan.ProductName;
                            drNewRow["Effective"] = objPlan.EffectiveDate.ToString("MM/dd/yy");
                            drNewRow["Renewal"] = objPlan.RenewalDate.ToString("MM/dd/yy"); ;
                            drNewRow["PolicyNumber"] = objPlan.PolicyNumber;
                            drNewRow["ProductId"] = objPlan.ProductId;
                            drNewRow["ProductName"] = objPlan.ProductName;
                            drNewRow["ProductTypeId"] = objPlan.ProductTypeId;
                            drNewRow["PlanType"] = objPlan.ProductTypeDescription;
                            drNewRow["SummaryName"] = objPlan.SummaryName;
                            drNewRow["SummaryId"] = objPlan.SummaryID;
                            drNewRow["PlanNumber"] = objPlan.PolicyNumber;
                            dtblPlan.Rows.Add(drNewRow);
                        }
                    }
                }
            }
            Session["PlanList"] = PlanList;
            Session["PlanTable"] = dtblPlan;
        }
        private DataTable CreateLOCDataTable()
        {
            DataTable dtLOCData = new DataTable();
            dtLOCData.Columns.Add(new DataColumn("LOCName"));
            dtLOCData.Columns.Add(new DataColumn("SelectedPlan"));
            dtLOCData.Columns.Add(new DataColumn("CarrierName"));
            dtLOCData.Columns.Add(new DataColumn("ProductID"));
            dtLOCData.Columns.Add(new DataColumn("FundingType"));
            dtLOCData.Columns.Add(new DataColumn("Contribution"));
            dtLOCData.Columns.Add(new DataColumn("ApplicablePlanTypeIds"));
            dtLOCData.Columns.Add(new DataColumn("IsVoluntaryProduct"));

            DataRow drDental = dtLOCData.NewRow();
            drDental["LOCName"] = "Dental";
            drDental["SelectedPlan"] = "";
            drDental["ApplicablePlanTypeIds"] = "180,190,200,210";
            drDental["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drDental);

            DataRow drVision = dtLOCData.NewRow();
            drVision["LOCName"] = "Vision";
            drVision["SelectedPlan"] = "";
            drVision["ApplicablePlanTypeIds"] = "230";
            drVision["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drVision);

            DataRow drLifeADD = dtLOCData.NewRow();
            drLifeADD["LOCName"] = "Life / AD&D";
            drLifeADD["SelectedPlan"] = "";
            drLifeADD["ApplicablePlanTypeIds"] = "250,1150,240,1230,270";
            drLifeADD["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drLifeADD);

            DataRow drVoluntaryLifeADD = dtLOCData.NewRow();
            drVoluntaryLifeADD["LOCName"] = "Voluntary Life / AD&D";
            drVoluntaryLifeADD["SelectedPlan"] = "";
            drVoluntaryLifeADD["ApplicablePlanTypeIds"] = "260,280";
            drVoluntaryLifeADD["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drVoluntaryLifeADD);

            DataRow drShortTermDisability = dtLOCData.NewRow();
            drShortTermDisability["LOCName"] = "Short Term Disability";
            drShortTermDisability["SelectedPlan"] = "";
            drShortTermDisability["ApplicablePlanTypeIds"] = "290,294,297,295,293";
            drShortTermDisability["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drShortTermDisability);

            DataRow drVoluntarySTD = dtLOCData.NewRow();
            drVoluntarySTD["LOCName"] = "Voluntary STD";
            drVoluntarySTD["SelectedPlan"] = "";
            drVoluntarySTD["ApplicablePlanTypeIds"] = "290";
            drVoluntarySTD["IsVoluntaryProduct"] = true;
            dtLOCData.Rows.Add(drVoluntarySTD);

            DataRow drLongTermDisability = dtLOCData.NewRow();
            drLongTermDisability["LOCName"] = "Long Term Disability";
            drLongTermDisability["SelectedPlan"] = "";
            drLongTermDisability["ApplicablePlanTypeIds"] = "292,300";
            drLongTermDisability["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drLongTermDisability);

            DataRow drVoluntaryLTD = dtLOCData.NewRow();
            drVoluntaryLTD["LOCName"] = "Voluntary LTD";
            drVoluntaryLTD["SelectedPlan"] = "";
            drVoluntaryLTD["ApplicablePlanTypeIds"] = "300";
            drVoluntaryLTD["IsVoluntaryProduct"] = true;
            dtLOCData.Rows.Add(drVoluntaryLTD);

            DataRow drAbsenceManagement = dtLOCData.NewRow();
            drAbsenceManagement["LOCName"] = "Absence Management";
            drAbsenceManagement["SelectedPlan"] = "";
            drAbsenceManagement["ApplicablePlanTypeIds"] = "5330";
            drAbsenceManagement["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drAbsenceManagement);

            DataRow drEAPAdministration = dtLOCData.NewRow();
            drEAPAdministration["LOCName"] = "EAP Administration";
            drEAPAdministration["SelectedPlan"] = "";
            drEAPAdministration["ApplicablePlanTypeIds"] = "310";
            drEAPAdministration["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drEAPAdministration);

            DataRow drCancer = dtLOCData.NewRow();
            drCancer["LOCName"] = "Cancer";
            drCancer["SelectedPlan"] = "";
            drCancer["ApplicablePlanTypeIds"] = "1400";
            drCancer["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drCancer);

            DataRow drHospital = dtLOCData.NewRow();
            drHospital["LOCName"] = "Hospital";
            drHospital["SelectedPlan"] = "";
            drHospital["ApplicablePlanTypeIds"] = "5060";
            drHospital["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drHospital);

            DataRow drCriticalIllness = dtLOCData.NewRow();
            drCriticalIllness["LOCName"] = "Critical Illness";
            drCriticalIllness["SelectedPlan"] = "";
            drCriticalIllness["ApplicablePlanTypeIds"] = "1160";
            drCriticalIllness["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drCriticalIllness);

            DataRow drAccident = dtLOCData.NewRow();
            drAccident["LOCName"] = "Accident";
            drAccident["SelectedPlan"] = "";
            drAccident["ApplicablePlanTypeIds"] = "5500";
            drAccident["IsVoluntaryProduct"] = false;
            dtLOCData.Rows.Add(drAccident);

            return dtLOCData;
        }
        private DataTable CreateLOCDataTable_AnalysisTemplate()
        {
            DataTable dtLOCData = new DataTable();
            dtLOCData.Columns.Add(new DataColumn("LOCNo"));
            dtLOCData.Columns.Add(new DataColumn("LOCName"));
            dtLOCData.Columns.Add(new DataColumn("PlanType"));
            dtLOCData.Columns.Add(new DataColumn("AnalysisType"));
            dtLOCData.Columns.Add(new DataColumn("PlanName"));
            dtLOCData.Columns.Add(new DataColumn("ProductID"));
            dtLOCData.Columns.Add(new DataColumn("SelectedBenefitSummary"));
            dtLOCData.Columns.Add(new DataColumn("CarrierName"));
            dtLOCData.Columns.Add(new DataColumn("SummaryId"));
            dtLOCData.Columns.Add(new DataColumn("IsDual"));
            dtLOCData.Columns.Add(new DataColumn("SheetName"));
            dtLOCData.Columns.Add(new DataColumn("Eligibility"));
            dtLOCData.Columns.Add(new DataColumn("EligibilityId"));
            return dtLOCData;
        }
        private string GetFundingType(string FundingType)
        {
            switch (FundingType.ToUpper())
            {
                case "FI":
                    FundingType = "Fully Insured";
                    break;
                case "SF":
                    FundingType = "Self Funded";
                    break;
            }
            return FundingType;
        }
        private string GetContributionsPlanName(string PlanName)
        {
            switch (PlanName.ToUpper())
            {
                case "ER PAID":
                    PlanName = "100% ER Paid";
                    break;
                case "EE PAID":
                    PlanName = "100% EE Paid";
                    break;
            }
            return PlanName;
        }
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private bool IsValidDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }
        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryId", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
        #endregion
        #region Event Handlers
        protected void ddlUSI_State_SelectedIndexChanged(object sender, EventArgs e)
        {
            //USI State
            DataTable dtOfficeCity = new DataTable();
            if (ddlUSI_State.SelectedIndex > 0)
            {
                dtOfficeCity = bp.GetOfficeCityList(ddlUSI_State.SelectedValue);
                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            else
            {
                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            ddlUSI_City.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlUSI_City.SelectedIndex = 0;
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            if (Session["Summary"].ToString() == "RFPAnalysisReport")
            {
                SessionId = Session["SessionId"].ToString();

                if (ddlcontents.SelectedValue == "Ancillary_Analysis")
                {
                    if (ddlUSI_State.SelectedIndex == 0 || ddlUSI_State.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select USI State.')</script>");
                        ddlUSI_State.Focus();
                        return;
                    }
                    if (ddlUSI_City.SelectedIndex == 0 || ddlUSI_City.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select USI City.')</script>");
                        ddlUSI_City.Focus();
                        return;
                    }
                    if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        return;
                    }
                    if (txtAncillaryAnalysisRenewalDate.Text.Trim() == string.Empty)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Renewal Date.')</script>", false);
                        txtAncillaryAnalysisRenewalDate.Focus();
                        return;
                    }

                    if (!IsValidDate(txtAncillaryAnalysisRenewalDate.Text.Trim()))
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Renewal Date. Date format should be MM/DD/YYYY')</script>", false);
                        txtAncillaryAnalysisRenewalDate.Focus();
                        return;
                    }
                    SummaryDetail sd = new SummaryDetail();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();

                    sd.BuildAccountTable();
                    sd.BuildEmployeeTypesTable();

                    // AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                    AccountDS = sd.GetAccountDetail_AccountProfileSummeryDetails(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    // Get the Account Office and Account Region for the selected client

                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    if (ddlOrientation.SelectedValue == "Landscape")
                        CreateAnalysisTemplate_Landscape(SessionId, AccountTeamMemberDS, AccountDS, Account_Office);
                    else if (ddlOrientation.SelectedValue == "Portrait")
                        CreateAnalysisTemplate_Portrait(SessionId, AccountTeamMemberDS, AccountDS, Account_Office);

                    #region Added by vinod : storing the activity logs
        
                    
                    List<Contact> ContactList = new List<Contact>();
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DictDepartment = sd.getDepartmentDetails();
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                }
                else if (ddlcontents.SelectedValue == "Ancillary_Unpopulated")
                {
                    DownLoad_AncillaryUnpopulatedTemplate();
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, string.Empty, Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, Convert.ToString(ddlcontents.SelectedItem.Text), string.Empty, string.Empty, string.Empty);
                }

            }
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToString(Session["Summary"]) == "RFPAnalysisReport")
            {
                Session["PlanList"] = new List<Plan>();
                Session["ProductDS"] = null;
                Handle_ClientChange();
            }
        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            List<Plan> PlanList = new List<Plan>();
            LoadPlans();
            DataTable dtbl = CreateLOCDataTable();
        }
        protected void ddlcontents_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetForm();
            string OrientationOption = "";
            if (dictOrientationOption.ContainsKey(ddlcontents.SelectedValue))
            {
                OrientationOption = dictOrientationOption[ddlcontents.SelectedValue].ToLower();
            }
            switch (OrientationOption)
            {
                case "portrait":
                    ddlOrientation.SelectedValue = "Portrait";
                    ddlOrientation.Enabled = false;
                    break;
                case "landscape":
                    ddlOrientation.SelectedValue = "Landscape";
                    ddlOrientation.Enabled = false;
                    break;
                case "all":
                    ddlOrientation.SelectedValue = "0";
                    ddlOrientation.Enabled = true;
                    break;
                default:
                    ddlOrientation.SelectedValue = "0";
                    ddlOrientation.Enabled = true;
                    break;
            }

            switch (ddlcontents.SelectedValue)
            {
                case "Ancillary_Analysis":
                    txtLetterDecription.Text = "For existing USI clients. Provides line of coverage benefit & rate illustrations populated with client data for dental, vision, life, disability, EAP, & absence mgmt. Current and renewal benefits are populated with data as stated in BenefitPoint. Not all benefits will populate; empty cells are benefits not housed in BenefitPoint or not entered for that client. Rates, enrollment, and some benefits must be manually entered. Templates are fully editable in excel.";
                    tblAnalysisPlans.Style.Add("display", "");
                    spnClientDescription.InnerText = "Indicate which BenefitPoint client you would like to create an Analysis for.";
                    tblClientDetails.Style.Add("display", "");
                    tblAnalysisPlans.Style.Add("display", "");
                    StateCityTable.Style.Add("display", "");
                    txtLetterDecription.Visible = true;
                    break;
                case "Ancillary_Unpopulated":
                    txtLetterDecription.Text = "For clients not yet in BenefitPoint. Provides line of coverage benefit & rate illustrations for dental, vision, life, disability, EAP, & absence mgmt. All entries for benefits, rates, and enrollment must be manually entered. Templates are fully editable in excel.";
                    spnClientDescription.InnerText = "";
                    tblClientDetails.Style.Add("display", "none");
                    tblAnalysisPlans.Style.Add("display", "none");
                    txtLetterDecription.Visible = true;
                    StateCityTable.Style.Add("display", "none");
                    break;
                default:
                    tblClientDetails.Style.Add("display", "none");
                    tblAnalysisPlans.Style.Add("display", "none");
                    StateCityTable.Style.Add("display", "none");
                    txtLetterDecription.Visible = false;
                    break;

            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ddlcontents.SelectedValue = "0";
            ResetForm();
        }
        protected void rdlAncillaryAnalysisPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvAncillaryAnalysisPlans.DataSource = null;
            gvAncillaryAnalysisPlans.DataBind();
            if (ddlClient.SelectedIndex > 0)
            {
                AnalysisTemplate_BindPlanGrid();
            }
        }
        #endregion


        private void DownLoad_AncillaryUnpopulatedTemplate()
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                 string myPath = "";
                 if (ddlOrientation.SelectedValue == "Portrait")
                     myPath = Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryPortUnpopulated_v1.xlsx");
                 else if (ddlOrientation.SelectedValue == "Landscape")
                     myPath = Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryLandUnpopulated_v1.xlsx");

              
                string savefilename = Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisUnpopulated/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisUnpopulated/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisUnpopulated/"));
                }
                File.Copy(myPath, savefilename, true);
                DownloadFileNew_ExcelFormat(savefilename.ToString());
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
            }

        }
        private void AnalysisTemplate_BindPlanGrid()
        {
            DataTable dtblLOC = CreateLOCDataTable_AnalysisTemplate();
            LoadPlans();
            for (int i = 1; i <= 10; i++)
            {
                DataRow dr = dtblLOC.NewRow();
                dtblLOC.Rows.Add();
            }

            gvAncillaryAnalysisPlans.DataSource = dtblLOC;
            gvAncillaryAnalysisPlans.DataBind();

        }
        protected void gvAncillaryAnalysisPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            DropDownList ddlLineOfCoverage = e.Row.FindControl("ddlLineOfCoverage") as DropDownList;
            if (ddlLineOfCoverage != null)
            {
                ddlLineOfCoverage.DataSource = lstAnalysisLOCOptions;
                ddlLineOfCoverage.DataBind();
                ddlLineOfCoverage.Items.Insert(0, new ListItem("Select", "Select"));
                ddlLineOfCoverage.SelectedIndex = 0;

                DropDownList ddlAnalysisType = e.Row.FindControl("ddlAnalysisType") as DropDownList;
                DropDownList ddlPlan = e.Row.FindControl("ddlPlan") as DropDownList;
                DropDownList ddlBenefitSummary = e.Row.FindControl("ddlBenefitSummary") as DropDownList;
                DropDownList ddlEligibility = e.Row.FindControl("ddlEligibility") as DropDownList;

                ddlAnalysisType.Items.Insert(0, new ListItem("Select", "Select"));
                ddlAnalysisType.SelectedIndex = 0;
                ddlPlan.Items.Insert(0, new ListItem("Select", "Select"));
                ddlPlan.SelectedIndex = 0;
                ddlBenefitSummary.Items.Insert(0, new ListItem("Select", "Select"));
                ddlBenefitSummary.SelectedIndex = 0;

                ddlEligibility.Items.Insert(0, new ListItem("Select", "Select"));
                ddlEligibility.SelectedIndex = 0;

                if (e.Row.RowIndex > 0)
                {
                    ddlAnalysisType.Enabled = false;
                    ddlPlan.Enabled = false;
                    ddlBenefitSummary.Enabled = false;
                    ddlEligibility.Enabled = false;

                }
            }

        }
        protected void gvAncillaryAnalysisPlans_LOCChanged(object sender, EventArgs e)
        {
            DropDownList ddlSender = sender as DropDownList;
            bool EnableDropDowns = true;
            bool CheckPlansExists = false;
            if (ddlSender != null)
            {
                string ddlSenderClientID = ddlSender.ClientID;
                string[] IdParts = ddlSenderClientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);

                DropDownList ddlAnalysisType = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlAnalysisType") as DropDownList;
                DropDownList ddlPlan = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlan") as DropDownList;
                DropDownList ddlBenefitSummary = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary") as DropDownList;
                DropDownList ddlEligibility = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlEligibility") as DropDownList;

                DropDownList ddlPlanDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlanDual") as DropDownList;
                DropDownList ddlBenefitSummaryDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryDual") as DropDownList;
                DropDownList ddlEligibilityDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlEligibilityDual") as DropDownList;

                HiddenField hdnBenefitSummaryApplicable = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummaryApplicable") as HiddenField;
                HiddenField hdnEligibilityApplicable = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnEligibilityApplicable") as HiddenField;

                hdnBenefitSummaryApplicable.Value = "true";
                hdnEligibilityApplicable.Value = "true";

                ddlAnalysisType.Items.Clear();
                ddlPlan.Items.Clear();
                ddlBenefitSummary.Items.Clear();

                ddlPlanDual.Items.Clear();
                ddlBenefitSummaryDual.Items.Clear();

                ddlEligibility.Items.Clear();
                ddlEligibilityDual.Items.Clear();

                switch (ddlSender.SelectedValue)
                {
                    case "Dental":
                        ddlAnalysisType.DataSource = lstDentalAnalysisType;
                        ddlAnalysisType.DataBind();
                        hdnEligibilityApplicable.Value = "false";
                        break;
                    case "Vision":
                        CheckPlansExists = true;
                        ddlAnalysisType.DataSource = lstVisionAnalysisType;
                        ddlAnalysisType.DataBind();
                        hdnEligibilityApplicable.Value = "false";
                        break;
                    case "Life and AD&D":
                        ddlAnalysisType.DataSource = lstLifeADDAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "Short Term Disability":
                        ddlAnalysisType.DataSource = lstShortTermDisablityAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "Long Term Disability":
                        ddlAnalysisType.DataSource = lstLongTermDisablityAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "Absence Management":
                        hdnBenefitSummaryApplicable.Value = "false";
                        hdnEligibilityApplicable.Value = "false";
                        CheckPlansExists = true;
                        ddlAnalysisType.DataSource = lstAbsenseAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "EAP":
                        CheckPlansExists = true;
                        hdnEligibilityApplicable.Value = "false";
                        ddlAnalysisType.DataSource = lstEAPAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "Voluntary L/AD&D":
                        CheckPlansExists = true;
                        ddlAnalysisType.DataSource = lstVolLADDAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "Voluntary STD":
                        CheckPlansExists = true;
                        ddlAnalysisType.DataSource = lstVolSTDAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "Voluntary LTD":
                        CheckPlansExists = true;
                        ddlAnalysisType.DataSource = lstVolLTDAnalysisType;
                        ddlAnalysisType.DataBind();
                        break;
                    case "STD Statutory":
                        CheckPlansExists = true;
                        ddlAnalysisType.DataSource = lstSTDStatutoryAnalysisType;
                        ddlAnalysisType.DataBind();
                        hdnEligibilityApplicable.Value = "false";
                        break;
                    default:
                        EnableDropDowns = false;
                        break;

                }
                if (RowIndex == 0)
                    EnableDropDowns = true;

                ddlAnalysisType.Items.Insert(0, new ListItem("Select", "Select"));
                ddlAnalysisType.SelectedIndex = 0;

                if (ddlAnalysisType.Items.Count == 2)
                    ddlAnalysisType.SelectedIndex = 1;

                gvAncillaryAnalysisPlans_AnalysisTypeChanged(ddlAnalysisType, null);

                if (CheckPlansExists || ddlAnalysisType.Items.Count == 2)
                {
                    List<Plan> lstPlans = GetAnalysisTypePlans(ddlAnalysisType.Items[1].Text);
                    if (lstPlans.Count == 0)
                    {
                        ddlPlan.Items[0].Text = "No Plans Available";
                        ddlPlanDual.Items[0].Text = "No Plans Available";
                        ddlBenefitSummary.Items[0].Text = "No Summaries Available";
                        ddlBenefitSummaryDual.Items[0].Text = "No Summaries Available";
                    }
                }

                if (hdnBenefitSummaryApplicable.Value.ToLower() == "false")
                {
                    ddlBenefitSummary.Items[0].Text = "Not Applicable";
                    ddlBenefitSummaryDual.Items[0].Text = "Not Applicable";
                }

                ddlAnalysisType.Enabled = EnableDropDowns;
                ddlPlan.Enabled = EnableDropDowns;
                ddlBenefitSummary.Enabled = EnableDropDowns;
                ddlEligibility.Enabled = EnableDropDowns;

                ddlPlanDual.Enabled = EnableDropDowns;
                ddlBenefitSummaryDual.Enabled = EnableDropDowns;
                ddlEligibilityDual.Enabled = EnableDropDowns;

                if (hdnEligibilityApplicable.Value.ToLower() == "false")
                {
                    ddlEligibility.Items[0].Text = "Not Applicable";
                    ddlEligibilityDual.Items[0].Text = "Not Applicable";
                    ddlEligibility.Enabled = false;
                    ddlEligibilityDual.Enabled = false;
                }
            }
        }
        protected void gvAncillaryAnalysisPlans_AnalysisTypeChanged(object sender, EventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            WriteAncillaryIntakeFormRFP wr = new WriteAncillaryIntakeFormRFP();
            DropDownList ddlSender = sender as DropDownList;
            bool IsDual = CheckPlanIsDual(ddlSender.SelectedValue);
            bool IsClassType = CheckPlanIsClass(ddlSender.SelectedValue);
            if (ddlSender != null)
            {
                string ddlSenderClientID = ddlSender.ClientID;
                string[] IdParts = ddlSenderClientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
                List<int> planTypeIds = new List<int>();
                List<int> VolentaryFlagCheckPlanTypes = new List<int>();

                List<Plan> FinalList = new List<Plan>();
                FinalList = GetAnalysisTypePlans(ddlSender.SelectedValue);
                DropDownList ddlLineOfCoverage = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlLineOfCoverage") as DropDownList;
                DropDownList ddlPlan = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlan") as DropDownList;
                DropDownList ddlPlanDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlanDual") as DropDownList;
                DropDownList ddlBenefitSummary = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary") as DropDownList;
                DropDownList ddlBenefitSummaryDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryDual") as DropDownList;
                HiddenField hdnIsDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnIsDual") as HiddenField;
                HiddenField hdnBenefitSummaryApplicable = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummaryApplicable") as HiddenField;
                DropDownList ddlEligibility = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlEligibility") as DropDownList;
                DropDownList ddlEligibilityDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlEligibilityDual") as DropDownList;
                HiddenField hdnIsClassTemplate = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnIsClassTemplate") as HiddenField;
                DropDownList ddlBenefitSummaryClass2 = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryClass2") as DropDownList;
                DropDownList ddlBenefitSummaryClass3 = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryClass3") as DropDownList;

                if (ddlLineOfCoverage.SelectedItem.Text == "Absence Management")
                {
                    hdnBenefitSummaryApplicable.Value = "false";
                }
                else
                {
                    hdnBenefitSummaryApplicable.Value = "true";
                }
                hdnIsDual.Value = IsDual.ToString();
                hdnIsClassTemplate.Value = IsClassType.ToString();
                if (ddlPlan != null)
                {
                    ddlPlan.Items.Clear();
                    ddlPlan.DataSource = FinalList;
                    ddlPlan.DataBind();

                    ddlPlanDual.Items.Clear();
                    ddlPlanDual.DataSource = FinalList;
                    ddlPlanDual.DataBind();

                    ddlBenefitSummary.Items.Clear();
                    ddlBenefitSummaryDual.Items.Clear();

                    ddlBenefitSummaryClass2.Items.Clear();
                    ddlBenefitSummaryClass3.Items.Clear();


                    ddlEligibility.Items.Clear();
                    ddlEligibilityDual.Items.Clear();

                    ddlPlan.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlPlanDual.Items.Insert(0, new ListItem("Select", "Select"));

                    ddlBenefitSummary.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlBenefitSummaryDual.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlBenefitSummaryClass2.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlBenefitSummaryClass3.Items.Insert(0, new ListItem("Select", "Select"));

                    ddlEligibility.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlEligibilityDual.Items.Insert(0, new ListItem("Select", "Select"));

                    if (FinalList.Count == 0 && ddlSender.SelectedValue != "Select")
                    {
                        ddlPlan.Items[0].Text = "No Plans Available";
                        ddlPlanDual.Items[0].Text = "No Plans Available";
                    }
                    else if (FinalList.Count == 1)
                    {
                        ddlPlan.SelectedValue = FinalList.First().ProductId.ToString();
                        ddlPlanDual.SelectedValue = FinalList.First().ProductId.ToString();
                    }
                    else
                    {
                        ddlPlan.SelectedValue = "Select";
                        ddlPlanDual.SelectedValue = "Select";
                    }

                    if (IsClassType)
                    {
                        ddlBenefitSummaryClass2.Visible = true;
                        ddlBenefitSummaryClass3.Visible = true;
                    }
                    else
                    {
                        ddlBenefitSummaryClass2.Visible = false;
                        ddlBenefitSummaryClass3.Visible = false;
                    }
                    gvAncillaryAnalysisPlans_PlanChanged(ddlPlan, null);
                    gvAncillaryAnalysisPlans_DualPlanChanged(ddlPlanDual, null);
                    if (IsDual)
                    {
                        ddlPlanDual.Visible = true;
                        ddlBenefitSummaryDual.Visible = true;
                    }
                    else
                    {
                        ddlPlanDual.Visible = false;
                        ddlBenefitSummaryDual.Visible = false;
                    }
                   
                }

            }
        }
        protected void gvAncillaryAnalysisPlans_PlanChanged(object sender, EventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            BPBusiness bp = new BPBusiness();
            List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            DropDownList ddlSender = sender as DropDownList;
            if (ddlSender != null)
            {
                string ddlSenderClientID = ddlSender.ClientID;
                string[] IdParts = ddlSenderClientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
                DropDownList ddlBenefitSummary = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary") as DropDownList;
                HiddenField hdnBenefitSummaryApplicable = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummaryApplicable") as HiddenField;
                HiddenField hdnEligibilityApplicable = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnEligibilityApplicable") as HiddenField;
                DropDownList ddlEligibility = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlEligibility") as DropDownList;
                DropDownList ddlBenefitSummaryClass2 = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryClass2") as DropDownList;
                DropDownList ddlBenefitSummaryClass3 = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryClass3") as DropDownList;
                List<Eligibility> EligibilityList = new List<Eligibility>();
                HiddenField hdnIsClassTemplate = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnIsClassTemplate") as HiddenField;

                if (ddlBenefitSummary != null)
                {
                    ddlBenefitSummary.Items.Clear();
                    ddlBenefitSummaryClass2.Items.Clear();
                    ddlBenefitSummaryClass3.Items.Clear();
                    ddlEligibility.Items.Clear();
                    List<Plan> lstTempPlans = Session["PlanList"] as List<Plan>;
                    int PlanId = 0;
                    int.TryParse(ddlSender.SelectedValue, out PlanId);
                    Plan SelectedPlan = lstTempPlans.Where(r => r.ProductId == PlanId).FirstOrDefault();
                    if (SelectedPlan != null && hdnBenefitSummaryApplicable.Value.ToLower() == "true")
                    {
                        BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), SelectedPlan.ProductId, SessionId);
                        if (BenefitSummaryList != null && BenefitSummaryList.Count > 0)
                        {
                            BenefitSummaryList = BenefitSummaryList.OrderBy(objSort => objSort.BenefitDescription).ToList();
                            ddlBenefitSummary.DataSource = BenefitSummaryList;
                            ddlBenefitSummary.DataBind();
                            ddlBenefitSummaryClass2.DataSource = BenefitSummaryList;
                            ddlBenefitSummaryClass2.DataBind();
                            ddlBenefitSummaryClass3.DataSource = BenefitSummaryList;
                            ddlBenefitSummaryClass3.DataBind();
                            if (BenefitSummaryList.Count == 1)
                            {
                                ddlBenefitSummary.SelectedValue = BenefitSummaryList.First().BenefitsummmaryId.ToString();
                                gvAncillaryAnalysisPlans_BenefitSummaryChanged(ddlBenefitSummary, null);
                                ddlBenefitSummaryClass2.Visible = false;
                                ddlBenefitSummaryClass3.Visible = false;
                            }
                            else
                            {
                                if (hdnIsClassTemplate.Value.ToLower().Equals("true"))
                                {
                                    if (BenefitSummaryList.Count == 2)
                                    {
                                        ddlBenefitSummaryClass2.Visible = true;
                                        ddlBenefitSummaryClass3.Visible = false;
                                        ddlBenefitSummary.SelectedValue = BenefitSummaryList.First().BenefitsummmaryId.ToString();
                                        ddlBenefitSummaryClass2.SelectedValue = BenefitSummaryList.Skip(1).First().BenefitsummmaryId.ToString();
                                    }
                                    else
                                    {
                                        ddlBenefitSummaryClass2.Visible = true;
                                        ddlBenefitSummaryClass3.Visible = true;
                                        ddlBenefitSummary.SelectedValue = BenefitSummaryList.First().BenefitsummmaryId.ToString();
                                        ddlBenefitSummaryClass2.SelectedValue = BenefitSummaryList.Skip(1).First().BenefitsummmaryId.ToString();
                                        ddlBenefitSummaryClass3.SelectedValue = BenefitSummaryList.Skip(2).First().BenefitsummmaryId.ToString();
                                    }
                                }
                            }
                        }
                        else
                        {
                            ddlBenefitSummaryClass2.Visible = false;
                            ddlBenefitSummaryClass3.Visible = false;
                        }
                        if (hdnEligibilityApplicable.Value.ToLower() == "true")
                        {
                            EligibilityList = bp.FindEligibility(PlanId, SessionId);
                            ddlEligibility.DataSource = EligibilityList;
                            ddlEligibility.DataBind();
                            if (EligibilityList.Count == 1)
                            {
                                ddlEligibility.SelectedValue = EligibilityList.First().EligibilityId.ToString();
                            }
                        }
                    }
                 
                    ddlBenefitSummary.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlBenefitSummaryClass2.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlBenefitSummaryClass3.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlEligibility.Items.Insert(0, new ListItem("Select", "Select"));

                    if (ddlSender.SelectedItem.Text == "No Plans Available")
                    {
                        ddlBenefitSummary.Items[0].Text = "No Summaries Available";
                        ddlEligibility.Items[0].Text = "No Eligibility Available";
                        ddlBenefitSummaryClass2.Visible = false;
                        ddlBenefitSummaryClass3.Visible = false;
                    }

                    if (hdnEligibilityApplicable.Value.ToLower() == "true" && EligibilityList.Count == 0 && ddlSender.SelectedItem.Text != "Select")
                    {
                        ddlEligibility.Items[0].Text = "No Eligibility Available";
                    }

                    if (hdnBenefitSummaryApplicable.Value.ToLower() == "false")
                        ddlBenefitSummary.Items[0].Text = "Not Applicable";

                    if (hdnEligibilityApplicable.Value.ToLower() == "false")
                        ddlEligibility.Items[0].Text = "Not Applicable";
                }
            }
        }
        protected void gvAncillaryAnalysisPlans_DualPlanChanged(object sender, EventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            BPBusiness bp = new BPBusiness();
            List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            DropDownList ddlSender = sender as DropDownList;
            if (ddlSender != null)
            {
                List<Eligibility> EligibilityList = new List<Eligibility>();
                string ddlSenderClientID = ddlSender.ClientID;
                string[] IdParts = ddlSenderClientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
                DropDownList ddlBenefitSummaryDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryDual") as DropDownList;
                HiddenField hdnBenefitSummaryApplicable = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnBenefitSummaryApplicable") as HiddenField;
                HiddenField hdnEligibilityApplicable = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnEligibilityApplicable") as HiddenField;
                DropDownList ddlEligibilityDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlEligibilityDual") as DropDownList;
                if (ddlBenefitSummaryDual != null)
                {
                    ddlBenefitSummaryDual.Items.Clear();
                    ddlEligibilityDual.Items.Clear();
                    List<Plan> lstTempPlans = Session["PlanList"] as List<Plan>;
                    int PlanId = 0;
                    int.TryParse(ddlSender.SelectedValue, out PlanId);
                    Plan SelectedPlan = lstTempPlans.Where(r => r.ProductId == PlanId).FirstOrDefault();
                    if (SelectedPlan != null && hdnBenefitSummaryApplicable.Value.ToLower() == "true")
                    {
                        BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), SelectedPlan.ProductId, SessionId);
                        if (BenefitSummaryList != null || BenefitSummaryList.Count > 0)
                        {
                            BenefitSummaryList = BenefitSummaryList.OrderBy(objSort => objSort.BenefitDescription).ToList();
                            ddlBenefitSummaryDual.DataSource = BenefitSummaryList;
                            ddlBenefitSummaryDual.DataBind();
                            if (BenefitSummaryList.Count == 1)
                            {
                                ddlBenefitSummaryDual.SelectedValue = BenefitSummaryList.First().BenefitsummmaryId.ToString();
                                gvAncillaryAnalysisPlans_BenefitSummaryChanged(ddlBenefitSummaryDual, null);
                            }
                        }
                        if (hdnEligibilityApplicable.Value.ToLower() == "true")
                        {
                            EligibilityList = bp.FindEligibility(PlanId, SessionId);
                            ddlEligibilityDual.DataSource = EligibilityList;
                            ddlEligibilityDual.DataBind();
                            if (EligibilityList.Count == 1)
                            {
                                ddlEligibilityDual.SelectedValue = EligibilityList.First().EligibilityId.ToString();
                            }
                        }
                    }
                    DropDownList ddlLineOfCoverage = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlLineOfCoverage") as DropDownList;
                    ddlBenefitSummaryDual.Items.Insert(0, new ListItem("Select", "Select"));
                    ddlEligibilityDual.Items.Insert(0, new ListItem("Select", "Select"));

                    if (ddlSender.SelectedItem.Text == "No Plans Available")
                    {
                        ddlBenefitSummaryDual.Items[0].Text = "No Summaries Available";
                        ddlEligibilityDual.Items[0].Text = "No Eligibility Available";
                    }

                    if (hdnEligibilityApplicable.Value.ToLower() == "true" && EligibilityList.Count == 0 && ddlSender.SelectedItem.Text != "Select")
                    {
                        ddlEligibilityDual.Items[0].Text = "No Eligibility Available";
                    }

                    if (hdnBenefitSummaryApplicable.Value.ToLower() == "false")
                        ddlBenefitSummaryDual.Items[0].Text = "Not Applicable";

                    if (hdnEligibilityApplicable.Value.ToLower() == "false")
                        ddlEligibilityDual.Items[0].Text = "Not Applicable";
                }
            }
        }
        public bool IsDuplicateDualPlan(int RowIndex)
        {
            DropDownList ddlPlan = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlan") as DropDownList;
            DropDownList ddlBenefitSummary = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary") as DropDownList;

            DropDownList ddlPlanDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlanDual") as DropDownList;
            DropDownList ddlBenefitSummaryDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryDual") as DropDownList;

            if (ddlPlan.SelectedValue != "Select" && ddlBenefitSummary.SelectedValue != "Select" && ddlPlanDual.SelectedValue != "Select" && ddlBenefitSummaryDual.SelectedValue != "Select")
            {
                if (ddlPlan.SelectedValue == ddlPlanDual.SelectedValue && ddlBenefitSummary.SelectedValue == ddlBenefitSummaryDual.SelectedValue)
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsDuplicateClassBenefitSummary(int RowIndex)
        {
            bool IsDuplicate = false;

            DropDownList ddlPlan = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlan") as DropDownList;
            DropDownList ddlBenefitSummary = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummary") as DropDownList;
            DropDownList ddlBenefitSummaryClass2 = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryClass2") as DropDownList;
            DropDownList ddlBenefitSummaryClass3 = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryClass3") as DropDownList;

            DropDownList ddlPlanDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlPlanDual") as DropDownList;
            DropDownList ddlBenefitSummaryDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("ddlBenefitSummaryDual") as DropDownList;

            if (ddlPlan.SelectedIndex == 0 && ddlPlan.SelectedItem.Text == "No Plans Available")
                return false;

            if (ddlBenefitSummary.SelectedIndex == 0 && ddlBenefitSummary.SelectedItem.Text == "No Summaries Available")
                return false;
            
            if (ddlBenefitSummary.Items.Count == 2)
                return false;

            if (ddlBenefitSummary.Items.Count > 2)
            {
                if (ddlBenefitSummary.Items.Count == 3)
                {
                    if (ddlBenefitSummary.SelectedIndex != 0 && ddlBenefitSummaryClass2.SelectedIndex != 0 && ddlBenefitSummary.SelectedValue == ddlBenefitSummaryClass2.SelectedValue)
                    {
                        IsDuplicate = true;
                    }
                }
                else
                {
                    // 1,0,0
                    if (ddlBenefitSummaryClass2.SelectedIndex == 0 && ddlBenefitSummaryClass3.SelectedIndex == 0)
                        return false;
                    //1,1,0
                    if (ddlBenefitSummaryClass2.SelectedIndex != 0 && ddlBenefitSummary.SelectedValue == ddlBenefitSummaryClass2.SelectedValue) // Class 2 with Class1 compare
                    {
                        IsDuplicate = true;
                    }
                    //1,0,1
                    if (ddlBenefitSummaryClass3.SelectedIndex != 0 && ddlBenefitSummary.SelectedValue == ddlBenefitSummaryClass3.SelectedValue) // Class3 with Class1 compare
                    {
                        IsDuplicate = true;
                    }
                    //1,1,1
                    if (ddlBenefitSummaryClass2.SelectedIndex != 0 && ddlBenefitSummaryClass3.SelectedIndex != 0  && ddlBenefitSummaryClass3.SelectedValue == ddlBenefitSummaryClass2.SelectedValue)  //Class 3 with Class2 
                    {
                        IsDuplicate = true;
                    }
                }
            }

            return IsDuplicate;
        }
        private void ResetForm()
        {
            #region common
            spnClientDescription.InnerText = "";
            ddlOrientation.SelectedValue = "0";
            ddlOrientation.Enabled = true;
            txtLetterDecription.Text = "";
            txtLetterDecription.Visible = false;
            Session["PlanList"] = new List<Plan>();
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            rdlClient.SelectedIndex = 0;
            ddlClient_SelectedIndexChanged(null, null);
            ddlUSI_State.SelectedIndex = 0;
            ddlUSI_State_SelectedIndexChanged(null, null);
            #endregion
            #region Ancillary Intake Report
            tblAnalysisPlans.Style.Add("display", "none");
            txtAncillaryAnalysisRenewalDate.Text = "";
            rdlAncillaryAnalysisPlanStatus.SelectedIndex = 0;
            gvAncillaryAnalysisPlans.DataSource = null;
            gvAncillaryAnalysisPlans.DataBind();
            ddlAncillayAnalysisAdditionLOC.SelectedValue = "0";
            #endregion
        }
        protected void gvAncillaryAnalysisPlans_BenefitSummaryChanged(object sender, EventArgs e)
        {
            DropDownList ddlSender = sender as DropDownList;
            if (ddlSender != null)
            {
                string ddlSenderClientID = ddlSender.ClientID;
                string[] IdParts = ddlSenderClientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
                HiddenField hdnIsDual = gvAncillaryAnalysisPlans.Rows[RowIndex].FindControl("hdnIsDual") as HiddenField;
                if (hdnIsDual.Value.ToLower() == "true")
                {

                }
            }
        }
        protected void CopySheet(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string Source_SheetNames, string Destination_SheetName)
        {
            for (int i = 1; i <= myWorkbook.Worksheets.Count; i++)
            {
                Excel.Worksheet wkSheetToCheck = (Excel.Worksheet)myWorkbook.Worksheets[i];
                if (wkSheetToCheck.Name != null)
                {
                    if (wkSheetToCheck.Name.ToLower() == Source_SheetNames.ToLower())
                    {
                        (myWorkbook.Worksheets[wkSheetToCheck.Name] as Excel.Worksheet).Copy(After: myWorkbook.Worksheets[wkSheetToCheck.Name]);
                        (myWorkbook.Worksheets[i + 1] as Excel.Worksheet).Name = Destination_SheetName;
                        break;
                    }
                }
            }
        }
        public bool IsDuplicateLOCSelected(DataTable dtblSelectedPlans)
        {
            bool IsDuplicate = false;
            if (dtblSelectedPlans != null && dtblSelectedPlans.Rows.Count > 0)
            {
                for (int i = 0; i < dtblSelectedPlans.Rows.Count; i++)
                {
                    if (dtblSelectedPlans.Rows[i]["LOCName"].ToString() != "Select" && dtblSelectedPlans.Rows[i]["AnalysisType"].ToString() != "Select" && dtblSelectedPlans.Rows[i]["ProductID"].ToString() != "0")
                    {
                        for (int j = i + 1; j < dtblSelectedPlans.Rows.Count; j++)
                        {
                            if (dtblSelectedPlans.Rows[j] != null)
                            {
                                if (dtblSelectedPlans.Rows[i]["LOCName"].ToString() == dtblSelectedPlans.Rows[j]["LOCName"].ToString()
                               && dtblSelectedPlans.Rows[i]["AnalysisType"].ToString() == dtblSelectedPlans.Rows[j]["AnalysisType"].ToString()
                               && dtblSelectedPlans.Rows[i]["ProductID"].ToString() == dtblSelectedPlans.Rows[j]["ProductID"].ToString()
                               && dtblSelectedPlans.Rows[i]["SummaryId"].ToString() == dtblSelectedPlans.Rows[j]["SummaryId"].ToString())
                                {
                                    IsDuplicate = true;
                                    break;
                                }
                            }
                        }

                    }
                    if (IsDuplicate == true)
                        break;
                }
            }
            return IsDuplicate;
        }
        private List<Plan> GetAnalysisTypePlans(string AnalyisisType)
        {
            WriteAncillaryIntakeFormRFP wr = new WriteAncillaryIntakeFormRFP();
            List<int> planTypeIds = new List<int>();
            List<int> Include_VolentaryFlag_YES = new List<int>();
            List<int> Include_VolentaryFlag_NO = new List<int>();
            switch (AnalyisisType)
            {
                case "Dental":
                    planTypeIds = AnalysisType_Dental;
                    break;
                case "Dental Dual":
                    planTypeIds = AnalysisType_DentalDual;
                    break;
                case "Dental DHMO":
                    planTypeIds = AnalysisType_DentalDHMO;
                    break;
                case "Dental ASO":
                    planTypeIds = AnalysisType_DentalASO;
                    break;
                case "Dental ASO Dual":
                    planTypeIds = AnalysisType_DentalASODual;
                    break;
                case "Vision":
                    planTypeIds = AnalysisType_Vision;
                    break;
                case "Vision Dual":
                    planTypeIds = AnalysisType_VisionDual;
                    break;
                case "Vision ASO":
                    planTypeIds = AnalysisType_VisionASO;
                    break;
                case "Vision ASO Dual":
                    planTypeIds = AnalysisType_VisionASODual;
                    break;
                case "LADD":
                    planTypeIds = AnalysisType_LADD;
                    Include_VolentaryFlag_NO = new List<int>() { 250, 1150, 240, 1230, 270 }; // ONLY INCLUDE PRODUCT HAVING VOL FLAG NO
                    break;
                case "LADD Classes":
                    planTypeIds = AnalysisType_LADDClasses;
                    Include_VolentaryFlag_NO = new List<int>() { 250, 1150, 240, 1230, 270 };// ONLY INCLUDE PRODUCT HAVING VOL FLAG NO
                    break;
                case "STD Single":
                    planTypeIds = AnalysisType_STDSingle;
                    Include_VolentaryFlag_NO = new List<int>() { 290 };
                    break;
                case "STD Classes":
                    planTypeIds = AnalysisType_STDClasses;
                    Include_VolentaryFlag_NO = new List<int>() { 290 };
                    break;
                case "LTD Single":
                    planTypeIds = AnalysisType_LTDSingle;
                    Include_VolentaryFlag_NO = new List<int>() { 300 };
                    break;
                case "LTD Classes":
                    planTypeIds = AnalysisType_LTDClasses;
                    Include_VolentaryFlag_NO = new List<int>() { 300 };
                    break;
                case "Absence Management":
                    planTypeIds = AnalysisType_AbsenceManagement;
                    break;
                case "EAP":
                    planTypeIds = AnalysisType_EAP;
                    break;
                case "LADD Vol":
                    planTypeIds = AnalysisType_VolLADD_VOL;
                    Include_VolentaryFlag_YES = new List<int>() { 240, 270 };// ONLY INCLUDE PRODUCT HAVING VOL FLAG YES
                    break;
                case "STD Vol":
                    planTypeIds = AnalysisType_STDVol;
                    Include_VolentaryFlag_YES = new List<int>() { 290 };// ONLY INCLUDE PRODUCT HAVING VOL FLAG YES
                    break;
                case "LTD Vol":
                    planTypeIds = AnalysisType_LTDVol;
                    Include_VolentaryFlag_YES = new List<int>() { 300 };
                    break;
                case "STD Statutory":
                    planTypeIds = AnalysisType_STDStatutory;
                    break;
            }

            List<Plan> lstTempPlans = Session["PlanList"] as List<Plan>;
            //  Filter only required plans
            List<Plan> lstPlans = (from p in lstTempPlans
                                   where planTypeIds.Contains(p.ProductTypeId)
                                   select p).ToList<Plan>();

            List<Plan> FinalList = new List<Plan>();
            // IF required to filter only Voluntary plans from available plan types plans 
            if (Include_VolentaryFlag_YES.Count > 0 || Include_VolentaryFlag_NO.Count > 0)
            {
                foreach (Plan item in lstPlans)
                {
                    if (Include_VolentaryFlag_YES.Contains(item.ProductTypeId)) // If plan type required to consider only Voluntary Product / Plan
                    {
                        if (wr.IsProductVoluntary(item.ProductId, SessionId))
                        {
                            FinalList.Add(item);
                        }
                    }
                    else if (Include_VolentaryFlag_NO.Contains(item.ProductTypeId)) // If plan type required to consider only Voluntary Product / Plan
                    {
                        if (wr.IsProductVoluntary(item.ProductId, SessionId) == false)
                        {
                            FinalList.Add(item);
                        }
                    }
                    else
                    {
                        FinalList.Add(item);
                    }
                }
            }
            else
            {
                FinalList = lstPlans;
            }

            if (rdlAncillaryAnalysisPlanStatus.SelectedIndex == 0)
            {
                FinalList = FinalList.Where(p => p.RenewalDate > System.DateTime.Now && p.ProductStatus == p.ProductStatusCurrent).ToList();
            }

            FinalList = (from p in FinalList
                         orderby p.ProductName, p.CarrierName, p.RenewalDate ascending
                         select p).ToList();

            return FinalList;
        }
        private bool CheckPlanIsDual(string AnalyisisType)
        {
            bool IsDual = false;
            switch (AnalyisisType)
            {
                case "Dental Dual":
                    IsDual = true;
                    break;
                case "Dental ASO Dual":
                    IsDual = true;
                    break;
                case "Vision Dual":
                    IsDual = true;
                    break;
                case "Vision ASO Dual":
                    IsDual = true;
                    break;
            }
            return IsDual;
        }
        private bool CheckPlanIsClass(string AnalyisisType)
        {
            bool IsClass = false;
            switch (AnalyisisType)
            {
                case "LADD Classes":
                    IsClass = true;
                    break;
                case "LTD Classes":
                    IsClass = true;
                    break;
                case "STD Classes":
                    IsClass = true;
                    break;
            }
            return IsClass;
        }


        #region Landscape - Client details
        protected void CreateAnalysisTemplate_Landscape(string SessionId, DataSet AccountTeamMemberDS, DataSet AccountDS, string AccountOffice)
        {
            SummaryDetail sd = new SummaryDetail();
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            List<Plan> lstTempPlan = Session["PlanList"] as List<Plan>;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryTemplate_v4.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisRFPReport/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisRFPReport/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisRFPReport/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                Dictionary<string, int> lstAnalysisSheet = new Dictionary<string, int>();
                List<string> lstSheets = new List<string>();
                lstSheets.Add("DD");
                lstSheets.Add("Cost Summary");
                DataTable dtblAnalysisPlans = CreateLOCDataTable_AnalysisTemplate();
                DataTable dtblAnalysisDualPlans = CreateLOCDataTable_AnalysisTemplate();
                for (int i = 0; i < gvAncillaryAnalysisPlans.Rows.Count; i++)
                {
                    bool IsDual = false;
                    bool IsClassTemplate = false;
                    DropDownList ddlAnalysisType = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlAnalysisType") as DropDownList;
                    DropDownList ddlLineOfCoverage = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlLineOfCoverage") as DropDownList;
                    DropDownList ddlPlan = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlPlan") as DropDownList;
                    DropDownList ddlPlanDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlPlanDual") as DropDownList;
                    DropDownList ddlBenefitSummary = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummary") as DropDownList;
                    DropDownList ddlBenefitSummaryDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummaryDual") as DropDownList;
                    HiddenField hdnIsDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("hdnIsDual") as HiddenField;
                    HiddenField hdnEligibilityApplicable = gvAncillaryAnalysisPlans.Rows[i].FindControl("hdnEligibilityApplicable") as HiddenField;

                    DropDownList ddlBenefitSummaryClass2 = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummaryClass2") as DropDownList;
                    DropDownList ddlBenefitSummaryClass3 = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummaryClass3") as DropDownList;
                    HiddenField hdnIsClassTemplate = gvAncillaryAnalysisPlans.Rows[i].FindControl("hdnIsClassTemplate") as HiddenField;

                    DropDownList ddlEligibility = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlEligibility") as DropDownList;
                    DropDownList ddlEligibilityDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlEligibilityDual") as DropDownList;

                    string SheetName = "";
                    if (ddlAnalysisType != null)
                    {
                        if (ddlAnalysisType.SelectedValue != "Select" && ddlPlan.SelectedValue != "Select")
                        {

                            IsDual = hdnIsDual.Value.ToLower().Equals("true") ? true : false;
                            IsClassTemplate = hdnIsClassTemplate.Value.ToLower().Equals("true") ? true : false;
                            DataRow dr = dtblAnalysisPlans.NewRow();

                            if (ddlAnalysisType.SelectedValue == "LADD Vol")
                            {
                                SheetName = "Vol LADD";
                            }
                            else if (ddlAnalysisType.SelectedValue == "STD Vol")
                            {
                                SheetName = "Vol STD";
                            }
                            else if (ddlAnalysisType.SelectedValue == "LTD Vol")
                            {
                                SheetName = "Vol LTD";
                            }
                            else if (ddlAnalysisType.SelectedValue == "Absence Management")
                            {
                                SheetName = "Absence Mgmt";
                            }
                            else
                            {
                                SheetName = ddlAnalysisType.SelectedValue;
                            }

                            if (!lstAnalysisSheet.Keys.Contains(SheetName))
                            {
                                lstAnalysisSheet.Add(SheetName, 1);
                                dr["SheetName"] = SheetName;
                                lstSheets.Add(SheetName);
                            }
                            else
                            {
                                int SheetCount = lstAnalysisSheet[SheetName];
                                string NewSheetName = SheetName + "_" + (SheetCount).ToString();
                                if (SheetCount == 1)
                                {
                                    CopySheet(myExcelApp, myWorkbook, SheetName, NewSheetName);
                                }
                                else
                                {
                                    CopySheet(myExcelApp, myWorkbook, SheetName + "_" + (SheetCount - 1).ToString(), NewSheetName);
                                }

                                dr["SheetName"] = NewSheetName;
                                lstSheets.Add(NewSheetName);
                                lstAnalysisSheet[SheetName] = SheetCount + 1;
                            }

                            int ProductId = 0;
                            int BenefitSummaryId = 0;
                            int.TryParse(ddlPlan.SelectedValue, out ProductId);
                            int.TryParse(ddlBenefitSummary.SelectedValue, out BenefitSummaryId);
                            Plan selectedplan = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();
                            dr["IsDual"] = IsDual.ToString();
                            dr["LOCNo"] = (i + 1).ToString();
                            dr["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                            if (selectedplan.ProductTypeId == 5330)
                                selectedplan.ProductTypeDescription = "Absence Management";
                            dr["PlanType"] = selectedplan != null ? selectedplan.ProductTypeDescription : "";
                            dr["AnalysisType"] = ddlAnalysisType.SelectedValue;
                            dr["PlanName"] = ddlPlan.SelectedItem.Text;
                            dr["ProductID"] = ProductId;
                            dr["SelectedBenefitSummary"] = ddlBenefitSummary.SelectedItem.Text;
                            dr["CarrierName"] = selectedplan != null ? selectedplan.CarrierName : "";
                            dr["SummaryId"] = BenefitSummaryId;

                            int EleigibilityRuleId = 0;
                            SummaryDetail sdEligibility = new SummaryDetail();
                            sdEligibility.BuildEligibilityRuleTable();
                            DataTable Emp = new DataTable();
                            string DefinationOf_eligible_Emplyee = string.Empty;

                            if (hdnEligibilityApplicable.Value.ToLower() == "true")
                            {
                                if (ddlEligibility.SelectedIndex > 0)
                                {
                                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                                    DataSet EligibilityDS = sdEligibility.GetEligibilityRule(null, SessionId, EleigibilityRuleId);

                                    #region DefinationOf_eligible_Emplyee

                                    if (AccountDS.Tables.Count > 2)
                                    {
                                        if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                                        {
                                            Emp = AccountDS.Tables[2];
                                        }
                                    }
                                    if (EligibilityDS.Tables[1].Rows.Count > 0 && Emp.Rows.Count > 0)
                                    {

                                        IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                                     where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Tables[1].Rows[0]["EmployeeEligibilityRule_employeeTypeIDs"])
                                                                     select product;
                                        foreach (DataRow Def_Eligible_Emp in query)
                                        {
                                            DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                        }
                                    }
                                    #endregion
                                }

                                //dr["Eligibility"] = ddlEligibility.SelectedIndex == 0 || ddlEligibility.SelectedItem.Text == "Select" ? "" : ddlEligibility.SelectedItem.Text;
                                dr["Eligibility"] = DefinationOf_eligible_Emplyee;
                            }
                            else
                            {
                                dr["Eligibility"] = "";
                            }

                            dtblAnalysisPlans.Rows.Add(dr);

                            if (IsDual)
                            {
                                if (IsDuplicateDualPlan(i))
                                {
                                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select unique combination for Dual plan(s).')</script>");
                                    ddlPlanDual.Focus();
                                    return;
                                }

                                DataRow drDual = dtblAnalysisDualPlans.NewRow();
                                int DualProductId = 0;
                                int.TryParse(ddlPlanDual.SelectedValue, out DualProductId);
                                int DualBenefitSummaryId = 0;
                                int.TryParse(ddlBenefitSummaryDual.SelectedValue, out DualBenefitSummaryId);

                                Plan selectedDualPlan = lstTempPlan.Where(r => r.ProductId == DualProductId).FirstOrDefault();
                                drDual["LOCNo"] = (i + 1).ToString();
                                drDual["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                                drDual["PlanType"] = selectedDualPlan != null ? selectedDualPlan.ProductTypeDescription : "";
                                drDual["AnalysisType"] = ddlAnalysisType.SelectedValue;
                                drDual["PlanName"] = ddlPlanDual.SelectedItem.Text;
                                drDual["ProductID"] = DualProductId;
                                drDual["SelectedBenefitSummary"] = ddlBenefitSummaryDual.SelectedItem.Text;
                                drDual["CarrierName"] = selectedDualPlan != null ? selectedDualPlan.CarrierName : "";
                                drDual["SummaryId"] = DualBenefitSummaryId;
                                if (hdnEligibilityApplicable.Value.ToLower() == "true")
                                {
                                    //dr["Eligibility"] = ddlEligibility.SelectedIndex == 0 || ddlEligibility.SelectedItem.Text == "Select" ? "" : ddlEligibility.SelectedItem.Text;
                                    drDual["Eligibility"] = DefinationOf_eligible_Emplyee;
                                }
                                else
                                {
                                    drDual["Eligibility"] = "";

                                }

                                dtblAnalysisDualPlans.Rows.Add(drDual);
                            }
                            else if (IsClassTemplate)
                            {
                                if (ddlBenefitSummary.SelectedItem.Text.ToLower() == "select")
                                {
                                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('No Benefit Summary selected  for " + ddlAnalysisType.SelectedValue + "')</script>");
                                    return;
                                }

                                bool IsDuplicateClass = IsDuplicateClassBenefitSummary(i);

                                if (!IsDuplicateClass)
                                {
                                    DataRow drClass2 = dtblAnalysisDualPlans.NewRow();
                                    int Class2BenefitSummaryId = 0;
                                    int.TryParse(ddlBenefitSummaryClass2.SelectedValue, out Class2BenefitSummaryId);

                                    drClass2["LOCNo"] = (i + 1).ToString();
                                    drClass2["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                                    drClass2["PlanType"] = selectedplan != null ? selectedplan.ProductTypeDescription : "";
                                    drClass2["AnalysisType"] = ddlAnalysisType.SelectedValue;
                                    drClass2["PlanName"] = ddlPlan.SelectedItem.Text;
                                    drClass2["ProductID"] = selectedplan.ProductId;
                                    drClass2["SelectedBenefitSummary"] = ddlBenefitSummaryClass2.SelectedItem.Text;
                                    drClass2["CarrierName"] = selectedplan != null ? selectedplan.CarrierName : "";
                                    drClass2["SummaryId"] = Class2BenefitSummaryId;
                                    if (hdnEligibilityApplicable.Value.ToLower() == "true")
                                    {
                                        drClass2["Eligibility"] = DefinationOf_eligible_Emplyee;
                                    }
                                    else
                                    {
                                        drClass2["Eligibility"] = "";

                                    }

                                    dtblAnalysisDualPlans.Rows.Add(drClass2);

                                    DataRow drClass3 = dtblAnalysisDualPlans.NewRow();
                                    int Class3BenefitSummaryId = 0;
                                    int.TryParse(ddlBenefitSummaryClass3.SelectedValue, out Class3BenefitSummaryId);

                                    //Plan SelectedClassPlan = lstTempPlan.Where(r => r.ProductId == ClassProductID).FirstOrDefault();
                                    drClass3["LOCNo"] = (i + 1).ToString();
                                    drClass3["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                                    drClass3["PlanType"] = selectedplan != null ? selectedplan.ProductTypeDescription : "";
                                    drClass3["AnalysisType"] = ddlAnalysisType.SelectedValue;
                                    drClass3["PlanName"] = ddlPlan.SelectedItem.Text;
                                    drClass3["ProductID"] = selectedplan.ProductId;
                                    drClass3["SelectedBenefitSummary"] = ddlBenefitSummaryClass3.SelectedItem.Text;
                                    drClass3["CarrierName"] = selectedplan != null ? selectedplan.CarrierName : "";
                                    drClass3["SummaryId"] = Class3BenefitSummaryId;
                                    if (hdnEligibilityApplicable.Value.ToLower() == "true")
                                    {
                                        drClass3["Eligibility"] = DefinationOf_eligible_Emplyee;
                                    }
                                    else
                                    {
                                        drClass3["Eligibility"] = "";
                                    }

                                    dtblAnalysisDualPlans.Rows.Add(drClass3);
                                }
                                else
                                {
                                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Duplicate Benefit Summary selected  for " + ddlAnalysisType.SelectedValue + "')</script>");
                                    return;
                                }
                            }
                        }
                    }
                }
                lstSheets.Add("Notes");

                if (dtblAnalysisPlans.Rows.Count > 0)
                {
                    WriteAnalysisTemplate wr = new WriteAnalysisTemplate();
                    string SummaryName_SheetName = string.Empty;
                    DataTable dtOfficeAddress = new DataTable();
                    string MainAddress = string.Empty;
                    MainAddress = sd.GetFormattedAddress(AccountDS, "").Trim();
                    MainAddress = MainAddress.Replace("\n", "; ");
                    int x = MainAddress.LastIndexOf(";");
                    MainAddress = MainAddress.Remove(x);


                    if (ddlUSI_City.SelectedIndex > 0)
                    {
                        string[] office = ddlUSI_City.SelectedValue.Split('~');
                        string City = Convert.ToString(office[0]).Trim();
                        string BPOffice = Convert.ToString(office[1]).Trim();
                        string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                        dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                    }
                    int additionalRow = 0;
                    int.TryParse(ddlAncillayAnalysisAdditionLOC.SelectedValue, out additionalRow);
                    if (additionalRow > 0)
                    {
                        for (int i = 1; i <= additionalRow; i++)
                        {
                            DataRow dr = dtblAnalysisPlans.NewRow();
                            dr["IsDual"] = "false";
                            dr["LOCNo"] = "0";
                            dr["LOCName"] = "<<Additional LOC " + i.ToString() + ">>";
                            dr["PlanType"] = "<<Additional LOC " + i.ToString() + ">>";
                            dr["AnalysisType"] = "";
                            dr["PlanName"] = "";
                            dr["ProductID"] = 0;
                            dr["SelectedBenefitSummary"] = "";
                            dr["CarrierName"] = "";
                            dr["SummaryId"] = "0";
                            dtblAnalysisPlans.Rows.Add(dr);
                        }
                    }
                    if (IsDuplicateLOCSelected(dtblAnalysisPlans))
                    {
                        myWorkbook.Save();
                        myWorkbook.Close(true, Type.Missing, Type.Missing);
                        myExcelApp.Quit();
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Duplicate Line Of Coverage found.')</script>");

                    }
                    else
                    {
                        DataSet BenefitDS = new DataSet();
                        DataSet BenefitDSDual = new DataSet();
                        sd.BuildBenefitSummaryTable();
                        BenefitDS = sd.GetBenefitSummary_V2(dtblAnalysisPlans, SessionId);
                        SummaryDetail sd1 = new SummaryDetail();
                        sd1.BuildBenefitSummaryTable();
                        if (dtblAnalysisDualPlans != null && dtblAnalysisDualPlans.Rows.Count > 0)
                            BenefitDSDual = sd1.GetBenefitSummary_V2(dtblAnalysisDualPlans, SessionId);
                        SummaryName_SheetName = "Cost Summary";
                        myWorksheet = myWorkbook.Worksheets[1];
                        DateTime dtRenewalDate = GetDate(txtAncillaryAnalysisRenewalDate.Text.Trim());
                        int AdditionalLOCCount = int.Parse(ddlAncillayAnalysisAdditionLOC.SelectedValue);
                        //To Call BL
                        wr.WriteFields_AnalysisTemplate(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, dtRenewalDate, lstSheets);
                        wr.WritePlans_AnalysisTemplate(myExcelApp, myWorkbook, SummaryName_SheetName, dtblAnalysisPlans, dtblAnalysisDualPlans, BenefitDS, BenefitDSDual);
                        Microsoft.Office.Interop.Excel.Worksheet sheet = (Microsoft.Office.Interop.Excel.Worksheet)myExcelApp.Worksheets[SummaryName_SheetName];
                        sheet.Select(Type.Missing);
                        myWorkbook.Save();
                        myWorkbook.Close(true, Type.Missing, Type.Missing);
                        myExcelApp.Quit();
                        DownloadFileNew_ExcelFormat(savefilename.ToString());
                    }

                }
                else
                {
                    myWorkbook.Save();
                    myWorkbook.Close(true, Type.Missing, Type.Missing);
                    myExcelApp.Quit();
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select plan(s) from Line Of Coverage.')</script>");
                }




                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        #endregion

        #region Portrait - Client details
        protected void CreateAnalysisTemplate_Portrait(string SessionId, DataSet AccountTeamMemberDS, DataSet AccountDS, string AccountOffice)
        {
            SummaryDetail sd = new SummaryDetail();
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            List<Plan> lstTempPlan = Session["PlanList"] as List<Plan>;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryPortMapped_v1.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisRFPReport/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisRFPReport/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/RFPReports/Documents/Templates/AnalysisRFPReport/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                Dictionary<string, int> lstAnalysisSheet = new Dictionary<string, int>();
                List<string> lstSheets = new List<string>();
                lstSheets.Add("DD");
                lstSheets.Add("Cost Summary");
                DataTable dtblAnalysisPlans = CreateLOCDataTable_AnalysisTemplate();
                DataTable dtblAnalysisDualPlans = CreateLOCDataTable_AnalysisTemplate();
                for (int i = 0; i < gvAncillaryAnalysisPlans.Rows.Count; i++)
                {
                    bool IsDual = false;
                    bool IsClassTemplate = false;
                    DropDownList ddlAnalysisType = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlAnalysisType") as DropDownList;
                    DropDownList ddlLineOfCoverage = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlLineOfCoverage") as DropDownList;
                    DropDownList ddlPlan = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlPlan") as DropDownList;
                    DropDownList ddlPlanDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlPlanDual") as DropDownList;
                    DropDownList ddlBenefitSummary = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummary") as DropDownList;
                    DropDownList ddlBenefitSummaryDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummaryDual") as DropDownList;
                    HiddenField hdnIsDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("hdnIsDual") as HiddenField;
                    HiddenField hdnEligibilityApplicable = gvAncillaryAnalysisPlans.Rows[i].FindControl("hdnEligibilityApplicable") as HiddenField;

                    DropDownList ddlBenefitSummaryClass2 = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummaryClass2") as DropDownList;
                    DropDownList ddlBenefitSummaryClass3 = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlBenefitSummaryClass3") as DropDownList;
                    HiddenField hdnIsClassTemplate = gvAncillaryAnalysisPlans.Rows[i].FindControl("hdnIsClassTemplate") as HiddenField;

                    DropDownList ddlEligibility = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlEligibility") as DropDownList;
                    DropDownList ddlEligibilityDual = gvAncillaryAnalysisPlans.Rows[i].FindControl("ddlEligibilityDual") as DropDownList;

                    string SheetName = "";
                    if (ddlAnalysisType != null)
                    {
                        if (ddlAnalysisType.SelectedValue != "Select" && ddlPlan.SelectedValue != "Select")
                        {

                            IsDual = hdnIsDual.Value.ToLower().Equals("true") ? true : false;
                            IsClassTemplate = hdnIsClassTemplate.Value.ToLower().Equals("true") ? true : false;
                            DataRow dr = dtblAnalysisPlans.NewRow();

                            if (ddlAnalysisType.SelectedValue == "LADD Vol")
                            {
                                SheetName = "Vol LADD";
                            }
                            else if (ddlAnalysisType.SelectedValue == "STD Vol")
                            {
                                SheetName = "Vol STD";
                            }
                            else if (ddlAnalysisType.SelectedValue == "LTD Vol")
                            {
                                SheetName = "Vol LTD";
                            }
                            else if (ddlAnalysisType.SelectedValue == "Absence Management")
                            {
                                SheetName = "Absence Mgmt";
                            }
                            else
                            {
                                SheetName = ddlAnalysisType.SelectedValue;
                            }

                            if (!lstAnalysisSheet.Keys.Contains(SheetName))
                            {
                                lstAnalysisSheet.Add(SheetName, 1);
                                dr["SheetName"] = SheetName;
                                lstSheets.Add(SheetName);
                            }
                            else
                            {
                                int SheetCount = lstAnalysisSheet[SheetName];
                                string NewSheetName = SheetName + "_" + (SheetCount).ToString();
                                if (SheetCount == 1)
                                {
                                    CopySheet(myExcelApp, myWorkbook, SheetName, NewSheetName);
                                }
                                else
                                {
                                    CopySheet(myExcelApp, myWorkbook, SheetName + "_" + (SheetCount - 1).ToString(), NewSheetName);
                                }

                                dr["SheetName"] = NewSheetName;
                                lstSheets.Add(NewSheetName);
                                lstAnalysisSheet[SheetName] = SheetCount + 1;
                            }

                            int ProductId = 0;
                            int BenefitSummaryId = 0;
                            int.TryParse(ddlPlan.SelectedValue, out ProductId);
                            int.TryParse(ddlBenefitSummary.SelectedValue, out BenefitSummaryId);
                            Plan selectedplan = lstTempPlan.Where(r => r.ProductId == ProductId).FirstOrDefault();
                            dr["IsDual"] = IsDual.ToString();
                            dr["LOCNo"] = (i + 1).ToString();
                            dr["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                            if (selectedplan.ProductTypeId == 5330)
                                selectedplan.ProductTypeDescription = "Absence Management";
                            dr["PlanType"] = selectedplan != null ? selectedplan.ProductTypeDescription : "";
                            dr["AnalysisType"] = ddlAnalysisType.SelectedValue;
                            dr["PlanName"] = ddlPlan.SelectedItem.Text;
                            dr["ProductID"] = ProductId;
                            dr["SelectedBenefitSummary"] = ddlBenefitSummary.SelectedItem.Text;
                            dr["CarrierName"] = selectedplan != null ? selectedplan.CarrierName : "";
                            dr["SummaryId"] = BenefitSummaryId;

                            int EleigibilityRuleId = 0;
                            SummaryDetail sdEligibility = new SummaryDetail();
                            sdEligibility.BuildEligibilityRuleTable();
                            DataTable Emp = new DataTable();
                            string DefinationOf_eligible_Emplyee = string.Empty;

                            if (hdnEligibilityApplicable.Value.ToLower() == "true")
                            {
                                if (ddlEligibility.SelectedIndex > 0)
                                {
                                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                                    DataSet EligibilityDS = sdEligibility.GetEligibilityRule(null, SessionId, EleigibilityRuleId);

                                    #region DefinationOf_eligible_Emplyee

                                    if (AccountDS.Tables.Count > 2)
                                    {
                                        if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                                        {
                                            Emp = AccountDS.Tables[2];
                                        }
                                    }
                                    if (EligibilityDS.Tables[1].Rows.Count > 0 && Emp.Rows.Count > 0)
                                    {

                                        IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                                     where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Tables[1].Rows[0]["EmployeeEligibilityRule_employeeTypeIDs"])
                                                                     select product;
                                        foreach (DataRow Def_Eligible_Emp in query)
                                        {
                                            DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                        }
                                    }
                                    #endregion
                                }

                                //dr["Eligibility"] = ddlEligibility.SelectedIndex == 0 || ddlEligibility.SelectedItem.Text == "Select" ? "" : ddlEligibility.SelectedItem.Text;
                                dr["Eligibility"] = DefinationOf_eligible_Emplyee;
                            }
                            else
                            {
                                dr["Eligibility"] = "";
                            }

                            dtblAnalysisPlans.Rows.Add(dr);

                            if (IsDual)
                            {
                                if (IsDuplicateDualPlan(i))
                                {
                                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select unique combination for Dual plan(s).')</script>");
                                    ddlPlanDual.Focus();
                                    return;
                                }

                                DataRow drDual = dtblAnalysisDualPlans.NewRow();
                                int DualProductId = 0;
                                int.TryParse(ddlPlanDual.SelectedValue, out DualProductId);
                                int DualBenefitSummaryId = 0;
                                int.TryParse(ddlBenefitSummaryDual.SelectedValue, out DualBenefitSummaryId);

                                Plan selectedDualPlan = lstTempPlan.Where(r => r.ProductId == DualProductId).FirstOrDefault();
                                drDual["LOCNo"] = (i + 1).ToString();
                                drDual["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                                drDual["PlanType"] = selectedDualPlan != null ? selectedDualPlan.ProductTypeDescription : "";
                                drDual["AnalysisType"] = ddlAnalysisType.SelectedValue;
                                drDual["PlanName"] = ddlPlanDual.SelectedItem.Text;
                                drDual["ProductID"] = DualProductId;
                                drDual["SelectedBenefitSummary"] = ddlBenefitSummaryDual.SelectedItem.Text;
                                drDual["CarrierName"] = selectedDualPlan != null ? selectedDualPlan.CarrierName : "";
                                drDual["SummaryId"] = DualBenefitSummaryId;
                                if (hdnEligibilityApplicable.Value.ToLower() == "true")
                                {
                                    //dr["Eligibility"] = ddlEligibility.SelectedIndex == 0 || ddlEligibility.SelectedItem.Text == "Select" ? "" : ddlEligibility.SelectedItem.Text;
                                    drDual["Eligibility"] = DefinationOf_eligible_Emplyee;
                                }
                                else
                                {
                                    drDual["Eligibility"] = "";

                                }

                                dtblAnalysisDualPlans.Rows.Add(drDual);
                            }
                            else if (IsClassTemplate)
                            {
                                if (ddlBenefitSummary.SelectedItem.Text.ToLower() == "select")
                                {
                                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('No Benefit Summary selected  for " + ddlAnalysisType.SelectedValue + "')</script>");
                                    return;
                                }

                                bool IsDuplicateClass = IsDuplicateClassBenefitSummary(i);

                                if (!IsDuplicateClass)
                                {
                                    DataRow drClass2 = dtblAnalysisDualPlans.NewRow();
                                    int Class2BenefitSummaryId = 0;
                                    int.TryParse(ddlBenefitSummaryClass2.SelectedValue, out Class2BenefitSummaryId);

                                    drClass2["LOCNo"] = (i + 1).ToString();
                                    drClass2["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                                    drClass2["PlanType"] = selectedplan != null ? selectedplan.ProductTypeDescription : "";
                                    drClass2["AnalysisType"] = ddlAnalysisType.SelectedValue;
                                    drClass2["PlanName"] = ddlPlan.SelectedItem.Text;
                                    drClass2["ProductID"] = selectedplan.ProductId;
                                    drClass2["SelectedBenefitSummary"] = ddlBenefitSummaryClass2.SelectedItem.Text;
                                    drClass2["CarrierName"] = selectedplan != null ? selectedplan.CarrierName : "";
                                    drClass2["SummaryId"] = Class2BenefitSummaryId;
                                    if (hdnEligibilityApplicable.Value.ToLower() == "true")
                                    {
                                        drClass2["Eligibility"] = DefinationOf_eligible_Emplyee;
                                    }
                                    else
                                    {
                                        drClass2["Eligibility"] = "";

                                    }

                                    dtblAnalysisDualPlans.Rows.Add(drClass2);

                                    DataRow drClass3 = dtblAnalysisDualPlans.NewRow();
                                    int Class3BenefitSummaryId = 0;
                                    int.TryParse(ddlBenefitSummaryClass3.SelectedValue, out Class3BenefitSummaryId);

                                    //Plan SelectedClassPlan = lstTempPlan.Where(r => r.ProductId == ClassProductID).FirstOrDefault();
                                    drClass3["LOCNo"] = (i + 1).ToString();
                                    drClass3["LOCName"] = ddlLineOfCoverage.SelectedItem.Text;
                                    drClass3["PlanType"] = selectedplan != null ? selectedplan.ProductTypeDescription : "";
                                    drClass3["AnalysisType"] = ddlAnalysisType.SelectedValue;
                                    drClass3["PlanName"] = ddlPlan.SelectedItem.Text;
                                    drClass3["ProductID"] = selectedplan.ProductId;
                                    drClass3["SelectedBenefitSummary"] = ddlBenefitSummaryClass3.SelectedItem.Text;
                                    drClass3["CarrierName"] = selectedplan != null ? selectedplan.CarrierName : "";
                                    drClass3["SummaryId"] = Class3BenefitSummaryId;
                                    if (hdnEligibilityApplicable.Value.ToLower() == "true")
                                    {
                                        drClass3["Eligibility"] = DefinationOf_eligible_Emplyee;
                                    }
                                    else
                                    {
                                        drClass3["Eligibility"] = "";
                                    }

                                    dtblAnalysisDualPlans.Rows.Add(drClass3);
                                }
                                else
                                {
                                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Duplicate Benefit Summary selected  for " + ddlAnalysisType.SelectedValue + "')</script>");
                                    return;
                                }
                            }
                        }
                    }
                }
                lstSheets.Add("Notes");

                if (dtblAnalysisPlans.Rows.Count > 0)
                {
                    WriteAnalysisTemplate wr = new WriteAnalysisTemplate();
                    string SummaryName_SheetName = string.Empty;
                    DataTable dtOfficeAddress = new DataTable();
                    string MainAddress = string.Empty;
                    MainAddress = sd.GetFormattedAddress(AccountDS, "").Trim();
                    MainAddress = MainAddress.Replace("\n", "; ");
                    int x = MainAddress.LastIndexOf(";");
                    MainAddress = MainAddress.Remove(x);


                    if (ddlUSI_City.SelectedIndex > 0)
                    {
                        string[] office = ddlUSI_City.SelectedValue.Split('~');
                        string City = Convert.ToString(office[0]).Trim();
                        string BPOffice = Convert.ToString(office[1]).Trim();
                        string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                        dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                    }
                    int additionalRow = 0;
                    int.TryParse(ddlAncillayAnalysisAdditionLOC.SelectedValue, out additionalRow);
                    if (additionalRow > 0)
                    {
                        for (int i = 1; i <= additionalRow; i++)
                        {
                            DataRow dr = dtblAnalysisPlans.NewRow();
                            dr["IsDual"] = "false";
                            dr["LOCNo"] = "0";
                            dr["LOCName"] = "<<Additional LOC " + i.ToString() + ">>";
                            dr["PlanType"] = "<<Additional LOC " + i.ToString() + ">>";
                            dr["AnalysisType"] = "";
                            dr["PlanName"] = "";
                            dr["ProductID"] = 0;
                            dr["SelectedBenefitSummary"] = "";
                            dr["CarrierName"] = "";
                            dr["SummaryId"] = "0";
                            dtblAnalysisPlans.Rows.Add(dr);
                        }
                    }
                    if (IsDuplicateLOCSelected(dtblAnalysisPlans))
                    {
                        myWorkbook.Save();
                        myWorkbook.Close(true, Type.Missing, Type.Missing);
                        myExcelApp.Quit();
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Duplicate Line Of Coverage found.')</script>");

                    }
                    else
                    {
                        DataSet BenefitDS = new DataSet();
                        DataSet BenefitDSDual = new DataSet();
                        sd.BuildBenefitSummaryTable();
                        BenefitDS = sd.GetBenefitSummary_V2(dtblAnalysisPlans, SessionId);
                        SummaryDetail sd1 = new SummaryDetail();
                        sd1.BuildBenefitSummaryTable();
                        if (dtblAnalysisDualPlans != null && dtblAnalysisDualPlans.Rows.Count > 0)
                            BenefitDSDual = sd1.GetBenefitSummary_V2(dtblAnalysisDualPlans, SessionId);
                        SummaryName_SheetName = "Cost Summary";
                        myWorksheet = myWorkbook.Worksheets[1];
                        DateTime dtRenewalDate = GetDate(txtAncillaryAnalysisRenewalDate.Text.Trim());
                        int AdditionalLOCCount = int.Parse(ddlAncillayAnalysisAdditionLOC.SelectedValue);
                        //To Call BL
                        wr.WriteFields_AnalysisTemplate(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, dtRenewalDate, lstSheets);
                        wr.WritePlans_AnalysisTemplate(myExcelApp, myWorkbook, SummaryName_SheetName, dtblAnalysisPlans, dtblAnalysisDualPlans, BenefitDS, BenefitDSDual);
                        Microsoft.Office.Interop.Excel.Worksheet sheet = (Microsoft.Office.Interop.Excel.Worksheet)myExcelApp.Worksheets[SummaryName_SheetName];
                        sheet.Select(Type.Missing);
                        myWorkbook.Save();
                        myWorkbook.Close(true, Type.Missing, Type.Missing);
                        myExcelApp.Quit();
                        DownloadFileNew_ExcelFormat(savefilename.ToString());
                    }

                }
                else
                {
                    myWorkbook.Save();
                    myWorkbook.Close(true, Type.Missing, Type.Missing);
                    myExcelApp.Quit();
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select plan(s) from Line Of Coverage.')</script>");
                }




                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        #endregion
    }
}