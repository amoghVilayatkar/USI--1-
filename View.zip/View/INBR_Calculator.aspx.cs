﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Diagnostics;
using System.Threading;

using System.Data;
using System.IO;

using System.Runtime.InteropServices;
using System.Web.UI.WebControls;



using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Core;
using BenefitPointSummaryPortal.Common.ClientUserControl;
using BenefitPointSummaryPortal.BAL.Pilot;

namespace BenefitPointSummaryPortal.View
{
    public partial class INBR_Calculator : System.Web.UI.Page
    {
        string SessionId = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        private static string Activity = "INBR Calculator";
        private static string Activity_Group = "Analytics";
        private static readonly string DeliverableCategory = "Analytics";


        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                ucClientDropdown.ServiceOption = "";

                if (!IsPostBack)
                {
                    objCommFun.GetUserDetails();
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ucClientDropdown_ClientSelected(object sender, ClientSelectedEventArgs Args)
        {
            List<Contact> ContactList = ucClientDropdown.GetAccountContacts();
            ddlAcountContact.DataSource = ContactList;
            ddlAcountContact.DataBind();
            ddlAcountContact.Items.Insert(0, new ListItem("Select", "Select"));

        }

        protected void ucClientDropdown_ClientReset(object sender)
        {
            ddlAcountContact.Items.Clear();
            ddlAcountContact.Items.Insert(0, new ListItem("Select", ""));
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            bool flag; 
            try
            {
                if (Convert.ToString(Session["Summary"]) == "INBRCalculator")
                {

                    if (ucClientDropdown.IsClientSelected == false)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        ucClientDropdown.Focus();
                        flag = false;
                    }

                    else if (ddlAcountContact.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Account Contact.')</script>");
                        ddlAcountContact.Focus();
                        flag = false;

                    }
                    else
                    {
                        DataSet AccountDS = new DataSet();
                        AccountDS = ucClientDropdown.GetAccountDetails();
                        DataSet AccountTeamMemberDS = new DataSet();
                        AccountTeamMemberDS = ucClientDropdown.GetAccountTeamMembers();
                        // create function here
                        List<Contact> lstContact = ucClientDropdown.GetAccountContacts();
                        Create_INBRCalculator(ucClientDropdown.ClientName, SessionId, AccountDS, AccountTeamMemberDS, lstContact, ddlAcountContact.SelectedValue);
                        flag = true;
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

      

        protected void Create_INBRCalculator(string ClientName, string SessionId, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SelectedContactId)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            string BPUser_Name = string.Empty;
            string SICCode = string.Empty;

            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;
                string myPath = Server.MapPath("~/Files/Pilot/Documents/Templates/INBRCalculator_Template_V2.xlsb");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/INBRCalculator_Template/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsb");

                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/INBRCalculator_Template/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/INBRCalculator_Template/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                WriteINBR_Calculator wr = new WriteINBR_Calculator();
                wr.Write_INBRCalculator(myExcelApp, ClientName, SessionId, AccountDS, AccountTeamMemberDS, ContactList, SelectedContactId);
                //WriteCensusRequestTemplate wr = new WriteCensusRequestTemplate();
                // wr.Write_CensusOver50_Template(myExcelApp, ddlClient.SelectedItem.Text, SICCode);

                
                #region ------- Code for Add Activity Log --------
                string AdditionalCrtieriaOption_1 = string.Empty;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DictDepartment = sd.getDepartmentDetails();
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ucClientDropdown.ClientID), SessionId, out Account_Region);
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientName, Convert.ToString(Session["UserLoginName"]), ucClientDropdown.ClientID, Account_Region, Account_Office, Convert.ToString(DeliverableCategory), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                #endregion 

                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}