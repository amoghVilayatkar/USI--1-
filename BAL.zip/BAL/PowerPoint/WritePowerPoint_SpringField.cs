﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using System.Runtime.InteropServices;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.IO;
using System.Data;
using System.Collections;
using StringTrimmer;

namespace BenefitPointSummaryPortal.BAL.PowerPoint
{
    public class WritePowerPoint_SpringField : System.Web.UI.Page
    {
        Microsoft.Office.Interop.PowerPoint.Shapes objShapes;
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        /// <summary> 
        /// Write Field to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="AccountDS">Dataset AccountDS contain Account information for selected Client.</param>
        public void WriteFieldToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataTable OfficeTable, List<BRCData> BRCList, string ddlBRCSelectedValue, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = 0;
                int index = -1;

                ////if (ddlBRC.SelectedIndex > 1)
                ////{
                ////    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                ////}
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                // For showing current year in footer
                Microsoft.Office.Interop.PowerPoint.Master sliedmaster = objPres.SlideMaster;

                for (int i = 1; i <= sliedmaster.Shapes.Count; i++)
                {
                    if (sliedmaster.Shapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        if (sliedmaster.Shapes[i].Name == "Textdate")
                        {
                            txtFrame = sliedmaster.Shapes[i].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Footer_Year>>"))
                            {
                                txtRange.Replace("<<Footer_Year>>", DateTime.Today.Year.ToString());
                            }
                        }
                    }
                }

                for (int j = 1; j < sliedmaster.CustomLayouts.Count; j++)
                {
                    for (int i = 1; i <= sliedmaster.CustomLayouts[j].Shapes.Count; i++)
                    {
                        if (sliedmaster.CustomLayouts[j].Shapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                        {
                            if (sliedmaster.CustomLayouts[j].Shapes[i].Name == "Textdate")
                            {
                                txtFrame = sliedmaster.CustomLayouts[j].Shapes[i].TextFrame;
                                txtRange = txtFrame.TextRange;

                                if (txtRange.Text.Contains("<<Footer_Year>>"))
                                {
                                    txtRange.Replace("<<Footer_Year>>", DateTime.Today.Year.ToString());
                                }
                            }
                        }
                    }
                }
                

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            objSlides = objPres.Slides;

                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                objShapes = objSlides[i].Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                            if (objShapes[j].Name.ToString().Equals("HRA Table") || objShapes[j].Name.ToString().Equals("HSA Table"))
                                            {
                                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                                {
                                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                    {
                                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                        txtRange = txtFrame.TextRange;
                                                        if (txtRange.Text.Contains("<<Client Name>>"))
                                                        {
                                                            txtRange.Replace("<<Client Name>>", ddlClient.SelectedItem.Text.ToString());
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {

                                        if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                                        {
                                            break;
                                        }

                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<Client Name>>"))
                                        {
                                            txtRange.Replace("<<Client Name>>", ddlClient.SelectedItem.Text.ToString());
                                            txtRange.Replace("<<Client Name1>>", ddlClient.SelectedItem.Text.ToString());
                                            txtRange.Replace("<<Client Name2>>", ddlClient.SelectedItem.Text.ToString());
                                        }
                                        // Firstly client told to take renewal date, now told to take Effective date
                                        //if (txtRange.Text.Contains("<<First Med Plan Renewal Year>>"))
                                        //{
                                        //    string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        //    txtRange.Replace("<<First Med Plan Renewal Year>>", Convert.ToDateTime(renewal.ToString()).Year.ToString());
                                        //}
                                        if (txtRange.Text.Contains("<<Footer_Year>>"))
                                        {
                                            txtRange.Replace("<<Footer_Year>>", DateTime.Today.Year.ToString());
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Effective Year>>"))
                                        {
                                            string effective = PlanTable.Rows[k]["Effective"].ToString();
                                            txtRange.Replace("<<First Med Plan Effective Year>>", Convert.ToDateTime(effective.ToString()).Year.ToString());
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Eff Date Year>>"))
                                        {
                                            string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                            txtRange.Replace("<<First Med Plan Eff Date Year>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            txtRange.Replace("<<First Med Plan Eff Date Year1>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            txtRange.Replace("<<First Med Plan Eff Date Year2>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Expiration Year>>"))
                                        {
                                            //txtRange.Replace("<<First Med Plan Expiration Year>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).ToShortDateString()));
                                            txtRange.Replace("<<First Med Plan Expiration Year>>", Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year.ToString());

                                        }
                                        if (txtRange.Text.Contains("<<First Medical Plan Effective Date>>"))
                                        {
                                            // txtRange.Replace("<<First Med Plan Effective Date>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).ToShortDateString()));
                                            txtRange.Replace("<<First Medical Plan Effective Date>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).ToShortDateString()));
                                        }
                                        //if (Emp.Rows.Count > 0)
                                        //{
                                        //    if (txtRange.Text.Contains("<<Employee Status>>"))
                                        //    {
                                        //        txtRange.Replace("<<Employee Status>>", Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString());
                                        //    }
                                        //    if (txtRange.Text.Contains("<<working>>"))
                                        //    {
                                        //        txtRange.Replace("<<working>>", Emp.Rows[0]["VALUE"].ToString() + " " + Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString());
                                        //    }
                                        //}
                                        //else
                                        //{
                                        //    txtRange.Replace("<<Employee Status>>", " ");
                                        //    txtRange.Replace("<<working>>", " ");
                                        //}
                                        //if (txtRange.Text.Contains("<<Eligibility Rule – Waiting Period>>"))
                                        //{
                                        //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        //    {
                                        //        txtRange.Replace("<<Eligibility Rule – Waiting Period>>", EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString());
                                        //    }
                                        //    else
                                        //    {
                                        //        txtRange.Replace("<<Eligibility Rule – Waiting Period>>", " ");

                                        //    }
                                        //}
                                        //if (txtRange.Text.Contains("<<Eligibility Rule – Definition of Dependent – Spouse>>"))
                                        //{
                                        //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        //    {
                                        //        string str = " ";
                                        //        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString() != "")
                                        //        {
                                        //            str = "Legally married Spouse";
                                        //            str = str + "\n" + "Domestic Partner - " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                        //        }
                                        //        else
                                        //        {
                                        //            str = str + "\n" + " ";
                                        //        }

                                        //        //txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Spouse>>", EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString());
                                        //        txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Spouse>>", str);
                                        //    }
                                        //    else
                                        //    {
                                        //        string str1 = " ";
                                        //        txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Spouse>>", str1 + "\n");
                                        //    }
                                        //}
                                        //if (txtRange.Text.Contains("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>"))
                                        //{
                                        //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        //    {
                                        //        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString() != "")
                                        //        {
                                        //            txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", "Covered up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString());
                                        //        }
                                        //        else
                                        //        {
                                        //            txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", " ");
                                        //        }
                                        //    }
                                        //    else
                                        //    {
                                        //        txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", " ");
                                        //    }
                                        //}

                                        if (!String.IsNullOrEmpty(ddlBRCSelectedValue))
                                        {
                                            if (BRCList.Count > 0 && ddlBRCSelectedValue == "YES")
                                            {
                                                if (txtRange.Text.Contains("<<BRC Phone Number>>"))
                                                {
                                                    txtRange.Replace("<<BRC Phone Number>>", BRCList[BRCindex].BRCPhone);
                                                }
                                                if (txtRange.Text.Contains("<<BRC E-mail Address>>"))
                                                {
                                                    txtRange.Replace("<<BRC E-mail Address>>", BRCList[BRCindex].BRCEmail);
                                                }
                                                if (txtRange.Text.Contains("<<BRC Hours of Operation>>"))
                                                {
                                                    txtRange.Replace("<<BRC Hours of Operation>>", BRCList[BRCindex].BRCDayHours);
                                                }
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<BRC Phone Number>>", " ");
                                                txtRange.Replace("<<BRC E-mail Address>>", " ");
                                                txtRange.Replace("<<BRC Hours of Operation>>", " ");
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="ddlClient">For showing client name on the fields.</param> 
        /// <param name="ddlHSANoOfPlan">To check whether the HSA plan is selected or not, if selected then show attribute values for HSA in medical section.</param>
        public void WriteMedicalSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan, DropDownList ddlClient, DropDownList ddlHSANoOfPlan, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                string carrierName = string.Empty;

                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(1, "45");    //Calendar Year Deductible indivisual
                HashtableMedicalInNetwork1.Add(2, "44");    //Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(3, "53");    //Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedicalInNetwork1.Add(4, "52");    //Calendar Year Out of Pocket Maximum(Family)
                HashtableMedicalInNetwork1.Add(5, "112");   //General Plan Information Coinsurence
                HashtableMedicalInNetwork1.Add(6, "16");    //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalInNetwork1.Add(7, "386");   //Physician Office Visit (Primary)
                HashtableMedicalInNetwork1.Add(8, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalInNetwork1.Add(9, "555");   //Other Services[Urgent Care]
                HashtableMedicalInNetwork1.Add(10, "184");  //Emergency Room
                HashtableMedicalInNetwork1.Add(11, "409");  //Hospital/Facility[Outpatient Care]
                HashtableMedicalInNetwork1.Add(12, "295");  //Hospital/Facility[Inpatient Care]
                HashtableMedicalInNetwork1.Add(13, "971");            //Other Services[Complex Radiology]
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedicalOutNetwork.Add(1, "112");   //Out-of-Network Benefits[Coinsurance]

                #endregion

                int count = 1;
                string InNetwork_Indivisual_Plan1 = string.Empty;
                string InNetwork_Family_Plan1 = string.Empty;
                string OutOfPocket_Individual_Plan1 = string.Empty;
                string OutOfPocket_Family_Plan1 = string.Empty;
                string InNetwork_Coinsurance_Plan1 = string.Empty;
                string InNetwork_PreventiveCare_Plan1 = string.Empty;
                string InNetwork_Office_Visit_Plan1 = string.Empty;
                string InNetwork_XRay_And_LabTest_Plan1 = string.Empty;
                string InNetwork_cardio_Plan1 = string.Empty;
                string InNetwork_Urgent_Care_Plan1 = string.Empty;
                string InNetwork_Emergency_Plan1 = string.Empty;
                string InNetwork_Outpatient_Plan1 = string.Empty;
                string InNetwork_Inpatient_Plan1 = string.Empty;
                string Medical_Plan_Name_Plan1 = string.Empty;
                string Medical_Carrier_Plan1 = string.Empty;
                string Medical_Summary_Plan1 = string.Empty;

                string InNetwork_Indivisual_Plan2 = string.Empty;
                string InNetwork_Family_Plan2 = string.Empty;
                string OutOfPocket_Individual_Plan2 = string.Empty;
                string OutOfPocket_Family_Plan2 = string.Empty;
                string InNetwork_Coinsurance_Plan2 = string.Empty;
                string InNetwork_PreventiveCare_Plan2 = string.Empty;
                string InNetwork_Office_Visit_Plan2 = string.Empty;
                string InNetwork_XRay_And_LabTest_Plan2 = string.Empty;
                string InNetwork_cardio_Plan2 = string.Empty;
                string InNetwork_Urgent_Care_Plan2 = string.Empty;
                string InNetwork_Emergency_Plan2 = string.Empty;
                string InNetwork_Outpatient_Plan2 = string.Empty;
                string InNetwork_Inpatient_Plan2 = string.Empty;
                string Medical_Plan_Name_Plan2 = string.Empty;
                string Medical_Carrier_Plan2 = string.Empty;
                string Medical_Summary_Plan2 = string.Empty;

                string InNetwork_Indivisual_Plan3 = string.Empty;
                string InNetwork_Family_Plan3 = string.Empty;
                string OutOfPocket_Individual_Plan3 = string.Empty;
                string OutOfPocket_Family_Plan3 = string.Empty;
                string InNetwork_Coinsurance_Plan3 = string.Empty;
                string InNetwork_PreventiveCare_Plan3 = string.Empty;
                string InNetwork_Office_Visit_Plan3 = string.Empty;
                string InNetwork_XRay_And_LabTest_Plan3 = string.Empty;
                string InNetwork_cardio_Plan3 = string.Empty;
                string InNetwork_Urgent_Care_Plan3 = string.Empty;
                string InNetwork_Emergency_Plan3 = string.Empty;
                string InNetwork_Outpatient_Plan3 = string.Empty;
                string InNetwork_Inpatient_Plan3 = string.Empty;
                string Medical_Plan_Name_Plan3 = string.Empty;
                string Medical_Carrier_Plan3 = string.Empty;
                string Medical_Summary_Plan3 = string.Empty;

                string InNetwork_Indivisual_Plan4 = string.Empty;
                string InNetwork_Family_Plan4 = string.Empty;
                string OutOfPocket_Individual_Plan4 = string.Empty;
                string OutOfPocket_Family_Plan4 = string.Empty;
                string InNetwork_Coinsurance_Plan4 = string.Empty;
                string InNetwork_PreventiveCare_Plan4 = string.Empty;
                string InNetwork_Office_Visit_Plan4 = string.Empty;
                string InNetwork_XRay_And_LabTest_Plan4 = string.Empty;
                string InNetwork_cardio_Plan4 = string.Empty;
                string InNetwork_Urgent_Care_Plan4 = string.Empty;
                string InNetwork_Emergency_Plan4 = string.Empty;
                string InNetwork_Outpatient_Plan4 = string.Empty;
                string InNetwork_Inpatient_Plan4 = string.Empty;
                string Medical_Plan_Name_Plan4 = string.Empty;
                string Medical_Carrier_Plan4 = string.Empty;
                string Medical_Summary_Plan4 = string.Empty;

                List<string> carrierlist = new List<string>();

                string medicalcarrier = "";
                string value = string.Empty;
                //double coInsurance_Value = 0;
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (count == 1)
                            {
                                Medical_Plan_Name_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Medical_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Medical_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            if (count == 2)
                            {
                                Medical_Plan_Name_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Medical_Carrier_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Medical_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            if (count == 3)
                            {
                                Medical_Plan_Name_Plan3 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Medical_Carrier_Plan3 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Medical_Summary_Plan3 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            }
                            if (count == 4)
                            {
                                Medical_Plan_Name_Plan4 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Medical_Carrier_Plan4 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Medical_Summary_Plan4 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            #region MedicalTable

                            // Store the value for each attribute in the respective variables by iterating each key fronm hashtable for both the medical plans
                            foreach (int key in HashtableMedicalInNetwork1.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Indivisual_Plan1 = value.Trim_String(); break;
                                                case 2: InNetwork_Family_Plan1 = value.Trim_String(); break;
                                                case 3: OutOfPocket_Individual_Plan1 = value.Trim_String(); break;
                                                case 4: OutOfPocket_Family_Plan1 = value.Trim_String(); break;
                                                case 5: InNetwork_Coinsurance_Plan1 = value.Trim_String(); break;
                                                //    string Str = dr["value"].ToString().Trim();
                                                //    bool isNum = double.TryParse(Str, out coInsurance_Value);
                                                //    if (isNum)
                                                //    {
                                                //    }
                                                //    else
                                                //    {
                                                //        coInsurance_Value = 0;
                                                //    }
                                                //    break;
                                                case 6: InNetwork_PreventiveCare_Plan1 = value.Trim_String(); break;
                                                case 7: InNetwork_Office_Visit_Plan1 = value.Trim_String(); break;
                                                case 8: InNetwork_XRay_And_LabTest_Plan1 = value.Trim_String(); break;
                                                case 9: InNetwork_Urgent_Care_Plan1 = value.Trim_String(); break;
                                                case 10: InNetwork_Emergency_Plan1 = value.Trim_String(); break;
                                                case 11: InNetwork_Outpatient_Plan1 = value.Trim_String(); break;
                                                case 12: InNetwork_Inpatient_Plan1 = value.Trim_String(); break;
                                                case 13: InNetwork_cardio_Plan1 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Indivisual_Plan2 = value.Trim_String(); break;
                                                case 2: InNetwork_Family_Plan2 = value.Trim_String(); break;
                                                case 3: OutOfPocket_Individual_Plan2 = value.Trim_String(); break;
                                                case 4: OutOfPocket_Family_Plan2 = value.Trim_String(); break;
                                                case 5: InNetwork_Coinsurance_Plan2 = value.Trim_String(); break;
                                                case 6: InNetwork_PreventiveCare_Plan2 = value.Trim_String(); break;
                                                case 7: InNetwork_Office_Visit_Plan2 = value.Trim_String(); break;
                                                case 8: InNetwork_XRay_And_LabTest_Plan2 = value.Trim_String(); break;
                                                case 9: InNetwork_Urgent_Care_Plan2 = value.Trim_String(); break;
                                                case 10: InNetwork_Emergency_Plan2 = value.Trim_String(); break;
                                                case 11: InNetwork_Outpatient_Plan2 = value.Trim_String(); break;
                                                case 12: InNetwork_Inpatient_Plan2 = value.Trim_String(); break;
                                                case 13: InNetwork_cardio_Plan2 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Indivisual_Plan3 = value.Trim_String(); break;
                                                case 2: InNetwork_Family_Plan3 = value.Trim_String(); break;
                                                case 3: OutOfPocket_Individual_Plan3 = value.Trim_String(); break;
                                                case 4: OutOfPocket_Family_Plan3 = value.Trim_String(); break;
                                                case 5: InNetwork_Coinsurance_Plan3 = value.Trim_String(); break;
                                                case 6: InNetwork_PreventiveCare_Plan3 = value.Trim_String(); break;
                                                case 7: InNetwork_Office_Visit_Plan3 = value.Trim_String(); break;
                                                case 8: InNetwork_XRay_And_LabTest_Plan3 = value.Trim_String(); break;
                                                case 9: InNetwork_Urgent_Care_Plan3 = value.Trim_String(); break;
                                                case 10: InNetwork_Emergency_Plan3 = value.Trim_String(); break;
                                                case 11: InNetwork_Outpatient_Plan3 = value.Trim_String(); break;
                                                case 12: InNetwork_Inpatient_Plan3 = value.Trim_String(); break;
                                                case 13: InNetwork_cardio_Plan3 = value.Trim_String(); break;
                                            }
                                        }

                                        if (count == 4)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Indivisual_Plan4 = value.Trim_String(); break;
                                                case 2: InNetwork_Family_Plan4 = value.Trim_String(); break;
                                                case 3: OutOfPocket_Individual_Plan4 = value.Trim_String(); break;
                                                case 4: OutOfPocket_Family_Plan4 = value.Trim_String(); break;
                                                case 5: InNetwork_Coinsurance_Plan4 = value.Trim_String(); break;
                                                case 6: InNetwork_PreventiveCare_Plan4 = value.Trim_String(); break;
                                                case 7: InNetwork_Office_Visit_Plan4 = value.Trim_String(); break;
                                                case 8: InNetwork_XRay_And_LabTest_Plan4 = value.Trim_String(); break;
                                                case 9: InNetwork_Urgent_Care_Plan4 = value.Trim_String(); break;
                                                case 10: InNetwork_Emergency_Plan4 = value.Trim_String(); break;
                                                case 11: InNetwork_Outpatient_Plan4 = value.Trim_String(); break;
                                                case 12: InNetwork_Inpatient_Plan4 = value.Trim_String(); break;
                                                case 13: InNetwork_cardio_Plan4 = value.Trim_String(); break;
                                            }
                                        }
                                    }
                                }
                            }


                            #endregion

                            medicalcarrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            count++;
                        }
                    }
                }

                // Iterate through each slide for putting the attribute values for respective fields
                #region MergeField
                carrierName = objCommFun.GetCarrierList("\n", Medical_Carrier_Plan1, Medical_Carrier_Plan2, Medical_Carrier_Plan3, Medical_Carrier_Plan4);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            objSlides = objPres.Slides;

                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                    {
                                        // If shape is table then iterate through each row and each column 
                                        // and find the attribute name and replace it with respective value

                                        # region Medical contribution Table
                                        /*
                                        if (objShapes[j].Name.ToString().Equals("Medical_Rate_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Plan_Name_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Plan_Name_Plan2);
                                                    }
                                                }
                                            }
                                        }*/
                                        # endregion Medical contribution Table

                                        #region HRA table
                                        if (objShapes[j].Name.ToString().Equals("HRA Table") || objShapes[j].Name.ToString().Equals("HSA Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    if (txtRange.Text.Contains("<<First Medical Plan Carrier Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Carrier Name>>", Medical_Carrier_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Individual>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual>>", InNetwork_Indivisual_Plan1.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Family>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family>>", InNetwork_Family_Plan1.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Coinsurance>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance>>", InNetwork_Coinsurance_Plan1 + " in most cases");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance>>", " ");
                                                        }
                                                    }
                                                }
                                            }
                                        }


                                        #endregion

                                        if (objShapes[j].Name.ToString().Equals("Medical_Plan_Table_1"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    #region Summary Names
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name Delete>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name Delete>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(Medical_Plan_Name_Plan2))
                                                        {
                                                            txtRange.Replace("<<Second Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan2);
                                                        }
                                                    }

                                                    if (txtRange.Text.Contains("<<Third Medical Plan Summary Name Delete>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(Medical_Plan_Name_Plan3))
                                                        {
                                                            txtRange.Replace("<<Third Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan3);
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Fourth Medical Plan Summary Name Delete>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(Medical_Plan_Name_Plan4))
                                                        {
                                                            txtRange.Replace("<<Fourth Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan4);
                                                        }
                                                    }
                                                    #endregion Summary Names

                                                    #region Annual Deducteble INdivisual/Family for all 4 Plans
                                                    if (txtRange.Text.Contains("<<Annual ded/Individual>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual>>", InNetwork_Indivisual_Plan1.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Family>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family>>", InNetwork_Family_Plan1.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Individual2>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual2>>", InNetwork_Indivisual_Plan2.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Family2>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family2>>", InNetwork_Family_Plan2.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Individual3>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan3.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual3>>", InNetwork_Indivisual_Plan3.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual3>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Family3>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan3.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family3>>", InNetwork_Family_Plan3.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family3>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Individual4>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan4.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual4>>", InNetwork_Indivisual_Plan4.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual4>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Family4>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan4.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family4>>", InNetwork_Family_Plan4.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family4>>", " ");
                                                        }
                                                    }

                                                    #endregion Annual Deducteble INdivisual/Family for all 4 Plans

                                                    #region Annual Out-of Pocket Limit/Individual and Limit/Family for all 4 plans
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Individual>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual>>", OutOfPocket_Individual_Plan1);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Individual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual>>", OutOfPocket_Individual_Plan1.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Family>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of-Pocket Limit/Family>>", OutOfPocket_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family>>", OutOfPocket_Family_Plan1.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Individual2>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Individual2>>", OutOfPocket_Individual_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Individual_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual2>>", OutOfPocket_Individual_Plan2.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Family2>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Family2>>", OutOfPocket_Family_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Family_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family2>>", OutOfPocket_Family_Plan2.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Individual3>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Individual2>>", OutOfPocket_Individual_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Individual_Plan3.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual3>>", OutOfPocket_Individual_Plan3.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual3>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Family3>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Family2>>", OutOfPocket_Family_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Family_Plan3.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family3>>", OutOfPocket_Family_Plan3.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family3>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Individual4>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Individual2>>", OutOfPocket_Individual_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Individual_Plan4.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual4>>", OutOfPocket_Individual_Plan4.Trim() + " per individual");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual4>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Family4>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Family2>>", OutOfPocket_Family_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Family_Plan4.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family4>>", OutOfPocket_Family_Plan4.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family4>>", " ");
                                                        }
                                                    }

                                                    #endregion Annual Out-of Pocket Limit/Individual and Limit/Family for all 4 plans

                                                    #region General Plan Info – Coinsurance For all 4 Plans

                                                    if (txtRange.Text.Contains("<<General Plan Info – Coinsurance>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance>>", InNetwork_Coinsurance_Plan1 + " in most cases");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Coinsurance2>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance2>>", InNetwork_Coinsurance_Plan2 + " in most cases");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Coinsurance3>>"))
                                                    {

                                                        if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan3.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance3>>", InNetwork_Coinsurance_Plan3 + " in most cases");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance3>>", " ");
                                                        }
                                                    }

                                                    if (txtRange.Text.Contains("<<General Plan Info – Coinsurance4>>"))
                                                    {

                                                        if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan4.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance4>>", InNetwork_Coinsurance_Plan4 + " in most cases");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance4>>", " ");
                                                        }
                                                    }
                                                    #endregion General Plan Info – Coinsurance For all 4 Plans

                                                    #region General Plan Info – Office Visit/Exam
                                                    if (txtRange.Text.Contains("<<General Plan Info – Office Visit/Exam>>"))
                                                    {
                                                        txtRange.Replace("<<General Plan Info – Office Visit/Exam>>", InNetwork_Office_Visit_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Office Visit/Exam2>>"))
                                                    {
                                                        txtRange.Replace("<<General Plan Info – Office Visit/Exam2>>", InNetwork_Office_Visit_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Office Visit/Exam3>>"))
                                                    {
                                                        txtRange.Replace("<<General Plan Info – Office Visit/Exam3>>", InNetwork_Office_Visit_Plan3.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Office Visit/Exam4>>"))
                                                    {
                                                        txtRange.Replace("<<General Plan Info – Office Visit/Exam4>>", InNetwork_Office_Visit_Plan4.Trim());
                                                    }
                                                    #endregion General Plan Info – Office Visit/Exam

                                                    #region Outpatient Services – Diagnostic X-Ray and Lab Tests
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Diagnostic X-Ray and Lab Tests>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Diagnostic X-Ray and Lab Tests>>", InNetwork_XRay_And_LabTest_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Diagnostic X-Ray and Lab Tests2>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Diagnostic X-Ray and Lab Tests2>>", InNetwork_XRay_And_LabTest_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Diagnostic X-Ray and Lab Tests3>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Diagnostic X-Ray and Lab Tests3>>", InNetwork_XRay_And_LabTest_Plan3.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Diagnostic X-Ray and Lab Tests4>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Diagnostic X-Ray and Lab Tests4>>", InNetwork_XRay_And_LabTest_Plan4.Trim());
                                                    }
                                                    #endregion Outpatient Services – Diagnostic X-Ray and Lab Tests
                                                    #region Outpatient Services – Complex Radiology
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Complex Radiology>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Complex Radiology>>", InNetwork_cardio_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Complex Radiology2>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Complex Radiology2>>", InNetwork_cardio_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Complex Radiology3>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Complex Radiology3>>", InNetwork_cardio_Plan3.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Complex Radiology4>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Complex Radiology4>>", InNetwork_cardio_Plan4.Trim());
                                                    }
                                                    #endregion
                                                    #region Emergency Services – Emergency Room
                                                    if (txtRange.Text.Contains("<<Emergency Services – Emergency Room>>"))
                                                    {
                                                        txtRange.Replace("<<Emergency Services – Emergency Room>>", InNetwork_Emergency_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Emergency Services – Emergency Room2>>"))
                                                    {
                                                        txtRange.Replace("<<Emergency Services – Emergency Room2>>", InNetwork_Emergency_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Emergency Services – Emergency Room3>>"))
                                                    {
                                                        txtRange.Replace("<<Emergency Services – Emergency Room3>>", InNetwork_Emergency_Plan3.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Emergency Services – Emergency Room4>>"))
                                                    {
                                                        txtRange.Replace("<<Emergency Services – Emergency Room4>>", InNetwork_Emergency_Plan4.Trim());
                                                    }

                                                    #endregion Emergency Services – Emergency Room

                                                    #region Inpatient Hospital Services – Inpatient Hospitalization
                                                    if (txtRange.Text.Contains("<<Inpatient Hospital Services – Inpatient Hospitalization>>"))
                                                    {
                                                        txtRange.Replace("<<Inpatient Hospital Services – Inpatient Hospitalization>>", InNetwork_Inpatient_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Inpatient Hospital Services – Inpatient Hospitalization2>>"))
                                                    {
                                                        txtRange.Replace("<<Inpatient Hospital Services – Inpatient Hospitalization2>>", InNetwork_Inpatient_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Inpatient Hospital Services – Inpatient Hospitalization3>>"))
                                                    {
                                                        txtRange.Replace("<<Inpatient Hospital Services – Inpatient Hospitalization3>>", InNetwork_Inpatient_Plan3.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Inpatient Hospital Services – Inpatient Hospitalization4>>"))
                                                    {
                                                        txtRange.Replace("<<Inpatient Hospital Services – Inpatient Hospitalization4>>", InNetwork_Inpatient_Plan4.Trim());
                                                    }
                                                    #endregion Inpatient Hospital Services – Inpatient Hospitalization

                                                }
                                            }
                                        }
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape && !objShapes[j].Name.Contains("Rectangle")))
                                    {

                                    }
                                    else
                                    {
                                        if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                                        {
                                            break;
                                        }

                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<Medical Carrier Name>>"))
                                        {
                                            txtRange.Replace("<<Medical Carrier Name>>", carrierName);
                                        }
                                        if (txtRange.Text.Contains("<<First Medical Carrier Name>>"))
                                        {
                                            txtRange.Replace("<<First Medical Carrier Name>>", Medical_Carrier_Plan1);
                                        }

                                        if (txtRange.Text.Contains("<<First Medical Plan Carrier Name1>>"))
                                        {
                                            txtRange.Replace("<<First Medical Plan Carrier Name1>>", Medical_Carrier_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<Medical Plan Benefit Summary Name>>"))
                                        {
                                            txtRange.Replace("<<Medical Plan Benefit Summary Name>>", Medical_Summary_Plan1);
                                        }

                                        if (txtRange.Text.Contains("<<Footer_Year>>"))
                                        {
                                            txtRange.Replace("<<Footer_Year>>", DateTime.Today.Year.ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        public void WritePrescriptionDrugsSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string deductible_Plan1 = "";
                string Generic_Plan1 = "";
                string Formulary_Plan1 = "";
                string NonFormulary_Plan1 = "";
                string PreferredSpecialty_plan1 = "";

                string deductible_Plan2 = "";
                string Generic_Plan2 = "";
                string Formulary_Plan2 = "";
                string NonFormulary_Plan2 = "";
                string PreferredSpecialty_plan2 = "";

                string deductible_Plan3 = "";
                string Generic_Plan3 = "";
                string Formulary_Plan3 = "";
                string NonFormulary_Plan3 = "";
                string PreferredSpecialty_plan3 = "";

                string deductible_Plan4 = "";
                string Generic_Plan4 = "";
                string Formulary_Plan4 = "";
                string NonFormulary_Plan4 = "";
                string PreferredSpecialty_plan4 = "";

                #region Mail Order Variable
                string Mandetory_Mailorder_Plan1 = "";
                string Generic_Mailorder_Plan1 = "";
                string Formulary_Mailorder_Plan1 = "";
                string NonFormulary_Mailorder_Plan1 = "";
                string PreferredSpecialty_Mailorder_plan1 = "";

                string Mandetory_Mailorder_Plan2 = "";
                string Generic_Mailorder_Plan2 = "";
                string Formulary_Mailorder_Plan2 = "";
                string NonFormulary_Mailorder_Plan2 = "";
                string PreferredSpecialty_Mailorder_plan2 = "";

                string Mandetory_Mailorder_Plan3 = "";
                string Generic_Mailorder_Plan3 = "";
                string Formulary_Mailorder_Plan3 = "";
                string NonFormulary_Mailorder_Plan3 = "";
                string PreferredSpecialty_Mailorder_plan3 = "";

                string Mandetory_Mailorder_Plan4 = "";
                string Generic_Mailorder_Plan4 = "";
                string Formulary_Mailorder_Plan4 = "";
                string NonFormulary_Mailorder_Plan4 = "";
                string PreferredSpecialty_Mailorder_plan4 = "";
                #endregion

                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213"); //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");  //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");  //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "578"); //Deductible[Individual]
                HashtablePrescriptionDrugs.Add(5, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211"); //Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");  //Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");  //Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "578"); //Deductible[Individual]
                HashtableMailOrder.Add(5, "579");    //Mail Order[Mandetory]
                HashtableMailOrder.Add(6, "884");    //Mail Order[Preferred Specialty]
                #endregion

                string Medical_Plan_Name_Plan1 = string.Empty;
                string Medical_Summary_Plan1 = string.Empty;

                string Medical_Plan_Name_Plan2 = string.Empty;
                string Medical_Summary_Plan2 = string.Empty;

                string Medical_Plan_Name_Plan3 = string.Empty;
                string Medical_Summary_Plan3 = string.Empty;

                string Medical_Plan_Name_Plan4 = string.Empty;
                string Medical_Summary_Plan4 = string.Empty;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            Medical_Plan_Name_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                            Medical_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Plan1 = value.Trim_String(); break;
                                                case 2: Formulary_Plan1 = value.Trim_String(); break;
                                                case 3: NonFormulary_Plan1 = value.Trim_String(); break;
                                                case 4: deductible_Plan1 = value.Trim_String(); break;
                                                case 5: PreferredSpecialty_plan1 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            Medical_Plan_Name_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                            Medical_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Plan2 = value.Trim_String(); break;
                                                case 2: Formulary_Plan2 = value.Trim_String(); break;
                                                case 3: NonFormulary_Plan2 = value.Trim_String(); break;
                                                case 4: deductible_Plan2 = value.Trim_String(); break;
                                                case 5: PreferredSpecialty_plan2 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            Medical_Plan_Name_Plan3 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                            Medical_Summary_Plan3 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Plan3 = value.Trim_String(); break;
                                                case 2: Formulary_Plan3 = value.Trim_String(); break;
                                                case 3: NonFormulary_Plan3 = value.Trim_String(); break;
                                                case 4: deductible_Plan3 = value.Trim_String(); break;
                                                case 5: PreferredSpecialty_plan3 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 4)
                                        {
                                            Medical_Plan_Name_Plan4 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                            Medical_Summary_Plan4 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Plan4 = value.Trim_String(); break;
                                                case 2: Formulary_Plan4 = value.Trim_String(); break;
                                                case 3: NonFormulary_Plan4 = value.Trim_String(); break;
                                                case 4: deductible_Plan4 = value.Trim_String(); break;
                                                case 5: PreferredSpecialty_plan4 = value.Trim_String(); break;
                                            }
                                        }

                                    }
                                }
                            }
                            #region Mail Order
                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Mailorder_Plan1 = value.Trim_String(); break;
                                                case 2: Formulary_Mailorder_Plan1 = value.Trim_String(); break;
                                                case 3: NonFormulary_Mailorder_Plan1 = value.Trim_String(); break;
                                                case 4: Mandetory_Mailorder_Plan1 = value.Trim_String(); break;
                                                case 6: PreferredSpecialty_Mailorder_plan1 = value.Trim_String(); break;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Mailorder_Plan2 = value.Trim_String(); break;
                                                case 2: Formulary_Mailorder_Plan2 = value.Trim_String(); break;
                                                case 3: NonFormulary_Mailorder_Plan2 = value.Trim_String(); break;
                                                case 4: Mandetory_Mailorder_Plan2 = value.Trim_String(); break;
                                                case 6: PreferredSpecialty_Mailorder_plan2 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Mailorder_Plan3 = value.Trim_String(); break;
                                                case 2: Formulary_Mailorder_Plan3 = value.Trim_String(); break;
                                                case 3: NonFormulary_Mailorder_Plan3 = value.Trim_String(); break;
                                                case 4: Mandetory_Mailorder_Plan3 = value.Trim_String(); break;
                                                case 6: PreferredSpecialty_Mailorder_plan3 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 4)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Mailorder_Plan4 = value.Trim_String(); break;
                                                case 2: Formulary_Mailorder_Plan4 = value.Trim_String(); break;
                                                case 3: NonFormulary_Mailorder_Plan4 = value.Trim_String(); break;
                                                case 4: Mandetory_Mailorder_Plan4 = value.Trim_String(); break;
                                                case 6: PreferredSpecialty_Mailorder_plan4 = value.Trim_String(); break;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion Mail Order
                            count++;

                            value = "";
                        }
                    }
                }

                #region Merge Fields
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                    {
                                        // If shape is table then iterate through each row and each column 
                                        // and find the attribute name and replace it with respective value
                                        if (objShapes[j].Name.ToString().Equals("Medical_Prescription_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    #region Summary Names
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name Delete>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name Delete>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(Medical_Plan_Name_Plan2))
                                                        {
                                                            txtRange.Replace("<<Second Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan2);
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Third Medical Plan Summary Name Delete>>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(Medical_Plan_Name_Plan3))
                                                        {
                                                            txtRange.Replace("<<Third Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan3);
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Fourth Medical Plan Summary Name Delete>"))
                                                    {
                                                        if (!string.IsNullOrEmpty(Medical_Plan_Name_Plan4))
                                                        {
                                                            txtRange.Replace("<<Fourth Medical Plan Summary Name Delete>>", Medical_Plan_Name_Plan4);
                                                        }
                                                    }
                                                    #endregion Summary Names

                                                    #region Prescription Drug Benefits – Prescription Drug Deductible

                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Prescription Drug Deductible>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Prescription Drug Deductible>>", deductible_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Prescription Drug Deductible2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Prescription Drug Deductible2>>", deductible_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Prescription Drug Deductible3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Prescription Drug Deductible3>>", deductible_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Prescription Drug Deductible4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Prescription Drug Deductible4>>", deductible_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Prescription Drug Deductible

                                                    #region Prescription Drug Benefits – Generic

                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic>>", Generic_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic2>>", Generic_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic3>>", Generic_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic4>>", Generic_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Generic

                                                    #region Prescription Drug Benefits – Brand (Formulary/Preferred
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred>>", Formulary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred2>>", Formulary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred3>>", Formulary_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred4>>", Formulary_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Brand (Formulary/Preferred

                                                    #region Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred>>", NonFormulary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred2>>", NonFormulary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred3>>", NonFormulary_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred4>>", NonFormulary_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred
                                                    #region Prescription Drug Benefits – PreferredSpecialty
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty1>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty1>>", PreferredSpecialty_plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty2>>", PreferredSpecialty_plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty3>>", PreferredSpecialty_plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty4>>", PreferredSpecialty_plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – PreferredSpecialty

                                                    #region Write  Mail Order
                                                    #region Prescription Drug Benefits – Mail Order – Mail Order Mandatory
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory>>", Mandetory_Mailorder_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory2>>", Mandetory_Mailorder_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory3>>", Mandetory_Mailorder_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Mail Order – Mail Order Mandatory4>>", Mandetory_Mailorder_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Mail Order – Mail Order Mandatory

                                                    #region Prescription Drug Benefits – Generic-Mail Order
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic-Mail Order>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic-Mail Order>>", Generic_Mailorder_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic-Mail Order2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic-Mail Order2>>", Generic_Mailorder_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic-Mail Order3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic-Mail Order3>>", Generic_Mailorder_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic-Mail Order4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic-Mail Order4>>", Generic_Mailorder_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Generic-Mail Order

                                                    #region Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order>>", Formulary_Mailorder_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order2>>", Formulary_Mailorder_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order3>>", Formulary_Mailorder_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order4>>", Formulary_Mailorder_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Brand (Formulary/Preferred-Mail Order

                                                    #region Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder>>", NonFormulary_Mailorder_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder2>>", NonFormulary_Mailorder_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder3>>", NonFormulary_Mailorder_Plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder4>>", NonFormulary_Mailorder_Plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred-MailOrder
                                                    #region Prescription Drug Benefits – PreferredSpecialty-MailOrder
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder1>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder1>>", PreferredSpecialty_Mailorder_plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder2>>", PreferredSpecialty_Mailorder_plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder3>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder3>>", PreferredSpecialty_Mailorder_plan3);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder4>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – PreferredSpecialty-MailOrder4>>", PreferredSpecialty_Mailorder_plan4);
                                                    }
                                                    #endregion Prescription Drug Benefits – PreferredSpecialty-MailOrder
                                                    #endregion Write  Mail Order

                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="DentalBenefitColumnIdOutNetworkList">DentalBenefitColumnIdOutNetworkList contain out Network Benefit ColumnId for Dental Plan</param>
        public void WriteDentalSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                string carrierName = string.Empty;
                DataRow[] foundRows = null;

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(1, "45");      //Annual Deductible[Individual]
                HashtableDentalInNetwork.Add(2, "55");      //Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(3, "566");     //Deductible waived for Preventive
                HashtableDentalInNetwork.Add(4, "64");      //Basic Restorative Care - Basic 
                HashtableDentalInNetwork.Add(5, "336");     //Major Restorative Care - Major
                HashtableDentalInNetwork.Add(6, "392");     //Orthodontic Services
                HashtableDentalInNetwork.Add(7, "314");     //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDentalInNetwork.Add(8, "565");     //Additional Features[Waiting Periods]
                HashtableDentalInNetwork.Add(9, "44");      //Annual Deductible[Family]
                HashtableDentalInNetwork.Add(10, "164");    //Dental Categories[Preventive & Diagnostic Care]

                #endregion
                int count = 1;

                string value = "";

                string InNetwork_Calendar_Year_Deductible_Individual_Plan1 = string.Empty;
                string InNetwork_Calendar_Year_Deductible_Family_Plan1 = string.Empty;
                string InNetwork_Calendar_Year_Benefit_Maximum_Plan1 = string.Empty;
                string InNetwork_Preventive_Care_Waived_Plan1 = string.Empty;
                string InNetwork_Basic_Services_Plan1 = string.Empty;
                string InNetwork_Major_Services_Plan1 = string.Empty;
                string InNetwork_Orthodontia_Plan1 = string.Empty;
                string InNetwork_Orthodontia_Maximum_Plan1 = string.Empty;
                string InNetwork_Waiting_Periods_Plan1 = string.Empty;
                string InNetwork_Preventive_And_Diagnostic_Care_Plan1 = string.Empty;

                string Dental_Plan_1 = string.Empty;
                string Dental_Carrier_Plan1 = string.Empty;
                string Dental_Summary_Plan1 = string.Empty;

                string Dental_Plan_2 = string.Empty;
                string Dental_Carrier_Plan2 = string.Empty;
                string Dental_Summary_Plan2 = string.Empty;

                string Dental_Plan_3 = string.Empty;
                string Dental_Carrier_Plan3 = string.Empty;
                string Dental_Summary_Plan3 = string.Empty;

                string Dental_Plan_4 = string.Empty;
                string Dental_Carrier_Plan4 = string.Empty;
                string Dental_Summary_Plan4 = string.Empty;

                string InNetwork_Calendar_Year_Deductible_Individual_Plan2 = string.Empty;
                string InNetwork_Calendar_Year_Deductible_Family_Plan2 = string.Empty;
                string InNetwork_Calendar_Year_Benefit_Maximum_Plan2 = string.Empty;
                string InNetwork_Preventive_Care_Waived_Plan2 = string.Empty;
                string InNetwork_Basic_Services_Plan2 = string.Empty;
                string InNetwork_Major_Services_Plan2 = string.Empty;
                string InNetwork_Orthodontia_Plan2 = string.Empty;
                string InNetwork_Orthodontia_Maximum_Plan2 = string.Empty;
                string InNetwork_Waiting_Periods_Plan2 = string.Empty;
                string InNetwork_Preventive_And_Diagnostic_Care_Plan2 = string.Empty;

                string InNetwork_Calendar_Year_Deductible_Individual_Plan3 = string.Empty;
                string InNetwork_Calendar_Year_Deductible_Family_Plan3 = string.Empty;
                string InNetwork_Calendar_Year_Benefit_Maximum_Plan3 = string.Empty;
                string InNetwork_Preventive_Care_Waived_Plan3 = string.Empty;
                string InNetwork_Basic_Services_Plan3 = string.Empty;
                string InNetwork_Major_Services_Plan3 = string.Empty;
                string InNetwork_Orthodontia_Plan3 = string.Empty;
                string InNetwork_Orthodontia_Maximum_Plan3 = string.Empty;
                string InNetwork_Waiting_Periods_Plan3 = string.Empty;
                string InNetwork_Preventive_And_Diagnostic_Care_Plan3 = string.Empty;

                string InNetwork_Calendar_Year_Deductible_Individual_Plan4 = string.Empty;
                string InNetwork_Calendar_Year_Deductible_Family_Plan4 = string.Empty;
                string InNetwork_Calendar_Year_Benefit_Maximum_Plan4 = string.Empty;
                string InNetwork_Preventive_Care_Waived_Plan4 = string.Empty;
                string InNetwork_Basic_Services_Plan4 = string.Empty;
                string InNetwork_Major_Services_Plan4 = string.Empty;
                string InNetwork_Orthodontia_Plan4 = string.Empty;
                string InNetwork_Orthodontia_Maximum_Plan4 = string.Empty;
                string InNetwork_Waiting_Periods_Plan4 = string.Empty;
                string InNetwork_Preventive_And_Diagnostic_Care_Plan4 = string.Empty;

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (count == 1)
                            {
                                Dental_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Dental_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                Dental_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 2)
                            {
                                Dental_Plan_2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Dental_Carrier_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                Dental_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 3)
                            {
                                Dental_Plan_3 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Dental_Carrier_Plan3 = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                Dental_Summary_Plan3 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 4)
                            {
                                Dental_Plan_4 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Dental_Carrier_Plan4 = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                Dental_Summary_Plan4 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }

                            #region DentalTable

                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 1: InNetwork_Calendar_Year_Deductible_Individual_Plan1 = value.Trim_String(); break;
                                                case 2: InNetwork_Calendar_Year_Benefit_Maximum_Plan1 = value.Trim_String(); break;
                                                case 3: InNetwork_Preventive_Care_Waived_Plan1 = value.Trim_String(); break;
                                                case 4: InNetwork_Basic_Services_Plan1 = value.Trim_String(); break;
                                                case 5: InNetwork_Major_Services_Plan1 = value.Trim_String(); break;
                                                case 6: InNetwork_Orthodontia_Plan1 = value.Trim_String(); break;
                                                case 7: InNetwork_Orthodontia_Maximum_Plan1 = value.Trim_String(); break;
                                                case 8: InNetwork_Waiting_Periods_Plan1 = value.Trim_String(); break;
                                                case 9: InNetwork_Calendar_Year_Deductible_Family_Plan1 = value.Trim_String(); break;
                                                case 10: InNetwork_Preventive_And_Diagnostic_Care_Plan1 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 1: InNetwork_Calendar_Year_Deductible_Individual_Plan2 = value.Trim_String(); break;
                                                case 2: InNetwork_Calendar_Year_Benefit_Maximum_Plan2 = value.Trim_String(); break;
                                                case 3: InNetwork_Preventive_Care_Waived_Plan2 = value.Trim_String(); break;
                                                case 4: InNetwork_Basic_Services_Plan2 = value.Trim_String(); break;
                                                case 5: InNetwork_Major_Services_Plan2 = value.Trim_String(); break;
                                                case 6: InNetwork_Orthodontia_Plan2 = value; break;
                                                case 7: InNetwork_Orthodontia_Maximum_Plan2 = value.Trim_String(); break;
                                                case 8: InNetwork_Waiting_Periods_Plan2 = value.Trim_String(); break;
                                                case 9: InNetwork_Calendar_Year_Deductible_Family_Plan2 = value.Trim_String(); break;
                                                case 10: InNetwork_Preventive_And_Diagnostic_Care_Plan2 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 1: InNetwork_Calendar_Year_Deductible_Individual_Plan3 = value.Trim_String(); break;
                                                case 2: InNetwork_Calendar_Year_Benefit_Maximum_Plan3 = value.Trim_String(); break;
                                                case 3: InNetwork_Preventive_Care_Waived_Plan3 = value.Trim_String(); break;
                                                case 4: InNetwork_Basic_Services_Plan3 = value.Trim_String(); break;
                                                case 5: InNetwork_Major_Services_Plan3 = value.Trim_String(); break;
                                                case 6: InNetwork_Orthodontia_Plan3 = value; break;
                                                case 7: InNetwork_Orthodontia_Maximum_Plan3 = value.Trim_String(); break;
                                                case 8: InNetwork_Waiting_Periods_Plan3 = value.Trim_String(); break;
                                                case 9: InNetwork_Calendar_Year_Deductible_Family_Plan3 = value.Trim_String(); break;
                                                case 10: InNetwork_Preventive_And_Diagnostic_Care_Plan3 = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 4)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 1: InNetwork_Calendar_Year_Deductible_Individual_Plan4 = value.Trim_String(); break;
                                                case 2: InNetwork_Calendar_Year_Benefit_Maximum_Plan4 = value.Trim_String(); break;
                                                case 3: InNetwork_Preventive_Care_Waived_Plan4 = value.Trim_String(); break;
                                                case 4: InNetwork_Basic_Services_Plan4 = value.Trim_String(); break;
                                                case 5: InNetwork_Major_Services_Plan4 = value.Trim_String(); break;
                                                case 6: InNetwork_Orthodontia_Plan4 = value; break;
                                                case 7: InNetwork_Orthodontia_Maximum_Plan4 = value.Trim_String(); break;
                                                case 8: InNetwork_Waiting_Periods_Plan4 = value.Trim_String(); break;
                                                case 9: InNetwork_Calendar_Year_Deductible_Family_Plan4 = value.Trim_String(); break;
                                                case 10: InNetwork_Preventive_And_Diagnostic_Care_Plan4 = value.Trim_String(); break;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            count++;
                        }
                    }
                }

                // Iterate through each slide for putting the attribute values for respective fields
                #region MergeField

                carrierName = objCommFun.GetCarrierList("\n", Dental_Carrier_Plan1, Dental_Carrier_Plan2, Dental_Carrier_Plan3, Dental_Carrier_Plan4);
                objSlides = objPres.Slides;

                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;

                    //if (objSlides[i].SlideNumber == 39 || objSlides[i].SlideNumber == 40 || objSlides[i].SlideNumber == 41 || objSlides[i].SlideNumber == 42 || objSlides[i].SlideNumber == 43)
                    //{
                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            // If shape is table then iterate through each row and each column 
                            // and find the attribute name and replace it with respective value

                            if (objShapes[j].Name.ToString().Equals("Dental_Plan_1_Table"))
                            {
                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                {
                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                    {
                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                        txtRange = txtFrame.TextRange;
                                        #region Dental Plan 1
                                        if (txtRange.Text.Contains("<<First Dental Plan Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Dental_Plan_1))
                                            {
                                                txtRange.Replace("<<First Dental Plan Summary Name Delete>>", Dental_Plan_1);
                                            }
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual - In>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Individual - In>>", InNetwork_Calendar_Year_Deductible_Individual_Plan1 + " per individual");
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Family- In>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Family- In>>", InNetwork_Calendar_Year_Deductible_Family_Plan1 + " per family");
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max - In>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Plan Max - In>>", InNetwork_Calendar_Year_Benefit_Maximum_Plan1);
                                            continue;
                                        }

                                        if (txtRange.Text.Contains("<<General Plan Info – Preventative Care - In>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Preventative Care - In>>", InNetwork_Preventive_Care_Waived_Plan1);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Diagnostic & Preventive>>"))
                                        {
                                            txtRange.Replace("<<Diagnostic & Preventive>>", InNetwork_Preventive_And_Diagnostic_Care_Plan1);
                                            continue;
                                        }

                                        if (txtRange.Text.Contains("<<Covered Services – Basic - In>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Basic - In>>", InNetwork_Basic_Services_Plan1);
                                            continue;
                                        }

                                        if (txtRange.Text.Contains("<<Covered Services – Major - In>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Major - In>>", InNetwork_Major_Services_Plan1);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max - In>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max - In>>", InNetwork_Orthodontia_Maximum_Plan1);
                                            continue;
                                        }
                                        #endregion

                                        #region Dental Plan 2
                                        if (txtRange.Text.Contains("<<Second Dental Plan Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Dental_Plan_2))
                                            {
                                                txtRange.Replace("<<Second Dental Plan Summary Name Delete>>", Dental_Plan_2);
                                            }
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual – In2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Individual – In2>>", InNetwork_Calendar_Year_Deductible_Individual_Plan2 + " per individual");
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Family- In2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Family- In2>>", InNetwork_Calendar_Year_Deductible_Family_Plan2 + " per family");
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max – In2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Plan Max – In2>>", InNetwork_Calendar_Year_Benefit_Maximum_Plan2);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Preventative Care – In2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Preventative Care – In2>>", InNetwork_Preventive_Care_Waived_Plan2);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Diagnostic & Preventive2>>"))
                                        {
                                            txtRange.Replace("<<Diagnostic & Preventive2>>", InNetwork_Preventive_And_Diagnostic_Care_Plan2);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Basic – In2>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Basic – In2>>", InNetwork_Basic_Services_Plan2);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Major – In2>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Major – In2>>", InNetwork_Major_Services_Plan2);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max – In2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max – In2>>", InNetwork_Orthodontia_Maximum_Plan2);
                                            continue;
                                        }
                                        #endregion

                                        #region Dental Plan 3
                                        if (txtRange.Text.Contains("<<Third Dental Plan Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Dental_Plan_3))
                                            {
                                                txtRange.Replace("<<Third Dental Plan Summary Name Delete>>", Dental_Plan_3);
                                            }
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual – In3>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Individual – In3>>", InNetwork_Calendar_Year_Deductible_Individual_Plan3 + " per individual");
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Family- In3>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Family- In3>>", InNetwork_Calendar_Year_Deductible_Family_Plan3 + " per family");
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max – In3>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Plan Max – In3>>", InNetwork_Calendar_Year_Benefit_Maximum_Plan3);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Preventative Care – In3>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Preventative Care – In3>>", InNetwork_Preventive_Care_Waived_Plan3);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Diagnostic & Preventive3>>"))
                                        {
                                            txtRange.Replace("<<Diagnostic & Preventive3>>", InNetwork_Preventive_And_Diagnostic_Care_Plan3);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Basic – In3>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Basic – In3>>", InNetwork_Basic_Services_Plan3);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Major – In3>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Major – In3>>", InNetwork_Major_Services_Plan3);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max – In3>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max – In3>>", InNetwork_Orthodontia_Maximum_Plan3);
                                            continue;
                                        }
                                        #endregion

                                        #region Dental Plan 4
                                        if (txtRange.Text.Contains("<<Fourth Dental Plan Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Dental_Plan_4))
                                            {
                                                txtRange.Replace("<<Fourth Dental Plan Summary Name Delete>>", Dental_Plan_4);
                                            }
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual – In4>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Individual – In4>>", InNetwork_Calendar_Year_Deductible_Individual_Plan4 + " per individual");
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Family- In4>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Deductible Family- In4>>", InNetwork_Calendar_Year_Deductible_Family_Plan4 + " per family");
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max – In4>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Annual Plan Max – In4>>", InNetwork_Calendar_Year_Benefit_Maximum_Plan4);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Preventative Care – In4>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Preventative Care – In4>>", InNetwork_Preventive_Care_Waived_Plan4);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Diagnostic & Preventive4>>"))
                                        {
                                            txtRange.Replace("<<Diagnostic & Preventive4>>", InNetwork_Preventive_And_Diagnostic_Care_Plan4);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Basic – In4>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Basic – In4>>", InNetwork_Basic_Services_Plan4);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Major – In4>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Major – In4>>", InNetwork_Major_Services_Plan4);
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max – In4>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max – In4>>", InNetwork_Orthodontia_Maximum_Plan4);
                                            continue;
                                        }
                                        #endregion
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }

                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;
                            if (txtRange.Text.Contains("<<Dental Carrier Name>>"))
                            {
                                txtRange.Replace("<<Dental Carrier Name>>", carrierName);
                            }

                            if (txtRange.Text.Contains("<<Delete_Dental>>"))
                            {
                                if (!string.IsNullOrEmpty(Dental_Plan_1))
                                {
                                    txtRange.Replace("<<Delete_Dental>>", " ");
                                }
                            }
                        }
                    }
                    //}
                }
                #endregion
            }

            catch (Exception ex)
            {

                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, ArrayList VisionBenefitColumnIdOutNetworkList, DataTable CarrierSpecific, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                string carrierName = string.Empty;

                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitInNetwork.Add(1, "195");     //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(2, "194");     //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitInNetwork.Add(3, "507");     //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitInNetwork.Add(4, "208");     //Covered Services – Frames
                HashtableVisionBenefitInNetwork.Add(5, "356");     //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefitInNetwork.Add(6, "309");     //General Plan Information – Benefit Frequency – Lenses
                HashtableVisionBenefitInNetwork.Add(7, "207");     //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork.Add(8, "122");     //General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefitInNetwork.Add(9, "344");     //General Plan Information – Copay – Material Deductible

                //HashtableVisionBenefitInNetwork.Add(43, "309");     //General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefitInNetwork.Add(42, "122");     //General Plan Information – Benefit Frequency – Contacts
                //HashtableVisionBenefitInNetwork.Add(4, "207");      //General Plan Information – Benefit Frequency – Frames
                //HashtableVisionBenefitInNetwork.Add(5, "195");      //General Plan Information – Copay – Examination Deductible
                //HashtableVisionBenefitInNetwork.Add(7, "73");       //Covered Services – Lenses – Bifocal Lens
                //HashtableVisionBenefitInNetwork.Add(8, "553");      //Covered Services – Lenses – Trifocal Lens

                ArrayList arrVisionBenefitInNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                {
                    arrVisionBenefitInNetwork.Add(key);
                }

                arrVisionBenefitInNetwork.Sort();
                arrVisionBenefitInNetwork.Reverse();
                #endregion

                string CopayExamination_Plan1 = string.Empty;
                string CopayMaterials_Plan1 = string.Empty;
                string BenefitFrequency_Examination_Plan1 = string.Empty;
                string Single_Vision_Lenses_Plan1 = string.Empty;
                string Covered_Services_Frames_Plan1 = string.Empty;
                string Medically_Necessary_Plan1 = string.Empty;
                string BenefitFrequency_Lenses_Plan1 = string.Empty;
                string BenefitFrequency_Frames_Plan1 = string.Empty;
                string BenefitFrequency_Contacts_Plan1 = string.Empty;
                string Vision_Carrier_Plan1 = string.Empty;
                string Vision_Summary_Plan1 = string.Empty;

                string CopayExamination_Plan2 = string.Empty;
                string CopayMaterials_Plan2 = string.Empty;
                string BenefitFrequency_Examination_Plan2 = string.Empty;
                string Single_Vision_Lenses_Plan2 = string.Empty;
                string Covered_Services_Frames_Plan2 = string.Empty;
                string Medically_Necessary_Plan2 = string.Empty;
                string BenefitFrequency_Lenses_Plan2 = string.Empty;
                string BenefitFrequency_Frames_Plan2 = string.Empty;
                string BenefitFrequency_Contacts_Plan2 = string.Empty;
                string Vision_Carrier_Plan2 = string.Empty;
                string Vision_Summary_Plan2 = string.Empty;

                string Vision_Plan_1 = string.Empty;
                string Vision_Plan_2 = string.Empty;

                int count = 1;

                string value = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            if (count == 1)
                            {
                                Vision_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]; ;
                                Vision_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Vision_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 2)
                            {
                                Vision_Plan_2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]; ;
                                Vision_Carrier_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Vision_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }

                            # region VisionBenefitTable

                            foreach (int key in arrVisionBenefitInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: CopayExamination_Plan1 = value.Trim_String(); break;
                                                case 2: BenefitFrequency_Examination_Plan1 = value.Trim_String(); break;
                                                case 3: Single_Vision_Lenses_Plan1 = value.Trim_String(); break;
                                                case 4: Covered_Services_Frames_Plan1 = value.Trim_String(); break;
                                                case 5: Medically_Necessary_Plan1 = value.Trim_String(); break;
                                                case 6: BenefitFrequency_Lenses_Plan1 = value.Trim_String(); break;
                                                case 7: BenefitFrequency_Frames_Plan1 = value.Trim_String(); break;
                                                case 8: BenefitFrequency_Contacts_Plan1 = value.Trim_String(); break;
                                                case 9: CopayMaterials_Plan1 = value.Trim_String(); break;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: CopayExamination_Plan2 = value.Trim_String(); break;
                                                case 2: BenefitFrequency_Examination_Plan2 = value.Trim_String(); break;
                                                case 3: Single_Vision_Lenses_Plan2 = value.Trim_String(); break;
                                                case 4: Covered_Services_Frames_Plan2 = value.Trim_String(); break;
                                                case 5: Medically_Necessary_Plan2 = value.Trim_String(); break;
                                                case 6: BenefitFrequency_Lenses_Plan2 = value.Trim_String(); break;
                                                case 7: BenefitFrequency_Frames_Plan2 = value.Trim_String(); break;
                                                case 8: BenefitFrequency_Contacts_Plan2 = value.Trim_String(); break;
                                                case 9: CopayMaterials_Plan2 = value.Trim_String(); break;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            count++;
                        }
                    }
                }

                // Iterate through each slide for putting the attribute values for respective fields
                #region merge fields
                carrierName = objCommFun.GetCarrierList("\n", Vision_Carrier_Plan1, Vision_Carrier_Plan2);
                objSlides = objPres.Slides;

                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    //objShapes = mySlide.Shapes;
                    objShapes = objSlides[i].Shapes;

                    //if (objSlides[i].SlideNumber == 44 || objSlides[i].SlideNumber == 45 || objSlides[i].SlideNumber == 46 || objSlides[i].SlideNumber == 47 || objSlides[i].SlideNumber == 48)
                    //{
                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            // If shape is table then iterate through each row and each column 
                            // and find the attribute name and replace it with respective value
                            #region Vision Contribution Table
                            /*
                                if (objShapes[j].Name.ToString().Equals("Vision_Rate_Table"))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First Vision Plan Name>>"))
                                            {
                                                txtRange.Replace("<<First Vision Plan Name>>", Vision_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<Second Vision Plan Name>>"))
                                            {
                                                txtRange.Replace("<<Second Vision Plan Name>>", Vision_Plan_2);
                                            }
                                        }
                                    }
                                }*/
                            #endregion

                            #region For Vision Plan 1
                            if (objShapes[j].Name.ToString().Equals("Vision_Plan_1_Table"))
                            {
                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                {
                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                    {
                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<First Vision Plan Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Vision_Plan_1))
                                            {
                                                objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace("<<First Vision Plan Summary Name Delete>>", Vision_Plan_1);
                                            }
                                        }
                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<General Plan Info – Copay – Examination>>"))
                                        {
                                            objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace("<<General Plan Info – Copay – Examination>>", CopayExamination_Plan1);
                                            continue;
                                        }
                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<Copay / Materials>>"))
                                        {
                                            objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace("<<Copay / Materials>>", CopayMaterials_Plan1);
                                            continue;
                                        }
                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<General Plan Info – Ben Freq – Examination>>"))
                                        {
                                            if (!string.IsNullOrEmpty(BenefitFrequency_Examination_Plan1.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", "Covered every " + BenefitFrequency_Examination_Plan1.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", " ");
                                            }
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Lenses - Single Vision Lens>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Lenses - Single Vision Lens>>", Single_Vision_Lenses_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Lenses>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Single_Vision_Lenses_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan1.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", " every " + BenefitFrequency_Lenses_Plan1.Trim());
                                            }
                                            else if (string.IsNullOrEmpty(Single_Vision_Lenses_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan1.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", BenefitFrequency_Lenses_Plan1.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", " ");
                                            }
                                            continue;
                                        }

                                        if (txtRange.Text.Contains("<<Covered Services – Frames>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Frames>>", Covered_Services_Frames_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Frames>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Covered_Services_Frames_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan1.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", " every " + BenefitFrequency_Frames_Plan1.Trim());
                                            }
                                            else if (string.IsNullOrEmpty(Covered_Services_Frames_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan1.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", BenefitFrequency_Frames_Plan1.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", " ");
                                            }
                                            continue;
                                        }

                                        if (txtRange.Text.Contains("<<Covered Services – Contact Lenses – Medically Necessary>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Contact Lenses – Medically Necessary>>", Medically_Necessary_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Contacts>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Medically_Necessary_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan1.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", " every " + BenefitFrequency_Contacts_Plan1.Trim());
                                            }
                                            else if (string.IsNullOrEmpty(Medically_Necessary_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan1.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", BenefitFrequency_Contacts_Plan1.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", " ");
                                            }
                                            continue;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region For Vision Plan 2
                            if (objShapes[j].Name.ToString().Equals("Vision_Plan_1_Table"))
                            {
                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                {
                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                    {
                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<Second Vision Plan Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Vision_Plan_2))
                                            {
                                                objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace("<<Second Vision Plan Summary Name Delete>>", Vision_Plan_2);
                                            }
                                        }
                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<General Plan Info – Copay – Examination2>>"))
                                        {
                                            objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace("<<General Plan Info – Copay – Examination2>>", CopayExamination_Plan2);
                                            continue;
                                        }
                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<Copay / Materials2>>"))
                                        {
                                            objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace("<<Copay / Materials2>>", CopayMaterials_Plan2);
                                            continue;
                                        }
                                        if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<General Plan Info – Ben Freq – Examination2>>"))
                                        {
                                            if (!string.IsNullOrEmpty(BenefitFrequency_Examination_Plan2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", "Covered every " + BenefitFrequency_Examination_Plan2.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", " ");
                                            }
                                            continue;
                                        }
                                        if (txtRange.Text.Contains("<<Covered Services – Lenses - Single Vision Lens2>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Lenses - Single Vision Lens2>>", Single_Vision_Lenses_Plan2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Lenses2>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Single_Vision_Lenses_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Lenses2>>", " every " + BenefitFrequency_Lenses_Plan2.Trim());
                                            }
                                            else if (string.IsNullOrEmpty(Single_Vision_Lenses_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Lenses2>>", BenefitFrequency_Lenses_Plan2.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Lenses2>>", " ");
                                            }
                                            continue;
                                        }

                                        if (txtRange.Text.Contains("<<Covered Services – Frames2>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Frames2>>", Covered_Services_Frames_Plan2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Frames2>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Covered_Services_Frames_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Frames2>>", " every " + BenefitFrequency_Frames_Plan2.Trim());
                                            }
                                            else if (string.IsNullOrEmpty(Covered_Services_Frames_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Frames2>>", BenefitFrequency_Frames_Plan2.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Frames2>>", " ");
                                            }
                                            continue;
                                        }

                                        if (txtRange.Text.Contains("<<Covered Services – Contact Lenses – Medically Necessary2>>"))
                                        {
                                            txtRange.Replace("<<Covered Services – Contact Lenses – Medically Necessary2>>", Medically_Necessary_Plan2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Contacts2>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Medically_Necessary_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Contacts2>>", " every " + BenefitFrequency_Contacts_Plan2.Trim());
                                            }
                                            else if (string.IsNullOrEmpty(Medically_Necessary_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Contacts2>>", BenefitFrequency_Contacts_Plan2.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Ben Freq – Contacts2>>", " ");
                                            }
                                            continue;
                                        }
                                    }
                                }
                            }
                            #endregion
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }

                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Vision Carrier Name>>"))
                            {
                                txtRange.Replace("<<Vision Carrier Name>>", carrierName);
                            }
                            if (txtRange.Text.Contains("<<Delete_Vision>>"))
                            {
                                if (!string.IsNullOrEmpty(Vision_Plan_1))
                                {
                                    txtRange.Replace("<<Delete_Vision>>", " ");
                                }
                            }
                        }
                    }
                    //}
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ddlClient">ddlClient is used for showing client name in field.</param>
        public void WriteLifeADDToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DataTable CarrierSpecific, DropDownList ddlClient, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, ArrayList GroupTermLifeBenefitColumnIdList = null, ArrayList ADDBenefitColumnIdList = null)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string value = "";
                string Benefit_Amt_Employee = string.Empty;
                string Benefit_Amt_Spouse = string.Empty;
                string Benefit_Amt_Children = string.Empty;

                string Benefit_Amt_Employee2 = string.Empty;
                string Benefit_Amt_Spouse2 = string.Empty;
                string Benefit_Amt_Children2 = string.Empty;

                string Guarantee_IssueAmt_Employee = string.Empty;
                string Guarantee_IssueAmt_Spouse = string.Empty;
                string Guarantee_IssueAmt_Children = string.Empty;

                string Guarantee_IssueAmt_Employee2 = string.Empty;
                string Guarantee_IssueAmt_Spouse2 = string.Empty;
                string Guarantee_IssueAmt_Children2 = string.Empty;

                string Maximum_Benefit_Amt_Employee = string.Empty;
                string Maximum_Benefit_Amt_Spouse = string.Empty;

                string Maximum_Benefit_Amt_Employee2 = string.Empty;
                string Maximum_Benefit_Amt_Spouse2 = string.Empty;

                string Life_Carrier_Plan1 = string.Empty;
                string Life_Summary_Plan1 = string.Empty;
                string Life_Plan_1 = string.Empty;

                string Life_Carrier_Plan2 = string.Empty;
                string Life_Summary_Plan2 = string.Empty;
                string Life_Plan_2 = string.Empty;

                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "186");     //Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(2, "517");     //Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(3, "102");     //Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(4, "187");     //Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(5, "518");     //Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(6, "103");     //Child(ren)[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(7, "188");     //Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(8, "519");     //Spouse[Overall Maximum]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            if (count == 1)
                            {
                                Life_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Life_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Life_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            if (count == 2)
                            {
                                Life_Plan_2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Life_Carrier_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Life_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }

                            #region GroupLifeADDBenifitTable

                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }

                                    if (count == 1)
                                    {
                                        //value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Benefit_Amt_Employee = value.Trim_String(); break;
                                            case 2: Benefit_Amt_Spouse = value.Trim_String(); break;
                                            case 3: Benefit_Amt_Children = value.Trim_String(); break;
                                            case 4: Guarantee_IssueAmt_Employee = value.Trim_String(); break;
                                            case 5: Guarantee_IssueAmt_Spouse = value.Trim_String(); break;
                                            case 6: Guarantee_IssueAmt_Children = value.Trim_String(); break;
                                            case 7: Maximum_Benefit_Amt_Employee = value.Trim_String(); break;
                                            case 8: Maximum_Benefit_Amt_Spouse = value.Trim_String(); break;
                                        }
                                    }

                                    if (count == 2)
                                    {
                                        //value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Benefit_Amt_Employee2 = value.Trim_String(); break;
                                            case 2: Benefit_Amt_Spouse2 = value.Trim_String(); break;
                                            case 3: Benefit_Amt_Children2 = value.Trim_String(); break;
                                            case 4: Guarantee_IssueAmt_Employee2 = value.Trim_String(); break;
                                            case 5: Guarantee_IssueAmt_Spouse2 = value.Trim_String(); break;
                                            case 6: Guarantee_IssueAmt_Children2 = value.Trim_String(); break;
                                            case 7: Maximum_Benefit_Amt_Employee2 = value.Trim_String(); break;
                                            case 8: Maximum_Benefit_Amt_Spouse2 = value.Trim_String(); break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                objShapes = objSlides[i].Shapes;

                                //if (objSlides[i].SlideNumber == 49 || objSlides[i].SlideNumber == 50 || objSlides[i].SlideNumber == 51 || objSlides[i].SlideNumber == 52)
                                //{
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                    }
                                    else
                                    {
                                        if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                                        {
                                            break;
                                        }

                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<First Life AD&D Carrier and Plan Name>>"))
                                        {
                                            //txtRange.Replace("<<First Life AD&D Carrier and Plan Name>>", Life_Carrier_Plan1 + " " + Life_Summary_Plan1);
                                            txtRange.Replace("<<First Life AD&D Carrier and Plan Name>>", Life_Plan_1);
                                        }
                                        if (txtRange.Text.Contains("<<Delete_Life>>"))
                                        {
                                            txtRange.Replace("<<Delete_Life>>", " ");
                                        }
                                        if (count == 2)
                                        {
                                            if (txtRange.Text.Contains("<<Second Delete_Life>>"))
                                            {
                                                txtRange.Replace("<<Second Delete_Life>>", " ");
                                            }
                                        }

                                        #region Employee
                                        #region Life and AD&D Benefit Amount - Employee
                                        if (txtRange.Text.Contains("<<Life and AD&D Benefit Amount - Employee>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Benefit_Amt_Employee.Trim()))
                                            {
                                                txtRange.Replace("<<Life and AD&D Benefit Amount - Employee>>", Benefit_Amt_Employee);
                                            }
                                            //else if(objShapes[j].Name.ToString().Equals("Employee Benefit"))
                                            //{
                                            //objShapes[j].Delete();
                                            //}
                                        }
                                        if (txtRange.Text.Contains("<<Second Life and AD&D Benefit Amount - Employee>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Benefit_Amt_Employee2.Trim()))
                                            {
                                                txtRange.Replace("<<Second Life and AD&D Benefit Amount - Employee>>", Benefit_Amt_Employee2);
                                            }
                                            //else if (objShapes[j].Name.ToString().Equals("Employee Benefit2"))
                                            //{
                                            //    objShapes[j].Delete();
                                            //}
                                        }

                                        #endregion Life and AD&D Benefit Amount - Employee

                                        #region Guarantee Issue Amount - Employee
                                        if (txtRange.Text.Contains("<<Guarantee Issue Amount - Employee>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Guarantee_IssueAmt_Employee.Trim()))
                                            {
                                                txtRange.Replace("<<Guarantee Issue Amount - Employee>>", Guarantee_IssueAmt_Employee);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Guarantee Issue Amount - Employee>>", "");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<Second Guarantee Issue Amount - Employee>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Guarantee_IssueAmt_Employee2.Trim()))
                                            {
                                                txtRange.Replace("<<Second Guarantee Issue Amount - Employee>>", Guarantee_IssueAmt_Employee2);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Second Guarantee Issue Amount - Employee>>", "");
                                            }
                                        }
                                        #endregion Guarantee Issue Amount - Employee

                                        #region Maximum Benefit Amount-Employee
                                        if (txtRange.Text.Contains("<<Maximum Benefit Amount-Employee>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Maximum_Benefit_Amt_Employee.Trim()))
                                            {
                                                txtRange.Replace("<<Maximum Benefit Amount-Employee>>", Maximum_Benefit_Amt_Employee);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Maximum Benefit Amount-Employee>>", "");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<Second Maximum Benefit Amount-Employee>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Maximum_Benefit_Amt_Employee2.Trim()))
                                            {
                                                txtRange.Replace("<<Second Maximum Benefit Amount-Employee>>", Maximum_Benefit_Amt_Employee2);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Second Maximum Benefit Amount-Employee>>", "");
                                            }
                                        }
                                        #endregion Maximum Benefit Amount-Employee

                                        #endregion Employee

                                        #region Spouse

                                        #region Life and AD&D Benefit Amount - Spouse
                                        if (txtRange.Text.Contains("<<Life and AD&D Benefit Amount - Spouse>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Benefit_Amt_Spouse.Trim()))
                                            {
                                                txtRange.Replace("<<Life and AD&D Benefit Amount - Spouse>>", Guarantee_IssueAmt_Spouse);
                                            }
                                            //else if (objShapes[j].Name.ToString().Equals("Spouse Benefit"))
                                            //{
                                            //    objShapes[j].Delete();
                                            //}
                                        }
                                        if (txtRange.Text.Contains("<<Second Life and AD&D Benefit Amount - Spouse>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Benefit_Amt_Spouse2.Trim()))
                                            {
                                                txtRange.Replace("<<Second Life and AD&D Benefit Amount - Spouse>>", Guarantee_IssueAmt_Spouse2);
                                            }
                                            //else if (objShapes[j].Name.ToString().Equals("Spouse Benefit2"))
                                            //{
                                            //    objShapes[j].Delete();
                                            //}
                                        }
                                        #endregion Life and AD&D Benefit Amount - Spouse

                                        #region Guarantee Issue Amount - Spouse
                                        if (txtRange.Text.Contains("<<Guarantee Issue Amount - Spouse>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Guarantee_IssueAmt_Spouse.Trim()))
                                            {
                                                txtRange.Replace("<<Guarantee Issue Amount - Spouse>>", Guarantee_IssueAmt_Spouse);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Guarantee Issue Amount - Spouse>>", "");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<Second Guarantee Issue Amount - Spouse>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Guarantee_IssueAmt_Spouse2.Trim()))
                                            {
                                                txtRange.Replace("<<Second Guarantee Issue Amount - Spouse>>", Guarantee_IssueAmt_Spouse2);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Second Guarantee Issue Amount - Spouse>>", "");
                                            }
                                        }
                                        #endregion Guarantee Issue Amount - Spouse

                                        #region Maximum Benefit Amount-Spouse
                                        if (txtRange.Text.Contains("<<Maximum Benefit Amount-Spouse>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Maximum_Benefit_Amt_Spouse.Trim()))
                                            {
                                                txtRange.Replace("<<Maximum Benefit Amount-Spouse>>", Maximum_Benefit_Amt_Spouse);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Guarantee Issue Amount - Spouse>>", "");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<Second Maximum Benefit Amount-Spouse>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Maximum_Benefit_Amt_Spouse2.Trim()))
                                            {
                                                txtRange.Replace("<<Second Maximum Benefit Amount-Spouse>>", Maximum_Benefit_Amt_Spouse2);
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Second Maximum Benefit Amount-Spouse>>", "");
                                            }
                                        }
                                        #endregion Maximum Benefit Amount-Spouse

                                        #endregion Spouse

                                        #region Children
                                        if (txtRange.Text.Contains("<<Life and AD&D Benefit Amount –Child(ren)>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Benefit_Amt_Children.Trim()))
                                            {
                                                txtRange.Replace("<<Life and AD&D Benefit Amount –Child(ren)>>", Benefit_Amt_Children);
                                            }
                                            //else if (objShapes[j].Name.ToString().Equals("Children Benefit"))
                                            //{
                                            //    objShapes[j].Delete();
                                            //}
                                        }
                                        if (txtRange.Text.Contains("<<Second Life and AD&D Benefit Amount -Child(ren)>>"))
                                        {
                                            if (!string.IsNullOrEmpty(Benefit_Amt_Children2.Trim()))
                                            {
                                                txtRange.Replace("<<Second Life and AD&D Benefit Amount -Child(ren)>>", Benefit_Amt_Children2);
                                            }
                                            //else if (objShapes[j].Name.ToString().Equals("Children Benefit2"))
                                            //{
                                            //    objShapes[j].Delete();
                                            //}
                                        }
                                        #endregion Children
                                        if (txtRange.Text.Contains("<<Life_Vol_LTD_STD_Plans>>"))
                                        {
                                            txtRange.Replace("<<Life_Vol_LTD_STD_Plans>>", " ");
                                        }
                                    }
                                }
                                //}
                            }
                            #endregion
                        }
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVoluntaryLifeToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, DataTable CarrierSpecific, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();

                string value = "";
                string Benefit_Amt_Employee = string.Empty;
                string Benefit_Amt_Spouse = string.Empty;
                string Benefit_Amt_Children = string.Empty;

                string Benefit_Amt_Employee_ADD = string.Empty;
                string Benefit_Amt_Spouse_ADD = string.Empty;
                string Benefit_Amt_Children_ADD = string.Empty;

                string Voluntary_Life_Carrier_Plan1 = string.Empty;
                string Voluntary_Life_Summary_Plan1 = string.Empty;
                string Voluntary_Life_Plan_1 = string.Empty;

                string Voluntary_Life_Carrier_Plan_ADD1 = string.Empty;
                string Voluntary_Life_Summary_Plan_ADD1 = string.Empty;
                string Voluntary_Life_Plan_ADD1 = string.Empty;
                #region HashtablHashtableVoluntaryLife

                HashtableVoluntaryLifeADDBenifit.Add(1, "186");     //Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(2, "516");     //Spouse[Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(3, "106");     //Child(ren)[Benefit Amount] 
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                            {
                                Voluntary_Life_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Voluntary_Life_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Voluntary_Life_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                            {
                                Voluntary_Life_Plan_ADD1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Voluntary_Life_Carrier_Plan_ADD1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Voluntary_Life_Summary_Plan_ADD1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }

                            #region VoluntaryLifeADDBenifitTable

                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                                        {
                                            switch (key)
                                            {
                                                case 1: Benefit_Amt_Employee = value.Trim_String(); break;
                                                case 2: Benefit_Amt_Spouse = value.Trim_String(); break;
                                                case 3: Benefit_Amt_Children = value.Trim_String(); break;
                                            }
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                                        {
                                            switch (key)
                                            {
                                                case 1: Benefit_Amt_Employee_ADD = value.Trim_String(); break;
                                                case 2: Benefit_Amt_Spouse_ADD = value.Trim_String(); break;
                                                case 3: Benefit_Amt_Children_ADD = value.Trim_String(); break;
                                            }
                                        }
                                        //switch (key)
                                        //{
                                        //    case 1: Benefit_Amt_Employee = value.Trim_String(); break;
                                        //    case 2: Benefit_Amt_Spouse = value.Trim_String(); break;
                                        //    case 3: Benefit_Amt_Children = value.Trim_String(); break;
                                        //}
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //if (objSlides[i].SlideNumber == 49 || objSlides[i].SlideNumber == 50 || objSlides[i].SlideNumber == 53 || objSlides[i].SlideNumber == 54)
                                //{
                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                    {
                                        // If shape is table then iterate through each row and each column 
                                        // and find the attribute name and replace it with respective value
                                    }
                                    else
                                    {
                                        if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                                        {
                                            break;
                                        }

                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                                        {
                                            if (txtRange.Text.Contains("<<Delete_Voluntary_Life>>"))
                                            {
                                                txtRange.Replace("<<Delete_Voluntary_Life>>", " ");
                                            }

                                            if (txtRange.Text.Contains("<<Benefit Amount / Employee>>"))
                                            {
                                                txtRange.Replace("<<Benefit Amount / Employee>>", Benefit_Amt_Employee);
                                            }
                                            if (txtRange.Text.Contains("<<Benefit Amount / Spouse>>"))
                                            {
                                                txtRange.Replace("<<Benefit Amount / Spouse>>", Benefit_Amt_Spouse);
                                            }
                                            if (txtRange.Text.Contains("<<Benefit Amount / Dependent>>"))
                                            {
                                                txtRange.Replace("<<Benefit Amount / Dependent>>", Benefit_Amt_Children);
                                            }
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                                        {
                                            if (txtRange.Text.Contains("<<Delete_Voluntary_ADD>>"))
                                            {
                                                txtRange.Replace("<<Delete_Voluntary_ADD>>", " ");
                                            }

                                            if (txtRange.Text.Contains("<<ADD_Benefit_Amount / Employee>>"))
                                            {
                                                txtRange.Replace("<<ADD_Benefit_Amount / Employee>>", Benefit_Amt_Employee_ADD);
                                            }
                                            if (txtRange.Text.Contains("<<ADD_Benefit_Amount / Spouse>>"))
                                            {
                                                txtRange.Replace("<<ADD_Benefit_Amount / Spouse>>", Benefit_Amt_Spouse_ADD);
                                            }
                                            if (txtRange.Text.Contains("<<ADD_Benefit_Amount / Dependent>>"))
                                            {
                                                txtRange.Replace("<<ADD_Benefit_Amount / Dependent>>", Benefit_Amt_Children_ADD);
                                            }
                                        }

                                        if (txtRange.Text.Contains("<<Voluntary Life Insurance Carrier Name>>"))
                                        {
                                            txtRange.Replace("<<Voluntary Life Insurance Carrier Name>>", Voluntary_Life_Carrier_Plan1);
                                        }

                                        if (txtRange.Text.Contains("<<Life_Vol_LTD_STD_Plans>>"))
                                        {
                                            txtRange.Replace("<<Life_Vol_LTD_STD_Plans>>", " ");
                                        }


                                    }
                                }
                                //}
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteLTDSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableLTD = new Hashtable();

                string value = "";
                string Elimination_Periode = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit_Maximum = string.Empty;
                string Definition_Of_Disability = string.Empty;
                string Pre_Existing_Condition_Limit = string.Empty;
                string LTD_Carrier1 = string.Empty;
                string LTD_Summary_Plan1 = string.Empty;
                string LTD_Plan_1 = string.Empty;
                string Maximum_period_of_payment = string.Empty;

                string Elimination_Periode2 = string.Empty;
                string Benefit_Percentage2 = string.Empty;
                string Monthly_Benefit_Maximum2 = string.Empty;
                string Definition_Of_Disability2 = string.Empty;
                string Pre_Existing_Condition_Limit2 = string.Empty;
                string LTD_Carrier2 = string.Empty;
                string LTD_Summary_Plan2 = string.Empty;
                string LTD_Plan_2 = string.Empty;
                string Maximum_period_of_payment2 = string.Empty;

                #region HashtableLTD
                HashtableLTD.Add(1, "181");     //General Plan Information – Elimination Period
                HashtableLTD.Add(2, "71");      //General Plan Information – Benefit Percentage
                HashtableLTD.Add(3, "374");     //General Plan Information – Monthly Benefit Maximum
                HashtableLTD.Add(4, "141");     //Benefits[Definition of Disability]
                HashtableLTD.Add(5, "449");     //Benefits[Pre-Existing Condition Limitation]
                HashtableLTD.Add(6, "350");     //Benefits[Maximum period of payment]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTDBenifitTable

                            if (count == 1)
                            {
                                LTD_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                LTD_Carrier1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                LTD_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 2)
                            {
                                LTD_Plan_2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                LTD_Carrier2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                LTD_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: Elimination_Periode = value.Trim_String(); break;
                                                case 2: Benefit_Percentage = value.Trim_String(); break;
                                                case 3: Monthly_Benefit_Maximum = value.Trim_String(); break;
                                                case 4: Definition_Of_Disability = value.Trim_String(); break;
                                                case 5: Pre_Existing_Condition_Limit = value.Trim_String(); break;
                                                case 6: Maximum_period_of_payment = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: Elimination_Periode2 = value.Trim_String(); break;
                                                case 2: Benefit_Percentage2 = value.Trim_String(); break;
                                                case 3: Monthly_Benefit_Maximum2 = value.Trim_String(); break;
                                                case 4: Definition_Of_Disability2 = value.Trim_String(); break;
                                                case 5: Pre_Existing_Condition_Limit2 = value.Trim_String(); break;
                                                case 6: Maximum_period_of_payment2 = value.Trim_String(); break;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion
                        }

                        count++;
                    }
                }
                #region merge fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    //objShapes = mySlide.Shapes;
                    objShapes = objSlides[i].Shapes;
                    //if (objSlides[i].SlideNumber == 49 || objSlides[i].SlideNumber == 50 || objSlides[i].SlideNumber == 55 || objSlides[i].SlideNumber == 57)
                    //{
                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            // If shape is table then iterate through each row and each column 
                            // and find the attribute name and replace it with respective value
                            if (objShapes[j].Name.ToString().Equals("LTD_Table"))
                            {
                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                {
                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                    {
                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                        txtRange = txtFrame.TextRange;
                                        #region first LTD plan
                                        if (txtRange.Text.Contains("<<First LTD Benefit Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(LTD_Plan_1))
                                            {
                                                txtRange.Replace("<<First LTD Benefit Summary Name Delete>>", LTD_Plan_1);
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Elimination Period>>", Elimination_Periode);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Benefit Percentage>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Benefit Percentage>>", Benefit_Percentage);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Monthly Benefit Max>>"))
                                        {
                                            //txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum);
                                            if (!string.IsNullOrEmpty(Monthly_Benefit_Maximum.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", " ");
                                            }

                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Definition of Disability>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Definition of Disability>>", Definition_Of_Disability);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Pre-Existing Condition Limit>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Pre-Existing Condition Limit>>", Pre_Existing_Condition_Limit);
                                        }
                                        if (txtRange.Text.Contains("<<Maximum Period of Payment>>"))
                                        {
                                            txtRange.Replace("<<Maximum Period of Payment>>", Pre_Existing_Condition_Limit);
                                        }
                                        #endregion

                                        #region Second LTD plan
                                        if (txtRange.Text.Contains("<<Second LTD Benefit Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(LTD_Plan_2))
                                            {
                                                txtRange.Replace("<<Second LTD Benefit Summary Name Delete>>", LTD_Plan_2);
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Elimination Period2>>", Elimination_Periode2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Benefit Percentage2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Benefit Percentage2>>", Benefit_Percentage2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Monthly Benefit Max2>>"))
                                        {
                                            //txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum);
                                            if (!string.IsNullOrEmpty(Monthly_Benefit_Maximum2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max2>>", Monthly_Benefit_Maximum2.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max2>>", " ");
                                            }

                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Definition of Disability2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Definition of Disability2>>", Definition_Of_Disability2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Pre-Existing Condition Limit2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Pre-Existing Condition Limit2>>", Pre_Existing_Condition_Limit2);
                                        }
                                        if (txtRange.Text.Contains("<<Maximum Period of Payment2>>"))
                                        {
                                            txtRange.Replace("<<Maximum Period of Payment2>>", Pre_Existing_Condition_Limit2);
                                        }
                                        #endregion
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }

                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;


                            if (txtRange.Text.Contains("<<Long Term Disability Carrier Name>>"))
                            {
                                txtRange.Replace("<<Long Term Disability Carrier Name>>", LTD_Carrier1);
                            }

                            if (txtRange.Text.Contains("<<Delete_LTD>>"))
                            {
                                txtRange.Replace("<<Delete_LTD>>", " ");
                            }

                            if (txtRange.Text.Contains("<<Delete_LTD_STD>>"))
                            {
                                txtRange.Replace("<<Delete_LTD_STD>>", " ");
                            }

                            if (txtRange.Text.Contains("<<Life_Vol_LTD_STD_Plans>>"))
                            {
                                txtRange.Replace("<<Life_Vol_LTD_STD_Plans>>", " ");
                            }
                        }
                    }
                    //}
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP plan</param>
        public void WriteEAPSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.EAPPlanType_CommonCriteria.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region merge fields
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            objSlides = objPres.Slides;

                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //if (objSlides[i].SlideNumber == 59 || objSlides[i].SlideNumber == 58)
                                //{
                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                    }
                                    else
                                    {
                                        if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                                        {
                                            break;
                                        }

                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<Employee Assistance Program>>"))
                                        {
                                            txtRange.Replace("<<Employee Assistance Program>>", "Employee Assistance Program");
                                        }
                                        if (txtRange.Text.Contains("<<EAP_PA_Telemedi_Plan>>"))
                                        {
                                            txtRange.Replace("<<EAP_PA_Telemedi_Plan>>", " ");
                                        }
                                        if (txtRange.Text.Contains("<<Delete_EAP>>"))
                                        {
                                            txtRange.Replace("<<Delete_EAP>>", " ");
                                        }
                                    }
                                }
                                //}
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteSTDSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableSTD = new Hashtable();

                string value = "";
                //variables for first plan 
                string Elimination_Period_Accident = string.Empty;
                string Elimination_Period_Sickness = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit_Maximum = string.Empty;
                string Definition_Of_Disability = string.Empty;
                string Pre_Existing_Condition_Limit = string.Empty;
                string Disability_Carrier = string.Empty;
                string STD_Summary_Plan1 = string.Empty;
                string STD_Plan_1 = string.Empty;
                string Maximum_period_of_payment = string.Empty;

                //variables for second plan 
                string Elimination_Period_Accident2 = string.Empty;
                string Elimination_Period_Sickness2 = string.Empty;
                string Benefit_Percentage2 = string.Empty;
                string Monthly_Benefit_Maximum2 = string.Empty;
                string Definition_Of_Disability2 = string.Empty;
                string Pre_Existing_Condition_Limit2 = string.Empty;
                string Disability_Carrier2 = string.Empty;
                string STD_Summary_Plan2 = string.Empty;
                string STD_Plan_2 = string.Empty;
                string Maximum_period_of_payment2 = string.Empty;

                #region HashtableSTD
                HashtableSTD.Add(1, "8");       //General Plan Information – Elimination Period - Accident
                HashtableSTD.Add(2, "505");     //General Plan Information – Elimination Period - Sickness
                HashtableSTD.Add(3, "71");      //General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "569");     //General Plan Information – Monthly Benefit Maximum
                HashtableSTD.Add(5, "141");     //Benefits[Definition of Disability]
                HashtableSTD.Add(6, "449");     //Benefits[Pre-Existing Condition Limitation]
                HashtableSTD.Add(7, "350");     //Benefits[Maximum period of payment]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STDBenifitTable
                            if (count == 1)
                            {
                                STD_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Disability_Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                STD_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 2)
                            {
                                STD_Plan_2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Disability_Carrier2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                STD_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }

                            #region STD Hashtable
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.STDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: Elimination_Period_Accident = value.Trim_String(); break;
                                                case 2: Elimination_Period_Sickness = value.Trim_String(); break;
                                                case 3: Benefit_Percentage = value.Trim_String(); break;
                                                case 4: Monthly_Benefit_Maximum = value.Trim_String(); break;
                                                case 5: Definition_Of_Disability = value.Trim_String(); break;
                                                case 6: Pre_Existing_Condition_Limit = value.Trim_String(); break;
                                                case 7: Maximum_period_of_payment = value.Trim_String(); break;
                                            }
                                        }
                                        if (count == 2)
                                        {

                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: Elimination_Period_Accident2 = value.Trim_String(); break;
                                                case 2: Elimination_Period_Sickness2 = value.Trim_String(); break;
                                                case 3: Benefit_Percentage2 = value.Trim_String(); break;
                                                case 4: Monthly_Benefit_Maximum2 = value.Trim_String(); break;
                                                case 5: Definition_Of_Disability2 = value.Trim_String(); break;
                                                case 6: Pre_Existing_Condition_Limit2 = value.Trim_String(); break;
                                                case 7: Maximum_period_of_payment2 = value.Trim_String(); break;
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                            //value = "";
                            #endregion
                        }
                    }
                }

                #region merge fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    //objShapes = mySlide.Shapes;
                    objShapes = objSlides[i].Shapes;

                    //if (objSlides[i].SlideNumber == 49 || objSlides[i].SlideNumber == 50 || objSlides[i].SlideNumber == 55 || objSlides[i].SlideNumber == 56)
                    //{
                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            // If shape is table then iterate through each row and each column 
                            // and find the attribute name and replace it with respective value
                            if (objShapes[j].Name.ToString().Equals("STD_Table"))
                            {
                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                {
                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                    {
                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        #region First STD Benefit Summary

                                        if (txtRange.Text.Contains("<<First STD Benefit Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(STD_Plan_1))
                                            {
                                                txtRange.Replace("<<First STD Benefit Summary Name Delete>>", STD_Plan_1);
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period - Accident>>"))
                                        {
                                            //txtRange.Replace("<<General Plan Info – Elimination Period - Accident>>", Elimination_Period_Accident);
                                            if (!string.IsNullOrEmpty(Elimination_Period_Sickness.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Elimination Period - Accident>>", Elimination_Period_Accident.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Elimination Period - Accident>>", " ");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period - Sickness>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Elimination Period - Sickness>>", Elimination_Period_Sickness);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Benefit Percentage>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Benefit Percentage>>", Benefit_Percentage);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Monthly Benefit Max>>"))
                                        {
                                            //txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum);
                                            if (!string.IsNullOrEmpty(Monthly_Benefit_Maximum.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", " ");
                                            }
                                        }
                                        //if (txtRange.Text.Contains("<<General Plan Info – Definition of Disability>"))
                                        //{
                                        //    txtRange.Replace("<<General Plan Info – Definition of Disability>>", Definition_Of_Disability);
                                        //}            

                                        if (txtRange.Text.Contains("<<Maximum Period of Payment>>"))
                                        {
                                            txtRange.Replace("<<Maximum Period of Payment>>", Maximum_period_of_payment);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Pre-Existing Condition Limit>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Pre-Existing Condition Limit>>", Pre_Existing_Condition_Limit);
                                        }

                                        #endregion First STD Benefit Summary

                                        #region Second STD Benefit Summary
                                        if (txtRange.Text.Contains("<<Second STD Benefit Summary Name Delete>>"))
                                        {
                                            if (!string.IsNullOrEmpty(STD_Plan_2))
                                            {
                                                txtRange.Replace("<<Second STD Benefit Summary Name Delete>>", STD_Plan_2);
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period – Accident2>>"))
                                        {
                                            //txtRange.Replace("<<General Plan Info – Elimination Period - Accident>>", Elimination_Period_Accident);
                                            if (!string.IsNullOrEmpty(Elimination_Period_Sickness2.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Elimination Period – Accident2>>", Elimination_Period_Accident2.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Elimination Period – Accident2>>", " ");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period – Sickness2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Elimination Period – Sickness2>>", Elimination_Period_Sickness2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Benefit Percentage2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Benefit Percentage2>>", Benefit_Percentage2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Monthly Benefit Max2>>"))
                                        {
                                            //txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum);
                                            if (!string.IsNullOrEmpty(Monthly_Benefit_Maximum.Trim()))
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max2>>", Monthly_Benefit_Maximum2.Trim());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max2>>", " ");
                                            }
                                        }
                                        //if (txtRange.Text.Contains("<<General Plan Info – Definition of Disability>"))
                                        //{
                                        //    txtRange.Replace("<<General Plan Info – Definition of Disability>>", Definition_Of_Disability);
                                        //}            

                                        if (txtRange.Text.Contains("<<Maximum Period of Payment2>>"))
                                        {
                                            txtRange.Replace("<<Maximum Period of Payment2>>", Maximum_period_of_payment2);
                                        }
                                        if (txtRange.Text.Contains("<<General Plan Info – Pre-Existing Condition Limit2>>"))
                                        {
                                            txtRange.Replace("<<General Plan Info – Pre-Existing Condition Limit2>>", Pre_Existing_Condition_Limit2);
                                        }

                                        #endregion Second STD Benefit Summary
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }

                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Short Term Disability Carrier Name>>"))
                            {
                                txtRange.Replace("<<Short Term Disability Carrier Name>>", Disability_Carrier);
                            }
                            if (txtRange.Text.Contains("<<Delete_LTD_STD>>"))
                            {
                                txtRange.Replace("<<Delete_LTD_STD>>", " ");
                            }
                            if (txtRange.Text.Contains("<<Delete_STD>>"))
                            {
                                txtRange.Replace("<<Delete_STD>>", " ");
                            }
                            if (txtRange.Text.Contains("<<Life_Vol_LTD_STD_Plans>>"))
                            {
                                txtRange.Replace("<<Life_Vol_LTD_STD_Plans>>", " ");
                            }
                        }
                    }
                    //}
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP plan</param>
        public void WriteFSASectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, DropDownList ddlFSABenefitSummary, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableFSA = new Hashtable();

                string value = "";
                string Dependant_Care_Max = string.Empty;
                string Med_Spending_Account_Max_GP = string.Empty;
                string Med_Spending_Account_Max_LP = string.Empty;
                string HSA_Carrier = string.Empty;
                string FSA_Carrier_Plan1 = string.Empty;
                string FSA_Summary_Plan1 = string.Empty;
                string FSA_Plan_1 = string.Empty;
                string Effectivedate = string.Empty;
                string Renewaldate = string.Empty;

                #region HashHashtableFSAtableEAP

                HashtableFSA.Add(1, "150");     //Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "354");     //Administration Services – Medical Spending
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HSAPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            HSA_Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                        }
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.FSAPlanType_CommonCriteria.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            FSA_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            FSA_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            FSA_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            Effectivedate = Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString()).ToShortDateString();
                            Renewaldate = Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString()).AddDays(-1).ToShortDateString();
                            #region FSA

                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.FSAPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Dependant_Care_Max = value; break;
                                            case 2:
                                                //if (ddlFSABenefitSummary.SelectedItem.Text.Contains("General"))
                                                //{
                                                //    Med_Spending_Account_Max_GP = value;
                                                //}
                                                //else if (ddlFSABenefitSummary.SelectedItem.Text.Contains("Limited"))
                                                //{
                                                //    Med_Spending_Account_Max_LP = value;
                                                //}
                                                Med_Spending_Account_Max_GP = value.Trim_String();
                                                break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                objShapes = objSlides[i].Shapes;
                                //objShapes = mySlide.Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                    }
                                    else
                                    {
                                        if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                                        {
                                            break;
                                        }

                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<Flexible Spending Account Carrier Name>>"))
                                        {
                                            txtRange.Replace("<<Flexible Spending Account Carrier Name>>", FSA_Carrier_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<Section 125 – Admin Services – Med Spending Account – Max>>"))
                                        {
                                            txtRange.Replace("<<Section 125 – Admin Services – Med Spending Account – Max>>", Med_Spending_Account_Max_GP.Trim());
                                        }
                                        if (txtRange.Text.Contains("<<FSA Effective Date>>"))
                                        {
                                            txtRange.Replace("<<FSA Effective Date>>", Effectivedate);
                                        }
                                        if (txtRange.Text.Contains("<<FSA Renewal Date minus one day>>"))
                                        {
                                            txtRange.Replace("<<FSA Renewal Date minus one day>>", Renewaldate);
                                        }
                                        if (txtRange.Text.Contains("<<FSA_PLAN>>"))
                                        {
                                            txtRange.Replace("<<FSA_PLAN>>", " ");
                                        }
                                        if (txtRange.Text.Contains("<<FSA_PLAN>>"))
                                        {
                                            txtRange.Replace("<<FSA_PLAN>>", " ");
                                        }
                                        if (txtRange.Text.Contains("<<FSA_HSA_PLAN>>"))
                                        {
                                            txtRange.Replace("<<FSA_HSA_PLAN>>", " ");
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS, DataSet ProductDS, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();
                int DentalCount = 0;
                int VisionCount = 0;
                int DentalPlanCount = 0;
                int VisionPlanCount = 0;
                string Frequency_Of_Contribution = string.Empty;
                string Frequency_Of_Contribution_Med = string.Empty;
                string Frequency_Of_Contribution_Dental = string.Empty;
                string Frequency_Of_Contribution_Vision = string.Empty;

                DataTable PremiumTableWriteMedical = new DataTable();
                objCommFun.BuildContributionPremiumTable(ref PremiumTableWriteMedical);

                DataTable PremiumTableWriteDental = new DataTable();
                objCommFun.BuildContributionPremiumTable(ref PremiumTableWriteDental);

                DataTable PremiumTableWriteVision = new DataTable();
                objCommFun.BuildContributionPremiumTable(ref PremiumTableWriteVision);

                string strPlan_Contri1 = "";
                string strPlan_Contri2 = "";
                ArrayList arrContributionID_Medical = new ArrayList();
                ArrayList arrContributionID_Dental = new ArrayList();
                ArrayList arrContributionID_Vision = new ArrayList();

                int MedicalTableRowCounter = 3;
                int DentalTableRowCounter = 3;
                int VisionTableRowCounter = 3;
                int medicalColumnNum = 1;
                int dentalColumnNum = 1;
                int visionColumnNum = 1;

                int contributionId_1 = 0;
                int contributionId_2 = 0;

                DataTable PremiumTable = new DataTable();

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    PremiumTable.Clear();
                    PremiumTable = objCommFun.CreateContributionPremiumTable(PlanTable, ContributionDS, index);
                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId"].ToString()))
                    {
                        contributionId_1 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId"].ToString());
                    }
                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId_2"].ToString()))
                    {
                        contributionId_2 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId_2"].ToString());
                    }
                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[contributionValueID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);

                    // The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                    //for (int k = 0; k < dt.Rows.Count; k++)
                    //{
                    //    if (Convert.ToDecimal(dt.Rows[k]["monthlycost"]) == 0)
                    //    {
                    //        dt.Rows[k].Delete();
                    //        k = k - 1;
                    //    }
                    //}
                    PremiumTable = dt;

                    //if (Frequency_Of_Contribution == "Bi_Weekly_26_or_yr")
                    //{
                    //    Frequency_Of_Contribution = "Bi-Weekly (26 Per Year) Cost";
                    //}

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()));
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }

                        if (index == 0)
                        {

                            if (PremiumTable.Rows.Count > 0)
                            {
                                Frequency_Of_Contribution_Med = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            objCommFun.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteMedical);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Medical_Rate_Table", PremiumTableWriteMedical, ref arrContributionID_Medical, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, 16, 1, ref medicalColumnNum, contributionId_1, contributionId_2, "<<Frequency of Contributions_Med>>", Frequency_Of_Contribution_Med);
                        }
                        if (index == 1)
                        {

                            PremiumTableWriteMedical.Clear();
                            objCommFun.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteMedical);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Medical_Rate_Table", PremiumTableWriteMedical, ref arrContributionID_Medical, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, 16, 2, ref medicalColumnNum, contributionId_1, contributionId_2);
                        }
                        if (index == 2)
                        {

                            PremiumTableWriteMedical.Clear();
                            objCommFun.GetPlanContribution(PremiumTable, 3, ref PremiumTableWriteMedical);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Medical_Rate_Table", PremiumTableWriteMedical, ref arrContributionID_Medical, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, 16, 3, ref medicalColumnNum, contributionId_1, contributionId_2);
                        }
                        if (index == 3)
                        {

                            PremiumTableWriteMedical.Clear();
                            objCommFun.GetPlanContribution(PremiumTable, 4, ref PremiumTableWriteMedical);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Medical_Rate_Table", PremiumTableWriteMedical, ref arrContributionID_Medical, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, 16, 4, ref medicalColumnNum, contributionId_1, contributionId_2);
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";



                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()));
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }

                        if (DentalCount == 0)
                        {
                            if (PremiumTable.Rows.Count > 0)
                            {
                                Frequency_Of_Contribution_Dental = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }

                            objCommFun.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteDental);

                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Dental_Rate_Table", PremiumTableWriteDental, ref arrContributionID_Dental, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, 42, 1, ref dentalColumnNum, contributionId_1, contributionId_2, "<<Frequency of Contributions_Dental>>", Frequency_Of_Contribution_Dental);
                        }
                        if (DentalCount == 1)
                        {

                            PremiumTableWriteDental.Clear();
                            objCommFun.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteDental);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Dental_Rate_Table", PremiumTableWriteDental, ref arrContributionID_Dental, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, 42, 2, ref dentalColumnNum, contributionId_1, contributionId_2);
                        }
                        if (DentalCount == 2)
                        {

                            PremiumTableWriteDental.Clear();
                            objCommFun.GetPlanContribution(PremiumTable, 3, ref PremiumTableWriteDental);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Dental_Rate_Table", PremiumTableWriteDental, ref arrContributionID_Dental, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, 42, 3, ref dentalColumnNum, contributionId_1, contributionId_2);
                        }
                        if (DentalCount == 3)
                        {

                            PremiumTableWriteDental.Clear();
                            objCommFun.GetPlanContribution(PremiumTable, 4, ref PremiumTableWriteDental);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Dental_Rate_Table", PremiumTableWriteDental, ref arrContributionID_Dental, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, 42, 4, ref dentalColumnNum, contributionId_1, contributionId_2);
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";

                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()));
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString()));
                        }


                        if (VisionCount == 0)
                        {

                            if (PremiumTable.Rows.Count > 0)
                            {
                                Frequency_Of_Contribution_Vision = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            objCommFun.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteVision);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Vision_Rate_Table", PremiumTableWriteVision, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, 47, 1, ref visionColumnNum, contributionId_1, contributionId_2, "<<Frequency of Contributions_Vision>>", Frequency_Of_Contribution_Vision);
                        }
                        if (VisionCount == 1)
                        {

                            PremiumTableWriteVision.Clear();
                            objCommFun.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteVision);
                            objCommFun.WriteContributionValuesFor_PPT(objPres, objPresSet, objSlides, objShapes, "Vision_Rate_Table", PremiumTableWriteVision, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, 47, 2, ref visionColumnNum, contributionId_1, contributionId_2);
                        }

                        VisionCount++;
                    }
                    #endregion
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteHSAToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HSABenefitColumnIdList, DataTable CarrierSpecific, DropDownList ddlClient, DropDownList ddlFSANoOfPlan, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                DataRow[] foundRows = null;

                Hashtable HashtableHSABenifit = new Hashtable();

                string Max_Annual_Contribution_Individual = " ";
                string Max_Annual_Contribution_Family = " ";


                string Max_Annual_Contribution_Individual1 = " ";
                string Max_Annual_Contribution_Family1 = " ";
                string Max_Annual_EmployerContribution_Individual1 = " ";
                string Max_Annual_EmployerContribution_Family1 = " ";
                string value = "";


                string HSA_Carrier = string.Empty;
                string HSA_Summary_Plan1 = string.Empty;
                string HSA_Plan_1 = string.Empty;

                #region HashtablHashtableHSA

                HashtableHSABenifit.Add(1, "635");     //General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSABenifit.Add(2, "636");     //General Plan Information – Maximum Annual Contribution/Family

                HashtableHSABenifit.Add(3, "640");     //Employer Contributions – Individual
                HashtableHSABenifit.Add(4, "644");     //Employer Contributions – Family
                //HashtableHSABenifit.Add(1, "640");     //Employer Contributions – Individual
                //HashtableHSABenifit.Add(2, "644");     //Employer Contributions – Family
                #endregion

                // IRS
                DataTable dt_IRS = new DataTable();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HSAPlanType_CommonCriteria.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            HSA_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            HSA_Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            HSA_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            // Get the renewal year for taking the IRS table detail
                            string renewalDate = Convert.ToString(Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString()).Year);

                            dt_IRS = bp.GetIRCList(renewalDate);

                            for (int j = 0; j < dt_IRS.Rows.Count; j++)
                            {
                                Max_Annual_Contribution_Individual = Convert.ToString(dt_IRS.Rows[j]["EmployeeOnlyCoverage"].ToString());
                                Max_Annual_Contribution_Family = Convert.ToString(dt_IRS.Rows[j]["FamilyCoverage"].ToString());
                            }
                            #region HSABenifitTable

                            foreach (int key in HashtableHSABenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.HSAPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSABenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Max_Annual_Contribution_Individual1 = value; break;
                                            case 2: Max_Annual_Contribution_Family1 = value; break;

                                            case 3: Max_Annual_EmployerContribution_Individual1 = value; break;
                                            case 4: Max_Annual_EmployerContribution_Family1 = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion


                        }

                    }
                }

                #region merge fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    //objShapes = mySlide.Shapes;

                    //if (objSlides[i].SlideNumber == 21 || objSlides[i].SlideNumber == 27 || objSlides[i].SlideNumber == 28 || objSlides[i].SlideNumber == 29 || objSlides[i].SlideNumber == 30 || objSlides[i].SlideNumber == 31 || objSlides[i].SlideNumber == 32 || objSlides[i].SlideNumber == 33 || objSlides[i].SlideNumber == 34 || objSlides[i].SlideNumber == 35 || objSlides[i].SlideNumber == 36 || objSlides[i].SlideNumber == 37)
                    //{
                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            if (objShapes[j].Name.ToString().Equals("HSA Table"))
                            {
                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                {
                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                    {
                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<Health Savings Account / Employer Contributions / Individual>>"))
                                        {
                                            txtRange.Replace("<<Health Savings Account / Employer Contributions / Individual>>", Max_Annual_EmployerContribution_Individual1.Trim_String());
                                        }
                                        if (txtRange.Text.Contains("<<Health Savings Account / Employer Contributions / Family>>"))
                                        {
                                            txtRange.Replace("<<Health Savings Account / Employer Contributions / Family>>", Max_Annual_EmployerContribution_Family1.Trim_String());
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }

                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Health Saving Account Carrier Name>>"))
                            {
                                txtRange.Replace("<<Health Saving Account Carrier Name>>", HSA_Carrier);
                            }
                            if (txtRange.Text.Contains("<<HSA Carrier>>"))
                            {
                                txtRange.Replace("<<HSA Carrier>>", HSA_Carrier);
                            }
                            if (txtRange.Text.Contains("<<HSA_PLAN>>"))
                            {
                                txtRange.Replace("<<HSA_PLAN>>", " ");
                            }
                            if (txtRange.Text.Contains("<<FSA_HSA_PLAN>>"))
                            {
                                txtRange.Replace("<<FSA_HSA_PLAN>>", " ");
                            }
                            if (txtRange.Text.Contains("<<Renewal Year Individual Contribution Maximum>>"))
                            {
                                txtRange.Replace("<<Renewal Year Individual Contribution Maximum>>", Max_Annual_Contribution_Individual1);
                            }
                            if (txtRange.Text.Contains("<<Renewal Year Family Contribution Maximum>>"))
                            {
                                txtRange.Replace("<<Renewal Year Family Contribution Maximum>>", Max_Annual_Contribution_Family1);
                            }
                        }
                    }
                    //}
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void ShowUniqueCarrierNames(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DataSet ProductDS, DataTable PlanTable)
        {
            try
            {
                Microsoft.Office.Interop.PowerPoint.Shape oShape = null;
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                string Life_CarrierName = string.Empty;
                string VolLife_CarrierName = string.Empty;
                string STD_CarrierName_1 = string.Empty;
                string STD_CarrierName_2 = string.Empty;
                string LTD_CarrierName = string.Empty;
                string carrierName_49 = string.Empty;

                string FSA_CarrierName = string.Empty;
                string HSA_CarrierName = string.Empty;
                string HRA_CarrierName = string.Empty;
                string carrierName_21 = string.Empty;
                string GroupTermLife_CarrierName = string.Empty;
                string ADNDLife_CarrierName = string.Empty;
                List<string> lstCarrierName = new List<string>();

                //int std_Count = 0;
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    // For Slide Number 21 Carrier Names
                    #region Slide 21 CarrierName - Spending Accounts
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.FSAPlanType_CommonCriteria.ToLower())
                    {
                        FSA_CarrierName = PlanTable.Rows[rowindex]["Carrier"].ToString();
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HSAPlanType_CommonCriteria.ToLower())
                    {
                        HSA_CarrierName = PlanTable.Rows[rowindex]["Carrier"].ToString();
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HRAPlanType_CommonCriteria.ToLower())
                    {
                        HRA_CarrierName = PlanTable.Rows[rowindex]["Carrier"].ToString();
                    }
                    #endregion

                    #region Slide 49 CarrierName - Ancillary Coverate
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        objCommFun.GetCarrierList(PlanTable.Rows[rowindex]["Carrier"].ToString(), ref lstCarrierName);
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        objCommFun.GetCarrierList(PlanTable.Rows[rowindex]["Carrier"].ToString(), ref lstCarrierName);
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        objCommFun.GetCarrierList(PlanTable.Rows[rowindex]["Carrier"].ToString(), ref lstCarrierName);
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        objCommFun.GetCarrierList(PlanTable.Rows[rowindex]["Carrier"].ToString(), ref lstCarrierName);
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        objCommFun.GetCarrierList(PlanTable.Rows[rowindex]["Carrier"].ToString(), ref lstCarrierName);
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        objCommFun.GetCarrierList(PlanTable.Rows[rowindex]["Carrier"].ToString(), ref lstCarrierName);
                    }
                    #endregion
                }

                carrierName_21 = objCommFun.GetCarrierList("\n", FSA_CarrierName, HSA_CarrierName, HRA_CarrierName);
                //carrierName_49 = objCommFun.GetCarrierList("\n", Life_CarrierName, VolLife_CarrierName, LTD_CarrierName, STD_CarrierName_1, STD_CarrierName_2);

                if (lstCarrierName.Count > 0)
                {
                    foreach (string item in lstCarrierName)
                    {
                        if (carrierName_49.Length == 0)
                        {
                            carrierName_49 = item;
                        }
                        else
                        {
                            carrierName_49 = carrierName_49 + "\n" + item;
                        }
                    }
                }

                objSlides = objPres.Slides;
                for (int sldNum = 1; sldNum <= objSlides.Count; sldNum++)
                {
                    objShapes = objSlides[sldNum].Shapes;
                    //if (sldNum == 21 || sldNum == 49)
                    //{
                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int shp = 1; shp <= objShapes.Count; shp++)
                    {
                        oShape = objShapes[shp];

                        if (oShape.Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoGroup || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoPicture || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoTable || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {

                        }
                        else
                        {
                            if (oShape.HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[shp].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Carrier Name Spending Account>>"))
                            {
                                txtRange.Replace("<<Carrier Name Spending Account>>", carrierName_21);
                            }
                            if (txtRange.Text.Contains("<<Carrier Name Ancillary Coverage>>"))
                            {
                                txtRange.Replace("<<Carrier Name Ancillary Coverage>>", carrierName_49);
                            }
                        }
                    }
                    //}
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        #region Added By vinod : Delete unwanted sections

        public void DeleteUnwantedSectionFromPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            Microsoft.Office.Interop.PowerPoint.Shape oShape = null;
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                #region merge fields
                bool isShapeDeleted = false;
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                objSlides = objPres.Slides;
                for (int sldNum = 1; sldNum <= objSlides.Count; sldNum++)
                {
                    objShapes = objSlides[sldNum].Shapes;

                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int shp = 1; shp <= objShapes.Count; shp++)
                    {
                        oShape = objShapes[shp];

                        isShapeDeleted = false;
                        if (oShape.Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoGroup || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoPicture || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoTable || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                            //if (sldNum == 12 || sldNum == 13 || sldNum == 14)
                            //{
                            //if (oShape.Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            //{
                            //    if (oShape.Name.ToString().Equals("Medical_Rate_Table") || oShape.Name.ToString().Equals("Dental_Rate_Table") || oShape.Name.ToString().Equals("Vision_Rate_Table"))
                            //    {
                            //        txtFrame = oShape.Table.Cell(2, 1).Shape.TextFrame;
                            //        txtRange = txtFrame.TextRange;
                            //        if (string.IsNullOrEmpty(txtRange.Text))
                            //        {
                            //            objSlides[sldNum].Delete();
                            //            sldNum = sldNum - 1;
                            //            break;
                            //        }
                            //    }
                            //}
                            //}
                        }
                        else
                        {

                            if (oShape.HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[shp].TextFrame;
                            txtRange = txtFrame.TextRange;


                            if (txtRange.Text.Contains("<<Life and AD&D Benefit Amount - Employee>>") || txtRange.Text.Contains("<<Life and AD&D Benefit Amount - Spouse>>") || txtRange.Text.Contains("<<Life and AD&D Benefit Amount –Child(ren)>>") || txtRange.Text.Contains("<<Second Life and AD&D Benefit Amount - Employee>>") || txtRange.Text.Contains("<<Second Life and AD&D Benefit Amount - Spouse>>") || txtRange.Text.Contains("<<Second Life and AD&D Benefit Amount -Child(ren)>>"))
                            {
                                oShape.Delete();
                                isShapeDeleted = true;
                                shp = shp - 1;
                            }

                            if (isShapeDeleted == false)
                            {
                                #region English videos : delete unwanted section

                                if (txtRange.Text.Contains("<<Delete_Contact>>") || txtRange.Text.Contains("<<Delete_Dental>>") || txtRange.Text.Contains("<<HRA_PLAN>>") || txtRange.Text.Contains("<<Delete_Vision>>") || txtRange.Text.Contains("<<Addition_Prod>>") || txtRange.Text.Contains("<<Delete_ Telemedicine>>") || txtRange.Text.Contains("<<Delete_Patient Advocacy>>") || txtRange.Text.Contains("<<Delete_Life>>") || txtRange.Text.Contains("<<Second Delete_Life>>") || txtRange.Text.Contains("<<Second <Delete_Life>>") || txtRange.Text.Contains("<<Delete_Voluntary_Life>>") || txtRange.Text.Contains("<<Delete_Voluntary_ADD>>") || txtRange.Text.Contains("<<Delete_LTD>>") || txtRange.Text.Contains("<<Delete_STD>>") || txtRange.Text.Contains("<<Delete_EAP>>") || txtRange.Text.Contains("<<FSA_HSA_PLAN>>") || txtRange.Text.Contains("<<FSA_PLAN>>") || txtRange.Text.Contains("<<HSA_PLAN>>") || txtRange.Text.Contains("<<Life_Vol_LTD_STD_Plans>>") || txtRange.Text.Contains("<<Delete_LTD_STD>>") || txtRange.Text.Contains("<<EAP_PA_Telemedi_Plan>>") || txtRange.Text.Contains("<<Life_STD_LTD_VolLife_Plans>>") || txtRange.Text.Contains("<<EAP_FSA_HSA_HRA_Plans>>") || txtRange.Text.Contains("<<MedVideo1>>") || txtRange.Text.Contains("<<MedVideo2>>") || txtRange.Text.Contains("<<MedVideo3>>") || txtRange.Text.Contains("<<MedVideo4>>") || txtRange.Text.Contains("<<MedVideo5>>") || txtRange.Text.Contains("<<MedVideo6>>") || txtRange.Text.Contains("<<MedVideo7>>") || txtRange.Text.Contains("<<MedVideo8>>") || txtRange.Text.Contains("<<MedVideo9>>") || txtRange.Text.Contains("<<MedVideo10>>") || txtRange.Text.Contains("<<MedVideo11>>") || txtRange.Text.Contains("<<MedVideo12>>") || txtRange.Text.Contains("<<MedVideo13>>") || txtRange.Text.Contains("<<MedVideo14>>") || txtRange.Text.Contains("<<MedVideo15>>") || txtRange.Text.Contains("<<MedVideo16>>") || txtRange.Text.Contains("<<MedVideo17>>") || txtRange.Text.Contains("<<HRAVideo1>>") || txtRange.Text.Contains("<<FSAVideo1>>") || txtRange.Text.Contains("<<DisabltyVideo1>>") || txtRange.Text.Contains("<<DenVideo1>>") || txtRange.Text.Contains("<<VisionVideo1>>") || txtRange.Text.Contains("<<LifeADVideo1>>") || txtRange.Text.Contains("<<LifeADVideo2>>") || txtRange.Text.Contains("<<VolBenfitVideo1>>") || txtRange.Text.Contains("<<AddnProdVideo1>>") || txtRange.Text.Contains("<<AddnProdVideo2>>") || txtRange.Text.Contains("<<AddnProdVideo3>>") || txtRange.Text.Contains("<<AddnProdVideo4>>") || txtRange.Text.Contains("<<AddnProdVideo5>>") || txtRange.Text.Contains("<<AddnProdVideo6>>") || txtRange.Text.Contains("<<AddnProdVideo7>>") || txtRange.Text.Contains("<<AddnProdVideo8>>") || txtRange.Text.Contains("<<AddnProdVideo9>>") || txtRange.Text.Contains("<<AddnProdVideo10>>") || txtRange.Text.Contains("<<AddnProdVideo11>>") || txtRange.Text.Contains("<<AddnProdVideo12>>") || txtRange.Text.Contains("<<MobileApp>>") || txtRange.Text.Contains("<<HSAFSAEnglish>>"))//4 July 2019
                                {
                                    //mySlide.Delete();
                                    objSlides[sldNum].Delete();
                                    sldNum = sldNum - 1;
                                    break;
                                }

                                #endregion

                                #region spanish videos : delete unwanted section

                                if (txtRange.Text.Contains("<<AddnProdVideo1_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo2_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo3_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo4_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo5_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo6_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo7_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo8_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo9_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo10_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo11_Spanish>>") || txtRange.Text.Contains("<<AddnProdVideo12_Spanish>>") || txtRange.Text.Contains("<<HRAVideo1_Spanish>>") || txtRange.Text.Contains("<<FSAVideo1_Spanish>>") || txtRange.Text.Contains("<<DenVideo1_Spanish>>") || txtRange.Text.Contains("<<VisionVideo1_Spanish>>") || txtRange.Text.Contains("<<LifeADVideo1_Spanish>>") || txtRange.Text.Contains("<<LifeADVideo2_Spanish>>") || txtRange.Text.Contains("<<VolBenfitVideo1_Spanish>>") || txtRange.Text.Contains("<<DisabltyVideo1_Spanish>>") || txtRange.Text.Contains("<<MobileApp>>")|| txtRange.Text.Contains("<<HSAFSA_Spanish>>"))//4 July 2019
                                {
                                    //mySlide.Delete();
                                    objSlides[sldNum].Delete();
                                    sldNum = sldNum - 1;
                                    break;
                                }
                                if (txtRange.Text.Contains("<<MedVideo1_Spanish>>") || txtRange.Text.Contains("<<MedVideo2_Spanish>>") || txtRange.Text.Contains("<<MedVideo3_Spanish>>") || txtRange.Text.Contains("<<MedVideo4_Spanish>>") || txtRange.Text.Contains("<<MedVideo5_Spanish>>") || txtRange.Text.Contains("<<MedVideo6_Spanish>>") || txtRange.Text.Contains("<<MedVideo7_Spanish>>") || txtRange.Text.Contains("<<MedVideo8_Spanish>>") || txtRange.Text.Contains("<<MedVideo9_Spanish>>") || txtRange.Text.Contains("<<MedVideo10_Spanish>>") || txtRange.Text.Contains("<<MedVideo11_Spanish>>") || txtRange.Text.Contains("<<MedVideo12_Spanish>>") || txtRange.Text.Contains("<<MedVideo13_Spanish>>") || txtRange.Text.Contains("<<MedVideo14_Spanish>>") || txtRange.Text.Contains("<<MedVideo15_Spanish>>") || txtRange.Text.Contains("<<MedVideo16_Spanish>>") || txtRange.Text.Contains("<<MedVideo17_Spanish>>"))
                                {
                                    //mySlide.Delete();
                                    objSlides[sldNum].Delete();
                                    sldNum = sldNum - 1;
                                    break;
                                }
                                #endregion

                                #region Delete Videos : Added videos in HR and Managemnet Section & Medical section
                                if (txtRange.Text.Contains("<<MedVideo18>>") || txtRange.Text.Contains("<<MedVideo18_Spanish>>") || txtRange.Text.Contains("<<MedVideo19>>") || txtRange.Text.Contains("<<MedVideo19_Spanish>>") || txtRange.Text.Contains("<<MedVideo20>>") || txtRange.Text.Contains("<<MedVideo20_Spanish>>") || txtRange.Text.Contains("<<MedVideo21>>") || txtRange.Text.Contains("<<MedVideo21_Spanish>>") || txtRange.Text.Contains("<<MedVideo22>>") || txtRange.Text.Contains("<<MedVideo22_Spanish>>") || txtRange.Text.Contains("<<MedVideo23>>") || txtRange.Text.Contains("<<MedVideo23_Spanish>>") || txtRange.Text.Contains("<<MedVideo24>>") || txtRange.Text.Contains("<<MedVideo24_Spanish>>") || txtRange.Text.Contains("<<MedVideo25>>") || txtRange.Text.Contains("<<MedVideo25_Spanish>>"))
                                {
                                    //mySlide.Delete();
                                    objSlides[sldNum].Delete();
                                    sldNum = sldNum - 1;
                                    break;
                                }
                                #endregion
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oShape != null)
                {
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(oShape) > 0) ;
                    oShape = null;
                }
            }
        }

        #endregion

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HRABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA plan</param>
        public void WriteHRASectionToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                string No_Of_Visits = string.Empty;
                string HRA_Carrier_Plan1 = string.Empty;
                string HRA_Summary_Plan1 = string.Empty;
                string HRA_Plan_1 = string.Empty;

                #region HashtableHRA
                Hashtable HashtableHRA = new Hashtable();
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "241"); // Health Reimbursement Account Tier 4
                //HashtableHRA.Add(3, "239"); // Health Reimbursement Account Tier 2 
                //HashtableHRA.Add(4, "240"); // Health Reimbursement Account Tier 3

                #endregion
                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_4 = string.Empty;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HRAPlanType_CommonCriteria.ToLower().ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            HRA_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            HRA_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            HRA_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            foreach (int key in HashtableHRA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                    {
                                        if (key == 1)
                                        {
                                            HRA_Tier_1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 2)
                                        {
                                            HRA_Tier_4 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            #region merge fields
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            objSlides = objPres.Slides;

                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //if (mySlide.SlideNumber == 10)
                                //if (objSlides[i].SlideNumber == 21 || objSlides[i].SlideNumber == 38)
                                //{
                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                                    {
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                    {
                                        if (objShapes[j].Name.ToString().Equals("HRA Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    if (txtRange.Text.Contains("<<Health Reimbursement Account/ Tier 1>>"))
                                                    {
                                                        txtRange.Replace("<<Health Reimbursement Account/ Tier 1>>", HRA_Tier_1.Trim_String());
                                                    }
                                                    if (txtRange.Text.Contains("<<Health Reimbursement Account / Tier 4>>"))
                                                    {
                                                        txtRange.Replace("<<Health Reimbursement Account / Tier 4>>", HRA_Tier_4.Trim_String());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                                        {
                                            break;
                                        }

                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<HRA_PLAN>>"))
                                        {
                                            txtRange.Replace("<<HRA_PLAN>>", "");
                                        }




                                        if (txtRange.Text.Contains("<< Health Reimbursement Account Carrier Name >>"))
                                        {
                                            txtRange.Replace("<< Health Reimbursement Account Carrier Name >>", HRA_Carrier_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<Medical Plan Benefit Summary Name>>"))
                                        {
                                            txtRange.Replace("<<Medical Plan Benefit Summary Name>>", HRA_Summary_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<FSA_HSA_PLAN>>"))
                                        {
                                            txtRange.Replace("<<FSA_HSA_PLAN>>", " ");
                                        }
                                    }
                                }
                                //}
                            }
                            #endregion
                        }

                        count++;
                    }
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        /// <param name="dtPlanContactDetails">DataTable dtPlanContactDetails contain the plan contact information (Optional Parameter)</param>
        public void WriteContactinformationToPowerPointTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DataTable dtPlanContactDetails = null)
        {
            try
            {
                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;

                int rowCnt = 2;

                objSlides = objPres.Slides;

                for (int slideno = 1; slideno <= objSlides.Count; slideno++)
                {
                    objShapes = objSlides[slideno].Shapes;
                    //if (objSlides[slideno].SlideNumber == 69)
                    //{
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            // If shape is table then iterate through each row and each column 
                            // and find the attribute name and replace it with respective value
                            if (objShapes[j].Name.ToString().Equals("Contact Info Table"))
                            {
                                for (int i = 0; i < dtPlanContactDetails.Rows.Count; i++)
                                {
                                    //if (k > 1)
                                    //{
                                    //    objShapes[j].Table.Rows.Add();
                                    //}
                                    carriername = dtPlanContactDetails.Rows[i]["PlanName"].ToString();
                                    plantype = dtPlanContactDetails.Rows[i]["PlanType"].ToString();
                                    ProductTypeDesc = dtPlanContactDetails.Rows[i]["ProductTypeDesc"].ToString();

                                    if (!string.IsNullOrEmpty(Convert.ToString(dtPlanContactDetails.Rows[i]["ContactPhoneNumber"])) || !string.IsNullOrEmpty(Convert.ToString(dtPlanContactDetails.Rows[i]["ContactEmail"])))
                                    {
                                        objShapes[j].Table.Cell(rowCnt, 1).Shape.TextFrame.TextRange.Text = Convert.ToString(ProductTypeDesc);
                                        objShapes[j].Table.Cell(rowCnt, 2).Shape.TextFrame.TextRange.Text = Convert.ToString(carriername);
                                        objShapes[j].Table.Cell(rowCnt, 3).Shape.TextFrame.TextRange.Text = Convert.ToString(dtPlanContactDetails.Rows[i]["ContactPhoneNumber"]) + "\n" + Convert.ToString(dtPlanContactDetails.Rows[i]["ContactEmail"]);

                                        // k++;
                                        objShapes[j].Table.Rows.Add();
                                        rowCnt++;
                                    }
                                }

                                ////// For deleting blank rows
                                ////for (int kl = 1; kl <= objShapes[j].Table.Rows.Count; kl++)
                                ////{
                                ////    if (kl > 1)
                                ////    {
                                ////        if (string.IsNullOrEmpty(objShapes[j].Table.Rows[kl].Cells[1].Shape.TextFrame.TextRange.Text))
                                ////        {
                                ////            objShapes[j].Table.Rows[kl].Delete();
                                ////        }
                                ////    }
                                ////}
                            }
                        }
                        else
                        {

                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Delete_Contact>>"))
                            {
                                txtRange.Replace("<<Delete_Contact>>", " ");
                            }

                        }
                    }
                    //}
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        public void WriteAdditionalProductsToTemplate4(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanInfoTable, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddlEAPNoOfPlan)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool is_EAP_Selected = false;
                bool is_Patient_Advocacy_Selected = false;
                bool is_Consumer_Driven_Telemedicine_Selected = false;
                bool is_Accident_Selected = false;
                bool is_Voluntary_Cancer_Selected = false;
                bool is_Voluntary_Critical_Illness_Selected = false;
                string PA_CarrierName = string.Empty;
                string Telemedicin_CarrierName = string.Empty;
                string Accident_CarrierName = string.Empty;
                string Voluntary_Cancer_CarrierName = string.Empty;
                string Critical_Illness_CarrierName = string.Empty;
                string EAP_CarrierName = string.Empty;
                string carrierName = string.Empty;
                string wsCarrierName = string.Empty;

                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        {
                            is_Patient_Advocacy_Selected = true;
                            PA_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        }
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.Employee_Assistance_Program)
                        {
                            if (ddlEAPNoOfPlan.SelectedIndex > 0)
                            {
                                is_EAP_Selected = true;
                                EAP_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                            }
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        {
                            is_Consumer_Driven_Telemedicine_Selected = true;
                            Telemedicin_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        {
                            is_Accident_Selected = true;
                            Accident_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            is_Voluntary_Cancer_Selected = true;
                            Voluntary_Cancer_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            is_Voluntary_Critical_Illness_Selected = true;
                            Critical_Illness_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        }
                    }
                }

                objSlides = objPres.Slides;
                carrierName = objCommFun.GetCarrierList("\n", EAP_CarrierName, PA_CarrierName, Telemedicin_CarrierName);
                wsCarrierName = objCommFun.GetCarrierList("\n", Accident_CarrierName, Voluntary_Cancer_CarrierName, Critical_Illness_CarrierName);
                for (int i = 1; i <= objSlides.Count; i++)
                {   //objShapes = mySlide.Shapes;
                    objShapes = objSlides[i].Shapes;

                    //if (objSlides[i].SlideNumber == 63 || objSlides[i].SlideNumber == 58 || objSlides[i].SlideNumber == 59 || objSlides[i].SlideNumber == 60 || objSlides[i].SlideNumber == 61 || objSlides[i].SlideNumber == 62)
                    //{
                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }

                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;
                            if (is_EAP_Selected == true || is_Patient_Advocacy_Selected == true || is_Consumer_Driven_Telemedicine_Selected == true)
                            {
                                if (txtRange.Text.Contains("<<EAP_PA_Telemedi_Plan>>"))
                                {
                                    txtRange.Replace("<<EAP_PA_Telemedi_Plan>>", " ");
                                }
                            }

                            if (txtRange.Text.Contains("<<PA_Tel_EAP_CarrierName>>"))
                            {
                                txtRange.Replace("<<PA_Tel_EAP_CarrierName>>", carrierName);
                            }

                            if (txtRange.Text.Contains("<<Worksite Carrier Name>>"))
                            {
                                txtRange.Replace("<<Worksite Carrier Name>>", wsCarrierName);
                            }

                            if (is_Patient_Advocacy_Selected == true)
                            {
                                if (txtRange.Text.Contains("<<Delete_Patient Advocacy>>"))
                                {
                                    txtRange.Replace("<<Delete_Patient Advocacy>>", " ");
                                }
                            }

                            if (is_Consumer_Driven_Telemedicine_Selected == true)
                            {
                                if (txtRange.Text.Contains("<<Delete_ Telemedicine>>"))
                                {
                                    txtRange.Replace("<<Delete_ Telemedicine>>", " ");

                                }
                            }

                            if (is_Accident_Selected == true)
                            {
                                if (txtRange.Text.Contains("<<Addition_Prod>>"))
                                {
                                    txtRange.Replace("<<Addition_Prod>>", " ");
                                }
                            }

                            if (is_Voluntary_Cancer_Selected == true)
                            {
                                if (txtRange.Text.Contains("<<Addition_Prod>>"))
                                {
                                    txtRange.Replace("<<Addition_Prod>>", " ");
                                }
                            }
                            if (is_Voluntary_Critical_Illness_Selected == true)
                            {
                                if (txtRange.Text.Contains("<<Addition_Prod>>"))
                                {
                                    txtRange.Replace("<<Addition_Prod>>", " ");
                                }
                            }
                        }
                    }
                    //}
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /*-------------------------- CODE ADDED BY Vinod -----------------------------*/
        // modified by shravan
        public void WriteMedicalVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, CheckBoxList chkMedicalVideos, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddllanguage)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool Video1 = false;
                bool Video2 = false;
                bool Video3 = false;
                bool Video4 = false;
                bool Video5 = false;
                bool Video6 = false;
                bool Video7 = false;
                bool Video8 = false;
                //bool Video9 = false;
                bool Video10 = false;
                bool Video11 = false;
                bool Video12 = false;
                bool Video13 = false;
                //bool Video14 = false;
                // bool Video15 = false;
                bool Video16 = false;
                bool Video17 = false;
                bool Video18 = false;
                bool Video19 = false;

                #region spanish videos variable initialization
                bool Video1_Spanish = false;
                bool Video2_Spanish = false;
                bool Video3_Spanish = false;
                bool Video4_Spanish = false;
                bool Video5_Spanish = false;
                bool Video6_Spanish = false;
                bool Video7_Spanish = false;
                bool Video8_Spanish = false;
                //bool Video9_Spanish = false;
                bool Video10_Spanish = false;
                bool Video11_Spanish = false;
                bool Video12_Spanish = false;
                bool Video13_Spanish = false;
                // bool Video14_Spanish = false;
                // bool Video15_Spanish = false;
                bool Video16_Spanish = false;
                bool Video17_Spanish = false;
                bool Video18_Spanish = false;
                bool Video19_Spanish = false;
                #endregion

                for (int z = 0; z <= chkMedicalVideos.Items.Count - 1; z++)
                {
                    if (chkMedicalVideos.Items[z].Selected == true)
                    {
                        int option = int.Parse(chkMedicalVideos.Items[z].Value);
                        switch (option)
                        {
                            case 0: Video1 = true; Video1_Spanish = true; break;
                            case 1: Video2 = true; Video2_Spanish = true; break;
                            case 2: Video3 = true; Video3_Spanish = true; break;
                            case 3: Video4 = true; Video4_Spanish = true; break;
                            case 4: Video5 = true; Video5_Spanish = true; break;
                            case 5: Video6 = true; Video6_Spanish = true; break;
                            case 6: Video7 = true; Video7_Spanish = true; break;
                            case 7: Video8 = true; Video8_Spanish = true; break;
                            //case 8: Video9 = true; Video9_Spanish = true; break;
                            case 9: Video10 = true; Video10_Spanish = true; break;
                            case 10: Video11 = true; Video11_Spanish = true; break;
                            case 11: Video12 = true; Video12_Spanish = true; break;
                            case 12: Video13 = true; Video13_Spanish = true; break;
                            // case 13: Video14 = true; Video14_Spanish = true; break;
                            // case 14: Video15 = true; Video15_Spanish = true; break;
                            case 15: Video16 = true; Video16_Spanish = true; break;
                            case 16: Video17 = true; Video17_Spanish = true; break;
                            case 17: Video18 = true; Video18_Spanish = true; break;
                            case 18: Video19 = true; Video19_Spanish = true; break;
                        }
                    }
                }

                #region merge fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    //objShapes = mySlide.Shapes;

                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                        {
                        }
                        else
                        {

                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;
                            string language = ddllanguage.SelectedItem.Value;

                            #region english videos for the merge fields

                            if (language == "English" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<MedVideo1>>"))
                                {
                                    if (Video1 == true)
                                        txtRange.Replace("<<MedVideo1>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo2>>"))
                                {
                                    if (Video2 == true)
                                        txtRange.Replace("<<MedVideo2>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo3>>"))
                                {
                                    if (Video3 == true)
                                        txtRange.Replace("<<MedVideo3>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo4>>"))
                                {
                                    if (Video4 == true)
                                        txtRange.Replace("<<MedVideo4>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo5>>"))
                                {
                                    if (Video5 == true)
                                        txtRange.Replace("<<MedVideo5>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo6>>"))
                                {
                                    if (Video6 == true)
                                        txtRange.Replace("<<MedVideo6>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo7>>"))
                                {
                                    if (Video7 == true)
                                        txtRange.Replace("<<MedVideo7>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo8>>"))
                                {
                                    if (Video8 == true)
                                        txtRange.Replace("<<MedVideo8>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<MedVideo9>>"))
                                //{
                                //    if (Video9 == true)
                                //        txtRange.Replace("<<MedVideo9>>", " ");
                                //}

                                if (txtRange.Text.Contains("<<MedVideo10>>"))
                                {
                                    if (Video10 == true)
                                        txtRange.Replace("<<MedVideo10>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo11>>"))
                                {
                                    if (Video11 == true)
                                        txtRange.Replace("<<MedVideo11>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo12>>"))
                                {
                                    if (Video12 == true)
                                        txtRange.Replace("<<MedVideo12>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo13>>"))
                                {
                                    if (Video13 == true)
                                        txtRange.Replace("<<MedVideo13>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<MedVideo14>>"))
                                //{
                                //    if (Video14 == true)
                                //        txtRange.Replace("<<MedVideo14>>", " ");
                                //}
                                //if (txtRange.Text.Contains("<<MedVideo15>>"))
                                //{
                                //    if (Video15 == true)
                                //        txtRange.Replace("<<MedVideo15>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<MedVideo16>>"))
                                {
                                    if (Video16 == true)
                                        txtRange.Replace("<<MedVideo16>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo17>>"))
                                {
                                    if (Video17 == true)
                                        txtRange.Replace("<<MedVideo17>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo21>>"))
                                {
                                    if (Video18 == true)
                                        txtRange.Replace("<<MedVideo21>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo22>>"))
                                {
                                    if (Video19 == true)
                                        txtRange.Replace("<<MedVideo22>>", " ");
                                }
                            }
                            #endregion

                            #region english videos for the merge fields

                            if (language == "Spanish" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<MedVideo1_Spanish>>"))
                                {
                                    if (Video1_Spanish == true)
                                        txtRange.Replace("<<MedVideo1_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo2_Spanish>>"))
                                {
                                    if (Video2_Spanish == true)
                                        txtRange.Replace("<<MedVideo2_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo3_Spanish>>"))
                                {
                                    if (Video3_Spanish == true)
                                        txtRange.Replace("<<MedVideo3_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo4_Spanish>>"))
                                {
                                    if (Video4_Spanish == true)
                                        txtRange.Replace("<<MedVideo4_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo5_Spanish>>"))
                                {
                                    if (Video5_Spanish == true)
                                        txtRange.Replace("<<MedVideo5_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo6_Spanish>>"))
                                {
                                    if (Video6_Spanish == true)
                                        txtRange.Replace("<<MedVideo6_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo7_Spanish>>"))
                                {
                                    if (Video7_Spanish == true)
                                        txtRange.Replace("<<MedVideo7_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo8_Spanish>>"))
                                {
                                    if (Video8_Spanish == true)
                                        txtRange.Replace("<<MedVideo8_Spanish>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<MedVideo9_Spanish>>"))
                                //{
                                //    if (Video9_Spanish == true)
                                //        txtRange.Replace("<<MedVideo9_Spanish>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<MedVideo10_Spanish>>"))
                                {
                                    if (Video10_Spanish == true)
                                        txtRange.Replace("<<MedVideo10_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo11_Spanish>>"))
                                {
                                    if (Video11_Spanish == true)
                                        txtRange.Replace("<<MedVideo11_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo12_Spanish>>"))
                                {
                                    if (Video12_Spanish == true)
                                        txtRange.Replace("<<MedVideo12_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo13_Spanish>>"))
                                {
                                    if (Video13_Spanish == true)
                                        txtRange.Replace("<<MedVideo13_Spanish>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<MedVideo14_Spanish>>"))
                                //{
                                //    if (Video14_Spanish == true)
                                //        txtRange.Replace("<<MedVideo14_Spanish>>", " ");
                                //}
                                //if (txtRange.Text.Contains("<<MedVideo15_Spanish>>"))
                                //{
                                //    if (Video15_Spanish == true)
                                //        txtRange.Replace("<<MedVideo15_Spanish>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<MedVideo16_Spanish>>"))
                                {
                                    if (Video16_Spanish == true)
                                        txtRange.Replace("<<MedVideo16_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo17_Spanish>>"))
                                {
                                    if (Video17_Spanish == true)
                                        txtRange.Replace("<<MedVideo17_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo21_Spanish>>"))
                                {
                                    if (Video18_Spanish == true)
                                        txtRange.Replace("<<MedVideo21_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo22_Spanish>>"))
                                {
                                    if (Video19_Spanish == true)
                                        txtRange.Replace("<<MedVideo22_Spanish>>", " ");
                                }
                            }
                            #endregion



                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteDentalVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, CheckBoxList chkDentalVideos, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddllanguage)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool Video1 = false;
                bool Video2 = false;

                #region spanish video variable initialization
                bool Video1_Spanish = false;
                bool Video2_Spanish = false;
                #endregion

                for (int z = 0; z <= chkDentalVideos.Items.Count - 1; z++)
                {
                    if (chkDentalVideos.Items[z].Selected == true)
                    {
                        switch (z)
                        {
                            case 0: Video1 = true;
                                Video1_Spanish = true;
                                break;
                            case 1: Video2 = true;
                                Video2_Spanish = true;
                                break;
                        }
                    }
                }

                #region merge fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    //objShapes = mySlide.Shapes;

                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                        {
                        }
                        else
                        {

                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            string language = ddllanguage.SelectedItem.Value;

                            #region dental english mergefields
                            if (language == "English" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<DenVideo1>>"))
                                {
                                    if (Video1 == true)
                                        txtRange.Replace("<<DenVideo1>>", " ");
                                }
                                if (txtRange.Text.Contains("<<VisionVideo1>>"))
                                {
                                    if (Video2 == true)
                                        txtRange.Replace("<<VisionVideo1>>", " ");
                                }
                            }

                            #endregion

                            #region dental english mergefields

                            if (language == "Spanish" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<DenVideo1_Spanish>>"))
                                {
                                    if (Video1_Spanish == true)
                                        txtRange.Replace("<<DenVideo1_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<VisionVideo1_Spanish>>"))
                                {
                                    if (Video2_Spanish == true)
                                        txtRange.Replace("<<VisionVideo1_Spanish>>", " ");
                                }
                            }

                            #endregion
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteHSAVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, CheckBoxList chkHSAVideos, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddllanguage)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool Video1 = false;
                bool Video2 = false;
                bool Video3 = false;
                bool Video4 = false;
                bool Video5 = false;

                #region spanish video variable initialization
                bool Video1_Spanish = false;
                bool Video2_Spanish = false;
                bool Video3_Spanish = false;
                bool Video4_Spanish = false;
                bool Video5_Spanish = false;

                #endregion

                for (int z = 0; z <= chkHSAVideos.Items.Count - 1; z++)
                {
                    if (chkHSAVideos.Items[z].Selected == true)
                    {
                        switch (z)
                        {
                            case 0: Video1 = true; Video1_Spanish = true; break;
                            case 1: Video2 = true; Video2_Spanish = true; break;
                            case 2: Video3 = true; Video3_Spanish = true; break;
                            case 3: Video4 = true; Video4_Spanish = true; break;
                            case 4: Video5 = true; Video5_Spanish = true; break;
                        }
                    }
                }

                #region Merge Fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                        {
                        }
                        else
                        {

                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;
                            string language = ddllanguage.SelectedItem.Value;

                            #region English video Slides mergefileds

                            if (language == "English" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<AddnProdVideo10>>"))
                                {
                                    if (Video1 == true)
                                        txtRange.Replace("<<AddnProdVideo10>>", " ");
                                }
                                if (txtRange.Text.Contains("<<FSAVideo1>>"))
                                {
                                    if (Video2 == true)
                                        txtRange.Replace("<<FSAVideo1>>", " ");
                                }
                                if (txtRange.Text.Contains("<<HRAVideo1>>"))
                                {
                                    if (Video3 == true)
                                        txtRange.Replace("<<HRAVideo1>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo9>>"))
                                {
                                    if (Video4 == true)
                                        txtRange.Replace("<<MedVideo9>>", " ");
                                }
                                if (txtRange.Text.Contains("<<HSAFSAEnglish>>"))
                                {
                                    if (Video5 == true)
                                        txtRange.Replace("<<HSAFSAEnglish>>", " ");
                                }

                            }
                            #endregion

                            #region spanish video Slides mergefileds

                            if (language == "Spanish" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<AddnProdVideo10_Spanish>>"))
                                {
                                    if (Video1_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo10_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<FSAVideo1_Spanish>>"))
                                {
                                    if (Video2_Spanish == true)
                                        txtRange.Replace("<<FSAVideo1_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<HRAVideo1_Spanish>>"))
                                {
                                    if (Video3_Spanish == true)
                                        txtRange.Replace("<<HRAVideo1_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<MedVideo9_Spanish>>"))
                                {
                                    if (Video4_Spanish == true)
                                        txtRange.Replace("<<MedVideo9_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<HSAFSA_Spanish>>"))
                                {
                                    if (Video5_Spanish == true)
                                        txtRange.Replace("<<HSAFSA_Spanish>>", " ");
                                }
                            }
                            #endregion
                        }
                    }
                }
                #endregion

            }//tryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteSTDLTDVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, CheckBoxList chkSTDLTDVideos, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddllanguage)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool Video1 = false;
                bool Video2 = false;
                bool Video3 = false;
                bool Video4 = false;
                bool Video5 = false;
                #region
                bool Video1_Spanish = false;
                bool Video2_Spanish = false;
                bool Video3_Spanish = false;
                bool Video4_Spanish = false;
                bool Video5_Spanish = false;
                #endregion

                for (int z = 0; z <= chkSTDLTDVideos.Items.Count - 1; z++)
                {
                    if (chkSTDLTDVideos.Items[z].Selected == true)
                    {
                        switch (z)
                        {
                            case 0: Video1 = true; Video1_Spanish = true; break;
                            case 1: Video2 = true; Video2_Spanish = true; break;
                            case 2: Video3 = true; Video3_Spanish = true; break;
                            case 3: Video4 = true; Video4_Spanish = true; break;
                            case 4: Video5 = true; Video5_Spanish = true; break;
                        }
                    }
                }

                #region Merge Fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                        {
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;
                            string language = ddllanguage.SelectedItem.Value;

                            #region english videos for merge fields
                            if (language == "English" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<DisabltyVideo1>>"))
                                {
                                    if (Video1 == true)
                                        txtRange.Replace("<<DisabltyVideo1>>", " ");
                                }
                                if (txtRange.Text.Contains("<<LifeADVideo1>>"))
                                {
                                    if (Video2 == true)
                                        txtRange.Replace("<<LifeADVideo1>>", " ");
                                }
                                if (txtRange.Text.Contains("<<LifeADVideo2>>"))
                                {
                                    if (Video3 == true)
                                        txtRange.Replace("<<LifeADVideo2>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo5>>"))
                                {
                                    if (Video4 == true)
                                        txtRange.Replace("<<AddnProdVideo5>>", " ");
                                }
                                if (txtRange.Text.Contains("<<VolBenfitVideo1>>"))
                                {
                                    if (Video5 == true)
                                        txtRange.Replace("<<VolBenfitVideo1>>", " ");
                                }
                            }
                            #endregion

                            #region spanish videos for merge fields
                            if (language == "Spanish" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<DisabltyVideo1_Spanish>>"))
                                {
                                    if (Video1_Spanish == true)
                                        txtRange.Replace("<<DisabltyVideo1_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<LifeADVideo1_Spanish>>"))
                                {
                                    if (Video2_Spanish == true)
                                        txtRange.Replace("<<LifeADVideo1_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<LifeADVideo2_Spanish>>"))
                                {
                                    if (Video3_Spanish == true)
                                        txtRange.Replace("<<LifeADVideo2_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo5_Spanish>>"))
                                {
                                    if (Video4_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo5_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<VolBenfitVideo1_Spanish>>"))
                                {
                                    if (Video5_Spanish == true)
                                        txtRange.Replace("<<VolBenfitVideo1_Spanish>>", " ");
                                }
                            }
                            #endregion
                        }
                    }
                }
                #endregion

            }//tryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteAdditionalProductsVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, CheckBoxList chkAdditionalProductsVideos, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddllanguage)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool Video12 = false;
                bool Video12_Spanish = false;

                #region variable declaration and initialization : Engish Videos

                bool Video1 = false;
                bool Video2 = false;
                bool Video3 = false;
                bool Video4 = false;
                // bool Video5 = false;
                bool Video6 = false;

                // bool Video7 = false;
                bool Video8 = false;
                //bool Video9 = false;
                //bool Video10 = false;
                bool Video11 = false;

                #endregion

                #region variable declaration and initialization : Spanish Videos

                bool Video1_Spanish = false;
                bool Video2_Spanish = false;
                bool Video3_Spanish = false;
                bool Video4_Spanish = false;
                //bool Video5_Spanish = false;
                bool Video6_Spanish = false;

                //Variable for the Spanish videos s
                //bool Video7_Spanish = false;
                bool Video8_Spanish = false;
                //bool Video9_Spanish = false;
                //bool Video10_Spanish = false;
                bool Video11_Spanish = false;

                #endregion


                for (int count = 0; count <= chkAdditionalProductsVideos.Items.Count - 1; count++)
                {
                    if (chkAdditionalProductsVideos.Items[count].Selected == true)
                    {
                        int index = int.Parse(chkAdditionalProductsVideos.Items[count].Value);
                        switch (index)
                        {

                            case 0: Video1 = true; Video1_Spanish = true; break;
                            case 1: Video2 = true; Video2_Spanish = true; break;
                            case 2: Video3 = true; Video3_Spanish = true; break;
                            case 3: Video4 = true; Video4_Spanish = true; break;
                            //case 4: Video5 = true; Video5_Spanish = true; break;
                            case 5: Video6 = true; Video6_Spanish = true; break;

                            #region switch case handling

                            //case 6: Video7 = true; Video7_Spanish = true; break;
                            case 7: Video8 = true; Video8_Spanish = true; break;
                            //case 8: Video9 = true; Video9_Spanish = true; break;
                            // case 9: Video10 = true; Video10_Spanish = true; break;
                            case 10: Video11 = true; Video11_Spanish = true; break;
                            case 11: Video12 = true; Video12_Spanish = true; break;
                            #endregion
                        }

                    }
                }

                #region Merge Fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                        {
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            //string language = "Both";
                            string language = ddllanguage.SelectedItem.Value;
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;
                            if (language == "English" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<AddnProdVideo1>>"))
                                {
                                    if (Video1 == true)
                                        txtRange.Replace("<<AddnProdVideo1>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo2>>"))
                                {
                                    if (Video2 == true)
                                        txtRange.Replace("<<AddnProdVideo2>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo3>>"))
                                {
                                    if (Video3 == true)
                                        txtRange.Replace("<<AddnProdVideo3>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo4>>"))
                                {
                                    if (Video4 == true)
                                        txtRange.Replace("<<AddnProdVideo4>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<AddnProdVideo5>>"))
                                //{
                                //    if (Video5 == true)
                                //        txtRange.Replace("<<AddnProdVideo5>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<AddnProdVideo6>>"))
                                {
                                    if (Video6 == true)
                                        txtRange.Replace("<<AddnProdVideo6>>", " ");
                                }

                                #region New 5 English video Slides mergefileds

                                //if (txtRange.Text.Contains("<<AddnProdVideo10>>"))
                                //{
                                //    if (Video7 == true)
                                //        txtRange.Replace("<<AddnProdVideo10>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<AddnProdVideo11>>"))
                                {
                                    if (Video8 == true)
                                        txtRange.Replace("<<AddnProdVideo11>>", " ");
                                }

                                if (txtRange.Text.Contains("<<AddnProdVideo12>>"))
                                {
                                    if (Video12 == true)
                                        txtRange.Replace("<<AddnProdVideo12>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<AddnProdVideo9>>"))
                                //{
                                //    if (Video9 == true)
                                //        txtRange.Replace("<<AddnProdVideo9>>", " ");
                                //}
                                //if (txtRange.Text.Contains("<<AddnProdVideo8>>"))
                                //{
                                //    if (Video10 == true)
                                //        txtRange.Replace("<<AddnProdVideo8>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<AddnProdVideo7>>"))
                                {
                                    if (Video11 == true)
                                        txtRange.Replace("<<AddnProdVideo7>>", " ");
                                }
                                #endregion
                            }

                            #region Spanish video Slides mergefileds

                            if (language == "Spanish" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<AddnProdVideo1_Spanish>>"))
                                {
                                    if (Video1_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo1_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo2_Spanish>>"))
                                {
                                    if (Video2_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo2_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo3_Spanish>>"))
                                {
                                    if (Video3_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo3_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo4_Spanish>>"))
                                {
                                    if (Video4_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo4_Spanish>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<AddnProdVideo5_Spanish>>"))
                                //{
                                //    if (Video5_Spanish == true)
                                //        txtRange.Replace("<<AddnProdVideo5_Spanish>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<AddnProdVideo6_Spanish>>"))
                                {
                                    if (Video6_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo6_Spanish>>", " ");
                                }

                                //if (txtRange.Text.Contains("<<AddnProdVideo10_Spanish>>"))
                                //{
                                //    if (Video7_Spanish == true)
                                //        txtRange.Replace("<<AddnProdVideo10_Spanish>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<AddnProdVideo11_Spanish>>"))
                                {
                                    if (Video8_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo11_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo12_Spanish>>"))
                                {
                                    if (Video12_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo12_Spanish>>", " ");
                                }
                                //if (txtRange.Text.Contains("<<AddnProdVideo9_Spanish>>"))
                                //{
                                //    if (Video9_Spanish == true)
                                //        txtRange.Replace("<<AddnProdVideo9_Spanish>>", " ");
                                //}
                                //if (txtRange.Text.Contains("<<AddnProdVideo8_Spanish>>"))
                                //{
                                //    if (Video10_Spanish == true)
                                //        txtRange.Replace("<<AddnProdVideo8_Spanish>>", " ");
                                //}
                                if (txtRange.Text.Contains("<<AddnProdVideo7_Spanish>>"))
                                {
                                    if (Video11_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo7_Spanish>>", " ");
                                }
                            #endregion
                            }


                        }
                    }
                }
                #endregion

            }//tryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteHrGeneralEducationVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, CheckBoxList chkHrGeneralEducationVideos, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddllanguage)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool Video1 = false;
                bool Video2 = false;
                bool Video3 = false;
                bool Video4 = false;
                bool Video5 = false;
                bool Video6 = false;
                bool Video7 = false;
                bool Video8 = false;
                bool Video9 = false;
                bool Video10 = false;

                #region spanish video variable initialization
                bool Video1_Spanish = false;
                bool Video2_Spanish = false;
                bool Video3_Spanish = false;
                bool Video4_Spanish = false;
                bool Video5_Spanish = false;
                bool Video6_Spanish = false;
                bool Video7_Spanish = false;
                bool Video8_Spanish = false;
                bool Video9_Spanish = false;
                bool Video10_Spanish = false;
                #endregion
                int count = 0;
                for (int z = 0; z <= chkHrGeneralEducationVideos.Items.Count - 1; z++)
                {
                    if (chkHrGeneralEducationVideos.Items[z].Selected == true)
                    {
                        count = int.Parse(chkHrGeneralEducationVideos.Items[z].Value);
                        switch (count)
                        {
                            case 0: Video1 = true;
                                Video1_Spanish = true;
                                break;
                            case 1: Video2 = true;
                                Video2_Spanish = true;
                                break;
                            case 2: Video3 = true;
                                Video3_Spanish = true;
                                break;
                            case 3: Video4 = true;
                                Video4_Spanish = true;
                                break;
                            case 4: Video5 = true;
                                Video5_Spanish = true;
                                break;
                            case 5: Video6 = true;
                                Video6_Spanish = true;
                                break;
                            case 6: Video7 = true;
                                Video7_Spanish = true;
                                break;
                            case 7: Video8 = true;
                                Video8_Spanish = true;
                                break;
                            case 8: Video9 = true;
                                Video9_Spanish = true;
                                break;
                            case 9: Video10 = true;
                                Video10_Spanish = true;
                                break;
                        }
                    }
                }

                #region merge fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    //objShapes = mySlide.Shapes;

                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                        {
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }
                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            string language = ddllanguage.SelectedItem.Value;

                            #region Hr and General english mergefields
                            if (language == "English" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<AddnProdVideo8>>"))
                                {
                                    if (Video1 == true)
                                        txtRange.Replace("<<AddnProdVideo8>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo9>>"))
                                {
                                    if (Video2 == true)
                                        txtRange.Replace("<<AddnProdVideo9>>", " ");
                                }

                                //Balance Billing
                                if (txtRange.Text.Contains("<<MedVideo24>>"))
                                {
                                    if (Video3 == true)
                                        txtRange.Replace("<<MedVideo24>>", " ");
                                }
                                //COBRA
                                if (txtRange.Text.Contains("<<MedVideo18>>"))
                                {
                                    if (Video4 == true)
                                        txtRange.Replace("<<MedVideo18>>", " ");
                                }
                                //FMLA
                                if (txtRange.Text.Contains("<<MedVideo19>>"))
                                {
                                    if (Video5 == true)
                                        txtRange.Replace("<<MedVideo19>>", " ");
                                }
                                //IRS 1095 Tax Form
                                if (txtRange.Text.Contains("<<MedVideo20>>"))
                                {
                                    if (Video6 == true)
                                        txtRange.Replace("<<MedVideo20>>", " ");
                                }
                                //PTO Paid Time Off
                                if (txtRange.Text.Contains("<<MedVideo23>>"))
                                {
                                    if (Video8 == true)
                                        txtRange.Replace("<<MedVideo23>>", " ");
                                }

                                //Key Health Insurance
                                if (txtRange.Text.Contains("<<MedVideo14>>"))
                                {
                                    if (Video7 == true)
                                        txtRange.Replace("<<MedVideo14>>", " ");
                                }

                                //Qualifying Life Events
                                if (txtRange.Text.Contains("<<MedVideo15>>"))
                                {
                                    if (Video9 == true)
                                        txtRange.Replace("<<MedVideo15>>", " ");
                                }
                                //EOB
                                if (txtRange.Text.Contains("<<MedVideo25>>"))
                                {
                                    if (Video10 == true)
                                        txtRange.Replace("<<MedVideo25>>", " ");
                                }

                            }

                            #endregion

                            #region Hr and General spanish mergefields

                            if (language == "Spanish" || language == "Both")
                            {
                                if (txtRange.Text.Contains("<<AddnProdVideo8_Spanish>>"))
                                {
                                    if (Video1_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo8_Spanish>>", " ");
                                }
                                if (txtRange.Text.Contains("<<AddnProdVideo9_Spanish>>"))
                                {
                                    if (Video2_Spanish == true)
                                        txtRange.Replace("<<AddnProdVideo9_Spanish>>", " ");
                                }

                                //Balance Billing
                                if (txtRange.Text.Contains("<<MedVideo24_Spanish>>"))
                                {
                                    if (Video3_Spanish == true)
                                        txtRange.Replace("<<MedVideo24_Spanish>>", " ");
                                }
                                //COBRA
                                if (txtRange.Text.Contains("<<MedVideo18_Spanish>>"))
                                {
                                    if (Video4_Spanish == true)
                                        txtRange.Replace("<<MedVideo18_Spanish>>", " ");
                                }
                                //FMLA
                                if (txtRange.Text.Contains("<<MedVideo19_Spanish>>"))
                                {
                                    if (Video5_Spanish == true)
                                        txtRange.Replace("<<MedVideo19_Spanish>>", " ");
                                }
                                //IRS 1095 Tax Form
                                if (txtRange.Text.Contains("<<MedVideo20_Spanish>>"))
                                {
                                    if (Video6_Spanish == true)
                                        txtRange.Replace("<<MedVideo20_Spanish>>", " ");
                                }
                                //PTO Paid Time Off
                                if (txtRange.Text.Contains("<<MedVideo23_Spanish>>"))
                                {
                                    if (Video8_Spanish == true)
                                        txtRange.Replace("<<MedVideo23_Spanish>>", " ");
                                }
                                //Key Health Insurance
                                if (txtRange.Text.Contains("<<MedVideo14_Spanish>>"))
                                {
                                    if (Video7_Spanish == true)
                                        txtRange.Replace("<<MedVideo14_Spanish>>", " ");
                                }
                                //Qualifying Life Events
                                if (txtRange.Text.Contains("<<MedVideo15_Spanish>>"))
                                {
                                    if (Video9_Spanish == true)
                                        txtRange.Replace("<<MedVideo15_Spanish>>", " ");
                                }
                                //EOB
                                if (txtRange.Text.Contains("<<MedVideo25_Spanish>>"))
                                {
                                    if (Video10_Spanish == true)
                                        txtRange.Replace("<<MedVideo25_Spanish>>", " ");
                                }
                            }

                            #endregion
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteMobileVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, CheckBoxList chkMobileVideos, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;
                bool Video1 = false;

                for (int z = 0; z <= chkMobileVideos.Items.Count - 1; z++)
                {
                    if (chkMobileVideos.Items[z].Selected == true)
                    {
                        switch (z)
                        {
                            case 0: Video1 = true; break;
                        }
                    }
                }

                #region Merge Fields
                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;
                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine)
                        {
                        }
                        else
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoFalse)
                            {
                                break;
                            }

                            txtFrame = objShapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;
                            if (txtRange.Text.Contains("<<MobileApp>>"))
                            {
                                if (Video1 == true)
                                    txtRange.Replace("<<MobileApp>>", " ");
                            }
                        }
                    }
                }
                #endregion

            }//tryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEligibility(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {


                SummaryDetail sd = new SummaryDetail();
                DataTable Emp = new DataTable();
                string EmployeeStatus = string.Empty;
                string Working = string.Empty;
                string Frequency = string.Empty;
                string UOM = string.Empty;
                string Defination_UnmarriedChildAge = string.Empty;
                string Medical_Waiting_Period = string.Empty;
                string domesticPartner = string.Empty;

                SummaryDetail sd1 = new SummaryDetail();
                DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

                if (AccountDS.Tables.Count > 2)
                {
                    Emp = AccountDS.Tables[2];
                    if (Emp.Rows.Count > 0)
                    {
                        EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                    }
                }

                DataTable EligibilityDS = new DataTable();
                EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

                if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                {
                    Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                    domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                    Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                    IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                 where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                 select product;

                    foreach (DataRow Def_Eligible_Emp in query)
                    {
                        EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                        //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                        //{
                        //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                        //}
                        Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                        Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                        UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                    }

                }

                objSlides = objPres.Slides;

                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;

                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (!(objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine))
                        {
                            if (objShapes[j].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoTrue)
                            {
                                txtFrame = objShapes[j].TextFrame;
                                txtRange = txtFrame.TextRange;

                                if (txtRange.Text.Contains("<<Employee Status>>"))
                                {
                                    txtRange.Replace("<<Employee Status>>", EmployeeStatus.ToString());
                                }

                                if (txtRange.Text.Contains("<<working>>"))
                                {
                                    txtRange.Replace("<<working>>", Working.ToString() + " " + UOM.ToString() + " " + Frequency.ToString());
                                }

                                if (txtRange.Text.Contains("<<Eligibility Rule – Waiting Period>>"))
                                {
                                    txtRange.Replace("<<Eligibility Rule – Waiting Period>>", Medical_Waiting_Period.ToString());
                                }

                                if (txtRange.Text.Contains("<<Eligibility Rule – Definition of Dependent – Spouse>>"))
                                {
                                    string str = " ";
                                    if (domesticPartner.ToString().Trim() != "")
                                    {
                                        str = "Legally married Spouse";
                                        str = str + "\n" + "Domestic Partner - " + domesticPartner.ToString();
                                    }
                                    txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Spouse>>", str);
                                }

                                if (txtRange.Text.Contains("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>"))
                                {
                                    if (Defination_UnmarriedChildAge.ToString().Trim() != "")
                                    {
                                        txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", "Covered up to age " + Defination_UnmarriedChildAge.ToString());
                                    }
                                    else
                                    {
                                        txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", " ");
                                    }
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}