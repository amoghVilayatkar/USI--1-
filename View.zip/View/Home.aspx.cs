﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using System.Configuration;
using System.IO;
using BenefitPointSummaryPortal.BAL.BenefitSummary;

namespace BenefitPointSummaryPortal.View
{
    public partial class Home1 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS commnObj = new CommonFunctionsBS();
        protected void Page_Load(object sender, EventArgs e)
        {

            divPopup.Controls.Add(commnObj.Writer_FooterText_ForAllPages());
            div_footer.Controls.Add(commnObj.Writer_FooterText_ForAllPages());
            GetUserDetails();
        }

        protected void lnkBenefitSummary1_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template1";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("BenefitSummaryReport.aspx");
        }

        protected void lnkBenefitSummary2_Click(object sender, EventArgs e)
        {

            Session["Summary"] = "Template2";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("BenefitSummaryReport.aspx");
        }

        // Uncomment the following block of code if the Client wants to use old UI 
        /*
        //protected void lnkBenefitSummary3_Click(object sender, EventArgs e)
        //{
        //    Session["Summary"] = "Template3";
        //    Response.Redirect("BenefitSummaryReport.aspx");
        //}
        */

        protected void lnkBenefitSummary3_Click(object sender, EventArgs e)
        {
            Session["Title"] = "";
            Session["Summary"] = "Template3_V2";
            Session["Title"] = "Employee Benefit Summaries";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("BenefitSummaryReport_V2.aspx");
        }

        protected void lnkBenefitSummary4_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template4";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("BenefitSummaryReport.aspx");
        }

        protected void lnkBenefitSummary5_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template5";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("BenefitSummaryReport.aspx");
        }

        protected void lnkBenefitSummary6_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template6";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("BenefitSummaryReport.aspx");
        }

        protected void lnkBenefitSummary7_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template7";
            Response.Redirect("BenefitSummaryReport.aspx");
        }

        protected void lnkBenefitSummary8_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template8";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("BenefitSummaryReport_AnnualLegalNotice.aspx");
        }
        protected void lnkpowerPoint_v2_Click(object sender, EventArgs e)
        {
            Session["Title"] = "";
            Session["DeliverableCategory"] = "Employee Communications";
            Session["Summary"] = "PowerPointColorfulDots_v2";
            Session["Title"] = "PowerPoint Presentations";
            Response.Redirect("BenefitSummaryReport_V2.aspx");
        }

        protected void lnkPowerPoint1_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PowerPoint1";

            Response.Redirect("BenefitSummaryReport.aspx");
        }

        protected void lnkPowerPoint2_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PowerPoint2";

            Response.Redirect("BenefitSummaryReport.aspx");
        }
        protected void lnkPowerPoint3_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PowerPoint3";

            Response.Redirect("BenefitSummaryReport.aspx");
        }

        protected void lnkTimeline1_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Timeline1";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("TimeLine.aspx");
        }

        protected void lnkTimeline2_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Timeline2";

            Response.Redirect("TimeLine.aspx");
        }

        //protected void lnkTools1_Click(object sender, EventArgs e)
        //{
        //    Session["Summary"] = "Tools1";

        //    Response.Redirect("Tools.aspx");
        //}

        protected void lnkTools1_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Tools1_5500_Worksheet";
            Session["Title"] = "";
            Session["Title"] = "5500 Worksheet";
            Session["DeliverableCategory"] = "Compliance";
            Response.Redirect("BenefitSummaryReport_V2.aspx");
        }

        protected void lnkComplianceCalculators_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ComplianceCalculators";
            Session["DeliverableCategory"] = "Compliance";
            Response.Redirect("ComplianceCalculators.aspx");

        }
        protected void lnkTools2_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Tools2";

            Response.Redirect("Tools.aspx");
        }
        protected void lnkAcquisition_Transmittal_Form_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Tools2";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("Acquisition_Transmittal_Form.aspx");
        }
        protected void lnkAccountProfile_Detailed_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Tools2";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("AccountProfileSummary_Detailed.aspx");
        }

        protected void lnkReports1_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Reports1";

            Response.Redirect("Reports.aspx");
        }
        protected void lnkReports2_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Reports2_RenewalStatusReport";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            Response.Redirect("BenefitSummaryReport_V2.aspx");
        }

        protected void lnkTools3_ContractReview_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Tools_ContractReview";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("Tools_ContractReview.aspx");
        }
        protected void lnkTools4_ClientContract_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Tools_ClientContact";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("Tools_ClientContact.aspx");
        }

        protected void lnkTools5_ClientIntake_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ClientIntakeForm";
            Session["DeliverableCategory"] = "HR Technology";
            Response.Redirect("Tools.aspx");
        }

        protected void lnkTools6_ClientIntakePHM_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ClientIntakeFormPHM";
            Session["DeliverableCategory"] = "Population Health Management";
            Response.Redirect("Tools.aspx");
        }

        protected void lnkClientIntakeCompliance_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ClientIntakeFormCompliance";
            Session["DeliverableCategory"] = "Compliance";
            Response.Redirect("Tools.aspx");

        }
        protected void lnkServiceCalendar1_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ServiceCalendar1";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("ServiceCalendar.aspx");
        }

        protected void lnkServiceCalendar2_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ServiceCalendar2";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("ServiceCalendar.aspx");
        }

        protected void lnkServiceCalendar3_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ServiceCalendar3";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("ServiceCalendar.aspx");
        }

        protected void lnkCompliance1_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template1";
            Session["DeliverableCategory"] = "Compliance";
            Response.Redirect("Compliance.aspx");
        }

        protected void lnkDetailedCompliance_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template2";
            Session["DeliverableCategory"] = "Compliance";
            Response.Redirect("Compliance.aspx");
        }
        protected void lnkComplianceChecklist_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Template1";
            Session["DeliverableCategory"] = "Compliance";
            Response.Redirect("ComplianceChecklist.aspx");
        }

        private void GetUserDetails()
        {
            try
            {
                string DisplayName = string.Empty;
                string Department = string.Empty;
                string physicalDeliveryOfficeName = string.Empty;
                string company = string.Empty;

                string windowsLogin = Page.User.Identity.Name;
                //Response.Write("windowsLogin : " + windowsLogin);
                //Response.Write("HttpContext : " + Request.RequestContext.HttpContext.User.Identity.Name);
                //Response.Write("Request.ServerVariables : " + Request.ServerVariables["LOGON_USER"]);


                //Normally if the domain is present you get a string like DOMAINNAME\username, remove the domain
                int hasDomain = windowsLogin.IndexOf(@"\");
                if (hasDomain > 0)
                {
                    windowsLogin = windowsLogin.Remove(0, hasDomain + 1);
                } //end if 


                DirectoryEntry de = new DirectoryEntry("LDAP://USII");
                de.AuthenticationType = AuthenticationTypes.Secure;

                DirectorySearcher deSearch = new DirectorySearcher();
                deSearch.SearchRoot = de;
                //SearchResultCollection results;
                SearchResult results;
                deSearch.PropertiesToLoad.Add("displayname");//first name
                deSearch.PropertiesToLoad.Add("userWorkstations");//first name
                deSearch.PropertiesToLoad.Add("department");//first name
                deSearch.PropertiesToLoad.Add("physicalDeliveryOfficeName");//first name
                deSearch.PropertiesToLoad.Add("company");//first name
                //Search the USER object in the hierachy                   
                //deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + loginUserName + "))";
                // deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "mayur.darshale" + "))";
                //deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "rickey.brown" + "))";
                //deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "laurie.lim" + "))";
                deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + windowsLogin + "))";
                deSearch.SearchScope = SearchScope.Subtree;


                // Session for User Login Name
                Session["UserLoginName"] = windowsLogin;
                //Add the attributes which we want to return to the search result          

                results = deSearch.FindOne();

                if ((results != null))
                {
                    DisplayName = "";
                    Department = "";
                    physicalDeliveryOfficeName = "";
                    company = "";

                    if (results.Properties.Contains("displayname"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["displayname"][0]))
                        {
                            DisplayName = (String)results.Properties["displayname"][0];
                            Session["UserName"] = DisplayName;
                        }
                    }
                    if (results.Properties.Contains("department"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["department"][0]))
                        {
                            Department = (String)results.Properties["department"][0];
                            Session["Department"] = Department;
                        }
                    }
                    if (results.Properties.Contains("physicalDeliveryOfficeName"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["physicalDeliveryOfficeName"][0]))
                        {
                            physicalDeliveryOfficeName = (String)results.Properties["physicalDeliveryOfficeName"][0];
                            Session["Office"] = physicalDeliveryOfficeName;
                        }
                    }
                    if (results.Properties.Contains("company"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["company"][0]))
                        {
                            company = (String)results.Properties["company"][0];
                            Session["Region"] = company;
                        }
                    }
                }
                else
                {


                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void DeleteTempFiles()
        {
            try
            {
                //eventLog1.WriteEntry("Deleting temporary files started at : " + DateTime.Now);
                // Get extensions from the App.Config file for the temporary generated files to be deleted
                string extension = ConfigurationManager.AppSettings["ExtensionsToDelete"].ToString();
                // Get the interval in days from the App.Config file for before how much days the files should be deleted
                int dayInterval = Convert.ToInt16(ConfigurationManager.AppSettings["DayInterval"].ToString());
                // Get the root folder path from which we have to take the Report folders
                string folderPath; // Convert.ToString(ConfigurationSettings.AppSettings["FolderPath"].ToString());
                // Split the extensions using "|" (Pipe) seperator to iterate the loop for different extensions
                string[] arrExtensions = extension.Split('|');


                //string strPath = AppDomain.CurrentDomain.BaseDirectory;

                string[] filePaths;
                bool isFileUsed = false;

                // Iterate the loop on all the keys from app.config file to get the folder path
                foreach (var path in ConfigurationManager.AppSettings.AllKeys)
                {
                    if (path.ToString().Contains("FolderPath"))
                    {
                        folderPath = Convert.ToString(ConfigurationManager.AppSettings.GetValues(path).First());

                        // Check if the selected directory is exists or not
                        if (Directory.Exists(folderPath))
                        {
                            // Iterate the loop for all the extension present in App.Config file
                            foreach (var ext in arrExtensions)
                            {
                                // Get the list of directories having "Report" word
                                string[] arrDirList = Directory.GetDirectories(folderPath, "Report*", SearchOption.AllDirectories);

                                foreach (var dirReport in arrDirList)
                                {
                                    if (!dirReport.Contains("Reports"))
                                    {
                                        // Get all the files from the directory for selected extensions
                                        filePaths = Directory.GetFiles(dirReport, "*." + ext, SearchOption.AllDirectories);

                                        // Iterate for the files which are present in Report folder only
                                        foreach (var fileName in filePaths)
                                        {
                                            // Convert each file into proper file having specific extension
                                            FileInfo tempFile = new FileInfo(fileName);

                                            if (File.Exists((fileName)))
                                            {
                                                // Check for the condition that how many days before from current date files to be deleted
                                                if (tempFile.LastWriteTime.Date <= DateTime.Now.AddDays(-1 * dayInterval))
                                                {
                                                    tempFile.IsReadOnly = false;

                                                    isFileUsed = IsFileinUse(tempFile);
                                                    if (isFileUsed == false)
                                                    {

                                                        // Delete the file
                                                        tempFile.Delete();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        // Get all the files from the directory for selected extensions
                                        filePaths = Directory.GetFiles(dirReport, "*." + ext, SearchOption.TopDirectoryOnly);

                                        // Iterate for the files which are present in Report folder only
                                        foreach (var fileName in filePaths)
                                        {

                                            // Convert each file into proper file having specific extension
                                            FileInfo tempFile = new FileInfo(fileName);

                                            // Check for the condition that how many days before from current date files to be deleted
                                            if (tempFile.LastWriteTime.Date <= DateTime.Now.AddDays(-1 * dayInterval))
                                            {
                                                tempFile.IsReadOnly = false;

                                                isFileUsed = IsFileinUse(tempFile);
                                                if (isFileUsed == false)
                                                {
                                                    // Delete the file
                                                    tempFile.Delete();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //eventLog1.WriteEntry("Deleting temporary files ended at : " + DateTime.Now);
            }
            catch (Exception ex)
            {
                //eventLog1.WriteEntry("Exception occurs at : " + DateTime.Now);
                //eventLog1.WriteEntry(ex.Message);

                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Function to check whether any of the file is opened and is being used by another user (process)
        // If the file is being used by another process then return "TRUE" else return "FALSE"
        // Make use of this bool return type for checking the file
        // If the file is being used then do not delete the file else delete the file
        protected virtual bool IsFileinUse(FileInfo file)
        {
            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException)
            {
                // the file is unavailable because it is:
                // still being written to
                // or being processed by another thread
                // or does not exist (has already been processed)
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }
            return false;
        }

        protected void lnkRenewalStatusReport_SSRS_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Reports2_RenewalStatusReport";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            //Response.Redirect("Reports_SSRS.aspx");
            Session["DeliverableCategory"] = "Internal Mgmt Reports & Tools";
            Response.Redirect("Renewal_StatusReport_SSRS.aspx");
        }

        protected void lnkMeetingTrackingReport_SSRS_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Reports1_RenewalStatusReport";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            //Response.Redirect("Reports_SSRS.aspx");
            Session["DeliverableCategory"] = "Internal Mgmt Reports & Tools";
            Response.Redirect("Meeting_Tracking_Report_SSRS.aspx");
        }

        protected void lnkTools3_BenchmarkingAudit_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Benchmarking_AuditReport";
            Session["DeliverableCategory"] = "Internal Mgmt Reports & Tools";
            Response.Redirect("Tools_ContractReview.aspx");
        }


        protected void lnkPHMWellnessReport_SSRS_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PHMWellnessReport_SSRS";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            //Response.Redirect("Reports_SSRS.aspx");
            Session["DeliverableCategory"] = "Population Health Management";
            Response.Redirect("PHM_WellnessReport_SSRS.aspx");
        }
        protected void lnkBRCCostSavingsReport_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BRC_CostSavingsReport";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            //Response.Redirect("Reports_SSRS.aspx");
            Session["DeliverableCategory"] = "Benefit Resource Center";
            Response.Redirect("BRC_CostSavingsReport_SSRS.aspx");
        }
        protected void lnkBRCDetailedUtilizationMonthlyReport_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BRC_DetailedUtilizationMonthly";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            //Response.Redirect("Reports_SSRS.aspx");
            Session["DeliverableCategory"] = "Benefit Resource Center";
            Response.Redirect("BRC_DetailedUtilizationMonthly_SSRS.aspx");
        }
        protected void lnkBRCDetailedUtilizationSummaryReport_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BRC_DetailedUtilizationSummary";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            //Response.Redirect("Reports_SSRS.aspx");
            Session["DeliverableCategory"] = "Benefit Resource Center";
            Response.Redirect("BRC_DetailedUtilizationSummary_SSRS.aspx");
        }
        protected void lnkBRCMultiYearUtilization_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BRC_MultiYearUtilization";
            Session["Title"] = "";
            Session["Title"] = "Reports";
            //Response.Redirect("Reports_SSRS.aspx");
            Session["DeliverableCategory"] = "Benefit Resource Center";
            Response.Redirect("BRC_MultiYearUtilization_SSRS.aspx");
        }

        protected void lnkClientMobileApp_Click(object sender, EventArgs e)
        {
            //Session["Summary"] = "Tools2";
            Session["Summary"] = "MobileAppRequestForm";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("Pilot_MobApp.aspx");
        }

        protected void lnkPatraTransmittal_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PatraTransmittal";
            Session["DeliverableCategory"] = "Internal Mgmt Reports & Tools";
            Response.Redirect("Pilot_Patra Transmittal.aspx");
        }

        protected void lnkClientRevenueSummary_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ClientRevenueSummary";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("Tools_ClientRevenueSummary.aspx");
        }

        protected void lnkBenchmarkingTool_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BenchmarkingTool";
            Session["DeliverableCategory"] = "Analytics";
            Response.Redirect("Pilot_BenchmarkingTool.aspx");
        }
        protected void lnkEmail_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BenefitPointEmail";
            Response.Redirect("Pilot_BenefitPointEmail.aspx");
        }
        ////protected void lnkletters_Click(object sender, EventArgs e)
        ////{
        ////    Session["Summary"] = "BenefitPointEmail";
        ////    Response.Redirect("BenefitPointLetters.aspx");
        ////}

        protected void lnkAdditionalLetters_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "AdditionalLetter";
            Session["DeliverableCategory"] = "Letters & Email Templates";
            Response.Redirect("AdditionalLetter.aspx");
        }

        protected void lnkButtonFlyer_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Flyer";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("Flyers.aspx");
        }
        protected void lnkFinanceFormsSagitta_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "Finance";
            Response.Redirect("FinanceForms_Sagitta.aspx");
        }
        protected void OnSite_Clinics_Disclosure_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "OnSiteClinics_Disclosure";
            Session["DeliverableCategory"] = "Population Health Management";
            Response.Redirect("OnSiteClinicsDisclosure.aspx");
        }
        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ServiceCalendar";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("ConsolidateServiceCalendar.aspx");
        }
        protected void lnkBenefitPointTools_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BenefitPointTools_NewRenewReport";
            Session["DeliverableCategory"] = "Internal Mgmt Reports & Tools";
            Response.Redirect("BenefitPointTools.aspx");
        }
        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "RFPReport";
            Session["DeliverableCategory"] = "Analytics";
            Response.Redirect("RFPReport.aspx");
        }

        //ClientAgreement
        protected void lnkClientAgreements_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ClientAgreement";
            Session["DeliverableCategory"] = "Compliance";
            Response.Redirect("ClientAgreements.aspx");
        }



        //Added by shravan - 27th July.
        protected void lnkButtonFLIMPVideos_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "FreeStandingFLIMP";
            Response.Redirect("FreeStandingFLIMP.aspx");
        }
        protected void LinkButton6_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "RFPAnalysisReport";
            Session["DeliverableCategory"] = "Analytics";
            Response.Redirect("RFPAnalysisReport.aspx");
        }

        //Added By shravan
        protected void LnkCensus_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "CensusRequestTemplate";
            Session["DeliverableCategory"] = "Client Management Tools";
            Response.Redirect("CensusRequestTemplate.aspx");
        }

        protected void INBRCalculator_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "INBRCalculator";
            Session["DeliverableCategory"] = "Analytics";
            Response.Redirect("INBR_Calculator.aspx");
        }
        protected void lnkBenifitWrapper_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "BenifitWrapper";
            Session["DeliverableCategory"] = "Employee Communications";
            Response.Redirect("Benefit_Wrappers.aspx");

        }

        protected void lnkExperienceReports_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ExperienceReports";
            Session["DeliverableCategory"] = "Analytics";
            Response.Redirect("ExperienceReport.aspx");
        }
        protected void lnkOpenEnrollmentMemos_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "OpenEnrollmentMemos";
            Response.Redirect("OpenEnrollmentMemos.aspx");
        }
        protected void lnkMedicalLOCTemplates_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "MedicalLOCTemplates";
            Response.Redirect("MedicalLOCReports.aspx");
        }

        protected void lnkAnalyticsCoverPages_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "TOCSectionDividers";
            Response.Redirect("AnalyticsCoverPage.aspx");
            Session["DeliverableCategory"] = "Analytics";
        }

        protected void VolumeCalculator_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "VolumeCalculator";
            Session["DeliverableCategory"] = "Analytics";
            Response.Redirect("VolumeCalculator.aspx");
        }
        protected void lnkRenewalTimeLineActAudit_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "SSRS_RenewalTimelineActivityAudit";
            Session["Title"] = "Renewal Timeline Activity Audit";
            Session["DeliverableCategory"] = "Internal Mgmt Reports & Tools";
            Response.Redirect("RenewalTimelineActivityAudit.aspx");
        }

        protected void lnkDigitalClientExtract_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "SSRS_DigitalClientExtract";
            Session["Title"] = "DIgital Client Extract";
            Session["DeliverableCategory"] = "Internal Mgmt Reports & Tools";
            Response.Redirect("DigitalClientExtractReport.aspx");
        }


        protected void lnkPHMStrategicPlan_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PHMStrategicPlan";
            Session["DeliverableCategory"] = "Population Health Management";
            Response.Redirect("PHMStrategicPlan.aspx");
        }
        protected void lnkVendorComparison_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PHMVendorComparison";
            Session["DeliverableCategory"] = "Population Health Management";
            Response.Redirect("PHMVendorComparison.aspx");
        }
        protected void lnkAncillaryPanelCarriers_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "AncillaryPanelCarrier";
            Response.Redirect("AncillaryPanelCarrier.aspx");
        }
        protected void lnkPostCard_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "PostCard";
            Response.Redirect("PostCards.aspx");
        }

        protected void lnkActuarialValueCalculator_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ActuarialValueCalculator";
            Response.Redirect("ActuarialValueCalculator.aspx");
        }

        protected void lnkCoverPageAnalytics_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "CoverPageAnalytics";
            Response.Redirect("CoverPageAnalytics.aspx");
            Session["DeliverableCategory"] = "Analytics";
        }

        protected void lnk_ExecutiveSummary_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "ExecutiveSummary";
            Response.Redirect("ExecutiveSummary.aspx");
            Session["DeliverableCategory"] = "Analytics";
        }

        protected void lnkBenefitTrifolds_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "EmployeeCommunication";
            Response.Redirect("ClientBenefitSummary.aspx");
            Session["DeliverableCategory"] = "EmployeeCommunication";
        }

        protected void lnkRenewalDecisionForm_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "RenewalDecisionForm";
            Response.Redirect("RenewalDecisionForm.aspx");
            Session["DeliverableCategory"] = "Client Management Tools";
        }
        protected void lnkEmpEducation_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "EmployeeEducationMaterials";
            Response.Redirect("EmployeeEducationMaterials.aspx");
            Session["DeliverableCategory"] = "EmployeeCommunication";
        }

        protected void lnkAnalystAssignmentReq_Click(object sender, EventArgs e)
        {
            Session["Summary"] = "AnalystAssignmentReq";
            Response.Redirect("AnalystAssignRequest.aspx");
            Session["DeliverableCategory"] = "Analytics";
        }
    }
}