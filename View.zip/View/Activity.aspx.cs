﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.DirectoryServices;
using System.Collections;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using System.IO;
using System.Drawing;
using Microsoft.Office.Core;
using System.Globalization;
using System.Data.SqlClient;

namespace BenefitPointSummaryPortal
{
    public partial class Activity : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();

        protected void Page_Load(object sender, EventArgs e)
        {
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnExport);

            if (!IsPostBack)
            {
                Homelink.HRef = "AdminPortal.aspx";
                bindDropDownLists();
                ddlRegion_SelectedIndexChanged(null, null);
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            //required to avoid the run time error "  
            //Control 'GridView1' of type 'Grid View' must be placed inside a form tag with runat=server."  
        }

        void bindDropDownLists()
        {
            try
            {
                //---------------------------------------------------------------------------------------------------------------
                //----- Do not delete code starts from here
                //---------------------------------------------------------------------------------------------------------------
                //---- Code to get and fill information from 'Active Directory' in drop down list ----------
                ////DirectoryEntry de = new DirectoryEntry("LDAP://USII");

                ////de.AuthenticationType = AuthenticationTypes.Secure;

                ////DirectorySearcher deSearch = new DirectorySearcher();
                ////deSearch.SearchRoot = de;
                ////deSearch.PageSize = 48000;

                ////deSearch.PropertiesToLoad.Add("department");//department
                ////deSearch.PropertiesToLoad.Add("displayname");//User Name          
                ////deSearch.PropertiesToLoad.Add("physicalDeliveryOfficeName");//Office
                ////deSearch.PropertiesToLoad.Add("company");//Region

                ////deSearch.SearchScope = System.DirectoryServices.SearchScope.Subtree;

                ////ArrayList ArrDepartment = new ArrayList();
                ////ArrayList ArrUsername = new ArrayList();
                ////ArrayList ArrOffice = new ArrayList();
                ////ArrayList ArrComapny = new ArrayList();

                ////SearchResult result;
                ////deSearch.Filter = "(&(objectClass=user)(objectCategory=person))";

                //////deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "robin.cirillo" + "))";
                //////deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "nicole.steiner" + "))";
                ////SearchResultCollection resultCol = deSearch.FindAll();

                ////string Department = string.Empty;
                ////string UserName = string.Empty;
                ////string Office = string.Empty;
                ////string Company = string.Empty;


                ////if (resultCol != null)
                ////{
                ////    for (int counter = 0; counter < resultCol.Count; counter++)
                ////    {

                ////        result = resultCol[counter];
                ////        if (result.Properties.Contains("department"))
                ////        {
                ////            Department = (String)result.Properties["department"][0];
                ////            if (!ArrDepartment.Contains(Department))
                ////            {
                ////                ArrDepartment.Add(Department);
                ////            }
                ////        }

                ////        if (result.Properties.Contains("displayname"))
                ////        {
                ////            UserName = "";
                ////            UserName = (String)result.Properties["displayname"][0];

                ////            if (UserName.Contains("Robin"))
                ////            {
                ////                int a = 0;
                ////                a = 2;
                ////            }
                ////            if (!ArrUsername.Contains(UserName))
                ////            {
                ////                ArrUsername.Add(UserName);
                ////            }
                ////        }

                ////        if (result.Properties.Contains("physicalDeliveryOfficeName"))
                ////        {
                ////            Office = (String)result.Properties["physicalDeliveryOfficeName"][0];
                ////            if (!ArrOffice.Contains(Office))
                ////            {
                ////                ArrOffice.Add(Office);
                ////            }
                ////        }

                ////        if (result.Properties.Contains("company"))
                ////        {
                ////            Company = (String)result.Properties["company"][0];

                ////            if (!ArrComapny.Contains(Company))
                ////            {
                ////                ArrComapny.Add(Company);
                ////            }
                ////        }
                ////    }
                ////}
                ////ArrDepartment.Sort();
                ////ArrUsername.Sort();
                ////ArrComapny.Sort();
                ////ArrOffice.Sort();

                ////ddlDepartment.DataSource = ArrDepartment;
                ////ddlDepartment.DataBind();
                ////ddlDepartment.Items.Insert(0, new ListItem("Select", string.Empty));

                ////ddlRegion.DataSource = ArrComapny;
                ////ddlRegion.DataBind();
                ////ddlRegion.Items.Insert(0, new ListItem("Select", string.Empty));

                //ddlOffice.DataSource = ArrOffice;
                //ddlOffice.DataBind();
                //ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));

                ////ddlUser.DataSource = ArrUsername;
                ////ddlUser.DataBind();
                ////ddlUser.Items.Insert(0, new ListItem("Select", string.Empty));

                //---------------------------------------------------------------------------------------------------------------
                //----- Do not delete code ends here
                //---------------------------------------------------------------------------------------------------------------

                DataTable dt = new DataTable();
                DataTable dtActDistinct = new DataTable();
                DataTable dt_Act_Region = new DataTable();
                DataTable dt_Act_User = new DataTable();
                DataTable dt_Act_Department = new DataTable();
                DataTable dt_Act_Group = new DataTable();
                DataTable dt_Act_Name = new DataTable();
                //dt = bp.GetActivityDetails();
                dtActDistinct = bp.GetGetActivityLogDistinctValues();
                //DataView dtView = new DataView(dt);
                DataView dtViewActdistinct = new DataView(dtActDistinct);

                //=====================
                //Added by Shravan
                DataTable dt_Del_Type = new DataTable();

                DataTable dt_v2 = GetActivity_V2_Details();
                DataView dtView_v2 = new DataView(dt_v2);
                Session["DeliverableCategory"] = dt_v2;


                dt_Del_Type = dtView_v2.ToTable(true, "DeliverableType");
                dt_Del_Type.DefaultView.Sort = "[DeliverableType] asc";

                ddlDeliverableCategory.DataSource = dt_Del_Type;
                ddlDeliverableCategory.DataBind();
                ddlDeliverableCategory.Items.Insert(0, new ListItem("Select", string.Empty));

                //===================

                //Session["DeliverableType"] = dt;

                dt_Act_Region = dtViewActdistinct.ToTable(true, "Account_Region");
                dt_Act_Region.DefaultView.Sort = "Account_Region asc";
                dt_Act_Region.DefaultView.RowFilter = "LEN(Account_Region) > 0";

                dt_Act_User = dtViewActdistinct.ToTable(true, "UserName");
                dt_Act_User.DefaultView.Sort = "[UserName] asc";
                dt_Act_User.DefaultView.RowFilter = "LEN(UserName) > 0";

                dt_Act_Department = dtViewActdistinct.ToTable(true, "Account_Office");
                dt_Act_Department.DefaultView.Sort = "Account_Office asc";
                dt_Act_Department.DefaultView.RowFilter = "LEN(Account_Office) > 0";

                //dt_Act_Group = dtView.ToTable(true, "Activity_Group");
                //dt_Act_Group.DefaultView.Sort = "[Activity_Group] asc";

                //dt_Act_Name = dtView.ToTable(true, "Activity_Name");
                //dt_Act_Name.DefaultView.Sort = "[Activity_Name] asc";

                ddlRegion.DataSource = dt_Act_Region;
                ddlRegion.DataBind();
                ddlRegion.Items.Insert(0, new ListItem("Select", string.Empty));

                ddlUser.DataSource = dt_Act_User;
                ddlUser.DataBind();
                ddlUser.Items.Insert(0, new ListItem("Select", string.Empty));

                //ddlDepartment.DataSource = dt_Act_Department;
                //ddlDepartment.DataBind();
                //ddlDepartment.Items.Insert(0, new ListItem("Select", string.Empty));

                //ddlDeliverableType.DataSource = dt_Act_Group;
                //ddlDeliverableType.DataBind();
                //ddlDeliverableType.Items.Insert(0, new ListItem("Select", string.Empty));

                //ddlDeliverable.DataSource = dt_Act_Name;
                //ddlDeliverable.DataBind();
                //ddlDeliverable.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string whereClause = string.Empty;
            try
            {
                BPBusiness bp = new BPBusiness();
                DataTable dtActInfo = new DataTable();
                bool flag = true;

                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();

                //DateTime.TryParse(txtDateFrom.Text, out dtFrom);
                //DateTime.TryParse(txtDateTo.Text, out dtTo);

                DateTime.TryParseExact(txtDateFrom.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtFrom);
                DateTime.TryParseExact(txtDateTo.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtTo);

                if (txtDateFrom.Text != "")
                {
                    if (DateTime.MinValue == dtFrom)
                    {
                        txtDateFrom.Focus();
                        string script = "alert(\"'Date Created From' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (txtDateFrom.Text.Trim() != "" && txtDateTo.Text.Trim() == "")
                {
                    string script = "alert(\"Please enter 'Date Created To (mm/dd/yyyy)'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (txtDateTo.Text != "")
                {
                    if (DateTime.MinValue == dtTo)
                    {
                        txtDateTo.Focus();
                        string script = "alert(\"'Date Created To' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (txtDateFrom.Text.Trim() == "" && txtDateTo.Text.Trim() != "")
                {
                    string script = "alert(\"Please enter 'Date Created From (mm/dd/yyyy)'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (dtTo < dtFrom)
                {
                    string script = "alert(\"'Date Created To' should be greater than 'Date Created From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                    return;
                }

                if (ddlUser.SelectedIndex > 0)
                {
                    whereClause = whereClause + " AND [UserName] = '" + ddlUser.SelectedItem.Text + "'";
                }

                //if (ddlOffice.SelectedIndex > 0)
                //{
                //    whereClause = whereClause + " AND [Office] = '" + ddlOffice.SelectedItem.Text + "'";
                //}

                if (ddlRegion.SelectedIndex > 0)
                {
                    whereClause = whereClause + " AND [Account_Region] = '" + ddlRegion.SelectedItem.Text + "'";
                }


                if (ddlDepartment.SelectedIndex > 0)
                {
                    whereClause = whereClause + " AND [Account_Office] = '" + ddlDepartment.SelectedItem.Text + "'";
                }


                // Deliverable Category 
                if (ddlDeliverableCategory.SelectedIndex > 0)
                {
                    whereClause = whereClause + " AND [DeliverableCategory] = '" + ddlDeliverableCategory.SelectedItem.Text + "'";
                }

                if (ddlDeliverable.SelectedIndex > 0)
                {
                    whereClause = whereClause + " AND Activity = '" + ddlDeliverable.SelectedItem.Text + "'";
                }

                if (ddlDeliverableType.SelectedIndex > 0)
                {
                    whereClause = whereClause + " AND Activity_Group = '" + ddlDeliverableType.SelectedItem.Text + "'";
                }

                //string selectedDate = calDate.SelectedDate.ToString("MM/dd/yyyy");
                //whereClause = whereClause + " AND CONVERT(nvarchar(10),Created_Date,101) = '" + selectedDate + "'";

                if (txtDateFrom.Text.Trim() != "" && txtDateTo.Text.Trim() != "")
                {
                    whereClause = whereClause + " AND CONVERT(datetime,Created_Date,101) BETWEEN '" + txtDateFrom.Text.Trim() + "' AND DATEADD(day, 1, '" + txtDateTo.Text.Trim() + "')";
                }

                //if (txtDateFrom.Text.Trim() != "")
                //    whereClause = whereClause + " AND CONVERT(nvarchar(10),Created_Date,101) = '" + txtDateFrom.Text.Trim() + "'";

                if (flag == true)
                {
                    //dtActInfo = bp.GetActivityInformation(whereClause);
                    dtActInfo = GetActivityInformation_V2(whereClause);
                    Session["ActivityDataTable"] = dtActInfo;
                    grdActivity.DataSource = dtActInfo;
                    grdActivity.DataBind();
                    if (dtActInfo.Rows.Count == 0)
                    {
                        string script = "alert(\"No Records found for selected criteria.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }
                }
                //Export_To_Excel(dtActInfo);

                //ExportToExcel(sender, e);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //==============================================================
        /// <summary>
        /// Get Activity Information
        /// </summary>
        /// <returns>Datatable</returns>
        public DataTable GetActivityInformation_V2(string whereClause)
        {
            DataTable dtActivityDetails = new DataTable();

            try
            {
                SqlParameter[] parameters = { new SqlParameter("@whereClause ", SqlDbType.NVarChar) };
                parameters[0].Value = whereClause;
                dtActivityDetails = DB_helper.ExecProcedure("GetActivityDetails_V2", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtActivityDetails;
        }
        //===========================================================

        public void Export_To_Excel(DataTable ds)
        {
            try
            {
                string data = null;
                string Header = null;
                int i = 0;
                int j = 0;
                int k = 1;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                Object missing = System.Reflection.Missing.Value;

                string fileName = Server.MapPath("~/Files/ActivityReport/Base_ActivityFile.xls");

                xlApp = new Excel.Application();

                xlWorkBook = xlApp.Workbooks.Open(fileName);
                xlWorkSheet = xlWorkBook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ActivityReport/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                 System.DateTime.Now.Hour.ToString() +
                                  System.DateTime.Now.Minute.ToString() +
                                 System.DateTime.Now.Second.ToString() +
                                 System.DateTime.Now.Millisecond.ToString() +

                                ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ActivityReport/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ActivityReport/Report1"));
                }

                xlWorkBook.SaveAs(savefilename, Excel.XlFileFormat.xlWorkbookDefault, missing, missing, false, false,
                   Excel.XlSaveAsAccessMode.xlNoChange, false, false, missing, missing, missing);

                for (j = 0; j <= ds.Columns.Count - 1; j++)
                {
                    Header = ds.Columns[j].Caption;
                    xlWorkSheet.Cells[1, j + 1] = Header;
                }

                for (i = 0; i <= ds.Rows.Count - 1; i++)
                {
                    for (j = 0; j <= ds.Columns.Count - 1; j++)
                    {

                        data = ds.Rows[i].ItemArray[j].ToString();
                        xlWorkSheet.Cells[i + 2, j + 1] = data;
                    }
                }

                xlWorkBook.Save();
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);


                // MessageBox.Show("Excel file created , you can find the file c:\\csharp.net-informations.xls");
                /*
                //Give the user the option to save the copy of the file anywhere they desire
                System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
                response.ClearContent();
                response.Clear();
                response.ContentType = "application/vnd.ms-excel";
                response.AddHeader("Content-Disposition", "attachment; filename=ActivityReport-" + DateTime.Now.ToShortDateString() + ".xls;");
                response.TransmitFile(savefilename.ToString());
                response.Flush();
                response.Close();

                //Delete the temporary file
                //DeleteFile(savefilename.ToString());
                */

                FileStream fs = null;
                BinaryReader br = null;
                byte[] data1 = null;

                if (File.Exists(savefilename.ToString()))
                {
                    FileInfo file = new FileInfo(savefilename.ToString());
                    fs = new FileStream(savefilename.ToString(), FileMode.Open, FileAccess.Read, FileShare.Read);
                    br = new BinaryReader(fs, System.Text.Encoding.Default);
                    data1 = new byte[Convert.ToInt32(fs.Length)];
                    br.Read(data1, 0, data1.Length);

                    Response.Clear();
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.AddHeader("content-disposition", "attachment; filename=ActivityReport-" + DateTime.Now.ToShortDateString() + ".xlsx");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.BinaryWrite(data1);
                    Response.Flush();
                    Response.Close();
                }

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        private void DeleteFile(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    File.Delete(fileName);
                }
                catch (Exception ex)
                {
                    //Could not delete the file, wait and try again
                    try
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        File.Delete(fileName);
                    }
                    catch
                    {
                        //Could not delete the file still
                        //Response.Write(ex.Message);
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
            }
        }

        protected void ddlDeliverableType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataView dtDelCat = new DataView((DataTable)Session["DeliverableCategory"]);
                DataTable dt_Act_Name = new DataTable();
                DataRow[] foundRows;
                //ddlDeliverableType.Items.Clear();
                //DataTable dtDel = (DataTable)Session["DeliverableType"];
                // DataTable dt = new DataTable();
                //DataRow[] foundRows;
                ddlDeliverable.Items.Clear();

                dtDelCat.Sort = "[ActivityName] asc";
                dt_Act_Name = dtDelCat.ToTable(true, "ActivityGroup", "DeliverableType", "ActivityName");

                foundRows = dt_Act_Name.Select("ActivityGroup = '" + ddlDeliverableType.SelectedItem.Text + "' ");

                int index = 0;
                for (int i = 0; i < foundRows.Length; i++)
                {
                    if (Convert.ToString(foundRows[i]["DeliverableType"]) == ddlDeliverableCategory.SelectedItem.Text.ToString())
                    {
                        ddlDeliverable.Items.Insert(index, Convert.ToString(foundRows[i]["ActivityName"]));
                        index++;
                    }
                }
                ddlDeliverable.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlDeliverableCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataView dtDelCat = new DataView((DataTable)Session["DeliverableCategory"]);
                DataTable dt_Act_Grp = new DataTable();
                DataRow[] foundRows;
                ddlDeliverableType.Items.Clear();
                ddlDeliverable.Items.Clear();

                //dtDelCat.Sort = "ActivityGroup asc";
                dt_Act_Grp = dtDelCat.ToTable(true, "ActivityGroup", "DeliverableType");

                foundRows = dt_Act_Grp.Select("DeliverableType = '" + ddlDeliverableCategory.SelectedItem.Text + "'", "ActivityGroup");
                // ddlDeliverableType.DataBind();
                //ddlDeliverableType.Items.Insert(0, new ListItem("Select", string.Empty));

                //dtDelCat.DefaultView.Sort = "[DeliverableType] asc";
                ////dtDel.DefaultView.Sort = "[Activity_Name] asc";

                //foundRows = dtDelCat.Select("DeliverableType = '" + ddlDeliverableCategory.SelectedItem.Text + "'");
                ////foundRows = dtDel.Select("Activity_Group = '" + ddlDeliverableType.SelectedItem.Text + "'");

                for (int i = 0; i < foundRows.Length; i++)
                {
                    ddlDeliverableType.Items.Insert(i, Convert.ToString(foundRows[i]["ActivityGroup"]));
                }
                ddlDeliverableType.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //===============================================================

        BenefitPointSummaryPortal.DAL.DBHelper DB_helper = new BenefitPointSummaryPortal.DAL.DBHelper();
        /// <summary>
        /// Get Activity Details
        /// </summary>
        /// <returns>Datatable</returns>
        public DataTable GetActivity_V2_Details()
        {
            DataTable dtActivity = new DataTable();

            try
            {
                dtActivity = DB_helper.ExecProcedure("GetActivity_V2", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtActivity;
        }
        //===============================================================

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)Session["ActivityDataTable"];
            if (dt != null && dt.Rows.Count > 0)
            {
                Export_To_Excel(dt);
            }
            else
            {
                string script = "alert(\"Sorry ! There are no Records to export.\");";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            }

        }

        protected void grdActivity_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

            grdActivity.PageIndex = e.NewPageIndex;
            DataTable dt = (DataTable)Session["ActivityDataTable"];

            grdActivity.DataSource = dt;
            grdActivity.DataBind();

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ddlRegion.SelectedIndex = 0;
            //ddlOffice.SelectedIndex = 0;
            ddlDeliverableCategory.SelectedIndex = 0;
            ddlUser.SelectedIndex = 0;
            ddlRegion_SelectedIndexChanged(null, null);
            //ddlDeliverableType.SelectedIndex = 0;
            ddlDeliverableType.Items.Clear();
            ddlDeliverable.Items.Clear();
            txtDateFrom.Text = "";
            txtDateTo.Text = "";
            grdActivity.DataSource = null;
            grdActivity.DataBind();
        }

        protected void ddlRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDepartment.Items.Clear();
            if (ddlRegion.SelectedValue != string.Empty)
            {
                DataTable dt_Act_Department = new DataTable();
                dt_Act_Department = bp.GetAccountRegionOffices(ddlRegion.SelectedValue);
                ddlDepartment.DataSource = dt_Act_Department;
                ddlDepartment.DataBind();
            }
            ddlDepartment.Items.Insert(0, new ListItem("Select", string.Empty));

        }

    }
}