﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls;
using Microsoft.Office.Core;
using System.Threading;
using BenefitPointSummaryPortal.BAL.Client_Agreements;

namespace BenefitPointSummaryPortal.View
{
    public partial class ClientAgreements : System.Web.UI.Page
    {
        string SessionId = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        string temperror = "cs";

        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        private string userState = string.Empty;
        private string State = string.Empty;
        DataTable dbAgreeementMatrix = new DataTable();
      
        string FeeOnly_StateSpecificText = "";
        string FeeOnly_StateSpecificTextMiscellaneous = "";

        string FeeCommission_StateSpecificText = "";
        string FeeCommission_StateSpecificTextMiscellaneous = "";

        string FeeOffsetby_Commission_StateSpecificText = "";
        string FeeOffsetby_Commission_StateSpecificTextMiscellaneous = "";



        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        List<string> lstInvoiceSchedule = new List<string>() { "Monthly", "Quarterly", "Yearly" };
        Dictionary<string, string> dictBasisOfCompensation = new Dictionary<string, string>();
        Dictionary<string, string> dictAgreementDetails = new Dictionary<string, string>();



        protected void Page_Load(object sender, EventArgs e)
        {

            //Session["Summary"] = "ClientAgreement";
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>hideShowbutton();</Script>", false);
           
            if (!IsPostBack)
            {
                ResetControl(0);
                objCommFun.GetUserDetails();
                DictDepartment = sd.getDepartmentDetails();
                // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                if (Request.QueryString["ReportName"] != null)
                {
                    Session["Summary"] = Request.QueryString["ReportName"];
                }
                if (Session["Summary"] == null)
                {
                    Response.Redirect("Home.aspx");
                }

                SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                Session["SessionId"] = SessionId;

                if (Convert.ToString(Session["Summary"]) == "ClientAgreement")
                {
                    TitleSpan.InnerText = "Client Agreements";
                    Activity_Group = "Compliance";
                    Activity = "Client Agreements";
                    ddlClientProspect.SelectedValue = "Select";
                    ddlClientProspect_OnSelectedIndexChanged(null, null);
                }
            }
        }

        #region  Events On Page


        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
                ddlType.SelectedIndex = 0;
             
             
                //ddlType_OnSelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        #region Button Summery Click
         string _selectedClient = string.Empty;
                string _selectedType = string.Empty;
                string _selectedState = string.Empty;
                string _selectedBasisOfCompensation = string.Empty;
                string _selectedLegalEntity = string.Empty;
                string _selectedEffectiveDate = string.Empty;
                string _selectedFeeAmount = string.Empty;
                string _selectedlnvoiceSchedule = string.Empty;
                string _selectedAdditionalServices = string.Empty;
                string _selectdClientProspect = string.Empty;
                string mynewfile = "";
                string _Value = string.Empty;

               
               
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            _selectedState = ddlState.SelectedValue.Trim();
            _selectedBasisOfCompensation = ddlBasisOfCompensation.SelectedValue;
             _selectedState = ddlState.SelectedValue.Trim();
            try
            {
               
                if (ValidateForm())
                {
                    CreateClientAgreementsReport();
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                ResetControl(1);
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();
                SessionId = Session["SessionId"].ToString();
                ddlClient.Items.Clear();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
                rdlClient.SelectedIndex = 0;
                ddlState.Items.Clear();
                ddlType.SelectedIndex = 0;
                hideShowAdditionalSection(ddlType.SelectedValue.Trim());
                ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                return;
            }
            else if (ddlClient.SelectedIndex > 0)
            {

                userState = "";

                DataSet AccountDS = new DataSet();
                string Account_Office = string.Empty;
                string Account_Region = string.Empty;
                SessionId = Session["SessionId"].ToString();

                sd.BuildAccountTable();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"])))
                {

                    userState = Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"]);
                    State = userState.Replace("_", " ");
                    BindState(State);
                    ddlState_SelectedIndexChanged(null, null);
                }

                // Get the Account Office and Account Region for the selected client
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlLegalEntity.SelectedIndex = 0;
            ddlType.SelectedIndex = 0;
            txtEffectiveDate.Text = string.Empty;
            ddlType_OnSelectedIndexChanged(null, null);
        }
       
        protected void ddlClientProspect_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            ClearAllControl();
            hideShowClientProspect();
            if (ddlClientProspect.SelectedIndex > 0)
            {
               
                if (ddlClientProspect.SelectedValue == "Prospect")
                {
                    BindState();
                }
               
            }
        }
        /******CODE ADDED BY AMOGH */
        protected void ddlType_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            ClearControl();
            hideShowAdditionalSection(ddlType.SelectedValue.Trim());
            FillBasicOfCommissionDropDown();
           
        }
       

        protected void ddlBasisOfCompensation_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            hideShowAdditionalSectionControl(ddlType.SelectedValue.Trim(), ddlBasisOfCompensation.SelectedValue.Trim());
        }

        #endregion

        //Clear control 
        private void ClearControl()
        {
            ddlBasisOfCompensation.Items.Clear();
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;

            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
            trBasisOfCompensation.Visible = false;
            
           
            //ddlClientProspect.SelectedValue = "Select";
            //ddlClientProspect_OnSelectedIndexChanged(null, null);
            //trBasisOfCompensationException.Visible = false;

        }
        private void ClearAllControl()
        {
            txtProspectName.Text = "";
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlState.SelectedIndex = 0;
            ddlBasisOfCompensation.Items.Clear();
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;
            txtEffectiveDate.Text = "";
            ddlType.SelectedIndex = 0;
            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
            trBasisOfCompensation.Visible = false;
        }

        private void ResetControl(int value)
        {
            txtEffectiveDate.Text = string.Empty;
            ddlBasisOfCompensation.Items.Clear();
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;

            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
            trBasisOfCompensation.Visible = false;
            ddlClientProspect.SelectedValue = "Select";
            ddlClientProspect_OnSelectedIndexChanged(null, null);
            //trBasisOfCompensationException.Visible = false;
        }

        private void LoadInvoiceSchedule()
        {
            ddlnvoiceSchedule.DataSource = lstInvoiceSchedule;
            ddlnvoiceSchedule.DataBind();
            ddlnvoiceSchedule.Items.Insert(0, new ListItem("Select", ""));
            ddlnvoiceSchedule.SelectedIndex = 0;
        }

        /// <summary>
        /// HIDE SHOW THE FEE AMOUNT / INVOICE SCHEDULE / ADDITTION SERVICES 
        /// </summary>
        /// <param name="Type"></param>
        /// <param name="BasisOfCompensation"></param>
        private void hideShowAdditionalSectionControl(string Type, string BasisOfCompensation)
        {
            //trAdditionalOptions.Style.Add("display", "none");
            if (Type == "ClientService" || Type == "ClientServiceAndBusinessAssociate")
            {
                ClearControlForBasisOfCompensation();
                switch (BasisOfCompensation)
                {
                    case "FeeOnly":
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = true;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        LoadInvoiceSchedule();
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeCommission":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeOffsetByCommission":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeOnly*":
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = true;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        LoadInvoiceSchedule();
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeCommission*":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeOffsetByCommission*":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "Select":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    default:
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = false;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Hide')</script>", false);
                        break;
                }
            }
        }

        private void hideShowAdditionalSection(string Type)
        {
            trAdditionalOptions.Style.Add("display", "none");
            switch (Type)
            {
                case "BusinessAssociate":
                    trAdditionalOptions.Style.Add("display", "none");
                    trFeeAmount.Visible = false;
                    trBasisOfCompensation.Visible = false;
                    trInvoiceSchedule.Visible = false;
                    trIncludeAdditionalServices.Visible = false;
                    break;
                case "ClientService":
                    trBasisOfCompensation.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "ClientServiceAndBusinessAssociate":
                    trBasisOfCompensation.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                default:
                    trBasisOfCompensation.Visible = false;
                    trFeeAmount.Visible = false;
                    trInvoiceSchedule.Visible = false;
                    trIncludeAdditionalServices.Visible = false;
                    trAdditionalOptions.Style.Add("display", "none");
                    break;

            }
        }

        private void hideShowClientProspect()
        {
            trProspectName.Style.Add("display", "none");
            trSearchClient.Style.Add("display", "none");
            trClientName.Style.Add("display", "none");
            trStateName.Style.Add("display", "none");
            switch (ddlClientProspect.SelectedValue)
            {
                case "Prospect":
                    trProspectName.Style.Add("display", "");
                    trStateName.Style.Add("display", "");
                    break;
                case "Client":
                    trSearchClient.Style.Add("display", "");
                    trClientName.Style.Add("display", "");
                    trStateName.Style.Add("display", "");
                    break;
            }
        }
        private void BindState(string State)
        {
            //USI State
            DataTable dtOfficeState = new DataTable();
            //dtOfficeState = bp.GetOfficeStateList(); //StateListforClientAgreement
            dtOfficeState = bp.StateListforClientAgreement();
            ddlState.DataSource = dtOfficeState;
            ddlState.DataBind();
            var item = ddlState.Items.FindByValue(State);
            if (item != null)
            {
                ddlState.SelectedValue = Convert.ToString(item);
            }
            else
            {
                ddlState.SelectedIndex = 0;
            }
        }

        private void BindState()
        {
            //USI State
            DataTable dtOfficeState = new DataTable();
            //dtOfficeState = bp.GetOfficeStateList(); //StateListforClientAgreement
            dtOfficeState = bp.StateListforClientAgreement();
            ddlState.DataSource = dtOfficeState;
            ddlState.DataBind();
           
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void FillBasicOfCommissionDropDown()
        {
            try
            {
                string inputFeeOnly = "";
                string inputFeeCommission = "";
                string inputFeeOffsetby_Commission = "";
                DataSet DS_AgreementMatrix = new DataSet();
                string userState = Convert.ToString(ddlState.SelectedItem.Text);

                if (!string.IsNullOrEmpty(userState))
                {
                    dbAgreeementMatrix = bp.loadClientAgreementMatrix(userState);
                    DS_AgreementMatrix.Tables.Add(dbAgreeementMatrix.Copy());
                }

                if (DS_AgreementMatrix.Tables.Count > 0)
                {
                    for (int i = 0; i < DS_AgreementMatrix.Tables[0].Rows.Count; i++)
                    {
                        ddlBasisOfCompensation.Items.Clear();
                        //dictAgreementDetails.Clear();

                        inputFeeOnly = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOnly"]).ToLower();
                        inputFeeCommission = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeCommission"]).ToLower();
                        inputFeeOffsetby_Commission = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOffsetby_Commission"]).ToLower();

                        FeeOnly_StateSpecificText = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOnly_StateSpecificText"]).ToLower();
                        FeeOnly_StateSpecificTextMiscellaneous = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOnly_StateSpecificTextMiscellaneous"]).ToLower();

                        FeeCommission_StateSpecificText = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeCommission_StateSpecificText"]).ToLower();
                        FeeCommission_StateSpecificTextMiscellaneous = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeCommission_StateSpecificTextMiscellaneous"]).ToLower();

                        FeeOffsetby_Commission_StateSpecificText = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOffsetby_Commission_StateSpecificText"]).ToLower();
                        FeeOffsetby_Commission_StateSpecificTextMiscellaneous = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOffsetby_Commission_StateSpecificTextMiscellaneous"]).ToLower();

                        dictAgreementDetails.Add("inputFeeOnly", inputFeeOnly);
                        dictAgreementDetails.Add("FeeOnly_StateSpecificText", FeeOnly_StateSpecificText);
                        dictAgreementDetails.Add("FeeOnly_StateSpecificTextMiscellaneous", FeeOnly_StateSpecificTextMiscellaneous);

                        dictAgreementDetails.Add("inputFeeCommission", inputFeeCommission);
                        dictAgreementDetails.Add("FeeCommission_StateSpecificText", FeeCommission_StateSpecificText);
                        dictAgreementDetails.Add("FeeCommission_StateSpecificTextMiscellaneous", FeeCommission_StateSpecificTextMiscellaneous);

                        dictAgreementDetails.Add("inputFeeOffsetby_Commission", inputFeeOffsetby_Commission);
                        dictAgreementDetails.Add("FeeOffsetby_Commission_StateSpecificText", FeeOffsetby_Commission_StateSpecificText);
                        dictAgreementDetails.Add("FeeOffsetby_Commission_StateSpecificTextMiscellaneous", FeeOffsetby_Commission_StateSpecificTextMiscellaneous);

                        Session["dictAgreementDetails"] = dictAgreementDetails;
                        //// HERE WE CHECK FEE OPTION AVIALBEL FOR SPECIFIC STATE  -  Fee Only
                        if (!string.IsNullOrEmpty(inputFeeOnly) && inputFeeOnly != "no")
                        {
                            if (inputFeeOnly == "yes")
                            {
                                dictBasisOfCompensation.Add("FeeOnly", "Fee Only");
                            }
                            else if (inputFeeOnly == "no - with exception")
                            {
                                dictBasisOfCompensation.Add("FeeOnly*", "Fee Only*");
                            }
                        }

                        //// HERE WE CHECK  "Fee and Commission" OPTION AVIALBEL FOR SPECIFIC STATE  -   "Fee and Commission"
                        if (!string.IsNullOrEmpty(inputFeeCommission) && inputFeeCommission != "no")
                        {
                            if (inputFeeCommission == "yes")
                            {
                                dictBasisOfCompensation.Add("FeeCommission", "Fee and Commission");
                            }
                            else if (inputFeeCommission == "no - with exception")
                            {
                                dictBasisOfCompensation.Add("FeeCommission*", "Fee and Commission*");
                            }
                        }

                        //// HERE WE CHECK  "Fee and Commission" OPTION AVIALBEL FOR SPECIFIC STATE  -   "Fee and Commission"
                        if (!string.IsNullOrEmpty(inputFeeOffsetby_Commission) && inputFeeOffsetby_Commission != "no")
                        {
                            if (inputFeeOffsetby_Commission == "yes")
                            {
                                dictBasisOfCompensation.Add("FeeOffsetByCommission", "Fee Offset By Commission");
                            }
                            else if (inputFeeOffsetby_Commission == "no - with exception")
                            {
                                dictBasisOfCompensation.Add("FeeOffsetByCommission*", "Fee Offset By Commission*");
                            }
                        }
                    }

                    ddlBasisOfCompensation.DataTextField = "Value";
                    ddlBasisOfCompensation.DataValueField = "Key";
                    ddlBasisOfCompensation.DataSource = dictBasisOfCompensation;
                    ddlBasisOfCompensation.DataBind();

                    ddlBasisOfCompensation.Items.Insert(0, new ListItem("--Select--", "Select"));
                    ddlBasisOfCompensation.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {

            }
        }

        //Clear control 
        private void ClearControlForBasisOfCompensation()
        {
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;

            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
        }

        private string ClientService(string selectedClient, string selectedState, string selectedBasisOfCompensation, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedLegalEntity, string selectedEffectiveDate)
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp1 = new Word.Application();
            Word.Application oWordApp2 = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/ClientServiceAgreement.docm");
            Object fileNameSource = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/OriginalSorceFile05_06_StateSpecific.docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp1.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            Word.Document oWordDoc1 = oWordApp2.Documents.Open(ref fileNameSource,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp1.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                dictAgreementDetails = (Dictionary<string, string>)Session["dictAgreementDetails"];//= dictAgreementDetails;

                string selectedType = ddlType.SelectedValue;
                WriteTemplateClientAgreement wrt = new WriteTemplateClientAgreement();
                wrt.WriteCommonValueOnTemplate(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, selectedType);

                if (selectedBasisOfCompensation == "FeeOnly" || selectedBasisOfCompensation == "FeeOnly*")
                {
                    wrt.WriteFileds_ClientService_FeeOnly(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails);
                }
                else if (selectedBasisOfCompensation == "FeeCommission" || selectedBasisOfCompensation == "FeeCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeCommission(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails);
                }
                else if (selectedBasisOfCompensation == "FeeOffsetByCommission" || selectedBasisOfCompensation == "FeeOffsetByCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeOffsetByCommissionMiscellaneous(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails);
                }
                wrt.DeleteUnwantedBookMark(oWordDoc, oWordApp1, selectedClient, Convert.ToString(selectedState).ToLower(), selectedAdditionalServices, selectedType, selectedBasisOfCompensation);

                oWordDoc.Save();

                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }

            return (savefilename.ToString());

        }

        private string ClientServiceAndBusinessAssociate(string selectedClient, string selectedState, string selectedBasisOfCompensation, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedLegalEntity, string selectedEffectiveDate)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp1 = new Word.Application();
            Word.Application oWordApp2 = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/ClientServiceBusinessAssoicateAgreement.docm");
            Object fileNameSource = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/OriginalSorceFile05_06_StateSpecific.docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp1.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            Word.Document oWordDoc1 = oWordApp2.Documents.Open(ref fileNameSource,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp1.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                dictAgreementDetails = (Dictionary<string, string>)Session["dictAgreementDetails"];//= dictAgreementDetails;

                string selectedType = ddlType.SelectedValue;

                WriteTemplateClientAgreement wrt = new WriteTemplateClientAgreement();
                wrt.WriteCommonValueOnTemplate(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, selectedType);

                if (selectedBasisOfCompensation == "FeeOnly" || selectedBasisOfCompensation == "FeeOnly*")
                {
                    wrt.WriteFileds_ClientService_FeeOnly(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails);
                }
                else if (selectedBasisOfCompensation == "FeeCommission" || selectedBasisOfCompensation == "FeeCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeCommission(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails);
                }
                else if (selectedBasisOfCompensation == "FeeOffsetByCommission" || selectedBasisOfCompensation == "FeeOffsetByCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeOffsetByCommissionMiscellaneous(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails);
                }
                wrt.DeleteUnwantedBookMark(oWordDoc, oWordApp1, selectedClient, Convert.ToString(selectedState).ToLower(), selectedAdditionalServices, selectedType, selectedBasisOfCompensation);

                oWordDoc.Save();

                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }

            return (savefilename.ToString());
        }

        private string CreateBusinessAssciate(string ClientName, string LegalEntity, string EffectiveDate)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/BusinessAssociateAgreement.docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads/BusinessAssociateAgreement")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ClientAgreements/Documents/Templates/Downloads/BusinessAssociateAgreement"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);


                WriteTemplateClientAgreement objFee_Exhibits = new WriteTemplateClientAgreement();
                objFee_Exhibits.WriteFileds_OnSiteClientBusinessAssociate(oWordDoc, oWordApp, ClientName, LegalEntity, EffectiveDate);
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }




            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        private bool ValidateForm()
        {
            var pattern = @"^[0-9]{1,3}(,[0-9]{3})*(\.[0-9]+)?$";
            var pattern2 = @"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$";
            var regexp = new System.Text.RegularExpressions.Regex(pattern);
            var regexp2 = new System.Text.RegularExpressions.Regex(pattern2);
            var userInput = txtFeeAmount.Text.Trim();
            if (ddlClientProspect.SelectedIndex == 0 || ddlClientProspect.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Agreement.')</script>");
                return false;
            }
            if (ddlClientProspect.SelectedValue == "Client")
            {
                if (txtsearch.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please search Client.')</script>");
                    txtsearch.Focus();
                    return false;
                }
                if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                    ddlClient.Focus();
                    return false;
  
                }
                if (ddlState.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select State.')</script>");
                    ddlState.Focus();
                    return false;

                }

                if (txtEffectiveDate.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Effective Date.')</script>");
                    txtEffectiveDate.Focus();
                    return false;
                }
                if (ddlType.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Type.')</script>");
                    ddlType.Focus();
                    return false;

                }
                               
                if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeCommission"||_selectedBasisOfCompensation == "FeeOnly*" || _selectedBasisOfCompensation == "FeeCommission*")
                {
                    if (!regexp2.IsMatch(userInput))
                    {
                        if (!regexp.IsMatch(userInput))
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter valid Fee amount')</script>");
                            return false;
                        }
                    }
                }

            }
            if (ddlClientProspect.SelectedValue == "Prospect")
            {

                if (txtProspectName.Text.Trim()==string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please fill Prospect Name.')</script>");
                    ddlClient.Focus();
                    return false;

                }

                if (ddlState.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select State.')</script>");
                    ddlState.Focus();
                    return false;

                }

                if (txtEffectiveDate.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Effective Date.')</script>");
                    txtEffectiveDate.Focus();
                    return false;
                }
                if (ddlType.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Type.')</script>");
                    ddlType.Focus();
                    return false;

                }

                if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeOnly*" || _selectedBasisOfCompensation == "FeeCommission*")
                {
                    if (!regexp2.IsMatch(userInput))
                    {
                        if (!regexp.IsMatch(userInput))
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter valid Fee amount')</script>");
                            return false;
                        }
                    }
                }

            }

            return true;
        }

        private void CreateClientAgreementsReport()
        {

            if (Convert.ToString(Session["Summary"]) == "ClientAgreement")
            {
                _selectedType = ddlType.SelectedValue.Trim();
                _selectedState = ddlState.SelectedValue.Trim();
                _selectedLegalEntity = ddlLegalEntity.SelectedItem.Text.Trim();
                _selectedEffectiveDate = txtEffectiveDate.Text.Trim();
                if (ddlClientProspect.SelectedValue == "Client")
                {
                       
                        _selectedClient = ddlClient.SelectedItem.Text.Trim();
                       
                        if (_selectedType == "BusinessAssociate")
                        {
                            mynewfile = CreateBusinessAssciate(_selectedClient, _selectedLegalEntity, _selectedEffectiveDate);
                        }
                        else if (_selectedType == "ClientService")
                        {

                            _selectedAdditionalServices = ddlAdditionalServices.SelectedValue.Trim();

                            if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeOnly*")
                            {
                                _Value = txtFeeAmount.Text.Trim();
                               _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                                _selectedlnvoiceSchedule = ddlnvoiceSchedule.SelectedItem.Text.Trim();
                            }
                            else if (_selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeCommission*")
                            {
                                _Value = txtFeeAmount.Text.Trim();
                                 _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                            }
                            mynewfile = ClientService(_selectedClient, _selectedState, _selectedBasisOfCompensation, _selectedAdditionalServices, _selectedFeeAmount, _selectedlnvoiceSchedule, _selectedLegalEntity, _selectedEffectiveDate);
                        }
                        else if (_selectedType == "ClientServiceAndBusinessAssociate")
                        {
                            #region Code Added By Mahesh
                            _selectedBasisOfCompensation = ddlBasisOfCompensation.SelectedValue;
                            _selectedAdditionalServices = ddlAdditionalServices.SelectedValue.Trim();

                            if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeOnly*")
                            {
                                _Value = txtFeeAmount.Text.Trim();
                                _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                                _selectedlnvoiceSchedule = ddlnvoiceSchedule.SelectedItem.Text.Trim();
                            }
                            else if (_selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeCommission*")
                            {
                                 _Value = txtFeeAmount.Text.Trim();
                                 _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                            }
                            mynewfile = ClientServiceAndBusinessAssociate(_selectedClient, _selectedState, _selectedBasisOfCompensation, _selectedAdditionalServices, _selectedFeeAmount, _selectedlnvoiceSchedule, _selectedLegalEntity, _selectedEffectiveDate);

                            #endregion

                        }
                        #region Storing the Activity Logs
                        SessionId = Session["SessionId"].ToString();
                        List<Contact> ContactList = new List<Contact>();
                        ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                        DataSet AccountDS = new DataSet();
                        DataSet AccountTeamMemberDS = new DataSet();
                        sd.BuildAccountTable();
                        AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        if (ddlClient.SelectedValue != "")
                        {
                            AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        }
                        Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                        string Office_Region = Account_Region + " / " + Account_Office;
                        string AdditionalCrtieriaOption_1 = ddlState.SelectedItem.Text.Trim();
                        string AdditionalCrtieriaOption_2 = ddlLegalEntity.SelectedItem.Text.Trim();
                        string AdditionalCrtieriaOption_3 = ddlType.SelectedItem.Text.Trim(); ;
                        string AdditionalCrtieriaOption_4 = string.Empty;
                        DicActivityLog.Clear();
                        DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                        bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                      
                        #endregion

                        DownloadFileNew(mynewfile);
                    }
                else if (ddlClientProspect.SelectedValue == "Prospect")
                {
                   
                    _selectedClient = txtProspectName.Text.Trim();

                    if (_selectedType == "BusinessAssociate")
                    {
                        mynewfile = CreateBusinessAssciate(_selectedClient, _selectedLegalEntity, _selectedEffectiveDate);
                    }
                    else if (_selectedType == "ClientService")
                    {

                        _selectedAdditionalServices = ddlAdditionalServices.SelectedValue.Trim();

                        if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeOnly*")
                        {
                            _Value = txtFeeAmount.Text.Trim();
                            _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                            _selectedlnvoiceSchedule = ddlnvoiceSchedule.SelectedItem.Text.Trim();
                        }
                        else if (_selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeCommission*")
                        {
                            _Value = txtFeeAmount.Text.Trim();
                            _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                        }
                        mynewfile = ClientService(_selectedClient, _selectedState, _selectedBasisOfCompensation, _selectedAdditionalServices, _selectedFeeAmount, _selectedlnvoiceSchedule, _selectedLegalEntity, _selectedEffectiveDate);
                    }
                    else if (_selectedType == "ClientServiceAndBusinessAssociate")
                    {
                        #region Code Added By Mahesh
                        _selectedBasisOfCompensation = ddlBasisOfCompensation.SelectedValue;
                        _selectedAdditionalServices = ddlAdditionalServices.SelectedValue.Trim();

                        if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeOnly*")
                        {
                            _Value = txtFeeAmount.Text.Trim();
                            _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                            _selectedlnvoiceSchedule = ddlnvoiceSchedule.SelectedItem.Text.Trim();
                        }
                        else if (_selectedBasisOfCompensation == "FeeCommission"||_selectedBasisOfCompensation == "FeeCommission*")
                        {
                            _Value = txtFeeAmount.Text.Trim();
                            _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                        }
                        mynewfile = ClientServiceAndBusinessAssociate(_selectedClient, _selectedState, _selectedBasisOfCompensation, _selectedAdditionalServices, _selectedFeeAmount, _selectedlnvoiceSchedule, _selectedLegalEntity, _selectedEffectiveDate);

                        #endregion

                    }
                    #region Storing the Activity Logs
                    string AdditionalCrtieriaOption_1 = ddlState.SelectedItem.Text.Trim();
                    string AdditionalCrtieriaOption_2 = ddlLegalEntity.SelectedItem.Text.Trim();
                    string AdditionalCrtieriaOption_3 = ddlType.SelectedItem.Text.Trim();
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(txtProspectName.Text), Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office, "Compliance", "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    DownloadFileNew(mynewfile);
                }
               
                   
                }
            }
        
       }

}