﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using BenefitPointSummaryPortal.BAL.Reports;

namespace BenefitPointSummaryPortal.View
{
    public partial class BenefitSummaryReport_V2 : System.Web.UI.Page
    {
        #region Global Variable
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        DataSet AccountDS = new DataSet();
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        DataSet BenefitStructureDS = new DataSet();
        DataSet EligibilityDS = new DataSet();
        DataSet RateDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        Timeline_Constant tc = new Timeline_Constant();
        string temperror = "cs";

        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList MedicalBenefitColumnId_Tier3 = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList GroupTermLifeBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList();
        ArrayList WellnessBenefitColumnIdList = new ArrayList();
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        DataTable PlanInfoTable = new DataTable();
        static DataTable dtPlanContactInfo = new DataTable();

        //static List<int> MedicalPlanTypeList = new List<int>();
        //static List<int> DentalPlanTypeList = new List<int>();
        //static List<int> VisionPlanTypeList = new List<int>();
        //static List<int> LifeADDPlanTypeList = new List<int>();
        //static List<int> STDPlanTypeList = new List<int>();
        //static List<int> LTDPlanTypeList = new List<int>();
        //static List<int> VoluntaryLifeADDPlanTypeList = new List<int>();
        //static List<int> EAPPlanTypeList = new List<int>();
        //static List<int> FSAPlanTypeList = new List<int>();
        //static List<int> HRAPlanTypeList = new List<int>();
        //static List<int> HSAPlanTypeList = new List<int>();
        //static List<int> WellnessPlanTypeList = new List<int>();
        //static List<int> GroupTermLifePlanTypeList = new List<int>();
        //static List<int> ADNDPlanTypeList = new List<int>();
        //static List<int> AdditionalProductsPlanTypeList = new List<int>();
        SummaryDetail sd = new SummaryDetail();
        string selectedColor = string.Empty;

        #region Added by vinod : storing the activity logs
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        //        SummaryDetail sdd = new SummaryDetail();
        List<Contact> ContactList = new List<Contact>();
        BPBusiness bpp = new BPBusiness();
        #endregion

        #endregion

        # region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btnSummary);
                scriptManager.RegisterPostBackControl(this.btnReportCreate);
                selectedColor = ddlColor.SelectedValue.ToString();

                //Added by Shravan.
                PlanInfoTable = GetPlanInfoTable();

                if (Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain")
                {
                    ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceBenefitSummeryToPowerPointSummery", "<script>ReplaceBenefitSummeryToPowerPointSummery()</script>", false);
                    aDeliverable.HRef = "../Files/PowerPoint/Examples/Deliverables Plan Mapping PPT.pdf";
                }
                else
                {
                    aDeliverable.HRef = "../Files/BenefitSummary/Examples/Deliverables Plan Mapping.pdf";
                }

                if (!IsPostBack)
                {
                    TitleSpan.InnerText = Session["Title"].ToString();
                    idDesign_N_Style.InnerText = "Design and Style Options";
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    GetData();

                    #region Added by vinod : Get daprtment details
                    DictDepartment = sd.getDepartmentDetails();
                    #endregion

                    // Added by shravan
                    Hide_SummaryStyle_ListItems();

                    if (Session["Summary"].ToString() == "Tools1_5500_Worksheet")
                    {
                        idDesign_N_Style.InnerText = "Activity Option";
                        PnlScreen1_Tools_Text1.Visible = true;
                        pnlScreen1_Tools_Text2.Visible = true;
                        pnlScreen1_Tools_Text3.Visible = true;
                        pnlScreen1_Tools_Text4.Visible = true;
                        trActivityDDL.Visible = true;
                        trHR.Visible = false;
                        trlegalName.Visible = false;
                        ChkHSASlides.Visible = false;
                        spanPPT_View1.InnerText = "Criteria Page 1 of 2";
                        spanPPT_ViewPPTVideo.InnerText = "Additional Slides – Criteria Page 2 of 2";
                        trBRC.Visible = false;
                        trSummaryStyle.Visible = false;
                        trColorOption.Visible = false;
                        trImageOption.Visible = false;
                        hdnSummary.Value = "5500 Worksheet";
                    }
                    else if (Session["Summary"].ToString() == "PowerPointColorfulDots_v2")
                    {
                        pnlScreen1_BS_Text1.Visible = true;
                        pnlScreen1_BS_Text2.Visible = true;
                        pnlScreen1_BS_Text3.Visible = true;
                        pnlScreen1_BS_Text4.Visible = true;
                        lblPowerPoint.Visible = true;
                        trHR.Visible = false;
                        trlegalName.Visible = false;
                        spanStyleTitle.InnerText = "PowerPoint Style";
                        ChkHSASlides.Visible = false;
                        spanPPT_ViewCount.InnerText = "four";
                        spanPPT_View1.InnerText = "Criteria Page 1 of 4";
                        spanPPT_View2.InnerText = "Plan Details – Criteria Page 2 of 4";
                        spanPPT_ViewPPTVideo.InnerText = "Additional Slides – Criteria Page 3 of 4";
                        spanPPT_View3.InnerText = "Plan Contacts – Criteria Page 4 of 4";
                        //  ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceBenefitSummeryToPowerPointSummery", "<script>ReplaceBenefitSummeryToPowerPointSummery()</script>", false);
                        //spanStyletext.InnerText = "Select the style for your Powerpoint.";
                        //spanColortext.InnerText = "Select the color for your Powerpoint.";
                        //spanImgText.InnerText = "Select an image option for your Powerpoint. There are many industry-specific choices to customize the document for your client.";
                        //Commented by Vaibhav and Shravan :- Function is added above for this purpose
                        //ddlSummaryStyle.Items[1].Enabled = false;
                        //ddlSummaryStyle.Items[2].Enabled = false;
                        //ddlSummaryStyle.Items[3].Enabled = false;
                        //ddlSummaryStyle.Items[6].Enabled = false;
                        //ddlSummaryStyle.Items[8].Enabled = false;
                        trColorOption.Disabled = true;
                        trImageOption.Disabled = true;
                        hdnSummary.Value = "ColorfulDots";
                    }
                    else if (Session["Summary"].ToString() == "Template3_V2")
                    {
                        pnlScreen1_BS_Text1.Visible = true;
                        pnlScreen1_BS_Text2.Visible = true;
                        pnlScreen1_BS_Text3.Visible = true;
                        pnlScreen1_BS_Text4.Visible = true;
                        lblBenefitSummery.Visible = true;
                       // spanStyletext.InnerText = "Select the style for your Benefit Summary.";
                        spanColortext.InnerText = "Select the color for your Benefit Summary.";
                        spanImgText.InnerText = "Select an image option for your Benefit Summary. There are many industry-specific choices to customize the document for your client.";
                        //Commented by Vaibhav and Shravan :- Function is added above for this purpose
                        //ddlSummaryStyle.Items[4].Enabled = false;
                        //ddlSummaryStyle.Items[5].Enabled = false;
                        //ddlSummaryStyle.Items[7].Enabled = false;
                        trColorOption.Disabled = false;
                        trImageOption.Disabled = false;
                        hdnSummary.Value = "Summary";
                    }
                    //else if (Session["Summary"].ToString() == "Simple Summary")
                    //{
                    //    tdVoluntaryLifeSectionRate_1_DDL.Visible = false;
                    //    tdVoluntaryLifeSectionRate_1_Header.Visible = false;
                    //    trImageOption.Visible = true;
                    //}

                    if (Session["Summary"].ToString() == "Reports2_RenewalStatusReport")
                    {
                        mvBenefitSummary.ActiveViewIndex = 4;
                        btnNext.Visible = false;
                        btnPrevious.Visible = false;
                        btnSummary.Visible = false;
                        btnReportCreate.Visible = true;
                        btnReportReset.Visible = true;
                        Activity = "Renewal Status Report";
                        Activity_Group = "Reports";

                        List<Office> OfficeList = new List<Office>();
                        OfficeList = bp.FindOffice(SessionId, "");
                        Session["Reports_Office_List"] = OfficeList;

                        var lregion = (from s in OfficeList orderby s.RegionName ascending select s.RegionName).Distinct();

                        ddlRegion.DataSource = lregion;
                        ddlRegion.DataBind();
                        ddlRegion.Items.Insert(0, new ListItem("Select", "0"));

                        ////cblistOffice.DataSource = OfficeList;
                        ////cblistOffice.DataBind();

                        //Reading the data from Producer XML file and bind to ddlProducerTeam dropdown
                        DataSet procedure = new DataSet();
                        procedure.ReadXml(Server.MapPath("~/Common/Reports/Producer.xml"));
                        ddlProducerTeam.DataSource = procedure;
                        ddlProducerTeam.DataTextField = "description";
                        ddlProducerTeam.DataValueField = "id";
                        ddlProducerTeam.DataBind();

                        ddlProducerTeam.SelectedValue = "1111";
                    }
                    else
                    {
                        mvBenefitSummary.ActiveViewIndex = 0;
                        btnPrevious.Visible = false;
                        btnSummary.Visible = false;
                        btnReportCreate.Visible = false;
                        btnReportReset.Visible = false;
                    }
                    ScriptManagerBenefit.RegisterPostBackControl(btnSummary);
                    ddlColor.SelectedValue = "Gray";
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    SummaryDetail.isClientChanged_ForMedical = false;
                    SummaryDetail.isClientChanged_ForDental = false;
                    SummaryDetail.isClientChanged_ForVision = false;
                    SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                    SummaryDetail.isClientChanged_ForSTD = false;
                    SummaryDetail.isClientChanged_ForLTD = false;

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    Session["ProductSummaryTable"] = null;

                    if (Convert.ToString(Session["Summary"]) == "Template5")
                    {
                        //lblHeading.Text = "Summary Brochure";
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        //lblVisionHeading.Text = "Vision Plan";
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template2")
                    {
                        //lblHeading.Text = "FAQ Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        //lblVisionHeading.Text = "Vision Plan";
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template1")
                    {
                        //lblHeading.Text = "Simple Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    ////if (Convert.ToString(Session["Summary"]) == "Template3_V2")
                    ////{

                    ////    //lblHeading.Text = "Enrollment Summary";
                    ////    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ////    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    ////    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ////    //ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                    ////    //ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                    ////    Activity_Group = "Summaries";
                    ////}

                    if (Convert.ToString(Session["Summary"]) == "Template4")
                    {
                        //lblHeading.Text = "Detail Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        //lblVoluntaryLifeHeading.Text = "# Voluntary Life AD&D Plans";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                        lblImgOption.Visible = true;
                        ddlImageOption.Visible = true;
                    }

                    //if (Convert.ToString(Session["Summary"]) == "Template6")
                    //{
                    //    //lblHeading.Text = "Value Summary";
                    //    ddlMedicalNoOfPlan.Items[4].Enabled = false;
                    //    ddlDentalNoOfPlan.Items[3].Enabled = false;
                    //    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    //    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    //    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //    ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                    //    ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    //    ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                    //    ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                    //    Activity_Group = "Summaries";
                    //    //lnkColorOption.Visible = true;
                    //}

                    //if (Convert.ToString(Session["Summary"]) == "Template7")
                    //{
                    //    //lblHeading.Text = "Highlights Summary";
                    //    ddlLifeADDNoOfPlan.Items[2].Enabled = true;
                    //    ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    //    ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                    //    ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                    //    //lblLifeAddHeading.Text = "# Life AD&D Plan";
                    //    //lblGroupTermLifeHeading.Text = "# Group Term Life Plan";
                    //    Activity_Group = "Summaries";
                    //    lblColor.Visible = false;
                    //    ddlColor.Visible = false;
                    //}

                    if (Convert.ToString(Session["Summary"]) == "PowerPoint1")
                    {
                        //lblHeading.Text = "HSA vs. PPO Dual Choice";
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;

                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        //lblTemplateNo.Text = "#1";

                        //trNotice_Heading.Visible = false;
                        //trNotice_Options.Visible = false;
                        //trChip_Notice.Visible = false;
                        trCreditableCoverage.Visible = false;
                        //trNoticeOfMarketplace.Visible = false;
                        Activity_Group = "PowerPoint";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    if (Convert.ToString(Session["Summary"]) == "PowerPoint2")
                    {
                        //lblHeading.Text = "Dual Choice Medical";
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false; ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        //lblVisionHeading.Text = "Vision Plan";
                        //lblTemplateNo.Text = "#2";

                        //trNotice_Heading.Visible = false;
                        //trNotice_Options.Visible = false;
                        //trChip_Notice.Visible = false;
                        trCreditableCoverage.Visible = false;
                        //trNoticeOfMarketplace.Visible = false;
                        Activity_Group = "PowerPoint";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    if (Convert.ToString(Session["Summary"]) == "PowerPoint3")
                    {
                        //lblHeading.Text = "Single Choice Medical";
                        ddlMedicalNoOfPlan.Items[2].Enabled = false;
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[2].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        //lblMedicalHeading.Text = "Medical Plan";
                        //lblDentalHeading.Text = "Dental Plan";
                        //lblVisionHeading.Text = "Vision Plan";
                        //lblTemplateNo.Text = "#3";

                        //trNotice_Heading.Visible = false;
                        //trNotice_Options.Visible = false;
                        //trChip_Notice.Visible = false;
                        trCreditableCoverage.Visible = false;
                        //trNoticeOfMarketplace.Visible = false;
                        Activity_Group = "PowerPoint";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    //Activity = lblHeading.Text;


                    txtsearch.Focus();

                    #region BindImageDropdown

                    // This block is used to bind the Image DropDownList with the folder names in a given path
                    string path = Server.MapPath("~/Files/BenefitSummary/Images/Pictures/New Benefit Summaries/");
                    DirectoryInfo objDirInfo = new DirectoryInfo(path);
                    DirectoryInfo[] diArr = null;
                    diArr = objDirInfo.GetDirectories();

                    // Display the names of the directories.
                    foreach (DirectoryInfo dri in diArr)
                    {
                        if (dri.Name == "Standard (Default)")
                        {
                            ddlImageOption.Items.Insert(0, new ListItem(dri.Name, string.Empty));
                        }
                        else
                        {
                            ddlImageOption.Items.Add(dri.Name);
                        }
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //BPBusiness bp = new BPBusiness();
                //List<Account> AccountList = new List<Account>();
                //SessionId = Session["SessionId"].ToString();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ddlActivity.Items.Clear();
                if (Convert.ToString(Session["Summary"]) == "Tools1_5500_Worksheet")
                {
                    objCommFun.GetActivity_List("All", tc.Tools1_SubjectID, ddlClient, ref ddlActivity);
                }

                //BPBusiness bp = new BPBusiness();

                Clear();
                ClearMedical();
                ClearDental();
                ClearVision();
                SummaryDetail.isClientChanged_ForMedical = true;
                SummaryDetail.isClientChanged_ForDental = true;
                SummaryDetail.isClientChanged_ForVision = true;
                SummaryDetail.isClientChanged_ForVoluntaryLifeADD = true;
                SummaryDetail.isClientChanged_ForGroupTermLife = true;
                SummaryDetail.isClientChanged_ForLifeADD = true;
                SummaryDetail.isClientChanged_ForSTD = true;
                SummaryDetail.isClientChanged_ForLTD = true;
                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
                FindPlans();
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
                Session["Contact"] = ContactList;
                ddlHRContact.DataSource = ContactList;
                ddlHRContact.DataBind();
                ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlHRContact.Items.Insert(1, new ListItem("None", "-1"));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                SummaryDetail.isClientChanged_ForMedical = false;
                SummaryDetail.isClientChanged_ForDental = false;
                SummaryDetail.isClientChanged_ForVision = false;
                SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                SummaryDetail.isClientChanged_ForSTD = true;
                SummaryDetail.isClientChanged_ForLTD = true;
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //---------------------------------------------------------------------
                // Do not delete code start here -- 02 July 2014
                //---------------------------------------------------------------------
                //List<Account> AccountList = new List<Account>();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //---------------------------------------------------------------------
                // Do not delete code ends here -- 02 July 2014
                //---------------------------------------------------------------------
                Clear();

                if (ddlOffice.Items.Count > 1)
                {
                    ddlOffice.SelectedIndex = 2;
                }
                ddlBRC.SelectedIndex = 0;
                ddlSummaryStyle.SelectedIndex = 0;
                ddlColor.SelectedValue = "Gray";
                ddlImageOption.SelectedIndex = 0;
                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
                ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void GetPlanDetailsForSelectedPlanSections(List<int> planTypeList, string planName, ref List<Plan> planList)
        {
            try
            {
                Plan PlanItem = new Plan();

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    if (planTypeList.Contains(Convert.ToInt16(dr["ProductTypeId"])))
                    {
                        PlanItem = new Plan();
                        // PlanItem.CarrierId 
                        // PlanItem.ProductStatus 
                        // PlanItem.ProductStatusCurrent 
                        // PlanItem.ProductStatusPending 
                        // PlanItem.RateList 
                        // PlanItem.SummaryID 
                        // PlanItem.SummaryName 

                        PlanItem.CarrierName = Convert.ToString(dr["Carrier"]);
                        PlanItem.EffectiveDate = Convert.ToDateTime(dr["Effective"]);
                        PlanItem.LOC = planName;
                        PlanItem.PolicyNumber = Convert.ToString(dr["PolicyNumber"]);
                        PlanItem.ProductId = Convert.ToInt32(dr["ProductId"]);
                        PlanItem.ProductName = Convert.ToString(dr["ProductName"].ToString().Replace("&amp;", "&"));
                        PlanItem.ProductTypeDescription = Convert.ToString(dr["Name"]);
                        PlanItem.ProductTypeId = Convert.ToInt16(dr["ProductTypeId"]);
                        PlanItem.RenewalDate = Convert.ToDateTime(dr["Renewal"]);

                        planList.Add(PlanItem);
                    }
                }

                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in planList)
                {

                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = item.LOC;

                    ProductSummaryTable.Rows.Add(dr);

                }
                Session["ProductSummaryTable"] = ProductSummaryTable;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        private void FillDropdownList(DropDownList ddl, List<Plan> PlanList, DropDownList ddlBenefitSummary, DropDownList ddlContribution1, DropDownList ddlContribution1_2, DropDownList ddlRate = null)
        {
            try
            {
                string selected_Value = string.Empty;
                string BenefitSummary_Selected_Value = string.Empty;
                string Contribution1_Selected_Value = string.Empty;
                string Contribution1_2_Selected_Value = string.Empty;
                string Rate_Selected_Value = string.Empty;

                if (ddl != null)
                {
                    selected_Value = Convert.ToString(ddl.SelectedValue);
                }
                if (ddlBenefitSummary != null)
                {
                    BenefitSummary_Selected_Value = Convert.ToString(ddlBenefitSummary.SelectedValue);
                }
                if (ddlContribution1 != null)
                {
                    Contribution1_Selected_Value = Convert.ToString(ddlContribution1.SelectedValue);
                }
                if (ddlContribution1_2 != null)
                {
                    Contribution1_2_Selected_Value = Convert.ToString(ddlContribution1_2.SelectedValue);
                }
                if (ddlRate != null)
                {
                    Rate_Selected_Value = Convert.ToString(ddlRate.SelectedValue);
                }

                ddl.Items.Clear();
                ddl.DataSource = PlanList;
                ddl.DataBind();
                ddl.Items.Insert(0, new ListItem("Select", "0"));


                if (ddl != null)
                {
                    ddl.SelectedIndex = ddl.Items.IndexOf(ddl.Items.FindByValue(selected_Value));
                }

                if (ddl.SelectedIndex > 0)
                {
                    BindDataToPlan(int.Parse(ddl.SelectedValue), ddlBenefitSummary, ddlContribution1, null, ddlRate, ddlContribution1_2);
                }
                else
                {
                    ClearDropDownList(ddlBenefitSummary, ddlContribution1, ddlContribution1_2);
                }

                if (ddlBenefitSummary != null)
                {
                    ddlBenefitSummary.SelectedIndex = ddlBenefitSummary.Items.IndexOf(ddlBenefitSummary.Items.FindByValue(BenefitSummary_Selected_Value));
                }
                if (ddlContribution1 != null)
                {
                    ddlContribution1.SelectedIndex = ddlContribution1.Items.IndexOf(ddlContribution1.Items.FindByValue(Contribution1_Selected_Value));
                }
                if (ddlContribution1_2 != null)
                {
                    ddlContribution1_2.SelectedIndex = ddlContribution1_2.Items.IndexOf(ddlContribution1_2.Items.FindByValue(Contribution1_2_Selected_Value));
                }
                if (ddlRate != null)
                {
                    ddlRate.SelectedIndex = ddlRate.Items.IndexOf(ddlRate.Items.FindByValue(Rate_Selected_Value));
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void MedicalPlansSelected()
        {
            try
            {
                if (ddlMedicalNoOfPlan.SelectedIndex == 0)
                {
                    ClearMedical();
                    if (ddlMedicalPlanName1 != null)
                    {
                        ddlMedicalPlanName1.Items.Clear();
                    }
                    if (ddlMedicalPlanName2 != null)
                    {
                        ddlMedicalPlanName2.Items.Clear();
                    }
                    if (ddlMedicalPlanName3 != null)
                    {
                        ddlMedicalPlanName3.Items.Clear();
                    }
                    if (ddlMedicalPlanName4 != null)
                    {
                        ddlMedicalPlanName4.Items.Clear();
                    }
                    if (ddlMedicalPlanName5 != null)
                    {
                        ddlMedicalPlanName5.Items.Clear();
                    }
                    if (ddlMedicalPlanName6 != null)
                    {
                        ddlMedicalPlanName6.Items.Clear();
                    }
                }
                string ch = ddlMedicalNoOfPlan.SelectedItem.Text;
                List<Plan> MedicalPlanList = new List<Plan>();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.MedicalPlanTypeList, cv.MedicalLOC, ref MedicalPlanList);
                string selected_Value = string.Empty;
                switch (ch)
                {
                    case "1":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = false;
                        tblMedicalPlan_3.Visible = false;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);

                        //if (ddlMedicalPlanName1.SelectedIndex > 0)
                        //{
                        //selected_Value = Convert.ToString(ddlMedicalPlanName1.SelectedValue);

                        //ddlMedicalPlanName1.Items.Clear();
                        //ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //ddlMedicalPlanName1.DataBind();
                        //ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", "0"));

                        //ddlMedicalPlanName1.SelectedIndex = ddlMedicalPlanName1.Items.IndexOf(ddlMedicalPlanName1.Items.FindByValue(selected_Value));
                        //}
                        //else if (ddlMedicalPlanName1.SelectedIndex == -1)
                        //{
                        //    ddlMedicalPlanName1.Items.Clear();
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", "0"));
                        //    ddlMedicalPlanName1.SelectedValue = selected_Value;

                        //    //SummaryDetail.isClientChanged_ForMedical = false;
                        //}

                        ddlMedicalPlanName2.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        ddlMedicalPlanName3.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                        break;

                    case "2":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = false;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //SummaryDetail.isClientChanged_ForMedical = false;

                        //selected_Value = Convert.ToString(ddlMedicalPlanName1.SelectedValue);

                        //ddlMedicalPlanName1.Items.Clear();
                        //ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //ddlMedicalPlanName1.DataBind();
                        //ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", "0"));

                        //ddlMedicalPlanName1.SelectedIndex = ddlMedicalPlanName1.Items.IndexOf(ddlMedicalPlanName1.Items.FindByValue(selected_Value));

                        //selected_Value = Convert.ToString(ddlMedicalPlanName2.SelectedValue);


                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);

                        ddlMedicalPlanName3.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);

                        break;

                    case "3":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);

                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                        SummaryDetail.isClientChanged_ForMedical = false;
                        break;

                    case "4":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = true;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName4.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName4.DataBind();
                        //    ddlMedicalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        FillDropdownList(ddlMedicalPlanName4, MedicalPlanList, ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);

                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                        SummaryDetail.isClientChanged_ForMedical = false;
                        break;

                    case "5":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = true;
                        tblMedicalPlan_5.Visible = true;
                        tblMedicalPlan_6.Visible = false;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName4.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName4.DataBind();
                        //    ddlMedicalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName5.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName5.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName5.DataBind();
                        //    ddlMedicalPlanName5.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        FillDropdownList(ddlMedicalPlanName4, MedicalPlanList, ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        FillDropdownList(ddlMedicalPlanName5, MedicalPlanList, ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);

                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);

                        break;
                    case "6":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = true;
                        tblMedicalPlan_5.Visible = true;
                        tblMedicalPlan_6.Visible = true;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName4.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName4.DataBind();
                        //    ddlMedicalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName5.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName5.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName5.DataBind();
                        //    ddlMedicalPlanName5.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName6.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName6.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName6.DataBind();
                        //    ddlMedicalPlanName6.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        FillDropdownList(ddlMedicalPlanName4, MedicalPlanList, ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        FillDropdownList(ddlMedicalPlanName5, MedicalPlanList, ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        FillDropdownList(ddlMedicalPlanName6, MedicalPlanList, ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);

                        break;
                    case "_":

                        tblMedicalPlan_1.Visible = false;
                        tblMedicalPlan_2.Visible = false;
                        tblMedicalPlan_3.Visible = false;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlMedicalNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                MedicalPlansSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlMedicalPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName1.SelectedValue), ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlEligibility, null, ddlMedicalContribution1_2);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
            }
        }

        protected void ddlMedicalPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName2.SelectedValue), ddlMedicalBenefitSummary2, ddlMedicalContribution2, null, null, ddlMedicalContribution2_2);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
            }
        }

        protected void ddlMedicalPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName3.SelectedValue), ddlMedicalBenefitSummary3, ddlMedicalContribution3, null, null, ddlMedicalContribution3_2);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
            }
        }

        protected void ddlMedicalPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName4.SelectedValue), ddlMedicalBenefitSummary4, ddlMedicalContribution4, null, null, ddlMedicalContribution4_2);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
            }
        }

        protected void ddlMedicalPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName5.SelectedValue), ddlMedicalBenefitSummary5, ddlMedicalContribution5, null, null, ddlMedicalContribution5_2);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
            }
        }

        protected void ddlMedicalPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName6.SelectedValue), ddlMedicalBenefitSummary6, ddlMedicalContribution6, null, null, ddlMedicalContribution6_2);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
            }
        }

        private void DentalPlanSelected()
        {
            try
            {
                if (ddlDentalNoOfPlan.SelectedIndex == 0)
                {
                    ClearDental();
                    if (ddlDentalPlanName1 != null)
                    {
                        ddlDentalPlanName1.Items.Clear();
                    }
                    if (ddlDentalPlanName2 != null)
                    {
                        ddlDentalPlanName2.Items.Clear();
                    }
                    if (ddlDentalPlanName3 != null)
                    {
                        ddlDentalPlanName3.Items.Clear();
                    }
                    if (ddlDentalPlanName4 != null)
                    {
                        ddlDentalPlanName4.Items.Clear();
                    }
                }
                string ch = ddlDentalNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> DentalPlanList = new List<Plan>();
                Plan PlanItem = new Plan();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.DentalPlanTypeList, cv.DentalLOC, ref DentalPlanList);

                switch (ch)
                {
                    case "1":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = false;
                        tblDentalPlan_3.Visible = false;
                        tblDentalPlan_4.Visible = false;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    SummaryDetail.isClientChanged_ForDental = false;
                        //}

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);

                        ddlDentalPlanName2.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        ddlDentalPlanName3.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        ddlDentalPlanName4.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        break;

                    case "2":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = false;
                        tblDentalPlan_4.Visible = false;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName2.DataSource = DentalPlanList;
                        //    ddlDentalPlanName2.DataBind();
                        //    ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        //SummaryDetail.isClientChanged_ForDental = false;

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);

                        ddlDentalPlanName3.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        ddlDentalPlanName4.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        break;

                    case "3":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = true;
                        tblDentalPlan_4.Visible = false;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName2.DataSource = DentalPlanList;
                        //    ddlDentalPlanName2.DataBind();
                        //    ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName3.DataSource = DentalPlanList;
                        //    ddlDentalPlanName3.DataBind();
                        //    ddlDentalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        FillDropdownList(ddlDentalPlanName3, DentalPlanList, ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);


                        ddlDentalPlanName4.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        //SummaryDetail.isClientChanged_ForDental = false;
                        break;

                    case "4":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = true;
                        tblDentalPlan_4.Visible = true;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName2.DataSource = DentalPlanList;
                        //    ddlDentalPlanName2.DataBind();
                        //    ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName3.DataSource = DentalPlanList;
                        //    ddlDentalPlanName3.DataBind();
                        //    ddlDentalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName4.DataSource = DentalPlanList;
                        //    ddlDentalPlanName4.DataBind();
                        //    ddlDentalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //SummaryDetail.isClientChanged_ForDental = false;

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        FillDropdownList(ddlDentalPlanName3, DentalPlanList, ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        FillDropdownList(ddlDentalPlanName4, DentalPlanList, ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);

                        break;

                    case "_":

                        tblDentalPlan_1.Visible = false;
                        tblDentalPlan_2.Visible = false;
                        tblDentalPlan_3.Visible = false;
                        tblDentalPlan_4.Visible = false;

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlDentalNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DentalPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlDentalPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName1.SelectedValue), ddlDentalBenefitSummary1, ddlDentalContribution1, null, null, ddlDentalContribution1_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
            }
        }

        protected void ddlDentalPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName2.SelectedValue), ddlDentalBenefitSummary2, ddlDentalContribution2, null, null, ddlDentalContribution2_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
            }
        }

        protected void ddlDentalPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName3.SelectedValue), ddlDentalBenefitSummary3, ddlDentalContribution3, null, null, ddlDentalContribution3_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
            }
        }

        protected void ddlDentalPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName4.SelectedValue), ddlDentalBenefitSummary4, ddlDentalContribution4, null, null, ddlDentalContribution4_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
            }
        }

        private void VisionPlanSelected()
        {
            try
            {
                if (ddlVisionNoOfPlan.SelectedIndex == 0)
                {
                    ClearVision();
                    if (ddlVisionPlanName1 != null)
                    {
                        ddlVisionPlanName1.Items.Clear();
                    }
                    if (ddlVisionPlanName2 != null)
                    {
                        ddlVisionPlanName2.Items.Clear();
                    }
                    if (ddlVisionPlanName3 != null)
                    {
                        ddlVisionPlanName3.Items.Clear();
                    }
                    if (ddlVisionPlanName4 != null)
                    {
                        ddlVisionPlanName4.Items.Clear();
                    }
                }
                string ch = ddlVisionNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> VisionPlanList = new List<Plan>();
                Plan PlanItem = new Plan();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.VisionPlanTypeList, cv.VisionLOC, ref VisionPlanList);

                switch (ch)
                {
                    case "1":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = false;
                        tblVisionPlan_3.Visible = false;
                        tblVisionPlan_4.Visible = false;

                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    SummaryDetail.isClientChanged_ForVision = false;
                        //}

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);

                        ddlVisionPlanName2.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        ddlVisionPlanName3.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                        break;

                    case "2":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = false;
                        tblVisionPlan_4.Visible = false;

                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName2.DataSource = VisionPlanList;
                        //    ddlVisionPlanName2.DataBind();
                        //    ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);

                        ddlVisionPlanName3.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                        //SummaryDetail.isClientChanged_ForVision = false;
                        break;

                    case "3":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = true;
                        tblVisionPlan_4.Visible = false;

                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName2.DataSource = VisionPlanList;
                        //    ddlVisionPlanName2.DataBind();
                        //    ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName3.DataSource = VisionPlanList;
                        //    ddlVisionPlanName3.DataBind();
                        //    ddlVisionPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        FillDropdownList(ddlVisionPlanName3, VisionPlanList, ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);

                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                        //SummaryDetail.isClientChanged_ForVision = false;
                        break;

                    case "4":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = true;
                        tblVisionPlan_4.Visible = true;

                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName2.DataSource = VisionPlanList;
                        //    ddlVisionPlanName2.DataBind();
                        //    ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName3.DataSource = VisionPlanList;
                        //    ddlVisionPlanName3.DataBind();
                        //    ddlVisionPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName4.DataSource = VisionPlanList;
                        //    ddlVisionPlanName4.DataBind();
                        //    ddlVisionPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        //SummaryDetail.isClientChanged_ForVision = false;

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        FillDropdownList(ddlVisionPlanName3, VisionPlanList, ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        FillDropdownList(ddlVisionPlanName4, VisionPlanList, ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);

                        break;

                    case "_":

                        tblVisionPlan_1.Visible = false;
                        tblVisionPlan_2.Visible = false;
                        tblVisionPlan_3.Visible = false;
                        tblVisionPlan_4.Visible = false;

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlVisionNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                VisionPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlVisionPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName1.SelectedValue), ddlVisionBenefitSummary1, ddlVisionContribution1, null, null, ddlVisionContribution1_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution1, ddlVisionContribution1_2);
            }
        }

        protected void ddlVisionPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName2.SelectedValue), ddlVisionBenefitSummary2, ddlVisionContribution2, null, null, ddlVisionContribution2_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
            }
        }

        protected void ddlVisionPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName3.SelectedValue), ddlVisionBenefitSummary3, ddlVisionContribution3, null, null, ddlVisionContribution3_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
            }
        }

        protected void ddlVisionPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName4.SelectedValue), ddlVisionBenefitSummary4, ddlVisionContribution4, null, null, ddlVisionContribution4_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
            }
        }

        private void LifeADDPlanSelected()
        {
            try
            {
                List<Plan> LifeADDPlanList = new List<Plan>();

                if (ddlLifeADDNoOfPlan.SelectedIndex == 0)
                {
                    ClearLifeADD();
                    if (ddlLifeADDPlanName1 != null)
                    {
                        ddlLifeADDPlanName1.Items.Clear();
                    }
                    if (ddlLifeADDPlanName2 != null)
                    {
                        ddlLifeADDPlanName2.Items.Clear();
                    }
                }

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.LifeADDPlanTypeList, cv.LifeADDLOC, ref LifeADDPlanList);

                if (ddlLifeADDNoOfPlan.SelectedIndex == 1)
                {
                    tblLifeADDPlan_1.Visible = true;
                    tblLifeADDPlan_2.Visible = false;

                    //if (ddlLifeADDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLifeADD == true)
                    //{
                    //    ddlLifeADDPlanName1.DataSource = LifeADDPlanList;
                    //    ddlLifeADDPlanName1.DataBind();
                    //    ddlLifeADDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}

                    FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);

                    ddlLifeADDPlanName2.Items.Clear();
                    ClearDropDownList(ddlLifeADDBenefitSummary2, null);
                    //SummaryDetail.isClientChanged_ForLifeADD = false;
                }
                else if (ddlLifeADDNoOfPlan.SelectedIndex == 2)
                {
                    tblLifeADDPlan_1.Visible = true;
                    tblLifeADDPlan_2.Visible = true;

                    //if (ddlLifeADDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLifeADD == true)
                    //{
                    //    ddlLifeADDPlanName1.DataSource = LifeADDPlanList;
                    //    ddlLifeADDPlanName1.DataBind();
                    //    ddlLifeADDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}
                    //if (ddlLifeADDPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLifeADD == true)
                    //{
                    //    ddlLifeADDPlanName2.DataSource = LifeADDPlanList;
                    //    ddlLifeADDPlanName2.DataBind();
                    //    ddlLifeADDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}
                    //SummaryDetail.isClientChanged_ForLifeADD = false;

                    FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);
                    FillDropdownList(ddlLifeADDPlanName2, LifeADDPlanList, ddlLifeADDBenefitSummary2, null, null);

                }
                else
                {
                    tblLifeADDPlan_1.Visible = false;
                    tblLifeADDPlan_2.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlLifeADDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                LifeADDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLifeADDPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName1.SelectedValue), ddlLifeADDBenefitSummary1, null, null);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary1, null);
            }
        }

        protected void ddlLifeADDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName2.SelectedValue), ddlLifeADDBenefitSummary2, null, null);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary2, null);
            }
        }

        private void STDPlanSelected()
        {
            try
            {
                List<Plan> STDPlanList = new List<Plan>();

                if (ddlSTDNoOfPlan.SelectedIndex == 0)
                {
                    ClearSTD();
                    if (ddlSTDPlanName1 != null)
                    {
                        ddlSTDPlanName1.Items.Clear();
                    }
                    if (ddlSTDPlanName2 != null)
                    {
                        ddlSTDPlanName2.Items.Clear();
                    }
                }

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.STDPlanTypeList, cv.STDPlanType_CommonCriteria, ref STDPlanList);

                if (ddlSTDNoOfPlan.SelectedIndex == 1)
                {
                    tblSTD_1.Visible = true;
                    tblSTD_2.Visible = false;

                    //if (ddlSTDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForSTD == true)
                    //{
                    //    ddlSTDPlanName1.DataSource = STDPlanList;
                    //    ddlSTDPlanName1.DataBind();
                    //    ddlSTDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}

                    FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null, ddlVoluntarySTDRate);

                    ddlSTDPlanName2.Items.Clear();
                    ClearDropDownList(ddlSTDBenefitSummary2, null);
                    //SummaryDetail.isClientChanged_ForSTD = false;
                }
                else if (ddlSTDNoOfPlan.SelectedIndex == 2)
                {
                    tblSTD_1.Visible = true;
                    tblSTD_2.Visible = true;

                    //if (ddlSTDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForSTD == true)
                    //{
                    //    ddlSTDPlanName1.DataSource = STDPlanList;
                    //    ddlSTDPlanName1.DataBind();
                    //    ddlSTDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}
                    //if (ddlSTDPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForSTD == true)
                    //{
                    //    ddlSTDPlanName2.DataSource = STDPlanList;
                    //    ddlSTDPlanName2.DataBind();
                    //    ddlSTDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}
                    //SummaryDetail.isClientChanged_ForSTD = false;

                    FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);
                    FillDropdownList(ddlSTDPlanName2, STDPlanList, ddlSTDBenefitSummary2, null, null);
                }
                else
                {
                    tblSTD_1.Visible = false;
                    tblSTD_2.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlSTDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                STDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlSTDPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName1.SelectedIndex > 0)
            {
                if (ddlSTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName1.SelectedValue), ddlSTDBenefitSummary1, null, null, ddlVoluntarySTDRate);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName1.SelectedValue), ddlSTDBenefitSummary1, null, null, ddlVoluntarySTDRate);
                }

                if (!IsProductVoluntary(Convert.ToInt32(ddlSTDPlanName1.SelectedValue), Session["SessionId"].ToString()) || !(Convert.ToString(Session["Summary"]) == "BenefitSummary_FAQv2"))
                {

                    trSTDRate1.Visible = false;
                }
                else if (IsProductVoluntary(Convert.ToInt32(ddlSTDPlanName1.SelectedValue), Session["SessionId"].ToString()) || (Convert.ToString(Session["Summary"]) == "BenefitSummary_FAQv2"))
                {
                    trSTDRate1.Visible = true;
                }
            }
            else
            {
                if (ddlSTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary1, null);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary1, null);
                }
            }
        }

        protected void ddlSTDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName2.SelectedIndex > 0)
            {
                if (ddlSTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName2.SelectedValue), ddlSTDBenefitSummary2, null, null);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName2.SelectedValue), ddlSTDBenefitSummary2, null, null);
                }
            }
            else
            {
                if (ddlSTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary2, null);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary2, null);
                }
            }
        }

        private void LTDPlanSelected()
        {
            try
            {
                List<Plan> LTDPlanList = new List<Plan>();

                if (ddlLTDNoOfPlan.SelectedIndex == 0)
                {
                    ClearLTD();
                    if (ddlLTDPlanName1 != null)
                    {
                        ddlLTDPlanName1.Items.Clear();
                    }
                    if (ddlLTDPlanName2 != null)
                    {
                        ddlLTDPlanName2.Items.Clear();
                    }
                }

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.LTDPlanTypeList, cv.LTDPlanType_CommonCriteria, ref LTDPlanList);

                if (ddlLTDNoOfPlan.SelectedIndex == 1)
                {
                    tblLTD_1.Visible = true;
                    tblLTD_2.Visible = false;

                    //if (ddlLTDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLTD == true)
                    //{
                    //    ddlLTDPlanName1.DataSource = LTDPlanList;
                    //    ddlLTDPlanName1.DataBind();
                    //    ddlLTDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}

                    FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null, ddlVoluntaryLTDRate);


                    ddlLTDPlanName2.Items.Clear();
                    ClearDropDownList(ddlLTDBenefitSummary2, null);
                    //SummaryDetail.isClientChanged_ForLTD = false;
                }
                else if (ddlLTDNoOfPlan.SelectedIndex == 2)
                {
                    tblLTD_1.Visible = true;
                    tblLTD_2.Visible = true;

                    //if (ddlLTDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLTD == true)
                    //{
                    //    ddlLTDPlanName1.DataSource = LTDPlanList;
                    //    ddlLTDPlanName1.DataBind();
                    //    ddlLTDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}
                    //if (ddlLTDPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLTD == true)
                    //{
                    //    ddlLTDPlanName2.DataSource = LTDPlanList;
                    //    ddlLTDPlanName2.DataBind();
                    //    ddlLTDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                    //}
                    //SummaryDetail.isClientChanged_ForLTD = false;

                    FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null);
                    FillDropdownList(ddlLTDPlanName2, LTDPlanList, ddlLTDBenefitSummary2, null, null);

                }
                else
                {
                    tblLTD_1.Visible = false;
                    tblLTD_2.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLTDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                LTDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLTDPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName1.SelectedIndex > 0)
            {
                if (ddlLTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName1.SelectedValue), ddlLTDBenefitSummary1, null, null, ddlVoluntaryLTDRate);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName1.SelectedValue), ddlLTDBenefitSummary1, null, null, ddlVoluntaryLTDRate);
                }


                if (!IsProductVoluntary(Convert.ToInt32(ddlLTDPlanName1.SelectedValue), Session["SessionId"].ToString()) || !(Convert.ToString(Session["Summary"]) == "BenefitSummary_FAQv2"))
                {

                    trLTDRate1.Visible = false;
                }
                else if (IsProductVoluntary(Convert.ToInt32(ddlLTDPlanName1.SelectedValue), Session["SessionId"].ToString()) || (Convert.ToString(Session["Summary"]) == "BenefitSummary_FAQv2"))
                {
                    trLTDRate1.Visible = true;
                }
            }
            else
            {
                if (ddlLTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary1, null);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary1, null);
                }
            }
        }

        protected void ddlLTDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName2.SelectedIndex > 0)
            {
                if (ddlLTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName2.SelectedValue), ddlLTDBenefitSummary2, null, null);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName2.SelectedValue), ddlLTDBenefitSummary2, null, null);
                }
            }
            else
            {
                if (ddlLTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary2, null);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary2, null);
                }
            }
        }

        private void VoluntariLifeADDPlanSelected()
        {
            try
            {
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                {
                    ClearVoluntaryLifeADD();
                    if (ddlVoluntaryLifeADDPlanName != null)
                    {
                        ddlVoluntaryLifeADDPlanName.Items.Clear();
                    }
                    if (ddlVoluntaryLifeADDPlanName2 != null)
                    {
                        ddlVoluntaryLifeADDPlanName2.Items.Clear();
                    }
                }

                string ch = ddlVoluntaryLifeADDNoOfPlan.SelectedItem.Text;
                List<Plan> VoluntaryLifeADDPlanList = new List<Plan>();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.VoluntaryLifeADDPlanTypeList, cv.VoluntaryLifeADDLOC, ref VoluntaryLifeADDPlanList);

                switch (ch)
                {
                    case "1":

                        tblVoluntaryLifeADD_1.Visible = true;

                        if (ddlVoluntaryLifeADDPlanName != null && ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                        {
                            if (ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADandD"))
                            {
                                tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                                tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
                            }
                            else
                            {
                                tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                                tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
                            }
                        }
                        else
                        {
                            tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                            tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
                        }

                        tblVoluntaryLifeADD_2.Visible = false;

                        //if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        //{
                        //    ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                        //    ddlVoluntaryLifeADDPlanName.DataBind();
                        //    ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                        //    ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                        //    ddlVoluntaryLifeADDRate.Items.Clear();
                        //}

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, ddlVoluntaryLifeADDRate);

                        ddlVoluntaryLifeADDPlanName2.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2);
                        break;

                    //case "Offered":
                    //    //trVoluntaryLifeADDSection.Visible = true;
                    //    if (ddlVoluntaryLifeADDPlanName != null && ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                    //    {
                    //        if (ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADandD"))
                    //        {
                    //            //trVoluntaryLifeADDSection11.Visible = false;
                    //        }
                    //        else
                    //        {
                    //            //trVoluntaryLifeADDSection11.Visible = true;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        //trVoluntaryLifeADDSection11.Visible = true;
                    //    }
                    //    //trVoluntaryLifeADDSection2.Visible = false;
                    //    //trVoluntaryLifeADDSection12.Visible = false;

                    //    if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                    //    {
                    //        ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                    //        ddlVoluntaryLifeADDPlanName.DataBind();
                    //        ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    //        SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                    //        ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                    //        ddlVoluntaryLifeADDRate.Items.Clear();
                    //    }

                    //    ddlVoluntaryLifeADDPlanName2.Items.Clear();
                    //    ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2);
                    //    break;

                    case "2":

                        tblVoluntaryLifeADD_1.Visible = true;

                        if (ddlVoluntaryLifeADDPlanName != null && ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                        {
                            if (ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADandD"))
                            {
                                tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                                tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
                            }
                            else
                            {
                                tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                                tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
                            }
                        }
                        else
                        {
                            tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                            tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
                        }

                        tblVoluntaryLifeADD_2.Visible = true;

                        if (ddlVoluntaryLifeADDPlanName2 != null && ddlVoluntaryLifeADDPlanName2.SelectedIndex > 0)
                        {
                            if (ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("ADandD"))
                            {
                                tdVoluntaryLifeSectionRate_2_Header.Visible = true;
                                tdVoluntaryLifeSectionRate_2_DDL.Visible = true;
                            }
                            else
                            {
                                tdVoluntaryLifeSectionRate_2_Header.Visible = true;
                                tdVoluntaryLifeSectionRate_2_DDL.Visible = true;
                            }
                        }
                        else
                        {
                            tdVoluntaryLifeSectionRate_2_Header.Visible = true;
                            tdVoluntaryLifeSectionRate_2_DDL.Visible = true;
                        }

                        //if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        //{
                        //    ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                        //    ddlVoluntaryLifeADDPlanName.DataBind();
                        //    ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                        //    ddlVoluntaryLifeADDRate.Items.Clear();
                        //}
                        //if (ddlVoluntaryLifeADDPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        //{
                        //    ddlVoluntaryLifeADDPlanName2.DataSource = VoluntaryLifeADDPlanList;
                        //    ddlVoluntaryLifeADDPlanName2.DataBind();
                        //    ddlVoluntaryLifeADDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    ddlVoluntaryLifeADDBenefitSummary2.Items.Clear();
                        //    ddlVoluntaryLifeADDRate2.Items.Clear();
                        //}
                        //SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, ddlVoluntaryLifeADDRate);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName2, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary2, null, null, ddlVoluntaryLifeADDRate2);

                        break;

                    case "_":

                        tblVoluntaryLifeADD_1.Visible = false;
                        tblVoluntaryLifeADD_2.Visible = false;

                        break;

                    case "Not Offered":
                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlVoluntaryLifeADDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            #region New Code
            try
            {
                VoluntariLifeADDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            #endregion
        }

        protected void ddlVoluntaryLifeADDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            tdVoluntaryLifeSectionRate_1_Header.Visible = true;
            tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
            tdVoluntaryLifeSectionRate_1_Header.Visible = true;
            tdVoluntaryLifeSectionRate_1_DDL.Visible = true;

            DropDownList ddlVolName1 = (DropDownList)sender;
            ddlVoluntaryLifeADDRate.Items.Clear();

            if (ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName.SelectedValue), ddlVoluntaryLifeADDBenefitSummary, null, null, ddlVoluntaryLifeADDRate);

                //if (ddlVolName1.SelectedItem.Text.Contains("AD&D") || ddlVolName1.SelectedItem.Text.Contains("ADD") || ddlVolName1.SelectedItem.Text.Contains("ADnD") || ddlVolName1.SelectedItem.Text.Contains("ADandD"))
                //{
                //    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName.SelectedValue), ddlVoluntaryLifeADDBenefitSummary, null, null);
                //    if (ddlVolName1.ID == "ddlVoluntaryLifeADDPlanName")
                //    {
                //        //trVoluntaryLifeADDSection11.Visible = false;
                //        //tdVoluntaryLifeSectionRate_1_Header.Visible = false;
                //        //tdVoluntaryLifeSectionRate_1_DDL.Visible = false;

                //        tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                //        tdVoluntaryLifeSectionRate_1_DDL.Visible = true;

                //    }
                //    else if (ddlVolName1.ID == "ddlVoluntaryLifeADDPlanName2")
                //    {
                //        //trVoluntaryLifeADDSection12.Visible = false;
                //        //tdVoluntaryLifeSectionRate_2_Header.Visible = false;
                //        //tdVoluntaryLifeSectionRate_2_DDL.Visible = false;

                //        tdVoluntaryLifeSectionRate_2_Header.Visible = true;
                //        tdVoluntaryLifeSectionRate_2_DDL.Visible = true;
                //    }
                //}
                //else
                //{
                //    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName.SelectedValue), ddlVoluntaryLifeADDBenefitSummary, null, null, ddlVoluntaryLifeADDRate);
                //}
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeADDRate);
            }
        }

        protected void ddlVoluntaryLifeADDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            tdVoluntaryLifeSectionRate_2_Header.Visible = true;
            tdVoluntaryLifeSectionRate_2_DDL.Visible = true;
            tdVoluntaryLifeSectionRate_2_Header.Visible = true;
            tdVoluntaryLifeSectionRate_2_DDL.Visible = true;

            DropDownList ddlVolName2 = (DropDownList)sender;
            ddlVoluntaryLifeADDRate2.Items.Clear();

            if (ddlVoluntaryLifeADDPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName2.SelectedValue), ddlVoluntaryLifeADDBenefitSummary2, null, null, ddlVoluntaryLifeADDRate2);

                //if (ddlVolName2.SelectedItem.Text.Contains("AD&D") || ddlVolName2.SelectedItem.Text.Contains("ADD") || ddlVolName2.SelectedItem.Text.Contains("ADnD") || ddlVolName2.SelectedItem.Text.Contains("ADandD"))
                //{
                //    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName2.SelectedValue), ddlVoluntaryLifeADDBenefitSummary2, null, null, ddlVoluntaryLifeADDRate2);
                //    //if (ddlVolName2.ID == "ddlVoluntaryLifeADDPlanName")
                //    //{
                //    //    //trVoluntaryLifeADDSection11.Visible = false;
                //    //    //tdVoluntaryLifeSectionRate_1_Header.Visible = false;
                //    //    //tdVoluntaryLifeSectionRate_1_DDL.Visible = false;

                //    //    tdVoluntaryLifeSectionRate_1_Header.Visible = true;
                //    //    tdVoluntaryLifeSectionRate_1_DDL.Visible = true;

                //    //}
                //    //else if (ddlVolName2.ID == "ddlVoluntaryLifeADDPlanName2")
                //    //{
                //    //    //trVoluntaryLifeADDSection12.Visible = false;
                //    //    //tdVoluntaryLifeSectionRate_2_Header.Visible = false;
                //    //    //tdVoluntaryLifeSectionRate_2_DDL.Visible = false;

                //    //    tdVoluntaryLifeSectionRate_2_Header.Visible = true;
                //    //    tdVoluntaryLifeSectionRate_2_DDL.Visible = true;
                //    //}
                //}
                //else
                //{
                //    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName2.SelectedValue), ddlVoluntaryLifeADDBenefitSummary2, null, null, ddlVoluntaryLifeADDRate2);
                //}
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2);
            }
        }

        private void EAPPlanSelected()
        {
            try
            {
                if (ddlEAPNoOfPlan.SelectedIndex == 0)
                {
                    ClearEAP();
                    if (ddlEAPPlanName != null)
                    {
                        ddlEAPPlanName.Items.Clear();
                    }
                }

                if (ddlEAPNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> EAPPlanList = new List<Plan>();

                    GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.EAPPlanTypeList, cv.EAPPlanType_CommonCriteria, ref EAPPlanList);

                    tblEAP_1.Visible = true;

                    //ddlEAPPlanName.DataSource = EAPPlanList;
                    //ddlEAPPlanName.DataBind();
                    //ddlEAPPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);
                }
                else
                {
                    tblEAP_1.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlEAPNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                EAPPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlEAPPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName.SelectedValue), ddlEAPBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary, null);
            }
        }

        private void FSAPlanSelected()
        {
            try
            {
                if (ddlFSANoOfPlan.SelectedIndex == 0)
                {
                    ClearFSA();
                    if (ddlFSAPlanName != null)
                    {
                        ddlFSAPlanName.Items.Clear();
                    }
                }

                if (ddlFSANoOfPlan.SelectedIndex == 1)
                {
                    List<Plan> FSAPlanList = new List<Plan>();

                    GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.FSAPlanTypeList, cv.FSAPlanType_CommonCriteria, ref FSAPlanList);

                    tblFSA_1.Visible = true;

                    //ddlFSAPlanName.DataSource = FSAPlanList;
                    //ddlFSAPlanName.DataBind();
                    //ddlFSAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);
                }
                else
                {
                    tblFSA_1.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlFSANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                FSAPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlFSAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName.SelectedValue), ddlFSABenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary, null);
            }
        }

        private void HSAPlanSelected()
        {
            try
            {
                if (ddlHSANoOfPlan.SelectedIndex == 0)
                {
                    ClearHSA();
                    if (ddlHSAPlanName != null)
                    {
                        ddlHSAPlanName.Items.Clear();
                    }
                }

                if (ddlHSANoOfPlan.SelectedIndex == 1)
                {
                    List<Plan> HSAPlanList = new List<Plan>();

                    GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.HSAPlanTypeList, cv.HSAPlanType_CommonCriteria, ref HSAPlanList);

                    tblHSA_1.Visible = true;

                    //ddlHSAPlanName.DataSource = HSAPlanList;
                    //ddlHSAPlanName.DataBind();
                    //ddlHSAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);
                }
                else
                {
                    tblHSA_1.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHSANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HSAPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHSAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName.SelectedValue), ddlHSABenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary, null);
            }
        }

        private void HRAPlanSelected()
        {
            try
            {
                if (ddlHRANoOfPlan.SelectedIndex == 0)
                {
                    ClearHRA();
                    if (ddlHRAPlanName != null)
                    {
                        ddlHRAPlanName.Items.Clear();
                    }
                }

                if (ddlHRANoOfPlan.SelectedIndex == 1)
                {
                    List<Plan> HRAPlanList = new List<Plan>();

                    GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.HRAPlanTypeList, cv.HRAPlanType_CommonCriteria, ref HRAPlanList);

                    tblHRA_1.Visible = true;

                    //    ddlHRAPlanName.DataSource = HRAPlanList;
                    //    ddlHRAPlanName.DataBind();
                    //    ddlHRAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);
                }
                else
                {
                    tblHRA_1.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHRANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HRAPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHRAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName.SelectedValue), ddlHRABenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary, null);
            }
        }

        protected void ddlAnnualLegalNotice_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlAnnualLegalNotice.SelectedIndex == 1)
                {
                    trAnual.Visible = true;
                    trNoticeOptions.Visible = true;
                }
                else
                {
                    trAnual.Visible = false;
                    trNoticeOptions.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {

                //Activity = Convert.ToString(ddlSummaryStyle.SelectedItem.Text);
                //System.Threading.Thread.Sleep(3000);
                Session["PlanTable"] = null;
                CreatePlanTable();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;
                DataTable PlanTable = new DataTable();
                PlanTable = (DataTable)Session["PlanTable"];
                DataTable PlansTable = PlanTable;
                PlansTable.DefaultView.Sort = "[PlanType] asc";

                // For PowerPoint template 2 medical plans are mandatory so below code is for validating the same
                if (Convert.ToString(Session["Summary"]) == "PowerPoint1" || Convert.ToString(Session["Summary"]) == "PowerPoint2")
                {
                    if (ddlMedicalNoOfPlan.SelectedIndex == 1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select 2 medical plans.')</script>");
                        flag = false;
                    }
                }


                if (flag == true)
                {
                    if (Session["PlanTable"] == null)
                    {
                        CreatePlanTable();
                        PlanTable = (DataTable)Session["PlanTable"];
                    }
                    sd.BuildAccountTable();
                    sd.BuildBenefitSummaryTable();
                    sd.BuildBenifitSummaryStructureTable();
                    sd.BuildContributionTable();
                    sd.BuildEligibilityRuleTable();
                    sd.BuildProductTable();
                    sd.BuildRateTable();

                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ProductDS = sd.GetProductDetail(PlanTable, SessionId);
                    //Commented by Vaibhav as per requested by Nicole. Benefit Summary - Basic Blue - Issue#9
                    //BenefitDS = sd.GetBenefitSummary (PlanTable, SessionId); 
                    //Added by Vaibhav as per requested by Nicole. Benefit Summary - Basic Blue - Issue#9
                    BenefitDS = sd.GetBenefitSummary_V2(PlanTable, SessionId);
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    DataTable ProductType = new DataTable();
                    ProductType.Columns.Add("ProductTypeId", typeof(Int32));
                    ProductType.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductType.Columns.Add("PlanNumber", typeof(string));
                    ProductType.Columns.Add("ProductId", typeof(Int32));//need to confirm ,column added for tools
                    DataRow[] foundrow = null;

                    for (int i = 0; i < ProductDS.Tables["ProductTable"].Rows.Count; i++)
                    {
                        ProductType.Rows.Add();
                        ProductType.Rows[i][0] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["productTypeID"]);

                        foundrow = PlanTable.Select("ProductId='" + ProductDS.Tables["ProductTable"].Rows[i]["ProductID"] + "'");

                        ProductType.Rows[i][1] = foundrow[0]["PlanType"];
                        ProductType.Rows[i][2] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["PlanNumber"]);
                        ProductType.Rows[i][3] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["ProductId"]);//need to confirm ,column added for tools
                    }

                    BenefitStructureDS = sd.GetBenefitSummaryStructure(ProductType, SessionId);
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                    {
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    }
                    EligibilityDS = sd.GetEligibilityRule(PlanTable, SessionId, EleigibilityRuleId);

                    if (Convert.ToString(Session["Summary"]) != "Simple_Summary")
                    {
                        RateDS = sd.GetRate(PlanTable, SessionId);
                    }
                    ContributionDS = sd.GetContribution(PlanTable, SessionId);

                    BPBusiness bp = new BPBusiness();

                    #region GET BRC DETAILS FROM SP - Edited by Mr.Amogh Vilayatkar

                    if (!string.IsNullOrEmpty(Account_Office))
                    {
                        List<BRCData> BRCListNew = new List<BRCData>();
                        BRCListNew = bp.GetBRCDetails(Account_Office);

                        if (BRCListNew.Count <= 0)
                        {
                            BRCData brcData = new BRCData();
                            brcData.BRCId = 0;
                            brcData.BRCName = "";
                            brcData.BRCLocation = "";
                            brcData.BRCEmail = "";
                            brcData.BRCPhone = "";
                            brcData.BRCFax = "";
                            brcData.BRCTimezone = "";
                            brcData.BRCDayHours = "";
                            BRCListNew.Add(brcData);
                        }
                        Session["BRCData"] = BRCListNew;
                    }
                    #endregion

                    DataTable Carrierspecific = bp.GetCarrierSpecific();
                    Session["Carrierspecific"] = Carrierspecific;

                    DataTable PlanTypeSpecific = bp.GetPlanTypeSpecific();
                    Session["PlanTypeSpecific"] = PlanTypeSpecific;
                    string mynewfile = "";
                    LoadPlanContactTable();
                    #region  Added by vinod
                    DataSet AccountTeamMemberDS = new DataSet();
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    #endregion

                    //if (Convert.ToString(Session["Summary"]) == "Template1")
                    //{
                    //    mynewfile = CreateSummaryTemplate1();
                    //}
                    //if (Convert.ToString(Session["Summary"]) == "Template5")
                    //{
                    //    mynewfile = CreateSummaryTemplate5();
                    //}
                    //if (Convert.ToString(Session["Summary"]) == "Template2")
                    //{
                    //    mynewfile = CreateSummaryTemplate2();
                    //}
                    if (Convert.ToString(Session["Summary"]) == "Template3_V2")
                    {
                        //// mynewfile = CreateSummaryTemplate3();
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryTemplate3(AccountDS, AccountTeamMemberDS);
                    }
                    //if (Convert.ToString(Session["Summary"]) == "Template4")
                    //{
                    //    mynewfile = CreateSummaryTemplate4();
                    //}
                    //if (Convert.ToString(Session["Summary"]) == "Template6")
                    //{
                    //    mynewfile = CreateSummaryTemplate6();
                    //}
                    if (Convert.ToString(Session["Summary"]) == "Template6_ValueSummary_V2")
                    {
                        //// mynewfile = CreateSummaryTemplate6_ValueSummary_V2();
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryTemplate6_ValueSummary_V2(AccountDS, AccountTeamMemberDS);
                    }
                    //if (Convert.ToString(Session["Summary"]) == "Template7")
                    //{
                    //    mynewfile = CreateSummaryTemplate7_Highlights();
                    //}
                    if (Convert.ToString(Session["Summary"]) == "Template7_V2")
                    {
                        //// mynewfile = CreateSummaryTemplate7_Highlights_V2();
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryTemplate7_Highlights_V2(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template9_EnrollmentGuide")
                    {
                        ////mynewfile = CreateSummaryTemplate9_EnrollmentGuide();
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryTemplate9_EnrollmentGuide(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_BasicBlue")
                    {
                        mynewfile = CreateSummaryTemplate_BasicBlue(AccountDS, AccountTeamMemberDS);
                    }

                    /******************** CALLING BAY- VIEW WORD REPORT **/
                    if (Convert.ToString(Session["Summary"]) == "BenefitSummaryWord_BayView")
                    {
                        mynewfile = CreateSummaryTemplate_BayView(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_SummerHealth")
                    {
                        mynewfile = CreateSummaryTemplate_SummerHealth(AccountDS, AccountTeamMemberDS);
                    }
                    //Benefit Summary Mosaic -- Added by shravan
                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_Mosaic")
                    {
                        mynewfile = CreateSummaryTemplate_Mosaic(AccountDS, AccountTeamMemberDS);
                    }

                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_Mountain")
                    {
                        mynewfile = CreateSummaryTemplate_Mountain(AccountDS, AccountTeamMemberDS);
                    }

                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_SpotLight")
                    {
                        //mynewfile = CreateSummaryTemplate_BasicBlue(AccountDS, AccountTeamMemberDS);
                        mynewfile = CreateSummaryTemplate_SpotLight(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_Tabs")
                    {
                        //mynewfile = CreateSummaryTemplate_BasicBlue(AccountDS, AccountTeamMemberDS);
                        mynewfile = CreateSummaryTemplate_Tabs(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_SpringField")
                    {
                        //mynewfile = CreateSummaryTemplate_BasicBlue(AccountDS, AccountTeamMemberDS);
                        mynewfile = CreateSummaryTemplate_SpringField(AccountDS, AccountTeamMemberDS);
                    }
                    //// For PowerPoint 1
                    //if (Convert.ToString(Session["Summary"]) == "PowerPoint1")
                    //{
                    //    mynewfile = CreateSummaryPowerPoint1();
                    //}
                    //// For PowerPoint 2
                    //if (Convert.ToString(Session["Summary"]) == "PowerPoint2")
                    //{
                    //    mynewfile = CreateSummaryPowerPoint2();
                    //}

                    //// For PowerPoint 3
                    //if (Convert.ToString(Session["Summary"]) == "PowerPoint3")
                    //{
                    //    mynewfile = CreateSummaryPowerPoint3();
                    //}

                    // For PowerPoint 4
                    if (Convert.ToString(Session["Summary"]) == "PowerPointColorfulDots_v2")
                    {
                        ////mynewfile = CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint4_ColorfulDots(AccountDS, AccountTeamMemberDS);
                    }
                    // For PowerPoint 5
                    if (Convert.ToString(Session["Summary"]) == "PowerPointGreenHealthy_v2")
                    {
                        //// mynewfile = CreateSummaryPowerPoint5_GreenHealthy();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint5_GreenHealthy(AccountDS, AccountTeamMemberDS);
                    }
                    // For PowerPoint 7
                    if (Convert.ToString(Session["Summary"]) == "PowerPointColorBlocks_v2")
                    {
                        //// mynewfile = CreateSummaryPowerPoint6_ColoBlocks_PPT();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint6_ColoBlocks_PPT(AccountDS, AccountTeamMemberDS);
                    }

                    //Added by Shravan For Bay View PPt 
                    if (Convert.ToString(Session["Summary"]) == "PowerPoint_BayView")
                    {
                        ////mynewfile = CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint_BayView(AccountDS, AccountTeamMemberDS);
                    }
                    //Added By shravan For Mountain PPt 
                    if (Convert.ToString(Session["Summary"]) == "PowerPoint_Mountain")
                    {
                        ////mynewfile = CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint_Mountain(AccountDS, AccountTeamMemberDS);
                    }

                    if (Convert.ToString(Session["Summary"]) == "PowerPointMosaic_v2")
                    {

                        #region Added by Kiran : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint_Mosaic(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "PowerPointTabs_PPT_v2")
                    {

                        #region Added by Kiran : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint_Tab_PPT(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "PowerPointBasicBlue_v2")
                    {
                        ////mynewfile = CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint4_BasicBlue(AccountDS, AccountTeamMemberDS);
                    }
                    #region Added by Vinod

                    //For Summer Health PPT
                    if (Convert.ToString(Session["Summary"]) == "PowerPoint_SummerHealth")
                    {
                        ////mynewfile = CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint_SummerHealth(AccountDS, AccountTeamMemberDS);
                    }

                    #endregion
                    ////Added By Amogh-10Aug2018  SpotLigh
                    if (Convert.ToString(Session["Summary"]) == "SpotLightPPT_V2")
                    {
                        #region Added by Amogh : As per new change for Activity Insert
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion

                        mynewfile = CreateSummaryPowerPoint4_SpotLight(AccountDS, AccountTeamMemberDS);
                    }
                    // For Tools1 5500 Worksheet
                    if (Convert.ToString(Session["Summary"]) == "Tools1_5500_Worksheet")
                    {
                        #region Added by vinod : As per new change
                        Activity = "5500 Worksheet";
                        Activity_Group = "Compliance";
                        #endregion

                        //Activity = "5500 Worksheet";
                        //Activity_Group = "Tools";
                        #region Commented by vinod
                        //DataSet AccountTeamMemberDS = new DataSet();
                        #endregion
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        mynewfile = CreateTools1_5500_Worksheet_V2(tc.Tools1_SubjectID, PlanInfoTable, AccountDS, AccountTeamMemberDS, SessionId);
                    }
                    //For Simple Summary Redesign
                    if (Convert.ToString(Session["Summary"]) == "Simple_Summary")
                    {
                        //// mynewfile = CreateSummarySimple_Summary();
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummarySimple_Summary(AccountDS, AccountTeamMemberDS);
                    }

                    // Added by shravan
                    if (Convert.ToString(Session["Summary"]) == "BenefitSummary_FAQv2")
                    {
                        //// mynewfile = CreateSummarySimple_Summary();
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummary_FAQv2(AccountDS, AccountTeamMemberDS);
                    }

                    //Added by aarti
                    if (Convert.ToString(Session["Summary"]) == "PowerPoint_SpringField")
                    {
                        ////mynewfile = CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod : As per new change
                        Activity = "PowerPoint Presentation";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryPowerPoint_SpringField(AccountDS, AccountTeamMemberDS);
                    }


                    /************************************* THIS CODE CHECK FOR WORD REPORT AND INSERT ACTIVITY LOG *****/
                    List<string> lstBenefitPointsOptions = new List<string>() { "Template3_V2", "Template7_V2", "Simple_Summary", "Template6_ValueSummary_V2", "Template9_EnrollmentGuide", "BenefitSummary_BasicBlue", "BenefitSummaryWord_BayView", "BenefitSummary_SummerHealth", "BenefitSummary_Mosaic", "BenefitSummary_Mountain", "BenefitSummary_SpotLight", "BenefitSummary_Tabs", "BenefitSummary_SpringField", "Wrapper_Mosaic", "FAQ_SummaryV2", "BenefitSummary_FAQv2" };
                    if (lstBenefitPointsOptions.Contains(Session["Summary"]))
                    {
                        #region Added by vinod : storing the activity logs
                        string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                        string AdditionalCrtieriaOption_2 = ddlColor.SelectedItem.Text;
                        string AdditionalCrtieriaOption_3 = ddlImageOption.SelectedItem.Text;
                        string AdditionalCrtieriaOption_4 = string.Empty;
                        DicActivityLog.Clear();
                        DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, (List<Contact>)Session["Contact"]);
                        bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), "Benefit Summaries", "Communications", DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                        #endregion
                    }

                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlGroupTermLifeNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 0)
                {
                    ClearGroupTermLife();
                    if (ddlGroupTermLifePlanName != null)
                    {
                        ddlGroupTermLifePlanName.Items.Clear();
                    }
                    if (ddlGroupTermLifePlanName2 != null)
                    {
                        ddlMedicalPlanName2.Items.Clear();
                    }
                }

                string ch = ddlGroupTermLifeNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> GroupTermLifePlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> GroupTermLifePlanTypeList = new List<int>();

                GroupTermLifePlanTypeList.Add(250);

                ConstantValue cv = new ConstantValue();
                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in GroupTermLifePlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.GroupTermLifePlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }

                switch (ch)
                {
                    case "1":
                        //trGroupTermLifeSection1.Visible = true;
                        //trGroupTermLifeSection2.Visible = false;

                        if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 0)
                        {
                            //trADNDSection.Attributes.Add("class", "trodd");
                            //trWellnessHeading.Attributes.Add("class", "treven");
                            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trADNDSection.Attributes.Add("class", "trodd");
                            //trWellnessHeading.Attributes.Add("class", "treven");
                            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            //trWellnessProgramSection.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else
                        {
                            //trADNDHeading.Attributes.Add("class", "trodd");
                            //trADNDNoOfPlans.Attributes.Add("class", "treven");
                            //trWellnessHeading.Attributes.Add("class", "trodd");
                            //trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }

                        if (ddlGroupTermLifePlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName.DataBind();
                            ddlGroupTermLifePlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForGroupTermLife = false;
                        }

                        ddlGroupTermLifePlanName2.Items.Clear();
                        ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null);
                        break;

                    case "2":
                        //trGroupTermLifeSection1.Visible = true;
                        //trGroupTermLifeSection2.Visible = true;

                        if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 0)
                        {
                            //trADNDSection.Attributes.Add("class", "treven");
                            //trWellnessHeading.Attributes.Add("class", "trodd");
                            //trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trADNDSection.Attributes.Add("class", "treven");
                            //trWellnessHeading.Attributes.Add("class", "trodd");
                            //trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            //trWellnessProgramSection.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else
                        {
                            //trADNDHeading.Attributes.Add("class", "treven");
                            //trADNDNoOfPlans.Attributes.Add("class", "trodd");
                            //trWellnessHeading.Attributes.Add("class", "treven");
                            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }

                        if (ddlGroupTermLifePlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName.DataBind();
                            ddlGroupTermLifePlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                        }

                        if (ddlGroupTermLifePlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName2.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName2.DataBind();
                            ddlGroupTermLifePlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        SummaryDetail.isClientChanged_ForGroupTermLife = false;
                        break;

                    case "None":
                        //trGroupTermLifeSection1.Visible = false;
                        //trGroupTermLifeSection2.Visible = false;

                        //trADNDHeading.Attributes.Add("class", "treven");
                        //trADNDNoOfPlans.Attributes.Add("class", "trodd");
                        //trWellnessHeading.Attributes.Add("class", "treven");
                        //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                        //LineShading_EAP(0);

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlGroupTermLife_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearGroupTermLife();
            SummaryDetail.isClientChanged_ForGroupTermLife = true;
            ddlGroupTermLifeNoOfPlan.SelectedIndex = 0;
            //trGroupTermLifeSection1.Visible = false;
            //trGroupTermLifeSection2.Visible = false;

            //trADNDHeading.Attributes.Add("class", "treven");
            //trADNDNoOfPlans.Attributes.Add("class", "trodd");
            //trWellnessHeading.Attributes.Add("class", "treven");
            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
            //LineShading_EAP(0);
        }

        protected void ddlGroupTermLifePlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlGroupTermLifePlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlGroupTermLifePlanName.SelectedValue), ddlGroupTermLifeBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlGroupTermLifeBenefitSummary, null);
            }
        }

        protected void ddlGroupTermLifePlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlGroupTermLifePlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlGroupTermLifePlanName2.SelectedValue), ddlGroupTermLifeBenefitSummary2, null, null);
            }
            else
            {
                ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null);
            }
        }

        protected void rdlADND_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearADD();
            ddlADNDNoOfPlan.SelectedIndex = 0;
            //trADNDSection.Visible = false;

            if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
            {
                //trADNDSection.Attributes.Add("class", "treven");
                //trWellnessHeading.Attributes.Add("class", "trodd");
                //trWellnessNoOfPlans.Attributes.Add("class", "treven");

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    //trWellnessProgramSection.Attributes.Add("class", "trodd");
                    //LineShading_EAP(0);
                }
                else
                {
                    //LineShading_EAP(1);
                }
            }
            else
            {
                //trADNDSection.Attributes.Add("class", "trodd");
                //trWellnessHeading.Attributes.Add("class", "treven");
                //trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    //trWellnessProgramSection.Attributes.Add("class", "treven");
                    //LineShading_EAP(1);
                }
                else
                {
                    //LineShading_EAP(0);
                }
            }
        }

        protected void ddlADNDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearADD();

                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> ADDPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> ADDPlanTypeList = new List<int>();
                    // ADD - 270
                    // Wellness - 317
                    ADDPlanTypeList.Add(270);

                    //if (rdlADND.SelectedIndex == 0)
                    //{

                    //    foreach (Plan item in PlanList)
                    //    {
                    //        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                    //        {
                    //            if (ADDPlanTypeList.Contains(item.ProductTypeId))
                    //            {
                    //                ADDPlanList.Add(item);
                    //            }
                    //        }
                    //    }
                    //}
                    //if (rdlADND.SelectedIndex == 1)
                    //{
                    //    foreach (Plan item in PlanList)
                    //    {
                    //        if (ADDPlanTypeList.Contains(item.ProductTypeId))
                    //        {
                    //            ADDPlanList.Add(item);
                    //        }
                    //    }
                    //}
                    ConstantValue cv = new ConstantValue();

                    //trADNDSection.Visible = true;

                    if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
                    {
                        //trADNDSection.Attributes.Add("class", "trodd");
                        //trWellnessHeading.Attributes.Add("class", "treven");
                        //trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else
                        {
                            //LineShading_EAP(0);
                        }
                    }
                    else
                    {
                        //trADNDSection.Attributes.Add("class", "treven");
                        //trWellnessHeading.Attributes.Add("class", "trodd");
                        //trWellnessNoOfPlans.Attributes.Add("class", "treven");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else
                        {
                            //LineShading_EAP(1);
                        }
                    }

                    ddlADNDPlanName.DataSource = ADDPlanList;
                    ddlADNDPlanName.DataBind();
                    ddlADNDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in ADDPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.ADD;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    //trADNDSection.Visible = false;

                    if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
                    {
                        //trADNDSection.Attributes.Add("class", "treven");
                        //trWellnessHeading.Attributes.Add("class", "trodd");
                        //trWellnessNoOfPlans.Attributes.Add("class", "treven");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else
                        {
                            //LineShading_EAP(1);
                        }
                    }
                    else
                    {
                        //trADNDSection.Attributes.Add("class", "trodd");
                        //trWellnessHeading.Attributes.Add("class", "treven");
                        //trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else
                        {
                            //LineShading_EAP(0);
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlADNDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlADNDPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlADNDPlanName.SelectedValue), ddlADNDBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlADNDBenefitSummary, null);
            }
        }

        protected void rdlWellnessProgram_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearWellness();
            ddlWellnessProgramNoOfPlan.SelectedIndex = 0;
            //trWellnessProgramSection.Visible = false;

            if (ddlADNDNoOfPlan.SelectedIndex == 1)
            {
                //trWellnessProgramSection.Attributes.Add("class", "treven");
                //LineShading_EAP(1);
            }
            else
            {
                //trWellnessProgramSection.Attributes.Add("class", "trodd");
                //LineShading_EAP(0);
            }
        }

        protected void ddlWellnessProgramNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearWellness();

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> WellnessPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> WellnessPlanTypeList = new List<int>();
                    // ADD - 270
                    // Wellness - 317
                    WellnessPlanTypeList.Add(317);

                    //if (rdlWellnessProgram.SelectedIndex == 0)
                    //{

                    //    foreach (Plan item in PlanList)
                    //    {
                    //        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                    //        {
                    //            if (WellnessPlanTypeList.Contains(item.ProductTypeId))
                    //            {
                    //                WellnessPlanList.Add(item);
                    //            }
                    //        }
                    //    }
                    //}
                    //if (rdlWellnessProgram.SelectedIndex == 1)
                    //{
                    //    foreach (Plan item in PlanList)
                    //    {
                    //        if (WellnessPlanTypeList.Contains(item.ProductTypeId))
                    //        {
                    //            WellnessPlanList.Add(item);
                    //        }
                    //    }
                    //}
                    ConstantValue cv = new ConstantValue();

                    //trWellnessProgramSection.Visible = true;

                    if (ddlADNDNoOfPlan.SelectedIndex == 1)
                    {
                        //trWellnessProgramSection.Attributes.Add("class", "trodd");
                        //LineShading_EAP(0);
                    }
                    else
                    {
                        //trWellnessProgramSection.Attributes.Add("class", "treven");
                        //LineShading_EAP(1);
                    }

                    ddlWellnessProgramPlanName.DataSource = WellnessPlanList;
                    ddlWellnessProgramPlanName.DataBind();
                    ddlWellnessProgramPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in WellnessPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.Wellness;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    //trWellnessProgramSection.Visible = false; ;
                    if (ddlADNDNoOfPlan.SelectedIndex == 1)
                    {
                        //trWellnessProgramSection.Attributes.Add("class", "treven");
                        //LineShading_EAP(1);
                    }
                    else
                    {
                        //trWellnessProgramSection.Attributes.Add("class", "trodd");
                        //LineShading_EAP(0);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlWellnessProgramPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName.SelectedValue), ddlWellnessProgramBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary, null);
            }
        }

        #endregion

        #region Function
        /// <summary>
        /// Bind data to office dropdown and BRC dropdown.
        /// </summary>
        protected void GetData()
        {
            try
            {
                //Office.
                Session["OffieceTable"] = null;
                Session["BRCList"] = null;
                BPBusiness bp = new BPBusiness();
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();
                dt = bp.GetOfficeList();
                Session["OffieceTable"] = dt;
                ddlOffice.DataSource = dt;
                ddlOffice.DataBind();
                ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlOffice.SelectedIndex = 2;
                ///** Office Dropdown Enabled=False by Amogh*/
                ddlOffice.Enabled = false;

                // BRC
                /*****Code Commented by Mr. Amogh Vilayatkar *****/

                ////List<BRC> BRCList = new List<BRC>();
                ////BRCList = bp.GetBRC_Region();
                ////Session["BRCList"] = BRCList;
                ////ddlBRC.DataSource = BRCList;
                ////ddlBRC.DataBind();
                ddlBRC.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlBRC.Items.Insert(1, new ListItem("Yes", "YES"));
                ddlBRC.Items.Insert(2, new ListItem("No", "NO"));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear(bool rdlPlanSelected = false)
        {
            // Clear Screen 1 controls
            if (rdlPlanSelected == false)
            {
                ddlSummaryStyle.SelectedIndex = 0;
                ddlColor.SelectedValue = "Gray";
                ddlImageOption.SelectedIndex = 0;
                ddlHRContact.Items.Clear();
                ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlBRC.SelectedIndex = 0;
                rdlPlan.SelectedIndex = 0;
            }
            grdPlans.DataSource = null;
            grdPlans.DataBind();

            PPTClearCheckBox();  // Added By Amogh TO Clear PPT Check box

            // Clear Screen 2 controls
            ddlMedicalNoOfPlan.SelectedIndex = 0;
            ddlMedicalPlanName1.Items.Clear();
            ddlMedicalPlanName2.Items.Clear();
            ddlMedicalPlanName3.Items.Clear();
            ddlMedicalPlanName4.Items.Clear();
            ddlMedicalPlanName5.Items.Clear();
            ddlMedicalPlanName6.Items.Clear();
            ClearMedical();

            tblMedicalPlan_1.Visible = false;
            tblMedicalPlan_2.Visible = false;
            tblMedicalPlan_3.Visible = false;
            tblMedicalPlan_4.Visible = false;
            tblMedicalPlan_5.Visible = false;
            tblMedicalPlan_6.Visible = false;

            //tdMedicalSectionPlan_1_Header.Visible = false;
            //tdMedicalSectionPlan_1_DDL.Visible = false;
            //tdMedicalSectionBS_1_Header.Visible = false;
            //tdMedicalSectionBS_1_DDL.Visible = false;
            //tdMedicalSectionContri_1_Header.Visible = false;
            //tdMedicalSectionContri_1_DDL.Visible = false;

            //tdMedicalSectionPlan_2_Header.Visible = false;
            //tdMedicalSectionPlan_2_DDL.Visible = false;
            //tdMedicalSectionBS_2_Header.Visible = false;
            //tdMedicalSectionBS_2_DDL.Visible = false;
            //tdMedicalSectionContri_2_Header.Visible = false;
            //tdMedicalSectionContri_2_DDL.Visible = false;

            //tdMedicalSectionPlan_3_Header.Visible = false;
            //tdMedicalSectionPlan_3_DDL.Visible = false;
            //tdMedicalSectionBS_3_Header.Visible = false;
            //tdMedicalSectionBS_3_DDL.Visible = false;
            //tdMedicalSectionContri_3_Header.Visible = false;
            //tdMedicalSectionContri_3_DDL.Visible = false;

            //tdMedicalSectionPlan_4_Header.Visible = false;
            //tdMedicalSectionPlan_4_DDL.Visible = false;
            //tdMedicalSectionBS_4_Header.Visible = false;
            //tdMedicalSectionBS_4_DDL.Visible = false;
            //tdMedicalSectionContri_4_Header.Visible = false;
            //tdMedicalSectionContri_4_DDL.Visible = false;

            //tdMedicalSectionPlan_5_Header.Visible = false;
            //tdMedicalSectionPlan_5_DDL.Visible = false;
            //tdMedicalSectionBS_5_Header.Visible = false;
            //tdMedicalSectionBS_5_DDL.Visible = false;
            //tdMedicalSectionContri_5_Header.Visible = false;
            //tdMedicalSectionContri_5_DDL.Visible = false;

            //tdMedicalSectionPlan_6_Header.Visible = false;
            //tdMedicalSectionPlan_6_DDL.Visible = false;
            //tdMedicalSectionBS_6_Header.Visible = false;
            //tdMedicalSectionBS_6_DDL.Visible = false;
            //tdMedicalSectionContri_6_Header.Visible = false;
            //tdMedicalSectionContri_6_DDL.Visible = false;

            ddlDentalNoOfPlan.SelectedIndex = 0;
            ddlDentalPlanName1.Items.Clear();
            ddlDentalPlanName2.Items.Clear();
            ddlDentalPlanName3.Items.Clear();
            ddlDentalPlanName4.Items.Clear();
            ClearDental();

            tblDentalPlan_1.Visible = false;
            tblDentalPlan_2.Visible = false;
            tblDentalPlan_3.Visible = false;
            tblDentalPlan_4.Visible = false;

            //tdDentalSectionPlan_1_Header.Visible = false;
            //tdDentalSectionPlan_1_DDL.Visible = false;
            //tdDentalSectionBS_1_Header.Visible = false;
            //tdDentalSectionBS_1_DDL.Visible = false;
            //tdDentalSectionContri_1_Header.Visible = false;
            //tdDentalSectionContri_1_DDL.Visible = false;

            //tdDentalSectionPlan_2_Header.Visible = false;
            //tdDentalSectionPlan_2_DDL.Visible = false;
            //tdDentalSectionBS_2_Header.Visible = false;
            //tdDentalSectionBS_2_DDL.Visible = false;
            //tdDentalSectionContri_2_Header.Visible = false;
            //tdDentalSectionContri_2_DDL.Visible = false;

            //tdDentalSectionPlan_3_Header.Visible = false;
            //tdDentalSectionPlan_3_DDL.Visible = false;
            //tdDentalSectionBS_3_Header.Visible = false;
            //tdDentalSectionBS_3_DDL.Visible = false;
            //tdDentalSectionContri_3_Header.Visible = false;
            //tdDentalSectionContri_3_DDL.Visible = false;

            //tdDentalSectionPlan_4_Header.Visible = false;
            //tdDentalSectionPlan_4_DDL.Visible = false;
            //tdDentalSectionBS_4_Header.Visible = false;
            //tdDentalSectionBS_4_DDL.Visible = false;
            //tdDentalSectionContri_4_Header.Visible = false;
            //tdDentalSectionContri_4_DDL.Visible = false;

            ddlVisionNoOfPlan.SelectedIndex = 0;
            ddlVisionPlanName1.Items.Clear();
            ddlVisionPlanName2.Items.Clear();
            ddlVisionPlanName3.Items.Clear();
            ddlVisionPlanName4.Items.Clear();
            ClearVision();

            tblVisionPlan_1.Visible = false;
            tblVisionPlan_2.Visible = false;
            tblVisionPlan_3.Visible = false;
            tblVisionPlan_4.Visible = false;

            //tdVisionSectionPlan_1_Header.Visible = false;
            //tdVisionSectionPlan_1_DDL.Visible = false;
            //tdVisionSectionBS_1_Header.Visible = false;
            //tdVisionSectionBS_1_DDL.Visible = false;
            //tdVisionSectionContri_1_Header.Visible = false;
            //tdVisionSectionContri_1_DDL.Visible = false;

            //tdVisionSectionPlan_2_Header.Visible = false;
            //tdVisionSectionPlan_2_DDL.Visible = false;
            //tdVisionSectionBS_2_Header.Visible = false;
            //tdVisionSectionBS_2_DDL.Visible = false;
            //tdVisionSectionContri_2_Header.Visible = false;
            //tdVisionSectionContri_2_DDL.Visible = false;

            //tdVisionSectionPlan_3_Header.Visible = false;
            //tdVisionSectionPlan_3_DDL.Visible = false;
            //tdVisionSectionBS_3_Header.Visible = false;
            //tdVisionSectionBS_3_DDL.Visible = false;
            //tdVisionSectionContri_3_Header.Visible = false;
            //tdVisionSectionContri_3_DDL.Visible = false;

            //tdVisionSectionPlan_4_Header.Visible = false;
            //tdVisionSectionPlan_4_DDL.Visible = false;
            //tdVisionSectionBS_4_Header.Visible = false;
            //tdVisionSectionBS_4_DDL.Visible = false;
            //tdVisionSectionContri_4_Header.Visible = false;
            //tdVisionSectionContri_4_DDL.Visible = false;

            ddlLifeADDNoOfPlan.SelectedIndex = 0;
            ddlLifeADDPlanName1.Items.Clear();
            ddlLifeADDPlanName2.Items.Clear();
            ClearLifeADD();

            tblLifeADDPlan_1.Visible = false;
            tblLifeADDPlan_2.Visible = false;

            //tdLifeSectionPlan_1_Header.Visible = false;
            //tdLifeSectionPlan_1_DDL.Visible = false;
            //tdLifeSectionBS_1_Header.Visible = false;
            //tdLifeSectionBS_1_DDL.Visible = false;

            //tdLifeSectionPlan_2_Header.Visible = false;
            //tdLifeSectionPlan_2_DDL.Visible = false;
            //tdLifeSectionBS_2_Header.Visible = false;
            //tdLifeSectionBS_2_DDL.Visible = false;

            ddlSTDNoOfPlan.SelectedIndex = 0;
            ddlSTDPlanName1.Items.Clear();
            ddlSTDPlanName2.Items.Clear();
            ClearSTD();

            tblSTD_1.Visible = false;
            tblSTD_2.Visible = false;

            //tdSTDSectionPlan_1_Header.Visible = false;
            //tdSTDSectionPlan_1_DDL.Visible = false;
            //tdSTDSectionBS_1_Header.Visible = false;
            //tdSTDSectionBS_1_DDL.Visible = false;

            //tdSTDSectionPlan_2_Header.Visible = false;
            //tdSTDSectionPlan_2_DDL.Visible = false;
            //tdSTDSectionBS_2_Header.Visible = false;
            //tdSTDSectionBS_2_DDL.Visible = false;

            ddlLTDNoOfPlan.SelectedIndex = 0;
            ddlLTDPlanName1.Items.Clear();
            ddlLTDPlanName2.Items.Clear();
            ClearLTD();

            tblLTD_1.Visible = false;
            tblLTD_2.Visible = false;

            //tdLTDSectionPlan_1_Header.Visible = false;
            //tdLTDSectionPlan_1_DDL.Visible = false;
            //tdLTDSectionBS_1_Header.Visible = false;
            //tdLTDSectionBS_1_DDL.Visible = false;

            //tdLTDSectionPlan_2_Header.Visible = false;
            //tdLTDSectionPlan_2_DDL.Visible = false;
            //tdLTDSectionBS_2_Header.Visible = false;
            //tdLTDSectionBS_2_DDL.Visible = false;

            ddlVoluntaryLifeADDNoOfPlan.SelectedIndex = 0;
            ddlVoluntaryLifeADDPlanName.Items.Clear();
            ddlVoluntaryLifeADDPlanName2.Items.Clear();
            ClearVoluntaryLifeADD();

            tblVoluntaryLifeADD_1.Visible = false;
            tblVoluntaryLifeADD_2.Visible = false;

            //tdVoluntaryLifeSectionPlan_1_Header.Visible = false;
            //tdVoluntaryLifeSectionPlan_1_DDL.Visible = false;
            //tdVoluntaryLifeSectionBS_1_Header.Visible = false;
            //tdVoluntaryLifeSectionBS_1_DDL.Visible = false;
            //tdVoluntaryLifeSectionRate_1_Header.Visible = false;
            //tdVoluntaryLifeSectionRate_1_DDL.Visible = false;

            //tdVoluntaryLifeSectionPlan_2_Header.Visible = false;
            //tdVoluntaryLifeSectionPlan_2_DDL.Visible = false;
            //tdVoluntaryLifeSectionBS_2_Header.Visible = false;
            //tdVoluntaryLifeSectionBS_2_DDL.Visible = false;
            //tdVoluntaryLifeSectionRate_2_Header.Visible = false;
            //tdVoluntaryLifeSectionRate_2_DDL.Visible = false;

            ddlEAPNoOfPlan.SelectedIndex = 0;
            ddlEAPPlanName.Items.Clear();
            ClearEAP();

            tblEAP_1.Visible = false;

            //tdEAPSectionPlan_1_Header.Visible = false;
            //tdEAPSectionPlan_1_DDL.Visible = false;
            //tdEAPSectionBS_1_Header.Visible = false;
            //tdEAPSectionBS_1_DDL.Visible = false;

            ddlFSANoOfPlan.SelectedIndex = 0;
            ddlFSAPlanName.Items.Clear();
            ClearFSA();

            tblFSA_1.Visible = false;

            //tdFSASectionPlan_1_Header.Visible = false;
            //tdFSASectionPlan_1_DDL.Visible = false;
            //tdFSASectionBS_1_Header.Visible = false;
            //tdFSASectionBS_1_DDL.Visible = false;

            ddlHSANoOfPlan.SelectedIndex = 0;
            ddlHSAPlanName.Items.Clear();
            ClearHSA();

            tblHSA_1.Visible = false;

            //tdHSASectionPlan_1_Header.Visible = false;
            //tdHSASectionPlan_1_DDL.Visible = false;
            //tdHSASectionBS_1_Header.Visible = false;
            //tdHSASectionBS_1_DDL.Visible = false;

            ddlHRANoOfPlan.SelectedIndex = 0;
            ddlHRAPlanName.Items.Clear();
            ClearHRA();

            tblHRA_1.Visible = false;

            //tdHRASectionPlan_1_Header.Visible = false;
            //tdHRASectionPlan_1_DDL.Visible = false;
            //tdHRASectionBS_1_Header.Visible = false;
            //tdHRASectionBS_1_DDL.Visible = false;

            ddlGroupTermLifeNoOfPlan.SelectedIndex = 0;
            ClearGroupTermLife();

            ddlADNDNoOfPlan.SelectedIndex = 0;
            ClearADD();

            ddlWellnessProgramNoOfPlan.SelectedIndex = 0;
            ClearWellness();

            // Clear Screen 3 controls
            //ddlPlanContacts.SelectedValue = "Exclude";
            ddlPlanContacts.SelectedIndex = 1;

            // Clear Screen 4 controls
            ddlAnnualLegalNotice.SelectedIndex = 0;
            chkAnualNotice.SelectedIndex = -1;

            trAnual.Visible = false;
            ddlChipNotice.SelectedIndex = 0;
        }

        private void PPTClearCheckBox()
        {
            chkHSAVideo.ClearSelection();
            chkMobileVideo.ClearSelection();
            chkMedicalVideo.ClearSelection();
            chkDentalVideo.ClearSelection();
            //chkVisionVideo.ClearSelection();
            // chkHRAVideo.ClearSelection();
            chkSTDLTDVideo.ClearSelection();
            // chkLifeADnDVideo.ClearSelection();
            // chkVoluntaryVideo.ClearSelection();
            chkAdditionalProductsVideo.ClearSelection();
        }

        /// <summary>
        /// Clear DropdownList
        /// </summary>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void ClearDropDownList(DropDownList Benefit, DropDownList Contribution, DropDownList Contribution2 = null)
        {
            try
            {
                if (Benefit != null)
                {
                    Benefit.Items.Clear();
                }
                if (Contribution != null)
                {
                    Contribution.Items.Clear();
                }
                if (Contribution2 != null)
                {
                    Contribution2.Items.Clear();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Clear Medical BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearMedical()
        {
            ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
            ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
            ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
            ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
            ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
            ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
        }
        /// <summary>
        /// Clear Dental BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearDental()
        {
            ClearDropDownList(ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
            ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
            ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
            ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
        }
        /// <summary>
        /// Clear Vision BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearVision()
        {
            ClearDropDownList(ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
            ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
            ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
            ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);

        }
        /// <summary>
        /// Clear LifeADD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearLifeADD()
        {
            ClearDropDownList(ddlLifeADDBenefitSummary1, null);
            ClearDropDownList(ddlLifeADDBenefitSummary2, null);
        }
        /// <summary>
        /// Clear GroupTermLife BenefitSummary.
        /// </summary>
        protected void ClearGroupTermLife()
        {
            ClearDropDownList(ddlGroupTermLifeBenefitSummary, null);
            ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null);
        }
        /// <summary>
        /// Clear STD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearSTD()
        {
            ClearDropDownList(ddlSTDBenefitSummary1, null);
            ClearDropDownList(ddlSTDBenefitSummary2, null);
        }
        /// <summary>
        /// Clear LTD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearLTD()
        {
            ClearDropDownList(ddlLTDBenefitSummary1, null);
            ClearDropDownList(ddlLTDBenefitSummary2, null);
            //lblLTDRate.Visible = false;
            //ddlLTDRate.Visible = false;
            //trLTDSection11.Visible = false;
        }
        /// <summary>
        /// Clear VoluntaryLifeADD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearVoluntaryLifeADD()
        {
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeADDRate);
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2);
        }
        /// <summary>
        /// Clear EAP BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearEAP()
        {
            ClearDropDownList(ddlEAPBenefitSummary, null);
        }
        /// <summary>
        /// Clear ADD BenefitSummary.
        /// </summary>
        protected void ClearADD()
        {
            ClearDropDownList(ddlADNDBenefitSummary, null);
        }
        /// <summary>
        /// Clear Wellness BenefitSummary.
        /// </summary>
        protected void ClearWellness()
        {
            ClearDropDownList(ddlWellnessProgramBenefitSummary, null);
        }
        /// <summary>
        /// Clear FSA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearFSA()
        {
            ClearDropDownList(ddlFSABenefitSummary, null);
        }
        /// <summary>
        /// Clear HSA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearHSA()
        {
            ClearDropDownList(ddlHSABenefitSummary, null);
        }
        /// <summary>
        /// Clear HRA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearHRA()
        {
            ClearDropDownList(ddlHRABenefitSummary, null);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="PlanTypeId">Select Plan TypeId</param>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void BindDataToPlan(int PlanTypeId, DropDownList Benefit, DropDownList Contribution, DropDownList Eligibility, DropDownList Rate = null, DropDownList Contribution_2 = null)
        {
            try
            {
                BPBusiness bp = new BPBusiness();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
                List<Rate> RateList = new List<Rate>();
                List<Contribution> ContributionList = new List<Contribution>();
                List<Eligibility> EligibilityList = new List<Eligibility>();

                SessionId = Session["SessionId"].ToString();

                //if (ddlClient.SelectedIndex > 0)   // Vinod Additional PPT slides - Issue #3 - Criteria Page, Benefit Summary drop-down sorting
                //{
                //    BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), PlanTypeId, SessionId);
                //    Benefit.DataSource = BenefitSummaryList;
                //    Benefit.DataBind();
                //    Benefit.Items.Insert(0, new ListItem("Select", string.Empty));
                //}
                if (ddlClient.SelectedIndex > 0)
                {
                    BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), PlanTypeId, SessionId);
                    if (BenefitSummaryList != null || BenefitSummaryList.Count > 0)
                    {
                        BenefitSummaryList = BenefitSummaryList.OrderBy(objSort => objSort.BenefitDescription).ToList();
                    }
                    Benefit.DataSource = BenefitSummaryList;
                    Benefit.DataBind();
                    Benefit.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Rate != null)
                {
                    RateList = bp.FindRates(PlanTypeId, SessionId);
                    Rate.DataSource = RateList;
                    Rate.DataBind();
                    Rate.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Contribution != null)
                {
                    ContributionList = bp.FindContributions(PlanTypeId, SessionId);//(4765506);
                    Contribution.DataSource = ContributionList;
                    Contribution.DataBind();
                    Contribution.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Contribution_2 != null)
                {
                    // ContributionList = bp.FindContributions(PlanTypeId, SessionId);//(4765506);
                    Contribution_2.DataSource = ContributionList;
                    Contribution_2.DataBind();
                    Contribution_2.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                //if (Eligibility != null)
                //{
                //    EligibilityList = bp.FindEligibility(PlanTypeId, SessionId);//(4765506);
                //    Eligibility.DataSource = EligibilityList;
                //    Eligibility.DataBind();
                //    Eligibility.Items.Insert(0, new ListItem("Select", string.Empty));
                //}
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Create Plan Table of selected Plan.
        /// </summary>
        protected void CreatePlanTable()
        {
            try
            {
                BindPlanTable(ddlMedicalPlanName1, ddlMedicalBenefitSummary1, ddlMedicalContribution1, null, 1, ddlMedicalContribution1_2);
                BindPlanTable(ddlMedicalPlanName2, ddlMedicalBenefitSummary2, ddlMedicalContribution2, null, 2, ddlMedicalContribution2_2);
                BindPlanTable(ddlMedicalPlanName3, ddlMedicalBenefitSummary3, ddlMedicalContribution3, null, 3, ddlMedicalContribution3_2);
                BindPlanTable(ddlMedicalPlanName4, ddlMedicalBenefitSummary4, ddlMedicalContribution4, null, 4, ddlMedicalContribution4_2);
                BindPlanTable(ddlMedicalPlanName5, ddlMedicalBenefitSummary5, ddlMedicalContribution5, null, 5, ddlMedicalContribution5_2);
                BindPlanTable(ddlMedicalPlanName6, ddlMedicalBenefitSummary6, ddlMedicalContribution6, null, 6, ddlMedicalContribution6_2);

                BindPlanTable(ddlDentalPlanName1, ddlDentalBenefitSummary1, ddlDentalContribution1, null, 1, ddlDentalContribution1_2);
                BindPlanTable(ddlDentalPlanName2, ddlDentalBenefitSummary2, ddlDentalContribution2, null, 2, ddlDentalContribution2_2);
                BindPlanTable(ddlDentalPlanName3, ddlDentalBenefitSummary3, ddlDentalContribution3, null, 3, ddlDentalContribution3_2);
                BindPlanTable(ddlDentalPlanName4, ddlDentalBenefitSummary4, ddlDentalContribution4, null, 4, ddlDentalContribution4_2);

                BindPlanTable(ddlVisionPlanName1, ddlVisionBenefitSummary1, ddlVisionContribution1, null, 1, ddlVisionContribution1_2);
                BindPlanTable(ddlVisionPlanName2, ddlVisionBenefitSummary2, ddlVisionContribution2, null, 2, ddlVisionContribution2_2);
                BindPlanTable(ddlVisionPlanName3, ddlVisionBenefitSummary3, ddlVisionContribution3, null, 3, ddlVisionContribution3_2);
                BindPlanTable(ddlVisionPlanName4, ddlVisionBenefitSummary4, ddlVisionContribution4, null, 4, ddlVisionContribution4_2);

                BindPlanTable(ddlLifeADDPlanName1, ddlLifeADDBenefitSummary1, null);
                BindPlanTable(ddlLifeADDPlanName2, ddlLifeADDBenefitSummary2, null);

                if (ddlSTDPlanName1.SelectedItem != null)
                {
                    if (ddlSTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName1, ddlSTDBenefitSummary1, null, ddlVoluntarySTDRate);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName1, ddlSTDBenefitSummary1, null, ddlVoluntarySTDRate);
                    }
                }

                if (ddlSTDPlanName2.SelectedItem != null)
                {
                    if (ddlSTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName2, ddlSTDBenefitSummary2, null);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName2, ddlSTDBenefitSummary2, null);
                    }
                }

                if (ddlLTDPlanName1.SelectedItem != null)
                {
                    if (ddlLTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName1, ddlLTDBenefitSummary1, null, ddlVoluntaryLTDRate);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName1, ddlLTDBenefitSummary1, null, ddlVoluntaryLTDRate);

                    }
                }

                if (ddlLTDPlanName2.SelectedItem != null)
                {
                    if (ddlLTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName2, ddlLTDBenefitSummary2, null);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName2, ddlLTDBenefitSummary2, null);

                    }
                }

                BindPlanTable(ddlVoluntaryLifeADDPlanName, ddlVoluntaryLifeADDBenefitSummary, null, ddlVoluntaryLifeADDRate);
                BindPlanTable(ddlVoluntaryLifeADDPlanName2, ddlVoluntaryLifeADDBenefitSummary2, null, ddlVoluntaryLifeADDRate2);

                BindPlanTable(ddlEAPPlanName, ddlEAPBenefitSummary, null);
                BindPlanTable(ddlFSAPlanName, ddlFSABenefitSummary, null);
                BindPlanTable(ddlHSAPlanName, ddlHSABenefitSummary, null);
                BindPlanTable(ddlHRAPlanName, ddlHRABenefitSummary, null);

                // Added for service calendar highlights
                BindPlanTable(ddlGroupTermLifePlanName, ddlGroupTermLifeBenefitSummary, null);
                BindPlanTable(ddlGroupTermLifePlanName2, ddlGroupTermLifeBenefitSummary2, null);

                BindPlanTable(ddlADNDPlanName, ddlADNDBenefitSummary, null);

                BindPlanTable(ddlWellnessProgramPlanName, ddlWellnessProgramBenefitSummary, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Bind data to Plan Table.
        /// </summary>
        /// <param name="DataTable">dtPlanInfoMaster</param>
        protected DataTable BindPlanTable(DataTable dtPlanInfoMaster)
        {
            DataTable planstable = new DataTable();
            try
            {
                planstable.Columns.Add("ProductId", typeof(Int32));
                planstable.Columns.Add("ProductName", typeof(string));
                planstable.Columns.Add("Carrier", typeof(string));
                planstable.Columns.Add("Effective", typeof(string));
                planstable.Columns.Add("Renewal", typeof(string));
                planstable.Columns.Add("PolicyNumber", typeof(string));
                planstable.Columns.Add("ProductTypeDescription", typeof(string));
                planstable.Columns.Add("PlanType", typeof(string));

                if (dtPlanInfoMaster != null)
                {
                    if (dtPlanInfoMaster.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtPlanInfoMaster.Rows.Count; i++)
                        {
                            DataRow dr = planstable.NewRow();

                            dr["ProductId"] = Convert.ToInt32(dtPlanInfoMaster.Rows[i]["ProductId"]);
                            dr["ProductName"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["ProductName"]);
                            dr["Carrier"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Carrier"]);
                            dr["Effective"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Effective"]);
                            dr["Renewal"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Renewal"]);
                            dr["PolicyNumber"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["PolicyNumber"]);
                            dr["ProductTypeDescription"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Name"]);
                            dr["PlanType"] = " ";

                            planstable.Rows.Add(dr);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return planstable;
        }

        /// <summary>
        /// Bind data to Plan Table.
        /// </summary>
        /// <param name="PlanTypeId">DropDownList Plan Type</param>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void BindPlanTable(DropDownList PlanType, DropDownList Benefit, DropDownList Contribution, DropDownList Rate = null, int PlanNumber = 0, DropDownList Contribution_2 = null)
        {
            CommonFunctionsBS.BuiltDictContactsPlanTypes();
            try
            {
                DataTable planstable = new DataTable();
                if (Session["PlanTable"] != null)
                {
                    planstable = (DataTable)Session["PlanTable"];
                }
                else
                {
                    planstable.Columns.Add("ProductId", typeof(Int32));
                    planstable.Columns.Add("ProductName", typeof(string));
                    planstable.Columns.Add("Carrier", typeof(string));
                    planstable.Columns.Add("Effective", typeof(string));
                    planstable.Columns.Add("Renewal", typeof(string));
                    planstable.Columns.Add("PolicyNumber", typeof(string));
                    planstable.Columns.Add("ProductTypeDescription", typeof(string));
                    planstable.Columns.Add("SummaryName", typeof(string));
                    planstable.Columns.Add("SummaryId", typeof(Int32));
                    planstable.Columns.Add("RateName", typeof(string));
                    planstable.Columns.Add("RateId", typeof(Int32));
                    planstable.Columns.Add("ContributionName", typeof(string));
                    planstable.Columns.Add("ContributionId", typeof(Int32));
                    planstable.Columns.Add("ContributionName_2", typeof(string));
                    planstable.Columns.Add("ContributionId_2", typeof(Int32));
                    planstable.Columns.Add("PlanType", typeof(string));
                    planstable.Columns.Add("PlanNumber", typeof(string));
                    planstable.Columns.Add("contactPlanType", typeof(string));
                    planstable.Columns.Add("UsiProductName", typeof(string));
                }

                DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

                if (PlanType.SelectedIndex > 0)
                {
                    DataRow[] foundrow = null;
                    foundrow = ProductSummaryTable.Select("ProductId='" + int.Parse(PlanType.SelectedValue.ToString()) + "'");
                    DataRow dr = planstable.NewRow();
                    dr["ProductId"] = PlanType.SelectedValue;
                    dr["ProductName"] = PlanType.SelectedItem.Text;
                    if (foundrow.Count() > 0)
                    {
                        dr["Carrier"] = foundrow[0]["Carrier"];
                        dr["Effective"] = foundrow[0]["Effective"];
                        dr["Renewal"] = foundrow[0]["Renewal"];
                        dr["PolicyNumber"] = foundrow[0]["PolicyNumber"];
                        dr["ProductTypeDescription"] = foundrow[0]["ProductTypeDescription"];
                        dr["PlanType"] = foundrow[0]["PlanType"];
                        dr["PlanNumber"] = foundrow[0]["PlanType"] + " " + Convert.ToString(PlanNumber);


                        List<Plan> PlanList = Session["PlanList"] as List<Plan>;
                        if (PlanList != null && PlanList.Count() > 0)
                        {
                            Plan SelectedPlan = PlanList.Where(p => p.ProductId == int.Parse(PlanType.SelectedValue)).FirstOrDefault();
                            if (SelectedPlan != null)
                            {
                                dr["UsiProductName"] = SelectedPlan.UsiProductName;
                                foreach (string plantype in CommonFunctionsBS.DictContactsPlanTypes.Keys)
                                {
                                    if (CommonFunctionsBS.DictContactsPlanTypes[plantype].Contains(SelectedPlan.ProductTypeId))
                                    {
                                        dr["contactPlanType"] = plantype;
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        dr["Carrier"] = "";
                        dr["Effective"] = "";
                        dr["Renewal"] = "";
                        dr["PolicyNumber"] = "";
                        dr["ProductTypeDescription"] = "";
                        dr["PlanType"] = "";
                        dr["PlanNumber"] = "";
                    }
                    if (Benefit.SelectedIndex > 0)
                    {
                        dr["SummaryName"] = Benefit.SelectedItem.Text;
                        dr["SummaryId"] = Benefit.SelectedValue;
                    }
                    else
                    {
                        dr["SummaryName"] = "";
                        dr["SummaryId"] = -1;
                    }
                    if (Rate != null && Rate.SelectedIndex > 0)
                    {
                        dr["RateName"] = Rate.SelectedItem.Text;
                        dr["RateId"] = Rate.SelectedValue;
                    }
                    else
                    {
                        dr["RateName"] = "";
                        dr["RateId"] = -1;
                    }
                    if (Contribution != null && Contribution.SelectedIndex > 0)
                    {
                        dr["ContributionName"] = Contribution.SelectedItem.Text;
                        dr["ContributionId"] = Contribution.SelectedValue;
                    }
                    else
                    {
                        dr["ContributionName"] = "";
                        dr["ContributionId"] = -1;
                    }

                    if (Contribution_2 != null && Contribution_2.SelectedIndex > 0)
                    {
                        dr["ContributionName_2"] = Contribution_2.SelectedItem.Text;
                        dr["ContributionId_2"] = Contribution_2.SelectedValue;
                    }
                    else
                    {
                        dr["ContributionName_2"] = "";
                        dr["ContributionId_2"] = -1;
                    }
                    planstable.Rows.Add(dr);
                    Session["PlanTable"] = planstable;
                }
                for (int i = 0; i < planstable.Rows.Count; i++)
                {
                    if (int.Parse(planstable.Rows[i]["SummaryId"].ToString()) == -1)
                    {
                        planstable.Rows[i].Delete();
                    }
                }
                Session["PlanTable"] = planstable;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Create Product Summary Table of selected Plan.
        /// </summary>
        /// <returns> ProductSummaryTable</returns>
        protected DataTable CreateProductSummaryTable()
        {
            DataTable ProductSummaryTable = new DataTable();
            try
            {
                if (Session["ProductSummaryTable"] != null)
                {
                    ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
                }
                else
                {
                    ProductSummaryTable.Columns.Add("ProductId", typeof(Int32));
                    ProductSummaryTable.Columns.Add("ProductName", typeof(string));
                    ProductSummaryTable.Columns.Add("Carrier", typeof(string));
                    ProductSummaryTable.Columns.Add("Effective", typeof(string));
                    ProductSummaryTable.Columns.Add("Renewal", typeof(string));
                    ProductSummaryTable.Columns.Add("PolicyNumber", typeof(string));
                    ProductSummaryTable.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductSummaryTable.Columns.Add("PlanType", typeof(string));
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return ProductSummaryTable;
        }

        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");

                //Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("104");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("109");
                MedicalBenefitColumnIdOutNetworkList.Add("113");

                //Tier 3 medical 
                MedicalBenefitColumnId_Tier3.Add("105");
                MedicalBenefitColumnId_Tier3.Add("110");

                //Outnetwok Dental 
                DentalBenefitColumnIdOutNetworkList.Add("117");

                //Dental      
                DentalBenefitColumnIdList.Add("115");
                DentalBenefitColumnIdList.Add("116");
                DentalBenefitColumnIdList.Add("118");
                DentalBenefitColumnIdList.Add("121");

                //EAP
                EAPBenefitColumnIdList.Add("133");

                //HRA
                HRABenefitColumnIdList.Add("143");

                //FSA
                FSABenefitColumnIdList.Add("135");

                //HSA
                HSABenefitColumnIdList.Add("147");

                //LTD
                LTDBenefitColumnIdList.Add("132");

                //STD
                STDBenefitColumnIdList.Add("131");

                //Vision
                VisionBenefitColumnIdList.Add("123");
                VisionBenefitColumnIdOutNetworkList.Add("124");

                //Voluntary Life & Volunatary AD&D Life
                VoluntaryLifeBenefitColumnIdList.Add("128");
                VoluntaryLifeBenefitColumnIdList.Add("130");

                //Life and AD&D
                LifeADDBenefitColumnIdList.Add("127");
                LifeADDBenefitColumnIdList.Add("140");

                // Group Term Life
                GroupTermLifeBenefitColumnIdList.Add("127");

                // ADD
                ADDBenefitColumnIdList.Add("129");

                // Wellness
                WellnessBenefitColumnIdList.Add("162");
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Create Summary Template1
        /// </summary>
        protected string CreateSummaryTemplate1()
        {

            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            Object missing = System.Reflection.Missing.Value;

            try
            {

                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report1"));
                }

                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example1_v5.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report1/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate1 wt = new WriteTemplate1();
                wt.WriteFieldToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice);
                wt.WriteMedicalSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, ddlMedicalNoOfPlan, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList);
                wt.WritePrescriptionDrugsSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, ProductDS, PlanTable, CarrierSpecific, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, ddlDentalNoOfPlan.SelectedIndex);
                wt.WriteVisionBenefitsSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList);
                wt.WriteGroupLifeADDBenifitToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList);
                wt.WriteSTDSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList);
                wt.WriteLTDSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList);
                wt.WriteVoluntaryLifeADDBenefitToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteFSASectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, PlanTypeSpecific, BenefitDS, FSABenefitColumnIdList);
                wt.WriteHRASectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName);
                wt.WriteHSASectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList);
                wt.WriteEAPSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, RateDS, ContributionDS, PlanTable);
                wt.WriteContactinformationToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.WriteNoticeSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary1" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            return (wobj.Save_File);
        }
        /// <summary>
        /// Create Summary Template2
        /// </summary>
        protected string CreateSummaryTemplate2()
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report2")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report2"));
                }

                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example2_v2.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report2/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();

                WriteTemplate2 wt = new WriteTemplate2();
                wt.WriteFieldToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList);
                wt.WriteMedicalSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, ddlMedicalNoOfPlan.SelectedItem.Text, CarrierSpecific);
                wt.WritePrescriptionDrugsSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, CarrierSpecific, PlanTypeSpecific);
                wt.WriteVisionSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific, VisionBenefitColumnIdOutNetworkList);
                wt.WriteVoluntaryLifeToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteGroupLifeADDBenifitToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteSTDSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlSTDNoOfPlan, ddlLTDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteLTDSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlSTDNoOfPlan, ddlLTDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteEAPSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ContributionDS);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteNoticeSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlAnnualLegalNotice, chkAnualNotice, ddlChipNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);
                wt.WriteContactInformationToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.DeleteDisabilityRow(wobj.office.oWordDoc, wobj.office.oWordApp);
                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary2" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        /// <summary>
        /// Create Summary Template5
        /// </summary>
        protected string CreateSummaryTemplate5()
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report5")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report5"));
                }

                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary-Example5_v1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report5/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();

                WriteTemplate5 wt = new WriteTemplate5();
                wt.WriteFieldToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient.SelectedItem.Text, AccountDS);
                wt.WriteMedicalSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan);
                wt.WriteDentalSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList);
                wt.WriteVisionSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific);
                wt.WriteLifeADDToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific);
                wt.WriteVoluntaryLifeToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteSTDSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, CarrierSpecific);
                wt.WriteLTDSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, CarrierSpecific, ddlSTDNoOfPlan, ddlSTDPlanName1);
                wt.WriteFSASectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, CarrierSpecific);
                wt.WriteEAPSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, CarrierSpecific);
                wt.WritePrescriptionDrugsSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList);
                wt.WriteMonthlyPremiumSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS);
                wt.WritePlanNameToTemplate5(ddlMedicalNoOfPlan.SelectedIndex, ddlDentalNoOfPlan.SelectedIndex, ddlEAPNoOfPlan.SelectedIndex, ddlFSANoOfPlan.SelectedIndex, ddlSTDNoOfPlan.SelectedIndex, ddlLTDNoOfPlan.SelectedIndex, ddlLifeADDNoOfPlan.SelectedIndex, ddlVoluntaryLifeADDNoOfPlan.SelectedIndex, ddlVisionNoOfPlan.SelectedIndex, wobj.office.oWordDoc, wobj.office.oWordApp);
                wt.WriteNoticeSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);
                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary5" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        /// <summary>
        /// Get all the plan for selected client.
        /// </summary>
        private void FindPlans()
        {
            BPBusiness bp = new BPBusiness();
            List<Plan> PlanList = new List<Plan>();
            Session["PlanList"] = null;
            SessionId = Session["SessionId"].ToString();
            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
            Session["PlanList"] = PlanList;
        }

        ///Function for Templeate 3
        ///
        protected string CreateSummaryTemplate3(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
             List<BRC> BRCList = new List<BRC>();
             BRCList = (List<BRC>)Session["BRCList"];
             */

            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];

            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report3")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report3"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example3_v2.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report3/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate3_V2 wt = new WriteTemplate3_V2();

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wt.WriteEligibilityToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//

                ////wt.WriteFieldToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor, null, ddlImageOption);
                wt.WriteFieldToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor, null, ddlImageOption);
                wt.WriteMedicalSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, selectedColor, MedicalBenefitColumnId_Tier3, BenefitStructureDS);
                wt.WritePrescriptionDrugsSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, MedicalBenefitColumnId_Tier3);
                if (ddlDentalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDentalSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, CarrierSpecific, PlanTypeSpecific, selectedColor);
                }
                if (ddlVisionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVisionSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific, selectedColor);
                }
                if (ddlHSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHSASectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList, ddlClient.SelectedItem.Text, ddlHSAPlanName);
                }
                if (ddlHRANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHRASectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList);
                }
                if (ddlFSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteFSASectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, PlanTypeSpecific, BenefitDS, FSABenefitColumnIdList);
                }
                if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLifeADDToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, selectedColor, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                }
                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteSTDSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlSTDPlanName1, selectedColor);
                }
                if (ddlLTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLTDSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlLTDPlanName1, selectedColor);
                }
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVoluntaryLifeToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, selectedColor);
                    wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, selectedColor);
                }
                if (ddlEAPNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteEAPSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                }
                wt.WriteAdditionalProductsToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);
                wt.WriteMonthlyPremiumSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS, selectedColor, BenefitDS);
                DataTable dtPlanContactDetails = new DataTable();
                //dtPlanContactDetails = GetDataTableFromGridView(dvPlanContacts);
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                wt.WriteContactinformationToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, selectedColor, dtPlanContactDetails);
                wt.WriteNoticeSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlMarketplaceCoverage, ddlCreditableCoverage, selectedColor);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary3" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                #region Added by vinod : storing the activity logs
                ////string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                ////if (BRCDataList.Count > 0 && ddlBRC.SelectedItem.Text == "YES")
                ////{
                ////    AdditionalCrtieriaOption_2 = BRCDataList[0].BRCLocation.Trim();
                ////}
                ////string AdditionalCrtieriaOption_3 = ddlSummaryStyle.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_4 = ddlColor.SelectedItem.Text;
                ////DicActivityLog.Clear();
                ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                ////bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion
                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        ///Function for Templeate 4
        ///
        protected string CreateSummaryTemplate4()
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report4")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report4"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example4_v1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report4/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate4 wt = new WriteTemplate4();
                wt.WriteFieldToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, ddlAnnualLegalNotice, ddlChipNotice, ddlImageOption);
                wt.WriteMedicalSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan);
                wt.WritePrescriptionDrugsSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList);
                wt.WriteVisionSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific);
                wt.WriteLifeADDToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific);
                wt.WriteSTDSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlLTDNoOfPlan, ddlClient, ddlSTDPlanName1);
                wt.WriteLTDSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlClient, ddlLTDPlanName1);
                wt.WriteVoluntaryLifeToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS);
                wt.WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ProductDS);
                wt.WriteFSASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, CarrierSpecific);
                wt.WriteHRASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS);
                wt.WriteHSASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList);
                wt.WriteEAPSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, CarrierSpecific);
                wt.WriteContactinformationToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.WriteNoticeSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlBRC, ddlMarketplaceCoverage, ddlCreditableCoverage);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary4" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        ///Function for Templeate 6
        ///
        protected string CreateSummaryTemplate6()
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            string color = ddlColor.SelectedValue.ToString();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report6")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report6"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example6_v1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report6/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate6 wt = new WriteTemplate6();
                wt.WriteFieldToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, color);
                wt.WriteMedicalSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, color);
                wt.WritePrescriptionDrugsSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, color);
                if (ddlDentalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDentalSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, color);
                }
                if (ddlVisionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVisionSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, color);
                }
                //if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                //{
                wt.WriteLifeADDBenifitToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ddlLifeADDNoOfPlan, ddlSTDNoOfPlan, ddlLTDNoOfPlan, color);
                //}
                //if (ddlSTDNoOfPlan.SelectedIndex > 0)
                //{
                wt.WriteSTDSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlLTDNoOfPlan, ddlClient, ddlSTDPlanName1, ddlLifeADDNoOfPlan, ddlSTDNoOfPlan, color);
                //}
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVoluntaryLifeToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, color);
                }
                wt.WriteMonthlyPremiumSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS, color);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, color);
                if (ddlFSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteFSASectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, CarrierSpecific, color);
                }
                if (ddlEAPNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteEAPSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, color);
                }
                wt.WriteContactinformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, color);
                //if (ddlAnnualLegalNotice.SelectedIndex > 0 || ddlChipNotice.SelectedIndex > 0)
                //{
                wt.WriteNoticeSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                //}
                wt.WriteTableOfContentInformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ddlAnnualLegalNotice, ddlChipNotice, ddlBRC, color);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary6" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }


        ///Function for Templeate 6
        ///
        protected string CreateSummaryTemplate6_ValueSummary_V2(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
             List<BRC> BRCList = new List<BRC>();
             BRCList = (List<BRC>)Session["BRCList"];
             */

            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];

            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            string color = ddlColor.SelectedValue.ToString();
            string IncomeProtectionPlan = string.Empty;
            List<string> IncomeProtectionPlanList = new List<string>();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report6")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report6"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example6_ValueSummary_v2.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report6/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate6_ValueSummary_V2 wt = new WriteTemplate6_ValueSummary_V2();
                if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    IncomeProtectionPlanList.Add("Basic Life, Accidental Death and Dismemberment (AD&D) ");
                }
                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    IncomeProtectionPlanList.Add("Short Term Disability");
                }
                if (ddlLTDNoOfPlan.SelectedIndex > 0)
                {
                    IncomeProtectionPlanList.Add(" Long Term Disability");
                }

                IncomeProtectionPlan = String.Join(", ", IncomeProtectionPlanList.ToArray());

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wt.WriteEligibilityToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//


                ////wt.WriteFieldToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, color, IncomeProtectionPlan, ddlImageOption);
                wt.WriteFieldToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, color, IncomeProtectionPlan, ddlImageOption);
                wt.WriteMedicalSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, color);
                wt.WritePrescriptionDrugsSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, color);
                if (ddlDentalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDentalSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, color);
                }
                if (ddlVisionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVisionSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, color);
                }
                if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLifeADDBenifitToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ddlLifeADDNoOfPlan, ddlSTDNoOfPlan, ddlLTDNoOfPlan, color, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                }
                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteSTDSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlLTDNoOfPlan, ddlClient, ddlSTDPlanName1, ddlLifeADDNoOfPlan, ddlSTDNoOfPlan, color);
                }
                if (ddlLTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLTDSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlLTDNoOfPlan, ddlClient, ddlLifeADDNoOfPlan, color);
                }
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVoluntaryLifeToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, color);
                }
                wt.WriteMonthlyPremiumSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS, color);
                ////wt.WriteAdditionalProductsToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);
                wt.WriteAdditionalProductsToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, color);

                if (ddlHSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHSASectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList, ddlClient.SelectedItem.Text, ddlHSAPlanName, color);
                }
                if (ddlHRANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHRASectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, color);
                }

                if (ddlFSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteFSASectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, CarrierSpecific, color);
                }
                if (ddlEAPNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteEAPSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, color);
                }

                if (ddlPlanContacts.SelectedValue == "0")
                {
                    DataTable dtPlanContactDetails = new DataTable();
                    dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                    wt.WriteContactinformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, selectedColor, dtPlanContactDetails);
                }
                objCommFun.DeleteRows_STD_LTD_Life(23, wobj.office.oWordDoc);
                //if (ddlAnnualLegalNotice.SelectedIndex > 0 || ddlChipNotice.SelectedIndex > 0)
                //{
                wt.WriteNoticeSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                //}

                bool isAllPlansSelected = false;
                if (ddlLifeADDPlanName1.SelectedIndex > 0 && ddlLifeADDPlanName2.SelectedIndex > 0 && ddlSTDPlanName1.SelectedIndex > 0 && ddlSTDPlanName2.SelectedIndex > 0 && ddlLTDPlanName1.SelectedIndex > 0 && ddlLTDPlanName2.SelectedIndex > 0)
                {
                    isAllPlansSelected = true;
                }
                ////wt.WriteTableOfContentInformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ddlAnnualLegalNotice, ddlChipNotice, ddlBRC, color, PlanInfoTable, isAllPlansSelected);
                wt.WriteTableOfContentInformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ddlAnnualLegalNotice, ddlChipNotice, BRCDataList, ddlBRCSelectedValue, color, PlanInfoTable, isAllPlansSelected);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary6" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                #region Added by vinod : storing the activity logs
                ////string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                ////if (BRCDataList.Count > 0 && ddlBRC.SelectedItem.Text == "YES")
                ////{
                ////    AdditionalCrtieriaOption_2 = BRCDataList[0].BRCLocation.Trim();
                ////}
                ////string AdditionalCrtieriaOption_3 = ddlSummaryStyle.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_4 = ddlColor.SelectedItem.Text;
                ////DicActivityLog.Clear();
                ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                ////bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Create Summary Template7 Highlights
        /// </summary>
        protected string CreateSummaryTemplate7_Highlights()
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report7")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report7"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_Example7_Highlights.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report7/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate7_Highlights wt = new WriteTemplate7_Highlights();

                wt.WriteFieldToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice);
                wt.WriteMedicalSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, ddlMedicalNoOfPlan, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList);
                wt.WritePrescriptionDrugsSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ProductDS, PlanTable, CarrierSpecific, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList);
                wt.WriteVisionBenefitsSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList);
                wt.WriteLifeADDBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList);
                wt.WriteGroupTermLifeBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList);
                wt.WriteADDBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, ADDBenefitColumnIdList);
                wt.WriteWellnessBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, WellnessBenefitColumnIdList);
                wt.WriteSTDSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList);
                wt.WriteLTDSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList);
                wt.WriteVoluntaryLifeADDBenefitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteFSASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, PlanTypeSpecific, BenefitDS, FSABenefitColumnIdList);
                wt.WriteHRASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList);
                wt.WriteHSASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList, ddlClient.SelectedItem.Text, ddlHSAPlanName);
                wt.WriteEAPSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS);
                wt.WriteNoticeSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary7" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Create Summary Template7 Highlights V2
        /// </summary>
        protected string CreateSummaryTemplate7_Highlights_V2(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
                 List<BRC> BRCList = new List<BRC>();
                 BRCList = (List<BRC>)Session["BRCList"];
            */

            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];

            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report7")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report7"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_Example7_Highlights_V2.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report7/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate7_Highlights_V2 wt = new WriteTemplate7_Highlights_V2();

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wt.WriteEligibilityToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//

                ////wt.WriteFieldToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, selectedColor);
                wt.WriteFieldToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, selectedColor);

                wt.WriteMedicalSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, ddlMedicalNoOfPlan, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, selectedColor);
                wt.WritePrescriptionDrugsSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ProductDS, PlanTable, CarrierSpecific, BenefitDS, MedicalBenefitColumnIdList, selectedColor);
                wt.WriteDentalSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, selectedColor);
                wt.WriteVisionBenefitsSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, selectedColor);
                //wt.WriteLifeADDBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, selectedColor);
                wt.WriteLifeADDToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, selectedColor, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                //wt.WriteGroupTermLifeBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, selectedColor);
                // wt.WriteADDBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, ADDBenefitColumnIdList, selectedColor);
                wt.WriteWellnessBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, WellnessBenefitColumnIdList, selectedColor);
                wt.WriteSTDSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, selectedColor);
                wt.WriteLTDSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, selectedColor);
                wt.WriteVoluntaryLifeADDBenefitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, selectedColor);
                wt.WriteFSASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, PlanTypeSpecific, BenefitDS, FSABenefitColumnIdList, selectedColor);
                wt.WriteHRASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, selectedColor);
                wt.WriteHSASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList, ddlClient.SelectedItem.Text, ddlHSAPlanName, selectedColor);
                wt.WriteEAPSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, selectedColor);
                //wt.WriteMonthlyPremiumSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS, selectedColor);
                wt.WriteMonthlyPremiumSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS, selectedColor, BenefitDS);
                wt.WriteNoticeSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlMarketplaceCoverage, ddlCreditableCoverage, selectedColor);
                ////wt.WriteAdditionalProductsToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);
                wt.WriteAdditionalProductsToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);

                if (ddlPlanContacts.SelectedValue == "0")
                {
                    DataTable dtPlanContactDetails = new DataTable();
                    //dtPlanContactDetails = GetDataTableFromGridView(dvPlanContacts);
                    dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                    wt.WriteContactinformationToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, selectedColor, dtPlanContactDetails);
                }
                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary7" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                #region Added by vinod : storing the activity logs
                ////string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                ////if (BRCDataList.Count > 0)
                ////{
                ////    AdditionalCrtieriaOption_2 = BRCDataList[0].BRCLocation;
                ////}
                ////string AdditionalCrtieriaOption_3 = ddlSummaryStyle.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_4 = ddlColor.SelectedItem.Text;
                ////DicActivityLog.Clear();
                ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                ////bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        ///Function for Templeate 9
        ///
        protected string CreateSummaryTemplate9_EnrollmentGuide(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
             List<BRC> BRCList = new List<BRC>();
             BRCList = (List<BRC>)Session["BRCList"];
            */

            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];

            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report9")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report9"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary-Example9_EnrollmentGuide_V1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report9/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate9_EnrollmentGuide wt = new WriteTemplate9_EnrollmentGuide();

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wt.WriteEligibilityToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//

                ////wt.WriteFieldToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor, null, ddlImageOption);
                wt.WriteFieldToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor, null, ddlImageOption);
                objCommFun.Fill_Shape(wobj.office.oWordDoc, wobj.office.oWordApp, selectedColor);
                wt.WriteMedicalSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, selectedColor, MedicalBenefitColumnId_Tier3, BenefitStructureDS);
                wt.WritePrescriptionDrugsSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, MedicalBenefitColumnId_Tier3);
                wt.WriteMonthlyPremiumSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS, selectedColor, BenefitDS);
                if (ddlDentalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDentalSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, CarrierSpecific, PlanTypeSpecific, DentalBenefitColumnIdOutNetworkList, selectedColor);
                }
                if (ddlVisionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVisionSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific, VisionBenefitColumnIdOutNetworkList, selectedColor);
                }
                if (ddlHSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHSASectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList, ddlClient.SelectedItem.Text, ddlHSAPlanName);
                }
                if (ddlHRANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHRASectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList);
                }
                if (ddlFSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteFSASectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, PlanTypeSpecific, BenefitDS, FSABenefitColumnIdList);
                }
                if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLifeADDToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, selectedColor, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                }
                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteSTDSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlSTDPlanName1, selectedColor);
                }
                if (ddlLTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLTDSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlLTDPlanName1, selectedColor);
                }
                wt.ShowUniqueCarrierNames_STD_LTD(wobj.office.oWordDoc, wobj.office.oWordApp, ProductDS, PlanTable);

                if (ddlEAPNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteEAPSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                }

                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVoluntaryLifeToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, selectedColor);
                    wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, selectedColor);
                }

                DataTable dtPlanContactDetails = new DataTable();
                //dtPlanContactDetails = GetDataTableFromGridView(dvPlanContacts);
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                ////wt.WriteAdditionalProductsToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);
                wt.WriteAdditionalProductsToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);
                wt.WriteContactinformationToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, selectedColor, dtPlanContactDetails);
                objCommFun.DeleteRows_STD_LTD_Life(13, wobj.office.oWordDoc);
                wt.WriteNoticeSectionToTemplate9(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlMarketplaceCoverage, ddlCreditableCoverage, selectedColor);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary9" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                #region Added by vinod : storing the activity logs
                ////string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                ////if (BRCDataList.Count > 0 && ddlBRC.SelectedItem.Text == "YES")
                ////{
                ////    AdditionalCrtieriaOption_2 = BRCDataList[0].BRCLocation.Trim();
                ////}
                ////string AdditionalCrtieriaOption_3 = ddlSummaryStyle.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_4 = ddlColor.SelectedItem.Text;
                ////DicActivityLog.Clear();
                ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                ////bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateSummaryTemplate_BasicBlue(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            WriteTemplate_BasicBlue wr = new WriteTemplate_BasicBlue();
            bool isBRCSelected = false;
            DataTable PlanContactTable = Session["PlanContactTable"] as DataTable;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/BasicBlue")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/BasicBlue"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BasicBlue_Template_V1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/BasicBlue/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();
                List<BRCData> BRCDataList = new List<BRCData>();
                BRCDataList = (List<BRCData>)Session["BRCData"];
                string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();
                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();

                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();


                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }


                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }

                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }

                }

                if (ddlBRC.SelectedValue == "YES")
                    isBRCSelected = true;
                else if (ddlBRC.SelectedValue == "NO")
                    isBRCSelected = false;

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                wr.WriteAccountContact(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ContactList, arrAcctContact);
                wr.WriteMedicalSectionToTemplateBasicBlue_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProducts["Medical"], dictContributionMap, ContributionDS);
                if (dictProducts.ContainsKey("Dental"))
                {
                    wr.WriteDentalSectionToTemplateBasicBlue_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProducts["Dental"], dictContributionMap, ContributionDS);
                }
                if (dictProductMap.ContainsKey("Vision"))
                {
                    wr.WriteVisionSectionToTemplateBasicBlue_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProducts["Vision"], dictContributionMap, ContributionDS);
                }
                if (dictProductMap.ContainsKey("HSA"))
                    wr.WriteHSASectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, HSABenefitColumnIdList, dictProductMap["HSA"]);
                if (dictProductMap.ContainsKey("HRA"))
                    wr.WriteHRASectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, HRABenefitColumnIdList, dictProductMap["HRA"]);
                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteFSASectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, FSABenefitColumnIdList, dictProductMap["FSA"]);
                if (dictProductMap.ContainsKey("Life and AD&D"))
                    wr.WriteLifeADnDSectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"]);
                if (dictProductMap.ContainsKey("Voluntary Life"))
                    wr.WriteVolunteryLifeSectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, VoluntaryLifeBenefitColumnIdList, dictProductMap["Voluntary Life"]);
                if (dictProductMap.ContainsKey("STD"))
                    wr.WriteShortTermDisabilityDSectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, STDBenefitColumnIdList, dictProductMap["STD"]);
                if (dictProductMap.ContainsKey("LTD"))
                    wr.WriteLongTermDisabilityDSectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, LTDBenefitColumnIdList, dictProductMap["LTD"]);
                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, EAPBenefitColumnIdList, dictProductMap["EAP"]);

                wr.WriteAdditionalProductToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanInfoTable);

                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                wr.WriteContactinformationToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, PlanContactTable, CarrierSpecific, selectedColor, isBRCSelected, BRCDataList, ddlBRCSelectedValue, dtPlanContactDetails);
                wr.WriteNoticeSectionToTemplateBasicBlue(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlMarketplaceCoverage, ddlCreditableCoverage, selectedColor);
                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }
                if (ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlCreditableCoverage.SelectedValue == "Not Included" && ddlChipNotice.SelectedValue == "Not Included" && ddlMarketplaceCoverage.SelectedValue == "Not Included")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalChip_Notice_Section_T9");
                }
                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected);
                wr.FillPlanDetails(wobj.office.oWordDoc, wobj.office.oWordApp);

                if (!dictProductMap.ContainsKey("STD") && !dictProductMap.ContainsKey("LTD"))
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "STDMain");
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "STD");
                }
                if (!dictProductMap.ContainsKey("STD"))
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "STD");
                }

                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        protected string CreateSummaryTemplate_SummerHealth(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            string IncomeProtectionPlan = string.Empty;
            List<string> IncomeProtectionPlanList = new List<string>();
            //string color = ddlColor.SelectedValue.ToString();
            bool isBRCSelected = false;
            string color = string.Empty;
            WriteTemplate_SummerHealth wr = new WriteTemplate_SummerHealth();
            if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
            {
                IncomeProtectionPlanList.Add("Basic Life, Accidental Death and Dismemberment (AD&D) ");
            }
            if (ddlSTDNoOfPlan.SelectedIndex > 0)
            {
                IncomeProtectionPlanList.Add("Short Term Disability");
            }
            if (ddlLTDNoOfPlan.SelectedIndex > 0)
            {
                IncomeProtectionPlanList.Add(" Long Term Disability");
            }
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/BasicBlue")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/BasicBlue"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/SummerHealth_Template_V1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/BasicBlue/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();

                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                Dictionary<int, List<int>> lstProductContributionMap = new Dictionary<int, List<int>>();

                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();

                foreach (DataRow dr in PlanTable.Rows)
                {

                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());

                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }

                    //Contribution code
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }

                }

                List<int> ADnDPlans = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> VoluntaryLifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();
                List<int> HRA = new List<int>();
                List<int> HSA = new List<int>();
                List<int> EAP = new List<int>();

                //Voluntary Life
                List<int> VoluntaryLife = new List<int>();
                List<int> VoluntaryADnD = new List<int>();

                //STD and LTD
                List<int> LTD = new List<int>();
                List<int> STD = new List<int>();
                List<int> VoluntarySTD = new List<int>();
                List<int> VoluntaryLTD = new List<int>();

                //Wellness
                List<int> Wellness = new List<int>();
                foreach (DataRow row in PlanTable.Rows)
                {
                    if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));

                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        ADnDPlans.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        VoluntaryLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower())
                    {
                        VoluntaryADnD.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntarySTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            STD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            LTD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.EAPPlanType_CommonCriteria.ToLower()) // _HRAPlanType_CC
                    {
                        EAP.Add(Convert.ToInt32(row["productID"]));
                    }
                }

                if (ddlBRC.SelectedValue == "YES")
                    isBRCSelected = true;
                else if (ddlBRC.SelectedValue == "NO")
                    isBRCSelected = false;

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToSummarHealth(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (dictProductMap.ContainsKey("Medical"))
                {
                    wr.WriteMedicalSectionToTemplateSummerHealth_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProducts["Medical"], dictContributionMap, ContributionDS);
                }

                if (dictProductMap.ContainsKey("Dental"))
                {
                    wr.WriteDentalSectionToTemplateSummerHealth_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProducts["Dental"], dictContributionMap, ContributionDS);
                }
                DataTable dtblPlanContact = Session["PlanContactTable"] as DataTable;
                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                wr.WriteContactinformationToTemplateSummmerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, dtblPlanContact, CarrierSpecific, selectedColor, AccountDS, ContactList, isBRCSelected, BRCDataList, ddlClient.SelectedItem.Text, dtPlanContactDetails);

                if (dictProductMap.ContainsKey("Vision"))
                {
                    wr.WriteVisionSectionToTemplateSummerHealth_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProducts["Vision"], dictContributionMap, ContributionDS);
                }

                if (LifeAndADnDPlans.Count() > 0)
                {
                    wr.WriteLifeADDTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans);
                }
                if (GroupTermLife.Count() > 0)
                {
                    wr.WriteGroupLifeADDTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                }
                //else
                //{
                //    string bookmark = "Group_term_life_ins_Bookmark";
                //    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                //}
                if (ADnDPlans.Count() > 0)
                {
                    wr.WriteADDandDInsuranceTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADnDPlans);
                }
                //else
                //{
                //    string bookmark = "ADD_and_D_Bookmark";
                //    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                //}

                wr.WriteVoluntaryLifeADDandDSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, VoluntaryLifeAndADnDPlans, VoluntaryLife, VoluntaryADnD);

                if (STD.Count > 0)
                {
                    wr.WriteShortTermDisabilityDSectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], STD);
                }
                //else
                //{
                //    string bookmark = "STD";
                //    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                //}

                if (VoluntarySTD.Count > 0)
                {
                    wr.WriteVoluntaryShortTermDisabilitySectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], VoluntarySTD);
                }
                //else
                //{
                //    string bookmark = "VolSTDInsurance";
                //    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                //}

                if (LTD.Count > 0)
                {
                    wr.WriteLongTermDisabilityDSectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], LTD);
                }
                //else
                //{
                //    string bookmark = "LTD";
                //    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                //}
                if (VoluntaryLTD.Count > 0)
                {
                    wr.WriteVoluntoryLongTermDisabilityDSectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], VoluntaryLTD);
                }
                //else
                //{
                //    string bookmark = "VolLTDInsurance";
                //    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                //}

                //if (VoluntarySTD.Count == 0 && VoluntaryLTD.Count == 0)
                //{
                //    string bookmark = "VoluntaryDisability";
                //    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                //}
                if (dictProductMap.ContainsKey("HSA"))
                    wr.WriteHSASectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, HSABenefitColumnIdList, dictProductMap["HSA"]);

                if (dictProductMap.ContainsKey("HRA"))
                    wr.WriteHRASectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, dictProductMap["HRA"]);

                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteFSASectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);

                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, dictProductMap["EAP"]);

                wr.WriteAdditionalProductsToTemplateSummmerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, selectedColor);
                wr.WriteChangesInBenefitElectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS);

                wr.WriteHeaderandIndexSectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, AccountTeamMemberDS, ProductDS, dictProductMap["Medical"], ContactList, arrAcctContact);

                wr.WriteNoticeSectionToTemplateSummerHealth(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalChip_Notice_Section_T9");
                }

                if (ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlCreditableCoverage.SelectedValue == "Not Included" && ddlChipNotice.SelectedValue == "Not Included" && ddlMarketplaceCoverage.SelectedValue == "Not Included")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "commanLegalNotice");
                }

                if (GroupTermLife.Count() == 0)
                {
                    string bookmark = "Group_term_life_ins_Bookmark";
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                }
                if (ADnDPlans.Count() == 0)
                {
                    string bookmark = "ADD_and_D_Bookmark";
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                }
                if (STD.Count == 0)
                {
                    string bookmark = "STD";
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                }

                if (VoluntarySTD.Count == 0)
                {
                    string bookmark = "VolSTDInsurance";
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                }

                if (LTD.Count == 0)
                {
                    string bookmark = "LTD";
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                }

                if (VoluntaryLTD.Count == 0)
                {
                    string bookmark = "VolLTDInsurance";
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                }

                if (VoluntarySTD.Count == 0 && VoluntaryLTD.Count == 0)
                {
                    string bookmark = "VoluntaryDisability";
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, bookmark);
                }

                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, true);
                wobj.office.oWordDoc.TablesOfContents[1].Update(); /***** update table of index ************/

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Create Tools 1 - 5500 Worksheet
        /// </summary>
        protected string CreateTools1_5500_Worksheet_V2(int SubjectID, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, string SessionId)
        {
            DataTable PlanTable = new DataTable();
            PlanTable = BindPlanTable(PlanInfoTable);
            DataTable Office = (DataTable)Session["OffieceTable"];
            Object missing = System.Reflection.Missing.Value;

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();
            DataSet ActivityDS = new DataSet();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/Report1"));
                }
                string filename = "~/Files/Tools/Documents/Templates/Tools_1.docm";
                string _savefilename = "~/Files/Tools/Documents/Templates/Report1/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                WriteTools1 wt = new WriteTools1();
                ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                ActivityDS = timeD.Get_Activity_Detail(Convert.ToInt32(ddlActivity.SelectedItem.Value), SessionId);

                DataTable dtPlanContactDetails = new DataTable();
                //if (ddlPlanContacts.SelectedValue == "0")
                //{
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                //}
                wt.WriteFieldToTools1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient, ActivityDS, ActivityInfoTable, AccountDS, PlanInfoTable, AccountTeamMemberDS, SessionId, dtPlanContactDetails);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanTools1" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                #region Added by vinod : storing the activity logs
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                string AdditionalCrtieriaOption_1 = ddlActivity.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlHSASelection.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlMobileSelection.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddllanguage.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }


        /// <summary>
        /// Create Summary Template 2
        /// </summary>
        protected void CreateReports2_RenewalStatusReport(int SubjectID, string SessionId)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;

            try
            {
                ArrayList arrCheckedOffice = new ArrayList();
                // Create ararylist of selected check box from office checkboxlist
                for (int i = 0; i < cblistOffice.Items.Count; i++)
                {
                    if (cblistOffice.Items[i].Selected == true)
                    {
                        arrCheckedOffice.Add(cblistOffice.Items[i].Text);
                    }
                }

                SessionId = Session["SessionId"].ToString();
                List<Account> filteredAccountList = new List<Account>();
                DateTime _fromdate = new DateTime();
                DateTime _todate = new DateTime();
                DateTime.TryParse(txtDateFrom.Text, out _fromdate);
                DateTime.TryParse(txtDateTo.Text, out _todate);

                if (_todate < _fromdate)
                {
                    string script = "alert(\"'Create Date To' should be greater than 'Create Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    return;
                }

                string dateType = ddlDateType.SelectedItem.Value;
                filteredAccountList = bp.FindFilteredClientListForReportsTab(SessionId, arrCheckedOffice, Convert.ToInt32(ddlProducerTeam.SelectedItem.Value), _fromdate, _todate, dateType);

                myExcelApp = new Excel.Application();

                myExcelApp.Visible = false;

                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Reports/Documents/Templates/Reports2_Renewal Status Report.xlsx");

                myExcelApp.DisplayAlerts = false;

                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Reports/Documents/Templates/Report2/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Reports/Documents/Templates/Report2")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Reports/Documents/Templates/Report2"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                RenewalStatusReport_V2 wr = new RenewalStatusReport_V2();
                wr.WriteFieldToReports2(myWorksheet, SubjectID, SessionId, cblistOffice, ddlProducerTeam, _fromdate, _todate, filteredAccountList, ddlDateType);

                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_Excel(savefilename.ToString());

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office);

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }

        ///Function for PowerPoint 1
        ///
        [STAThread]
        protected string CreateSummaryPowerPoint1()
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example1_v1.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report1/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report1")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report1"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint1 wt = new WritePowerPoint1();
                    wt.WriteFieldToPowerPointTemplate1(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteMedicalSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHSAToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.UpdateOtherPlansToPowerPointTemplate1(objPres, objPresSet, ddlDentalNoOfPlan, ddlVisionNoOfPlan, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlLTDNoOfPlan, ddlSTDNoOfPlan, ddlEAPNoOfPlan, ddlFSANoOfPlan, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate1(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateSummaryPowerPoint1();
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        ///Function for PowerPoint 2
        ///
        [STAThread]
        protected string CreateSummaryPowerPoint2()
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example2_v1.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;
            WritePowerPoint2 wt = new WritePowerPoint2();
            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report2/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report2")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report2"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    wt.WriteFieldToPowerPointTemplate2(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteMedicalSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlSTDNoOfPlan);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlLTDNoOfPlan, ddlLTDPlanName1);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHSAToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.UpdateOtherPlansToPowerPointTemplate2(objPres, objPresSet, ddlDentalNoOfPlan, ddlVisionNoOfPlan, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlLTDNoOfPlan, ddlSTDNoOfPlan, ddlEAPNoOfPlan, ddlFSANoOfPlan, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                    Response.Redirect("~/view/ErrorNotification.aspx");
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }

            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        ///Function for PowerPoint 3
        ///
        [STAThread]
        protected string CreateSummaryPowerPoint3()
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example3_v1.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;
            WritePowerPoint3 wt = new WritePowerPoint3();

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report3/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report3")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report3"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    wt.WriteFieldToPowerPointTemplate3(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteMedicalSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlSTDNoOfPlan);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlLTDNoOfPlan, ddlLTDPlanName1);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHSAToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }

                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.UpdateOtherPlansToPowerPointTemplate3(objPres, objPresSet, ddlDentalNoOfPlan, ddlVisionNoOfPlan, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlLTDNoOfPlan, ddlSTDNoOfPlan, ddlEAPNoOfPlan, ddlFSANoOfPlan, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate3(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                    Response.Redirect("~/view/ErrorNotification.aspx");
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }

            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion

        /// <summary>
        ///  Function For PowerPoint 4
        [STAThread]
        protected string CreateSummaryPowerPoint4_ColorfulDots(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];

            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
              List<BRC> BRCList = new List<BRC>();
              BRCList = (List<BRC>)Session["BRCList"];
            */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example4_v1_Colorful Dots.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint4_ColorfulDots wt = new WritePowerPoint4_ColorfulDots();
                    ////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)  // Commented as per new PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region exiting code commented for spanish videos

                    ///////*-------------------------------CODE ADDED BY AMOGH FOR ADDITIONAL PPT DEVELOPMENT------------------------ */
                    //////wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////////Added by Vaibhav for new request on 31st May 2018
                    //////wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);

                    //////// Commented by Vaibhav for new request on 31st May 2018
                    ////////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////////{
                    ////////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////////}
                    //////wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange);

                    #endregion

                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();


                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod
                        CreateSummaryPowerPoint4_ColorfulDots(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        /// <summary>
        ///  Function For PowerPoint 5
        [STAThread]
        protected string CreateSummaryPowerPoint5_GreenHealthy(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
              List<BRC> BRCList = new List<BRC>();
              BRCList = (List<BRC>)Session["BRCList"];
            */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example5_v1_GreenHealthy.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report5/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report5")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report5"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint5_GreenHealthy wt = new WritePowerPoint5_GreenHealthy();

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    ////wt.WriteFieldToPowerPointTemplate5(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate5(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)  // commnented as per New PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate5(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate5(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate5(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    #region commented by vinod for english and spanish videos

                    //wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);

                    /*-------------------------------CODE ADDED BY AMOGH */
                    //wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////Added by Vaibhav for new request on 31st May 2018
                    //wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////Commented by Vaibhav for new request on 31st May 2018
                    ////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////{
                    ////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////}
                    ////Short Term/Long Term Disability
                    //wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    #region Added By Vinod :English and Spanish Videos  // Commented by shravan

                    /*   // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    //Added by Vaibhav for new request on 31st May 2018
                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    //Commented by Vaibhav for new request on 31st May 2018
                    //if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    //{
                    //    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    //}
                    //Short Term/Long Term Disability
                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                   // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                  //  wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                   // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
*/
                    #endregion

                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region Added by Shravan : For English and spanish videos

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);
                    }

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate5(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }
                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate5(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint5_GreenHealthy();
                        CreateSummaryPowerPoint5_GreenHealthy(AccountDS, AccountTeamMemberDS);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        /// <summary>
        ///  Function For PowerPoint 7
        [STAThread]
        protected string CreateSummaryPowerPoint6_ColoBlocks_PPT(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
              List<BRC> BRCList = new List<BRC>();
              BRCList = (List<BRC>)Session["BRCList"];
            */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example6_v1_Color Blocks.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report6/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report6")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report6"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    //WritePowerPoint5_GreenHealthy wt = new WritePowerPoint5_GreenHealthy();
                    WritePowerPoint6_ColorBlocks wt = new WritePowerPoint6_ColorBlocks();

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    ////wt.WriteFieldToPowerPointTemplate6(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate6(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)   // Commented as per New PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate6(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate5(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate6(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate6(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }

                    #region Code added by amogh
                    //  /*-------------------------------CODE ADDED BY AMOGH------------------------ */
                    //  wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    //  wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    /////  wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    /////  wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    //  //Added by Vaibhav for new request on 31st May 2018
                    //  wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    //  //Commented by Vaibhav for new request on 31st May 2018
                    //  //if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    //  //{
                    //  //    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    //  //}
                    //  wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    /////  wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // /// wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    //  wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    #endregion

                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region Code added by shravan
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);
                    }


                    wt.UpdateOtherPlansToPowerPointTemplate6(objPres, objPresSet, ddlDentalNoOfPlan, ddlVisionNoOfPlan, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlLTDNoOfPlan, ddlSTDNoOfPlan, ddlEAPNoOfPlan, ddlFSANoOfPlan, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate5(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint6_ColoBlocks_PPT();
                        #region  Added by vinod
                        CreateSummaryPowerPoint6_ColoBlocks_PPT(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            Clear(true);
        }

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                List<Plan> PlanList = new List<Plan>();
                List<Plan> commonPlanList = new List<Plan>();
                Session["PlanList"] = null;
                SessionId = Session["SessionId"].ToString();
                objCommFun.LoadPlanTypeIds();

                // Get all the ProductTypeId's in one variable to show only those plans which are present under these ProductTypeId's
                List<int> plansProductTypeIds = new List<int>();

                // Maintain the order as given below 
                //•	Medical
                //•	Dental
                //•	Vision
                //•	HSA
                //•	HRA
                //•	FSA
                //•	Life and AD&D
                //•	Voluntary Life/AD&D  (was Voluntary Life)
                //•	Short Term Disability  (was STD)
                //•	Long Term Disability  (was LTD)
                //•	EAP
                plansProductTypeIds.Clear();
                plansProductTypeIds.AddRange(CommonFunctionsBS.MedicalPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.DentalPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.VisionPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.HSAPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.HRAPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.FSAPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.LifeADDPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.VoluntaryLifeADDPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.STDPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.LTDPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.EAPPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.WellnessPlanTypeList);
                plansProductTypeIds.AddRange(CommonFunctionsBS.AdditionalProductsPlanTypeList);

                if (ddlClient.SelectedIndex > 0)
                {
                    PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId, "EnrollmentSummary");
                }
                Session["PlanList"] = PlanList;

                if (PlanList != null)
                {
                    if (PlanList.Count > 0)
                    {
                        if (rdlPlan.SelectedIndex == 0)
                        {
                            foreach (Plan item in PlanList)
                            {
                                if (plansProductTypeIds.Contains(item.ProductTypeId))
                                {
                                    if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                    {
                                        commonPlanList.Add(item);
                                    }
                                }
                            }
                        }
                        if (rdlPlan.SelectedIndex == 1)
                        {
                            foreach (Plan item in PlanList)
                            {
                                if (plansProductTypeIds.Contains(item.ProductTypeId))
                                {
                                    commonPlanList.Add(item);
                                }
                            }
                        }

                        List<Plan> lstPlanList = new List<Plan>();

                        //lstPlanList = (from l in commonPlanList
                        //               orderby l.ProductTypeId, l.CarrierName ascending
                        //               select l).ToList();

                        foreach (int item in plansProductTypeIds)
                        {
                            foreach (var planItem in commonPlanList)
                            {
                                if (planItem.ProductTypeId == item)
                                {
                                    lstPlanList.Add(planItem);
                                }
                            }
                        }

                        grdPlans.DataSource = lstPlanList;
                        grdPlans.DataBind();

                        if (commonPlanList.Count > 0)
                        {
                            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                            ChkBoxHeader.Checked = true;
                            foreach (GridViewRow row in grdPlans.Rows)
                            {
                                System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                                ChkBoxRows.Checked = true;
                            }
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }
                        else
                        {
                            string script = "alert(\"No active plans.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        private DataTable GetPlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));

                        if (chkItemSelect.Checked == true)
                        {
                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }

                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For ProductTypeId
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                            }

                            rowCount++;
                        }
                        else
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));                 //Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));               // Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));             // Plan Type ID
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        //Hashtable htPlanNames = new Hashtable();
        List<string> lstPlanNames = new List<string>();
        List<Eligibility> lstEligibilityNames = new List<Eligibility>();

        protected void btnNext_Click(object sender, EventArgs e)
        {
            List<Eligibility> EligibilityList = new List<Eligibility>();
            Eligibility eligibilityItem = new Eligibility();
            string _PlanName = string.Empty;
            string selected_Value = string.Empty;

            try
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;

                PlanInfoTable = GetPlanInfoTable();
                Session["PlanInfoTable"] = PlanInfoTable;
                if (Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain" || Session["Summary"].ToString() == "PowerPoint_SpringField")
                {
                    if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0 || ddlSummaryStyle.SelectedIndex == 0 || ddlBRC.SelectedIndex == 0)
                    {
                        if (grdPlans.Rows.Count > 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }

                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "Validate", "<script>Validate();</script>", false);
                        return;
                    }
                }
                else if (Session["Summary"].ToString() == "Tools1_5500_Worksheet")
                {
                    if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0 || ddlActivity.SelectedIndex == 0 || string.IsNullOrEmpty(ddlActivity.SelectedValue))
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "Validate", "<script>Validate();</script>", false);
                        if (grdPlans.Rows.Count > 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }
                        return;
                    }
                }
                else
                {
                    if (ddlOffice.SelectedIndex == 0 || ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0 || ddlSummaryStyle.SelectedIndex == 0 || ddlBRC.SelectedIndex == 0 || ddlHRContact.SelectedIndex == 0)
                    {
                        if (grdPlans.Rows.Count > 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }

                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "Validate", "<script>Validate();</script>", false);
                        return;
                    }
                }
                // ActiveViewIndex == 0 ----- General Screen
                // ActiveViewIndex == 1 ----- Plan Detail Screen
                // ActiveViewIndex == 2 ----- Plan Contact Detail Screen
                // ActiveViewIndex == 3 ----- Legal Notices Section Screen

                if (PlanInfoTable != null)
                {
                    if (PlanInfoTable.Rows.Count > 0)
                    {
                        if (mvBenefitSummary.ActiveViewIndex == 0)
                        {
                            lblPlanContactMessage.Text = "";
                            if (Session["Summary"].ToString() == "Tools1_5500_Worksheet")
                            {
                                mvBenefitSummary.ActiveViewIndex = 2;
                                btnPrevious.Visible = true;
                                btnNext.Visible = false;
                                btnSummary.Visible = true;
                                ddlPlanContacts.SelectedValue = "1";
                                dvPlanContacts.DataSource = null;
                                dvPlanContacts.DataBind();
                            }
                            else
                            {
                                mvBenefitSummary.ActiveViewIndex = 1;
                                btnPrevious.Visible = true;
                                btnNext.Visible = true;
                                btnSummary.Visible = false;

                                MedicalPlansSelected();
                                DentalPlanSelected();
                                VisionPlanSelected();
                                LifeADDPlanSelected();
                                STDPlanSelected();
                                LTDPlanSelected();
                                VoluntariLifeADDPlanSelected();
                                FSAPlanSelected();
                                HSAPlanSelected();
                                HRAPlanSelected();
                                EAPPlanSelected();
                            }

                            pnlWidthToDisplay.Visible = true;
                            bool isAdditionalProduct = false;

                            //LoadPlanTypeIds();

                            foreach (DataRow dr in PlanInfoTable.Rows)
                            {
                                isAdditionalProduct = false;
                                for (int j = 0; j < CommonFunctionsBS.AdditionalProductsPlanTypeList.Count; j++)
                                {
                                    if (Convert.ToInt32(dr["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.AdditionalProductsPlanTypeList[j]))
                                    {
                                        isAdditionalProduct = true;
                                    }
                                }

                                if (isAdditionalProduct == false)
                                {
                                    // Get the plan names for the seleted PlanTypeId
                                    _PlanName = GetPlanName(Convert.ToInt16(dr["ProductTypeId"]));

                                    if (!lstPlanNames.Contains(_PlanName) && _PlanName != "" && _PlanName != cv.Wellness)
                                    {
                                        lstPlanNames.Add(_PlanName);
                                    }

                                    // Check if the selected plan is Medical, Dental or Vision
                                    // Because Eligibility is applicable only for Medical, Dental or Vision plans
                                    if (Check_PlanIs_Medical_Dental_Vision(Convert.ToInt16(dr["ProductTypeId"])))
                                    {
                                        EligibilityList = bp.FindEligibility(Convert.ToInt32(dr["ProductId"]), Session["SessionId"].ToString());

                                        foreach (var item in EligibilityList)
                                        {
                                            eligibilityItem = new Eligibility();
                                            eligibilityItem.EligibilityId = item.EligibilityId;
                                            eligibilityItem.EligibilityDescription = Convert.ToString(dr["Name"]) + " - " + Convert.ToString(dr["PolicyNumber"]) + " - " + item.EligibilityDescription;

                                            if (!lstEligibilityNames.Equals(eligibilityItem.EligibilityDescription))
                                            {
                                                lstEligibilityNames.Add(eligibilityItem);
                                            }
                                        }
                                    }
                                }
                            }

                            dlPlan.DataSource = lstPlanNames;
                            dlPlan.DataBind();
                            if (ddlEligibility != null)
                            {
                                selected_Value = Convert.ToString(ddlEligibility.SelectedValue);
                            }
                            ddlEligibility.DataSource = lstEligibilityNames;
                            ddlEligibility.DataBind();
                            ddlEligibility.Items.Insert(0, new ListItem("Select", string.Empty));
                            if (ddlEligibility != null)
                            {
                                ddlEligibility.SelectedIndex = ddlEligibility.Items.IndexOf(ddlEligibility.Items.FindByValue(selected_Value));
                            }
                        }

                        else if (mvBenefitSummary.ActiveViewIndex == 1)
                        {
                            Session["PlanTable"] = null;
                            CreatePlanTable();
                            bool flag = true;
                            DataTable PlanTable = new DataTable();
                            PlanTable = (DataTable)Session["PlanTable"];
                            DataTable PlansTable = PlanTable;

                            if (MedicalValidation() && HRAValidation() && HSAValidation() && DentalValidation() && VisionValidation() && LifeADnDValidation() && VoluntaryLifeADnDValidation() && STDValidation() && LTDValidation() && EAPValidation() && FSAValidation() && STDRatesValidation() && LTDRatesValidation())
                            {
                                // Check for if the dropdown list contains duplicate selection or not
                                for (int i = 0; i < PlanTable.Rows.Count; i++)
                                {
                                    if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.MedicalLOC || Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.DentalLOC || Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.VisionLOC)
                                    {
                                        if (int.Parse(PlansTable.Rows[i]["ContributionId"].ToString()) == int.Parse(PlansTable.Rows[i]["ContributionId_2"].ToString()))
                                        {
                                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('There is Duplicate Contribution for " + PlanTable.Rows[i]["ProductName"].ToString() + " Plan. Please Select different Contribution.')</script>", false);
                                            Session["PlanTable"] = null;

                                            if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.MedicalLOC)
                                            {
                                                pnlMedical.Visible = true;
                                            }
                                            else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.DentalLOC)
                                            {
                                                pnlDental.Visible = true;
                                            }
                                            else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.VisionLOC)
                                            {
                                                pnlVision.Visible = true;
                                            }
                                            flag = false;
                                            break;
                                        }
                                    }
                                    for (int j = 0; j < PlanTable.Rows.Count; j++)
                                    {
                                        if (i == j)
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.VoluntaryLifeADDLOC)
                                            {
                                                if (int.Parse(PlansTable.Rows[i]["ProductId"].ToString()) == int.Parse(PlansTable.Rows[j]["ProductId"].ToString()) && int.Parse(PlansTable.Rows[i]["SummaryId"].ToString()) == int.Parse(PlansTable.Rows[j]["SummaryId"].ToString()) && int.Parse(PlansTable.Rows[i]["RateId"].ToString()) == int.Parse(PlansTable.Rows[j]["RateId"].ToString()))
                                                {
                                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('There is Duplicate " + PlanTable.Rows[i]["PlanType"].ToString() + " Plan. Please Select different " + PlanTable.Rows[i]["PlanType"].ToString() + " Plan.')</script>", false);
                                                    Session["PlanTable"] = null;
                                                    pnlVoluntaryLife.Visible = true;
                                                }
                                            }
                                            else if (int.Parse(PlansTable.Rows[i]["ProductId"].ToString()) == int.Parse(PlansTable.Rows[j]["ProductId"].ToString()) && int.Parse(PlansTable.Rows[i]["SummaryId"].ToString()) == int.Parse(PlansTable.Rows[j]["SummaryId"].ToString()) && int.Parse(PlansTable.Rows[i]["ContributionId"].ToString()) == int.Parse(PlansTable.Rows[j]["ContributionId"].ToString()) && int.Parse(PlansTable.Rows[i]["ContributionId_2"].ToString()) == int.Parse(PlansTable.Rows[j]["ContributionId_2"].ToString()))
                                            {
                                                if (int.Parse(PlansTable.Rows[i]["ContributionId"].ToString()) == int.Parse(PlansTable.Rows[i]["ContributionId_2"].ToString()))
                                                { }
                                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('There is Duplicate " + PlanTable.Rows[i]["PlanType"].ToString() + " Plan. Please Select different " + PlanTable.Rows[i]["PlanType"].ToString() + " Plan.')</script>", false);
                                                Session["PlanTable"] = null;

                                                if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.MedicalLOC)
                                                {
                                                    pnlMedical.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.DentalLOC)
                                                {
                                                    pnlDental.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.VisionLOC)
                                                {
                                                    pnlVision.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.LifeADDLOC)
                                                {
                                                    pnlLifeADND.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.LTDPlanType_CommonCriteria)
                                                {
                                                    pnlLTD.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.STDPlanType_CommonCriteria)
                                                {
                                                    pnlSTD.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.VoluntaryLifeADDLOC)
                                                {
                                                    pnlVoluntaryLife.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.HSAPlanType_CommonCriteria)
                                                {
                                                    pnlHSA.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.HRAPlanType_CommonCriteria)
                                                {
                                                    pnlHRA.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.FSAPlanType_CommonCriteria)
                                                {
                                                    pnlFSA.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTable.Rows[i]["PlanType"]) == cv.EAPPlanType_CommonCriteria)
                                                {
                                                    pnlEAP.Visible = true;
                                                }

                                                flag = false;
                                            }
                                        }
                                    }
                                }

                                if (!(Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain" || Session["Summary"].ToString() == "PowerPoint_SpringField"))
                                {
                                    if (flag == true)
                                    {
                                        lblPlanContactMessage.Text = "";
                                        //mvBenefitSummary.ActiveViewIndex = 2;
                                        //viewPPTVideos.Visible = false;
                                        mvBenefitSummary.ActiveViewIndex = 3;
                                        if (Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain" || Session["Summary"].ToString() == "PowerPoint_SpringField")
                                        {
                                            btnPrevious.Visible = true;
                                            btnSummary.Visible = true;
                                            btnNext.Visible = false;
                                        }
                                        else
                                        {
                                            btnPrevious.Visible = true;
                                            btnSummary.Visible = false;
                                            btnNext.Visible = true;
                                        }
                                        //BindPlanContactGrid();
                                        ddlPlanContacts.SelectedIndex = 1;
                                        dvPlanContacts.DataSource = null;
                                        dvPlanContacts.DataBind();
                                    }
                                }
                                //Added by Sanchari for PPT Video change
                                else if (Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain" || Session["Summary"].ToString() == "PowerPoint_SpringField")
                                {
                                    btnPrevious.Visible = true;
                                    btnSummary.Visible = false;
                                    btnNext.Visible = true;
                                    mvBenefitSummary.ActiveViewIndex = 2;
                                }
                                else
                                {
                                    btnPrevious.Visible = true;
                                    btnSummary.Visible = false;
                                }
                                //mvBenefitSummary.ActiveViewIndex = 2;
                            }
                        }
                        else if (mvBenefitSummary.ActiveViewIndex == 2)
                        {
                            //if (flag == true)
                            //{
                            lblPlanContactMessage.Text = "";
                            //mvBenefitSummary.ActiveViewIndex = 2;

                            if (Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain" || Session["Summary"].ToString() == "PowerPoint_SpringField")
                            {
                                btnPrevious.Visible = true;
                                btnSummary.Visible = true;
                                btnNext.Visible = false;
                            }
                            else
                            {
                                btnPrevious.Visible = true;
                                btnSummary.Visible = false;
                            }
                            //BindPlanContactGrid();
                            ddlPlanContacts.SelectedIndex = 1;
                            dvPlanContacts.DataSource = null;
                            dvPlanContacts.DataBind();
                            //}
                            mvBenefitSummary.ActiveViewIndex = 3;
                            btnNext.Visible = false;
                            btnSummary.Visible = true;
                        }
                        else if (mvBenefitSummary.ActiveViewIndex == 3)
                        {
                            mvBenefitSummary.ActiveViewIndex = 4;
                            btnNext.Visible = false;
                            btnSummary.Visible = true;
                            btnPrevious.Visible = true;
                        }
                    }
                    else
                    {
                        if (grdPlans.Rows.Count > 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private bool MedicalValidation()
        {
            if (ddlMedicalNoOfPlan.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Number Of Medical Plan.')</script>", false);
                ddlMedicalNoOfPlan.Focus();
                pnlMedical.Visible = true;
                return false;
            }

            if (ddlMedicalNoOfPlan.SelectedIndex == 1 || ddlMedicalNoOfPlan.SelectedIndex == 2 || ddlMedicalNoOfPlan.SelectedIndex == 3 || ddlMedicalNoOfPlan.SelectedIndex == 4 || ddlMedicalNoOfPlan.SelectedIndex == 5 || ddlMedicalNoOfPlan.SelectedIndex == 6)
            {
                // For Medical Plan 1
                if (ddlMedicalPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName1.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlMedicalBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary1.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    if (ddlMedicalContribution1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                        ddlMedicalContribution1.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }
                }

                // For Medical Plan 2
                if (ddlMedicalPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName2.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlMedicalBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary2.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    if (ddlMedicalContribution2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                        ddlMedicalContribution2.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }
                }

                // For Medical Plan 3
                if (ddlMedicalPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName3.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlMedicalBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary3.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    if (ddlMedicalContribution3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                        ddlMedicalContribution3.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }
                }

                // For Medical Plan 4
                if (ddlMedicalPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName4.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlMedicalBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary4.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    if (ddlMedicalContribution4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                        ddlMedicalContribution4.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }
                }

                // For Medical Plan 5
                if (ddlMedicalPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName5.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlMedicalBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary5.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    if (ddlMedicalContribution5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                        ddlMedicalContribution5.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }
                }

                // For Medical Plan 6
                if (ddlMedicalPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName6.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlMedicalBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary6.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    if (ddlMedicalContribution6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                        ddlMedicalContribution6.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool DentalValidation()
        {
            if (ddlDentalNoOfPlan.SelectedIndex == 1 || ddlDentalNoOfPlan.SelectedIndex == 2 || ddlDentalNoOfPlan.SelectedIndex == 3 || ddlDentalNoOfPlan.SelectedIndex == 4)
            {
                // For Dental Plan 1
                if (ddlDentalPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName1.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary1.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }

                    if (ddlDentalContribution1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                        ddlDentalContribution1.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                }

                // For Dental Plan 2
                if (ddlDentalPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName2.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary2.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }

                    if (ddlDentalContribution2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                        ddlDentalContribution2.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                }

                // For Dental Plan 3
                if (ddlDentalPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName3.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary3.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }

                    if (ddlDentalContribution3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                        ddlDentalContribution3.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                }

                // For Dental Plan 4
                if (ddlDentalPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName4.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary4.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }

                    if (ddlDentalContribution4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                        ddlDentalContribution4.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool VisionValidation()
        {
            if (ddlVisionNoOfPlan.SelectedIndex == 1 || ddlVisionNoOfPlan.SelectedIndex == 2 || ddlVisionNoOfPlan.SelectedIndex == 3 || ddlVisionNoOfPlan.SelectedIndex == 4)
            {
                // For Vision Plan 1
                if (ddlVisionPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName1.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary1.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }

                    if (ddlVisionContribution1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                        ddlVisionContribution1.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                }

                // For Vision Plan 2
                if (ddlVisionPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName2.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary2.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }

                    if (ddlVisionContribution2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                        ddlVisionContribution2.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                }

                // For Vision Plan 3
                if (ddlVisionPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName3.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary3.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }

                    if (ddlVisionContribution3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                        ddlVisionContribution3.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                }

                // For Vision Plan 4
                if (ddlVisionPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName4.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary4.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }

                    if (ddlVisionContribution4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                        ddlVisionContribution4.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool HSAValidation()
        {
            if (ddlHSANoOfPlan.SelectedIndex == 1)
            {
                // For HSA Plan 1
                if (ddlHSAPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Plan.')</script>", false);
                    ddlHSAPlanName.Focus();
                    pnlHSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHSABenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Benefit Summary.')</script>", false);
                        ddlHSABenefitSummary.Focus();
                        pnlHSA.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool HRAValidation()
        {
            if (ddlHRANoOfPlan.SelectedIndex == 1)
            {
                // For HRA Plan 1
                if (ddlHRAPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Plan.')</script>", false);
                    ddlHRAPlanName.Focus();
                    pnlHRA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHRABenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Benefit Summary.')</script>", false);
                        ddlHRABenefitSummary.Focus();
                        pnlHRA.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool FSAValidation()
        {
            if (ddlFSANoOfPlan.SelectedIndex == 1)
            {
                // For FSA Plan 1
                if (ddlFSAPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Plan.')</script>", false);
                    ddlFSAPlanName.Focus();
                    pnlFSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlFSABenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Benefit Summary.')</script>", false);
                        ddlFSABenefitSummary.Focus();
                        pnlFSA.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool EAPValidation()
        {
            if (ddlEAPNoOfPlan.SelectedIndex == 1)
            {
                // For EAP Plan 1
                if (ddlEAPPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Plan.')</script>", false);
                    ddlEAPPlanName.Focus();
                    pnlEAP.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlEAPBenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Benefit Summary.')</script>", false);
                        ddlEAPBenefitSummary.Focus();
                        pnlEAP.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool LifeADnDValidation()
        {
            if (ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 2)
            {
                // For Life and AD&D Plan 1
                if (ddlLifeADDPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName1.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary1.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                }

                // For Life and AD&D Plan 2
                if (ddlLifeADDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName2.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary2.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool STDValidation()
        {
            if (ddlSTDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 2)
            {
                // For STD Plan 1
                if (ddlSTDPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName1.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary1.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                }

                // For STD Plan 2
                if (ddlSTDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName2.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary2.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool LTDValidation()
        {
            if (ddlLTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 2)
            {
                // For LTD Plan 1
                if (ddlLTDPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName1.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary1.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                }

                // For LTD Plan 2
                if (ddlLTDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName2.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary2.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }


        private bool STDRatesValidation()
        {
            bool IsValid = true;
            if (ddlSTDNoOfPlan.SelectedIndex == 1 && ddlSTDPlanName1.SelectedIndex > 0)
            {
                if ((Convert.ToString(Session["Summary"]) == "BenefitSummary_FAQv2") && ddlVoluntarySTDRate.Items.Count > 1 && IsProductVoluntary(Convert.ToInt32(ddlSTDPlanName1.SelectedValue), Session["SessionId"].ToString()))
                {
                    if (ddlVoluntarySTDRate.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Rate.')</script>", false);
                        ddlVoluntarySTDRate.Focus();
                        pnlSTD.Visible = true;
                        IsValid = false;
                    }
                    if (ddlVoluntarySTDRate.Visible == false)
                    {
                        ddlVoluntarySTDRate.Visible = true;
                        trSTDRate1.Visible = true;
                        ddlVoluntarySTDRate.Focus();
                    }
                }
            }

            return IsValid;

        }

        private bool LTDRatesValidation()
        {
            bool IsValid = true;
            if (ddlLTDNoOfPlan.SelectedIndex == 1 && ddlLTDPlanName1.SelectedIndex > 0)
            {
                if ((Convert.ToString(Session["Summary"]) == "BenefitSummary_FAQv2") && ddlVoluntaryLTDRate.Items.Count > 1 && IsProductVoluntary(Convert.ToInt32(ddlLTDPlanName1.SelectedValue), Session["SessionId"].ToString()))
                {
                    if (ddlVoluntaryLTDRate.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Rate.')</script>", false);
                        ddlVoluntaryLTDRate.Focus();
                        pnlLTD.Visible = true;
                        IsValid = false;
                    }
                    if (ddlVoluntaryLTDRate.Visible == false)
                    {
                        ddlVoluntaryLTDRate.Visible = true;
                        trLTDRate1.Visible = true;
                        ddlVoluntaryLTDRate.Focus();
                    }
                }
            }

            return IsValid;

        }

        private bool VoluntaryLifeADnDValidation()
        {
            if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 1 || ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 2)
            {
                // For Voluntary Life and AD&D Plan 1
                if (ddlVoluntaryLifeADDPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }

                    if ((Convert.ToString(Session["Summary"]) != "Simple_Summary") && (Convert.ToString(Session["Summary"]) != "BenefitSummary_Mountain"))
                    {
                        if (ddlVoluntaryLifeADDRate.SelectedIndex == 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Rate.')</script>", false);
                            ddlVoluntaryLifeADDRate.Focus();
                            pnlVoluntaryLife.Visible = true;
                            return false;
                        }
                    }
                }

                // For Voluntary Life and AD&D Plan 2
                if (ddlVoluntaryLifeADDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName2.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary2.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }

                    if ((Convert.ToString(Session["Summary"]) != "Simple_Summary") && (Convert.ToString(Session["Summary"]) != "BenefitSummary_Mountain"))
                    {
                        if (ddlVoluntaryLifeADDRate2.SelectedIndex == 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Rate.')</script>", false);
                            ddlVoluntaryLifeADDRate2.Focus();
                            pnlVoluntaryLife.Visible = true;
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (mvBenefitSummary.ActiveViewIndex == 3)
                {
                    if (!(Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain" || Session["Summary"].ToString() == "PowerPoint_SpringField"))
                    {
                        mvBenefitSummary.ActiveViewIndex = 1;
                        btnPrevious.Visible = true;
                        btnNext.Visible = true;
                    }
                    else
                    {
                        mvBenefitSummary.ActiveViewIndex = 2;
                        btnPrevious.Visible = true;
                        btnNext.Visible = true;
                        btnSummary.Visible = false;
                    }
                }
                else if (mvBenefitSummary.ActiveViewIndex == 4)
                {
                    if (!(Session["Summary"].ToString() == "PowerPointColorfulDots_v2" || Session["Summary"].ToString() == "PowerPointGreenHealthy_v2" || Session["Summary"].ToString() == "PowerPointColorBlocks_v2" || Session["Summary"] == "PowerPoint_BayView" || Session["Summary"] == "PowerPointMosaic_v2" || Session["Summary"] == "PowerPointBasicBlue_v2" || Session["Summary"].ToString() == "SpotLightPPT_V2" || Session["Summary"].ToString() == "PowerPointTabs_PPT_v2" || Session["Summary"].ToString() == "PowerPoint_SummerHealth" || Session["Summary"].ToString() == "PowerPoint_Mountain" || Session["Summary"].ToString() == "PowerPoint_SpringField"))
                    {
                        mvBenefitSummary.ActiveViewIndex = 3;
                        btnPrevious.Visible = true;
                        btnNext.Visible = true;
                        btnSummary.Visible = false;
                    }
                }
                else if (mvBenefitSummary.ActiveViewIndex == 2)
                {
                    if (Session["Summary"].ToString() == "Tools1_5500_Worksheet")
                    {
                        mvBenefitSummary.ActiveViewIndex = 0;
                        btnPrevious.Visible = false;
                        btnNext.Visible = true;
                    }
                    else
                    {
                        mvBenefitSummary.ActiveViewIndex = 1;
                        btnPrevious.Visible = true;
                        btnNext.Visible = true;
                    }
                    btnSummary.Visible = false;
                }
                else if (mvBenefitSummary.ActiveViewIndex == 1)
                {
                    mvBenefitSummary.ActiveViewIndex = 0;
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                    btnPrevious.Visible = false;
                    btnNext.Visible = true;
                    btnSummary.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //public void LoadPlanTypeIds()
        //{
        //    // Medical Plan Type Id's
        //    MedicalPlanTypeList.Clear();
        //    MedicalPlanTypeList.Add(100);       // Medical HMO
        //    MedicalPlanTypeList.Add(110);       // Medical PPO
        //    MedicalPlanTypeList.Add(120);       // Medical PPO (3-Tier)
        //    MedicalPlanTypeList.Add(130);       // Medical POS (2-Tier)
        //    MedicalPlanTypeList.Add(140);       // Medical POS (3-Tier)
        //    MedicalPlanTypeList.Add(150);       // Medical EPO (1-Tier)
        //    MedicalPlanTypeList.Add(160);       // Medical EPO (2-Tier)
        //    MedicalPlanTypeList.Add(170);       // Medical Indemnity

        //    // Dental Plan Type Id's
        //    DentalPlanTypeList.Clear();
        //    DentalPlanTypeList.Add(180);        // Managed Dental
        //    DentalPlanTypeList.Add(190);        // Dental PPO
        //    DentalPlanTypeList.Add(200);        // Dental Triple Option
        //    DentalPlanTypeList.Add(210);        // Dental Indemnity

        //    // Vision Plan Type Id's
        //    VisionPlanTypeList.Clear();
        //    VisionPlanTypeList.Add(230);        // Vision

        //    // Life AD&D Plan Type Id's
        //    LifeADDPlanTypeList.Clear();
        //    LifeADDPlanTypeList.Add(240);       // Life and AD&D
        //    LifeADDPlanTypeList.Add(250);       // Group Term Life
        //    LifeADDPlanTypeList.Add(270);       // AD&D

        //    // STD Plan Type Id's
        //    STDPlanTypeList.Clear();
        //    STDPlanTypeList.Add(290);       // Short Term Disability (STD)

        //    // STD Plan Type Id's
        //    LTDPlanTypeList.Clear();
        //    LTDPlanTypeList.Add(300);       // Long Term Disability (LTD)

        //    // Voluntary Life Plan Type Id's
        //    VoluntaryLifeADDPlanTypeList.Clear();
        //    VoluntaryLifeADDPlanTypeList.Add(260);      // For Voluntary Life
        //    VoluntaryLifeADDPlanTypeList.Add(280);      // For Voluntary AD&D

        //    // EAP Plan Type Id's
        //    EAPPlanTypeList.Clear();
        //    EAPPlanTypeList.Add(310);       // Employee Assistance Program (EAP)

        //    // FSA Plan Type Id's
        //    FSAPlanTypeList.Clear();
        //    FSAPlanTypeList.Add(330);       // Section 125

        //    // HRA Plan Type Id's
        //    HRAPlanTypeList.Clear();
        //    HRAPlanTypeList.Add(178);       // Health Reimbursement Arrangement

        //    // HSA Plan Type Id's
        //    HSAPlanTypeList.Clear();
        //    HSAPlanTypeList.Add(179);       // Health Savings Account

        //    // Wellness Plan Type Id's
        //    WellnessPlanTypeList.Clear();
        //    WellnessPlanTypeList.Add(317);                  // Wellness Program
        //    WellnessPlanTypeList.Add(1740);                 // Wellness/Disease Mgmt

        //    // Additional Products Plan Type Id's
        //    AdditionalProductsPlanTypeList.Clear();
        //    AdditionalProductsPlanTypeList.Add(1790);       // Patient Advocacy
        //    AdditionalProductsPlanTypeList.Add(5460);       // Consumer Driven Telemedicine
        //    AdditionalProductsPlanTypeList.Add(5500);       // Accident
        //    AdditionalProductsPlanTypeList.Add(1400);       // Voluntary Cancer
        //    AdditionalProductsPlanTypeList.Add(1160);       // Voluntary Critical Illness
        //}

        ConstantValue cv = new ConstantValue();

        public string GetPlanName(int PlanTypeId)
        {
            string _planName = string.Empty;

            try
            {
                // Medical
                foreach (var item in CommonFunctionsBS.MedicalPlanTypeList)
                {
                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.MedicalLOC;
                    }
                }

                // Dental
                foreach (var item in CommonFunctionsBS.DentalPlanTypeList)
                {
                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.DentalLOC;
                    }
                }

                // Vision
                foreach (var item in CommonFunctionsBS.VisionPlanTypeList)
                {
                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VisionLOC;
                    }
                }

                // Life and AD&D
                foreach (var item in CommonFunctionsBS.LifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LifeADDLOC;
                    }
                }

                // STD
                foreach (var item in CommonFunctionsBS.STDPlanTypeList)
                {
                    if (CommonFunctionsBS.STDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.STDLOC;
                    }
                }

                // Voluntary Life and AD&D
                foreach (var item in CommonFunctionsBS.VoluntaryLifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VoluntaryLifeADDLOC + "/" + cv.ADNDPlanType_CommonCriteria;
                    }
                }

                // LTD
                foreach (var item in CommonFunctionsBS.LTDPlanTypeList)
                {
                    if (CommonFunctionsBS.LTDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LTDLOC;
                    }
                }

                // EAP
                foreach (var item in CommonFunctionsBS.EAPPlanTypeList)
                {
                    if (CommonFunctionsBS.EAPPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.EAPPlanType_CommonCriteria;
                    }
                }

                // FSA
                foreach (var item in CommonFunctionsBS.FSAPlanTypeList)
                {
                    if (CommonFunctionsBS.FSAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.FSAPlanType_CommonCriteria;
                    }
                }

                // HRA
                foreach (var item in CommonFunctionsBS.HRAPlanTypeList)
                {
                    if (CommonFunctionsBS.HRAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.HRAPlanType_CommonCriteria;
                    }
                }

                // HSA
                foreach (var item in CommonFunctionsBS.HSAPlanTypeList)
                {
                    if (CommonFunctionsBS.HSAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.HSAPlanType_CommonCriteria;
                    }
                }

                // Wellness
                foreach (var item in CommonFunctionsBS.WellnessPlanTypeList)
                {
                    if (CommonFunctionsBS.WellnessPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.Wellness;
                    }
                }

                //// Group Term Life
                //foreach (var item in GroupTermLifePlanTypeList)
                //{
                //    if (GroupTermLifePlanTypeList.Contains(PlanTypeId))
                //    {
                //        return cv.GroupTermLifePlanType;
                //    }
                //}

                //// AD&D
                //foreach (var item in LifeADDPlanTypeList)
                //{
                //    if (LifeADDPlanTypeList.Contains(PlanTypeId))
                //    {
                //        return cv.ADD;
                //    }
                //}

                // Additional Products
                foreach (var item in CommonFunctionsBS.AdditionalProductsPlanTypeList)
                {
                    if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.AdditionalProducts;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _planName;
        }

        public bool Check_PlanIs_Medical_Dental_Vision(int PlanTypeId)
        {
            bool _IsMDV = false;

            try
            {
                // Medical
                foreach (var item in CommonFunctionsBS.MedicalPlanTypeList)
                {
                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }

                // Dental
                foreach (var item in CommonFunctionsBS.DentalPlanTypeList)
                {
                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }

                // Vision
                foreach (var item in CommonFunctionsBS.VisionPlanTypeList)
                {
                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _IsMDV;
        }

        protected void dlPlan_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                LinkButton lnkPlanNames = e.Item.FindControl("lnkPlanNames") as LinkButton;
                lnkPlanNames.Text = e.Item.DataItem.ToString();
            }
        }

        protected void lnkPlanNames_Click(object sender, EventArgs e)
        {
            // Set the background color for all the links to "#E7EEF4"
            foreach (DataListItem item in dlPlan.Items)
            {
                LinkButton lnkPlanNames = item.FindControl("lnkPlanNames") as LinkButton;
                lnkPlanNames.BackColor = System.Drawing.ColorTranslator.FromHtml("#E7EEF4");
                lnkPlanNames.ForeColor = System.Drawing.Color.Black;
            }

            // Set the background color for selected linkbutton to "#7092BE"
            ((System.Web.UI.WebControls.LinkButton)(sender)).BackColor = System.Drawing.ColorTranslator.FromHtml("#7092BE");
            ((System.Web.UI.WebControls.LinkButton)(sender)).ForeColor = System.Drawing.Color.White;

            if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.MedicalLOC)
            {
                pnlMedical.Visible = true;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.DentalLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = true;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.VisionLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = true;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.LifeADDLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = true;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.STDLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = true;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.LTDLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = true;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.VoluntaryLifeADDLOC + "/" + cv.ADNDPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = true;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.EAPPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = true;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.FSAPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = true;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.HRAPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = true;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.HSAPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = true;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.Wellness)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = true;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.ADD)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = true;
                pnlGroupTermLife.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.GroupTermLifePlanType)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = true;
            }

        }

        protected void ddlPlanContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    BindPlanContactGrid();

                    //if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                    //{
                    //    string[] TobeDistinct = { "ProductId" };
                    //    //dt = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct);
                    //    dvPlanContacts.DataSource = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct); ;
                    //    dvPlanContacts.DataBind();
                    //}
                }
                else
                {
                    lblPlanContactMessage.Text = "";
                    dvPlanContacts.DataSource = null;
                    dvPlanContacts.DataBind();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void dvPlanContacts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblProductID = (e.Row.FindControl("lblProductID") as Label);
                Label lblName = (e.Row.FindControl("lblName") as Label);
                DropDownList ddlItemPlanContact = (e.Row.FindControl("ddlItemPlanContact") as DropDownList);

                var name = (from a in PlanInfoTable.AsEnumerable()
                            where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                            select a.Field<string>("Name")).FirstOrDefault();

                var carrier = (from a in PlanInfoTable.AsEnumerable()
                               where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                               select a.Field<string>("Carrier")).FirstOrDefault();

                lblName.Text = name;

                var planContact = (from n in dtPlanContactInfo.AsEnumerable()
                                   where n.Field<int>("ProductId") == Convert.ToInt32(lblProductID.Text)
                                   select new { ContactId = (n.Field<int>("ContactId")), ContactName = (n.Field<string>("ContactName")), ContactPhoneNumber = (n.Field<string>("ContactWorkPhone")), ContactEmail = (n.Field<string>("ContactEmail")) });

                foreach (var item in planContact.ToList())
                {
                    ListItem li = new ListItem();
                    li.Text = item.ContactName + " - " + carrier;
                    li.Value = Convert.ToString(item.ContactId);
                    //li.Attributes.Add("ContactPhoneNumber", Convert.ToString(item.ContactPhoneNumber));
                    ddlItemPlanContact.Items.Add(li);
                }

                //Add Default Item in the DropDownList
                ddlItemPlanContact.Items.Insert(0, new ListItem("Select"));
                ddlItemPlanContact.Items.Insert(1, new ListItem("None"));
            }
        }

        private DataTable GetDataTableFromGridView(GridView dtg)
        {
            DataTable dt = new DataTable();
            DataRow dr;

            // add the columns to the datatable            
            dt.Columns.Add(new System.Data.DataColumn("PlanName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactId", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactPhoneNumber", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ProductId", typeof(String)));

            //  add each of the data rows to the table
            foreach (GridViewRow row in dtg.Rows)
            {
                Label lblName = (Label)row.FindControl("lblName");
                DropDownList ddlItemPlanContact = (DropDownList)row.FindControl("ddlItemPlanContact");
                DropDownList ddlItemPlanContactPhoneNumber = (DropDownList)row.FindControl("ddlItemPlanContactPhoneNumber");
                Label lblProductID = (Label)row.FindControl("lblProductID");

                if (ddlItemPlanContact.SelectedItem.Text != "Select")
                {
                    dr = dt.NewRow();
                    dr[0] = Convert.ToString(lblName.Text).Replace(" ", "");
                    dr[1] = Convert.ToString(ddlItemPlanContact.SelectedItem.Value);
                    dr[2] = Convert.ToString(ddlItemPlanContact.SelectedItem.Text);
                    dr[4] = Convert.ToString(lblProductID.Text);

                    foreach (ListItem item in ddlItemPlanContactPhoneNumber.Items)
                    {
                        if (item.Value == Convert.ToString(ddlItemPlanContact.SelectedItem.Value))
                        {
                            dr[3] = Convert.ToString(item.Text);
                        }
                    }

                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }

        private void BindPlanContactGrid()
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    List<int> lstProductIds = new List<int>();
                    //List<int> sessionProductIdList = new List<int>();
                    //sessionProductIdList = (List<int>)Session["ProductIdList"];

                    // Medical
                    if (ddlMedicalPlanName1.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlMedicalPlanName1.SelectedValue));
                    }
                    if (ddlMedicalPlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlMedicalPlanName2.SelectedValue));
                    }
                    if (ddlMedicalPlanName3.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlMedicalPlanName3.SelectedValue));
                    }
                    if (ddlMedicalPlanName4.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlMedicalPlanName4.SelectedValue));
                    }
                    if (ddlMedicalPlanName5.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlMedicalPlanName5.SelectedValue));
                    }
                    if (ddlMedicalPlanName6.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlMedicalPlanName6.SelectedValue));
                    }

                    // Dental
                    if (ddlDentalPlanName1.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlDentalPlanName1.SelectedValue));
                    }
                    if (ddlDentalPlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlDentalPlanName2.SelectedValue));
                    }
                    if (ddlDentalPlanName3.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlDentalPlanName3.SelectedValue));
                    }
                    if (ddlDentalPlanName4.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlDentalPlanName4.SelectedValue));
                    }

                    // Vision 
                    if (ddlVisionPlanName1.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlVisionPlanName1.SelectedValue));
                    }
                    if (ddlVisionPlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlVisionPlanName2.SelectedValue));
                    }
                    if (ddlVisionPlanName3.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlVisionPlanName3.SelectedValue));
                    }
                    if (ddlVisionPlanName4.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlVisionPlanName4.SelectedValue));
                    }

                    // Life and AD&D
                    if (ddlLifeADDPlanName1.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlLifeADDPlanName1.SelectedValue));
                    }
                    if (ddlLifeADDPlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlLifeADDPlanName2.SelectedValue));
                    }

                    // STD
                    if (ddlSTDPlanName1.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlSTDPlanName1.SelectedValue));
                    }
                    if (ddlSTDPlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlSTDPlanName2.SelectedValue));
                    }

                    // LTD
                    if (ddlLTDPlanName1.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlLTDPlanName1.SelectedValue));
                    }
                    if (ddlLTDPlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlLTDPlanName2.SelectedValue));
                    }

                    // Voluntary Life and AD&D
                    if (ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlVoluntaryLifeADDPlanName.SelectedValue));
                    }
                    if (ddlVoluntaryLifeADDPlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlVoluntaryLifeADDPlanName2.SelectedValue));
                    }

                    // Group Term life
                    if (ddlGroupTermLifePlanName.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlGroupTermLifePlanName.SelectedValue));
                    }
                    if (ddlGroupTermLifePlanName2.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlGroupTermLifePlanName2.SelectedValue));
                    }

                    // EAP
                    if (ddlEAPPlanName.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlEAPPlanName.SelectedValue));
                    }

                    // FSA
                    if (ddlFSAPlanName.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlFSAPlanName.SelectedValue));
                    }

                    // HRA
                    if (ddlHRAPlanName.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlHRAPlanName.SelectedValue));
                    }

                    // HSA
                    if (ddlHSAPlanName.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlHSAPlanName.SelectedValue));
                    }

                    // Wellness
                    if (ddlWellnessProgramPlanName.SelectedIndex > 0)
                    {
                        lstProductIds.Add(Convert.ToInt32(ddlWellnessProgramPlanName.SelectedValue));
                    }

                    // Additional Products
                    if (PlanInfoTable != null)
                    {
                        if (PlanInfoTable.Rows.Count > 0)
                        {
                            for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                            {
                                for (int j = 0; j < CommonFunctionsBS.AdditionalProductsPlanTypeList.Count; j++)
                                {
                                    if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.AdditionalProductsPlanTypeList[j]))
                                    {
                                        lstProductIds.Add(Convert.ToInt32(PlanInfoTable.Rows[i]["ProductId"]));
                                    }
                                }
                            }
                        }
                    }

                    try
                    {
                        //if (sessionProductIdList == null)
                        //{
                        //    Session["ProductIdList"] = lstProductIds;
                        dtPlanContactInfo.Clear();


                        if (Session["Summary"].ToString() == "Tools1_5500_Worksheet")
                        {
                            if (PlanInfoTable != null)
                            {
                                if (PlanInfoTable.Rows.Count > 0)
                                {
                                    for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                                    {
                                        lstProductIds.Add(Convert.ToInt32(PlanInfoTable.Rows[i]["ProductId"]));
                                    }
                                }
                            }
                        }

                        dtPlanContactInfo = sd.GetPlanContactInformation(lstProductIds, Session["SessionId"].ToString());
                        //}
                        //else if (sessionProductIdList.Count != lstProductIds.Count)
                        //{
                        //    Session["ProductIdList"] = lstProductIds;
                        //    dtPlanContactInfo = sd.GetPlanContactInformation(lstProductIds, Session["SessionId"].ToString());
                        //}
                        Session["DataTable_PlanContactInfo"] = dtPlanContactInfo;
                    }
                    catch (Exception ex)
                    {
                        dtPlanContactInfo.Clear();
                        Session["DataTable_PlanContactInfo"] = null;
                    }

                    if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                    {
                        string[] TobeDistinct = { "ProductId" };
                        //dt = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct);

                        dvPlanContacts.DataSource = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct); ;
                        dvPlanContacts.DataBind();
                    }
                    else
                    {
                        lblPlanContactMessage.Text = "No contacts found for the selected Plans/Products.";
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlSummaryStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ddlColor.Items[0].Text = "Grey (Default)";
                ddlColor.Enabled = true;

                trSTDRate1.Visible = false;
                trLTDRate1.Visible = false;
                ddlVoluntaryLTDRate.Items.Clear();
                ddlVoluntarySTDRate.Items.Clear();
                ddlMedicalNoOfPlan.Items[5].Enabled = true;
                ddlMedicalNoOfPlan.Items[6].Enabled = true;
                ddlMedicalNoOfPlan.Items[4].Enabled = true;
                ddlDentalNoOfPlan.Items[4].Enabled = true;
                ddlDentalNoOfPlan.Items[3].Enabled = true;
                ddlVisionNoOfPlan.Items[4].Enabled = true;
                ddlVisionNoOfPlan.Items[3].Enabled = true;
                ddlVisionNoOfPlan.Items[2].Enabled = true;
                ddlLifeADDNoOfPlan.Items[2].Enabled = true;
                ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = true;
                ddlSTDNoOfPlan.Items[2].Enabled = true;
                ddlLTDNoOfPlan.Items[2].Enabled = true;

                if (ddlSummaryStyle.SelectedValue == "1")
                {
                    Session["Summary"] = "Template3_V2";

                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    trImageOption.Disabled = false;
                    ddlImageOption.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Enrollment Summary";
                }

                if (ddlSummaryStyle.SelectedValue == "2")
                {
                    Session["Summary"] = "Template7_V2";
                    //lblHeading.Text = "Highlights Summary";
                    ddlMedicalNoOfPlan.Items[4].Enabled = false;
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    ddlBRC.SelectedItem.Text = ddlBRC.SelectedItem.Text;
                    trImageOption.Disabled = true;
                    ddlImageOption.Enabled = true;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Highlights Summary";
                }
                if (ddlSummaryStyle.SelectedValue == "3")
                {
                    Session["Summary"] = "PowerPointColorfulDots_v2";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Colorful Dots";
                }
                if (ddlSummaryStyle.SelectedValue == "4")
                {
                    Session["Summary"] = "PowerPointGreenHealthy_v2";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Green Healthy";
                }
                if (ddlSummaryStyle.SelectedValue == "7")
                {
                    Session["Summary"] = "PowerPointColorBlocks_v2";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Color Blocks";
                }
                if (ddlSummaryStyle.SelectedValue == "5")
                {
                    Session["Summary"] = "Template6_ValueSummary_V2";

                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    trImageOption.Disabled = false;
                    ddlImageOption.Enabled = true;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Value Summary";
                }
                if (ddlSummaryStyle.SelectedValue == "6")
                {
                    Session["Summary"] = "Template9_EnrollmentGuide";

                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    trImageOption.Disabled = false;
                    ddlImageOption.Enabled = true;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Color Block Summary";
                }
                if (ddlSummaryStyle.SelectedValue == "8")
                {
                    Session["Summary"] = "Simple_Summary";
                    //trImageOption.Style.Add("display","none");
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = false;
                    ddlVoluntaryLifeADDRate2.Enabled = false;
                    Activity_Group = "Summaries";
                    Activity = "Simple Summary";
                }
                if (ddlSummaryStyle.SelectedValue == "Bay View")
                {
                    Session["Summary"] = "PowerPoint_BayView";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Bay View";
                }
                if (ddlSummaryStyle.SelectedValue == "9")
                {
                    Session["Summary"] = "PowerPointBasicBlue_v2";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Basic Blue";
                }
                if (ddlSummaryStyle.SelectedValue == "10")
                {
                    Session["Summary"] = "PowerPointMosaic_v2";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Mosaic";
                }
                //Added By Amogh-10Aug2018
                if (ddlSummaryStyle.SelectedValue == "SpotLightPPT_V2")
                {
                    Session["Summary"] = "SpotLightPPT_V2";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "SpotLight";
                }
                if (ddlSummaryStyle.SelectedValue == "11")
                {
                    Session["Summary"] = "PowerPointTabs_PPT_v2";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Tabs PPT";
                }
                if (ddlSummaryStyle.SelectedValue == "Summer_Health")
                {
                    Session["Summary"] = "PowerPoint_SummerHealth";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Summer Health PPT";
                }
                if (ddlSummaryStyle.SelectedValue == "Mountain")
                {
                    Session["Summary"] = "PowerPoint_Mountain";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "Mountain";
                }
                if (ddlSummaryStyle.SelectedValue == "SpringField")
                {
                    Session["Summary"] = "PowerPoint_SpringField";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    Activity_Group = "PowerPoint";
                    Activity = "SpringField";
                }
                if (ddlSummaryStyle.SelectedValue == "BenefitSummary_BasicBlue")
                {
                    Session["Summary"] = "BenefitSummary_BasicBlue";
                    //trImageOption.Style.Add("display","none");
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Basic Blue";
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                }

                if (ddlSummaryStyle.SelectedValue == "BenefitSummaryWord_BayView")
                {
                    #region Added region for BayView
                    Session["Summary"] = "BenefitSummaryWord_BayView";
                    //trImageOption.Style.Add("display","none");
                    ////ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ////ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Simple Summary";
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                    #endregion
                }
                if (ddlSummaryStyle.SelectedValue == "BenefitSummary_SummerHealth")
                {
                    Session["Summary"] = "BenefitSummary_SummerHealth";
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Summer Health Benefit Summary";
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                }

                if (ddlSummaryStyle.SelectedValue == "BenefitSummary_Mosaic")
                {
                    Session["Summary"] = "BenefitSummary_Mosaic";
                    //trImageOption.Style.Add("display","none");
                    //ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    //ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                    Activity_Group = "Summaries";
                    Activity = "Mosaic Benefit Summary";
                }
                if (ddlSummaryStyle.SelectedValue == "BenefitSummary_Mountain")
                {
                    Session["Summary"] = "BenefitSummary_Mountain";
                    //trImageOption.Style.Add("display","none");
                    //ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    //ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = false;
                    ddlVoluntaryLifeADDRate2.Enabled = false;
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                    Activity_Group = "Summaries";
                    Activity = "Mountain Benefit Summary";
                }
                if (ddlSummaryStyle.SelectedValue == "BenefitSummary_SpotLight")
                {
                    Session["Summary"] = "BenefitSummary_SpotLight";
                    //trImageOption.Style.Add("display","none");
                    ////ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ////ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Spot Light";
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                }
                if (ddlSummaryStyle.SelectedValue == "BenefitSummary_Tabs")
                {
                    Session["Summary"] = "BenefitSummary_Tabs";
                    //trImageOption.Style.Add("display","none");
                    ////ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ////ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Tabs";
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                }
                if (ddlSummaryStyle.SelectedValue == "BenefitSummary_SpringField")
                {
                    Session["Summary"] = "BenefitSummary_SpringField";
                    //trImageOption.Style.Add("display","none");
                    ////ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ////ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    Activity_Group = "Summaries";
                    Activity = "Tabs";
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                }
                if (ddlSummaryStyle.SelectedValue == "FAQ_SummaryV2")
                {
                    Session["Summary"] = "BenefitSummary_FAQv2";
                    //trImageOption.Style.Add("display","none");
                    ddlMedicalNoOfPlan.Items[5].Enabled = false;
                    ddlMedicalNoOfPlan.Items[6].Enabled = false;
                    ddlMedicalNoOfPlan.Items[4].Enabled = false;
                    ddlDentalNoOfPlan.Items[4].Enabled = false;
                    ddlDentalNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[4].Enabled = false;
                    ddlVisionNoOfPlan.Items[3].Enabled = false;
                    ddlVisionNoOfPlan.Items[2].Enabled = false;
                    ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlSTDNoOfPlan.Items[2].Enabled = false;
                    ddlLTDNoOfPlan.Items[2].Enabled = false;

                    //ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                    ddlImageOption.Enabled = false;
                    ddlVoluntaryLifeADDRate.Enabled = true;
                    ddlVoluntaryLifeADDRate2.Enabled = true;
                    ddlColor.SelectedIndex = 0;
                    ddlColor.Items[0].Text = "Standard (Default)";
                    ddlColor.Enabled = false;
                    Activity_Group = "Summaries";
                    Activity = "FAQ Summary_V2";
                }

                if (grdPlans.Rows.Count > 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void btnReportReset_Click(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                ddlRegion.SelectedValue = "0";
                cblistOffice.Items.Clear();
                ddlDateType.SelectedValue = "0";
                txtDateFrom.Text = "";
                txtDateTo.Text = "";
                ddlProducerTeam.SelectedValue = "1111";
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<Office> OfficeList = new List<Office>();
                OfficeList = (List<Office>)Session["Reports_Office_List"];

                if (ddlRegion.SelectedValue != "-1" && ddlRegion.SelectedValue != "0" && ddlRegion.SelectedValue != "")
                {
                    var loffice = from s in OfficeList where s.RegionName == ddlRegion.SelectedItem.Text select s;
                    cblistOffice.DataSource = loffice;
                    cblistOffice.DataBind();
                }
                //else if (ddlRegion.SelectedValue == "0")
                //{
                //    cblistOffice.DataSource = null;
                //    cblistOffice.DataBind();
                //}
                else
                {
                    cblistOffice.Items.Clear();
                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReportCreate_Click(object sender, EventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            bool flag = true;
            try
            {
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();

                //DateTime.TryParse(txtDateFrom.Text, out dtFrom);
                //DateTime.TryParse(txtDateTo.Text, out dtTo);

                DateTime.TryParseExact(txtDateFrom.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtFrom);
                DateTime.TryParseExact(txtDateTo.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtTo);

                if (ddlReportStyle.SelectedValue == "0")
                {
                    string script = "alert(\"Please select Report.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    ddlReportStyle.Focus();
                    flag = false;
                    return;
                }

                if (ddlRegion.SelectedValue == "0")
                {
                    string script = "alert(\"Please select Region.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    ddlRegion.Focus();
                    flag = false;
                    return;
                }

                if (cblistOffice.Items.Count > 0)
                {
                    int cnt = 0;
                    for (int i = 0; i < cblistOffice.Items.Count; i++)
                    {
                        if (cblistOffice.Items[i].Selected == true)
                        {
                            cnt++;
                        }
                    }

                    if (cnt == 0)
                    {
                        string script = "alert(\"Please select Office(s).\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        flag = false;
                        return;
                    }
                }

                if (ddlDateType.SelectedValue == "0")
                {
                    string script = "alert(\"Please select Date Type.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    ddlDateType.Focus();
                    flag = false;
                    return;
                }

                if (ddlDateType.SelectedValue == "1")
                {
                    if (txtDateFrom.Text != "")
                    {
                        if (DateTime.MinValue == dtFrom)
                        {
                            txtDateFrom.Focus();
                            string script = "alert(\"'Date From' should be in 'mm/dd/yyyy' format.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            return;
                        }

                        if (dtFrom > DateTime.Today)
                        {
                            txtDateFrom.Focus();
                            string script = "alert(\"'Date From' should not be greater than today's date.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            return;
                        }
                    }
                }

                if (txtDateFrom.Text != "")
                {
                    if (DateTime.MinValue == dtFrom)
                    {
                        txtDateFrom.Focus();
                        string script = "alert(\"'Date From' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (txtDateFrom.Text.Trim() != "" && txtDateTo.Text.Trim() == "")
                {
                    txtDateTo.Focus();
                    string script = "alert(\"Please enter 'Date To'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (txtDateFrom.Text.Trim() == "" && txtDateTo.Text.Trim() != "")
                {
                    txtDateFrom.Focus();
                    string script = "alert(\"Please enter 'Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (txtDateTo.Text != "")
                {
                    if (DateTime.MinValue == dtTo)
                    {
                        txtDateTo.Focus();
                        string script = "alert(\"'Date To' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (dtTo < dtFrom)
                {
                    string script = "alert(\"'Date To' should be greater than 'Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                    return;
                }

                if (flag == true)
                {
                    // Get the Account Office and Account Region for the selected client
                    ////Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);


                    if (Convert.ToString(Session["Summary"]) == "Reports1_MeetingTrackingReport")
                    {
                        CreateReports1_MeetingTrackingReport(tc.Timeline1_SubjectID, SessionId);
                    }
                    if (Convert.ToString(Session["Summary"]) == "Reports2_RenewalStatusReport")
                    {
                        CreateReports2_RenewalStatusReport(tc.Timeline1_SubjectID, SessionId);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File in Excel format.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        public void DownloadFileNew_Excel(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlReportStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<Office> OfficeList = new List<Office>();
                OfficeList = bp.FindOffice(Convert.ToString(Session["SessionId"]), "");
                Session["Reports_Office_List"] = OfficeList;

                var lregion = (from s in OfficeList orderby s.RegionName ascending select s.RegionName).Distinct();

                ddlRegion.DataSource = lregion;
                ddlRegion.DataBind();
                ddlRegion.Items.Insert(0, new ListItem("Select", "0"));
                Activity_Group = "Reports";

                // Meeting Tracking Report
                if (ddlReportStyle.SelectedValue == "2")
                {
                    Session["Summary"] = "Reports1_MeetingTrackingReport";
                    Activity = "Meeting Tracking Report";
                }
                // Renewal Status Report
                else if (ddlReportStyle.SelectedValue == "1")
                {
                    Session["Summary"] = "Reports2_RenewalStatusReport";
                    Activity = "Renewal Status Report";
                }
                else if (ddlReportStyle.SelectedValue == "0") // Select
                {
                    ddlRegion.SelectedValue = "0";
                    cblistOffice.Items.Clear();
                    ddlDateType.SelectedValue = "0";
                    txtDateFrom.Text = "";
                    txtDateTo.Text = "";
                }

                //Reading the data from Producer XML file and bind to ddlProducerTeam dropdown
                DataSet procedure = new DataSet();
                procedure.ReadXml(Server.MapPath("~/Common/Reports/Producer.xml"));
                ddlProducerTeam.DataSource = procedure;
                ddlProducerTeam.DataTextField = "description";
                ddlProducerTeam.DataValueField = "id";
                ddlProducerTeam.DataBind();

                ddlProducerTeam.SelectedValue = "1111";
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void CreateReports1_MeetingTrackingReport(int SubjectID, string SessionId)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;

            try
            {
                ArrayList arrCheckedOffice = new ArrayList();
                // Create ararylist of selected check box from office checkboxlist
                for (int i = 0; i < cblistOffice.Items.Count; i++)
                {
                    if (cblistOffice.Items[i].Selected == true)
                    {
                        arrCheckedOffice.Add(cblistOffice.Items[i].Text);
                    }
                }

                SessionId = Session["SessionId"].ToString();
                List<Account> filteredAccountList = new List<Account>();
                DateTime _fromdate = new DateTime();
                DateTime _todate = new DateTime();
                DateTime.TryParse(txtDateFrom.Text, out _fromdate);
                DateTime.TryParse(txtDateTo.Text, out _todate);

                if (_todate < _fromdate)
                {
                    string script = "alert(\"'Create Date To' should be greater than 'Create Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    return;
                }

                filteredAccountList = bp.FindFilteredClientListForReportsTab(SessionId, arrCheckedOffice, Convert.ToInt32(ddlProducerTeam.SelectedItem.Value), _fromdate, _todate, ddlDateType.SelectedItem.Value);

                myExcelApp = new Excel.Application();

                myExcelApp.Visible = false;

                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Reports/Documents/Templates/Reports1_Meeting Tracker.xlsx");

                myExcelApp.DisplayAlerts = false;

                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Reports/Documents/Templates/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Reports/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Reports/Documents/Templates/Report1"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                WriteReports1 wr = new WriteReports1();
                if (ddlDateType.SelectedValue == "1")
                {
                    wr.WriteFieldToReports1(myWorksheet, SubjectID, SessionId, cblistOffice, ddlProducerTeam, _fromdate, _todate, filteredAccountList);
                }
                else if (ddlDateType.SelectedValue == "2")
                {
                    wr.WriteFieldToReports1_ForRenewalDateOnly(myWorksheet, SubjectID, SessionId, cblistOffice, ddlProducerTeam, _fromdate, _todate, filteredAccountList, Convert.ToString(ddlDateType.SelectedValue));
                }

                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew(savefilename.ToString());

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office);

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }

        ///Function for Simple Summary Redesign
        ///
        protected string CreateSummarySimple_Summary(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];

            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
               List<BRC> BRCList = new List<BRC>();
               BRCList = (List<BRC>)Session["BRCList"];
           */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            string color = ddlColor.SelectedValue.ToString();
            string IncomeProtectionPlan = string.Empty;
            List<string> IncomeProtectionPlanList = new List<string>();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report10")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report10"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_SimpleSummary_Redesign.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report10/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate10_SimpleSummary wt = new WriteTemplate10_SimpleSummary();
                if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    IncomeProtectionPlanList.Add("Basic Life, Accidental Death and Dismemberment (AD&D) ");
                }
                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    IncomeProtectionPlanList.Add("Short Term Disability");
                }
                if (ddlLTDNoOfPlan.SelectedIndex > 0)
                {
                    IncomeProtectionPlanList.Add(" Long Term Disability");
                }

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wt.WriteEligibilityToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//


                IncomeProtectionPlan = String.Join(", ", IncomeProtectionPlanList.ToArray());
                wt.WriteFieldToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, color, IncomeProtectionPlan, ddlImageOption);
                wt.WriteMedicalSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, ddlMedicalNoOfPlan, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, color);
                wt.WritePrescriptionDrugsSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, color);
                if (ddlDentalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDentalSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, color, ddlDentalNoOfPlan.SelectedIndex);
                }
                if (ddlVisionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVisionSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific, color);
                }
                if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLifeADDSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, CarrierSpecific, color);
                }
                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteSTDSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, color);
                }
                if (ddlLTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLTDSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, color);
                }
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVoluntaryLifeADDSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, color);
                }

                //wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, color);
                wt.WriteAdditionalProductsToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanInfoTable, ddlEAPNoOfPlan, color);
                if (ddlHSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHSASectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, color, HSABenefitColumnIdList);
                }
                if (ddlHRANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHRASectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, color);
                }
                if (ddlEAPNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteEAPSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, color);
                }
                if (ddlFSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteFSASectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, color);
                }
                wt.WriteMonthlyPremiumSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, ContributionDS, PlanTable, color);
                //if (ddlPlanContacts.SelectedValue == "0")
                //{
                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                wt.WriteContactinformationToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, selectedColor, dtPlanContactDetails);
                //}
                //else
                //{
                //    wt.FillColorContactinformationToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, selectedColor);
                //}
                //objCommFun.DeleteRows_STD_LTD_Life(23, wobj.office.oWordDoc);
                //if (ddlAnnualLegalNotice.SelectedIndex > 0 || ddlChipNotice.SelectedIndex > 0)
                //{
                wt.WriteNoticeSectionToTemplate10(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlMarketplaceCoverage, ddlCreditableCoverage, selectedColor);
                //}

                //bool isAllPlansSelected = false;
                //if (ddlLifeADDPlanName1.SelectedIndex > 0 && ddlLifeADDPlanName2.SelectedIndex > 0 && ddlSTDPlanName1.SelectedIndex > 0 && ddlSTDPlanName2.SelectedIndex > 0 && ddlLTDPlanName1.SelectedIndex > 0 && ddlLTDPlanName2.SelectedIndex > 0)
                //{
                //    isAllPlansSelected = true;
                //}
                //wt.WriteTableOfContentInformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ddlAnnualLegalNotice, ddlChipNotice, ddlBRC, color, PlanInfoTable, isAllPlansSelected);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary10" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                ////#region Added by vinod : storing the activity logs
                ////string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                ////if (BRCDataList.Count > 0 && ddlBRC.SelectedItem.Text == "YES")
                ////{
                ////    AdditionalCrtieriaOption_2 = Convert.ToString(BRCDataList[0].BRCLocation.Trim());
                ////}
                ////string AdditionalCrtieriaOption_3 = ddlSummaryStyle.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_4 = ddlColor.SelectedItem.Text;
                ////DicActivityLog.Clear();
                ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                ////bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                ////#endregion

                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }


        protected void ddlHSASelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (ddlHSASelection.SelectedValue == "1")
            //{
            //    trHSAVideo.Visible = true;
            //}
            //else if (ddlHSASelection.SelectedValue == "0")
            //{
            //    trHSAVideo.Visible = false;
            //    for (int index = 0; index < chkHSAVideo.Items.Count; ++index)
            //    {
            //        chkHSAVideo.ClearSelection();
            //    }
            //}
        }

        protected void ddlMobileSelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMobileSelection.SelectedValue == "1")
            {
                //  trMobileVideo.Visible = true;
                for (int index = 0; index < chkMobileVideo.Items.Count; ++index)
                {
                    chkMobileVideo.Items[index].Selected = true;
                }
            }
            else if (ddlMobileSelection.SelectedValue == "0")
            {
                // trMobileVideo.Visible = true;
                for (int index = 0; index < chkMobileVideo.Items.Count; ++index)
                {
                    chkMobileVideo.ClearSelection();
                }
            }
        }
        protected void Hide_SummaryStyle_ListItems()
        {
            List<string> lstBenefitPointsOptions = new List<string>() { "6", "1", "2", "8", "5", "BenefitSummary_BasicBlue", "BenefitSummaryWord_BayView", "BenefitSummary_SummerHealth", "BenefitSummary_Mosaic", "BenefitSummary_Mountain", "BenefitSummary_SpotLight", "BenefitSummary_Tabs", "BenefitSummary_SpringField", "Wrapper_Mosaic", "FAQ_SummaryV2" };
            List<string> lstPowerPointOptions = new List<string>() { "3", "4", "7", "Bay View", "9", "10", "11", "SpotLightPPT_V2", "Summer_Health", "Mountain", "SpringField" };


            //For PowerPoint 
            if (Session["Summary"].ToString() == "PowerPointColorfulDots_v2")
            {
                foreach (ListItem item in ddlSummaryStyle.Items)
                {
                    if (item.Value == "0" || lstPowerPointOptions.Contains(item.Value))
                    {
                        item.Enabled = true;
                    }
                    else
                    {
                        item.Enabled = false;
                    }
                }
            }

            //For Word
            else if (Session["Summary"].ToString() == "Template3_V2")
            {
                foreach (ListItem item in ddlSummaryStyle.Items)
                {
                    if (item.Value == "0" || lstBenefitPointsOptions.Contains(item.Value))
                    {
                        item.Enabled = true;
                    }
                    else
                    {
                        item.Enabled = false;
                    }
                }

            }

        }
        protected void LoadPlanContactTable()
        {
            List<Plan> lstPlans = Session["PlanList"] as List<Plan>;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable planstable = PlanTable.Copy();
            objCommFun.LoadPlanTypeIds();
            CommonFunctionsBS.BuiltDictContactsPlanTypes();
            foreach (DataRow dr in PlanInfoTable.Rows)
            {
                if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(int.Parse(dr["ProductTypeId"].ToString())) || CommonFunctionsBS.WellnessPlanTypeList.Contains(int.Parse(dr["ProductTypeId"].ToString())))
                {
                    Plan tempPlan = lstPlans.Where(p => p.ProductId == int.Parse(dr["ProductId"].ToString())).FirstOrDefault();
                    if (tempPlan != null)
                    {
                        DataRow NewRow = planstable.NewRow();
                        NewRow["ProductId"] = tempPlan.ProductId;
                        NewRow["ProductName"] = tempPlan.ProductName;
                        NewRow["Carrier"] = tempPlan.CarrierName;
                        NewRow["Effective"] = tempPlan.EffectiveDate.ToString("MM/dd/yyyy");
                        NewRow["Renewal"] = tempPlan.RenewalDate.ToString("MM/dd/yyyy");
                        NewRow["PolicyNumber"] = tempPlan.PolicyNumber;
                        NewRow["ProductTypeDescription"] = tempPlan.ProductTypeDescription;
                        NewRow["PlanType"] = tempPlan.ProductTypeDescription;
                        NewRow["PlanNumber"] = tempPlan.ProductTypeDescription + " " + tempPlan.PolicyNumber.ToString();
                        NewRow["UsiProductName"] = tempPlan.UsiProductName;
                        foreach (string plantype in CommonFunctionsBS.DictContactsPlanTypes.Keys)
                        {
                            if (CommonFunctionsBS.DictContactsPlanTypes[plantype].Contains(tempPlan.ProductTypeId))
                            {
                                NewRow["contactPlanType"] = plantype;
                            }
                        }
                        planstable.Rows.Add(NewRow);
                    }
                }
            }

            Session["PlanContactTable"] = planstable;
        }
        #region Bay View
        [STAThread]
        protected string CreateSummaryPowerPoint_BayView(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
             List<BRC> BRCList = new List<BRC>();
             BRCList = (List<BRC>)Session["BRCList"];
           */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/BayView_PPT.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/BayView_PPT/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/BayView_PPT")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/BayView_PPT"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint_BayView wt = new WritePowerPoint_BayView();

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    ////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)  // Commented as per new PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region exiting code commented for spanish videos

                    ///////*-------------------------------CODE ADDED BY AMOGH FOR ADDITIONAL PPT DEVELOPMENT------------------------ */
                    //////wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////////Added by Vaibhav for new request on 31st May 2018
                    //////wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);

                    //////// Commented by Vaibhav for new request on 31st May 2018
                    ////////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////////{
                    ////////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////////}
                    //////wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange);

                    #endregion

                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod
                        CreateSummaryPowerPoint_BayView(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion
        #region Mosaic
        [STAThread]
        protected string CreateSummaryPowerPoint_Mosaic(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
                List<BRC> BRCList = new List<BRC>();
                BRCList = (List<BRC>)Session["BRCList"];
            */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            //Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example4_v1_Colorful Dots.pptx");
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example7_v1_Mosaic.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint_Mosaic wt = new WritePowerPoint_Mosaic();

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    ////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion



                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod
                        CreateSummaryPowerPoint4_ColorfulDots(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion
        #region TAB_PPT
        [STAThread]
        protected string CreateSummaryPowerPoint_Tab_PPT(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
                   List<BRC> BRCList = new List<BRC>();
                   BRCList = (List<BRC>)Session["BRCList"];
            */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Tabs_PPT.pptx");
            //Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example7_v1_Mosaic.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint_Tabs wt = new WritePowerPoint_Tabs();
                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    ////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion



                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod
                        CreateSummaryPowerPoint4_ColorfulDots(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion

        #region Basic Blue
        [STAThread]
        protected string CreateSummaryPowerPoint4_BasicBlue(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
                List<BRC> BRCList = new List<BRC>();
                BRCList = (List<BRC>)Session["BRCList"];
            */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example4_v1_BasicBlue.PPTX");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint4_BasicBlue wt = new WritePowerPoint4_BasicBlue();

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    /////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }

                    #region Added by vinod : for all videos

                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region exiting code commented for spanish videos

                    ///////*-------------------------------CODE ADDED BY AMOGH FOR ADDITIONAL PPT DEVELOPMENT------------------------ */
                    //////wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////////Added by Vaibhav for new request on 31st May 2018
                    //////wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);

                    //////// Commented by Vaibhav for new request on 31st May 2018
                    ////////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////////{
                    ////////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////////}
                    //////wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange);

                    #endregion

                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    #endregion

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod
                        CreateSummaryPowerPoint4_ColorfulDots(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion
        #region Summer Health
        [STAThread]
        protected string CreateSummaryPowerPoint_SummerHealth(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
               List<BRC> BRCList = new List<BRC>();
               BRCList = (List<BRC>)Session["BRCList"];
            */

            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/SummerHealth_PPT.PPTX");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/SummerHealth_PPT/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/SummerHealth_PPT")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/SummerHealth_PPT"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint_SummerHealth wt = new WritePowerPoint_SummerHealth();
                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    ////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)  // Commented as per new PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region exiting code commented for spanish videos

                    ///////*-------------------------------CODE ADDED BY AMOGH FOR ADDITIONAL PPT DEVELOPMENT------------------------ */
                    //////wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////////Added by Vaibhav for new request on 31st May 2018
                    //////wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);

                    //////// Commented by Vaibhav for new request on 31st May 2018
                    ////////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////////{
                    ////////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////////}
                    //////wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange);

                    #endregion

                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod
                        CreateSummaryPowerPoint_SummerHealth(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion

        #region SpotLight
        [STAThread]
        //Added By Amogh-10Aug2018
        protected string CreateSummaryPowerPoint4_SpotLight(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
                     List<BRC> BRCList = new List<BRC>();
                     BRCList = (List<BRC>)Session["BRCList"];
             */
            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/SpotLight_PPT.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report4"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint4_SpotLight wt = new WritePowerPoint4_SpotLight();

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    ////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)  // Commented as per new PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region exiting code commented for spanish videos

                    ///////*-------------------------------CODE ADDED BY AMOGH FOR ADDITIONAL PPT DEVELOPMENT------------------------ */
                    //////wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////////Added by Vaibhav for new request on 31st May 2018
                    //////wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);

                    //////// Commented by Vaibhav for new request on 31st May 2018
                    ////////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////////{
                    ////////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////////}
                    //////wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange);

                    #endregion

                    #region Added by vinod : For English and spanish videos
                    // modified by shravan
                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);
                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);
                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by vinod
                        CreateSummaryPowerPoint4_SpotLight(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion

        //Added by Shravan
        #region Mountain
        [STAThread]
        protected string CreateSummaryPowerPoint_Mountain(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
              List<BRC> BRCList = new List<BRC>();
              BRCList = (List<BRC>)Session["BRCList"];
            */

            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Mountain_PPT.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Mountain_PPT/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Mountain_PPT")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Mountain_PPT"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint_Mountain wt = new WritePowerPoint_Mountain();

                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    /////wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);

                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)  // Commented as per new PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region exiting code commented for spanish videos

                    ///////*-------------------------------CODE ADDED BY AMOGH FOR ADDITIONAL PPT DEVELOPMENT------------------------ */
                    //////wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////////Added by Vaibhav for new request on 31st May 2018
                    //////wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);

                    //////// Commented by Vaibhav for new request on 31st May 2018
                    ////////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////////{
                    ////////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////////}
                    //////wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange);

                    #endregion

                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by Shravan
                        CreateSummaryPowerPoint_Mountain(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion

        #region Spring Field by Aarti
        private string CreateSummaryPowerPoint_SpringField(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {


            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            /**************This code is Commented by Mr. Amogh As per Nicole Requirement - Automatically determine the BRC  **********************
               List<BRC> BRCList = new List<BRC>();
               BRCList = (List<BRC>)Session["BRCList"];
               */

            //***** Added by Amogh  Nicole Requirement - Automatically determine the BRC
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/SpringField_PPT.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/SpringField_PPT/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/SpringField_PPT")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/SpringField_PPT"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    LoadColumnIdArrayList();
                    WritePowerPoint_SpringField wt = new WritePowerPoint_SpringField();
                    //************* START Elibibility Change ********************************//
                    int EleigibilityRuleId = 0;
                    if (ddlEligibility.SelectedIndex > 0)
                        EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                    wt.WriteEligibility(objPres, objPresSet, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId, objSlides, objShapes, txtFrame, txtRange);
                    //************* END Elibibility Change ********************************//

                    wt.WriteFieldToPowerPointTemplate4(objPres, objPresSet, PlanTable, Office, BRCDataList, ddlBRCSelectedValue, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteMedicalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange, GroupTermLifeBenefitColumnIdList, ADDBenefitColumnIdList);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHSANoOfPlan.SelectedIndex > 0 || ChkHSASlides.Checked == true)  // Commented as per new PPT Development
                    if (ddlHSANoOfPlan.SelectedIndex > 0 || ddlHSASelection.SelectedValue == "1")
                    {
                        wt.WriteHSAToPowerPointTemplate4(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteAdditionalProductsToTemplate4(objPres, objPresSet, PlanInfoTable, objSlides, objShapes, txtFrame, txtRange, ddlEAPNoOfPlan);
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate4(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);

                    if (ddlPlanContacts.SelectedValue == "0")
                    {
                        DataTable dtPlanContactDetails = new DataTable();
                        dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, dtPlanContactInfo);
                        wt.WriteContactinformationToPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, dtPlanContactDetails);
                    }


                    #region Creating checklist for medical videos -- Added by shravan
                    CheckBoxList chkMedcheckFinal = new CheckBoxList();
                    chkMedcheckFinal.Items.Clear();
                    foreach (ListItem item in chkMedicalVideo.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    foreach (ListItem item in chkMedicalVideo2.Items)
                    {
                        chkMedcheckFinal.Items.Add(item);
                    }
                    #endregion

                    #region exiting code commented for spanish videos

                    ///////*-------------------------------CODE ADDED BY AMOGH FOR ADDITIONAL PPT DEVELOPMENT------------------------ */
                    //////wt.WriteMedicalVideos(objPres, objPresSet, chkMedicalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange);

                    ////////Added by Vaibhav for new request on 31st May 2018
                    //////wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);

                    //////// Commented by Vaibhav for new request on 31st May 2018
                    ////////if (Convert.ToInt32(ddlHSASelection.SelectedValue) == 1)
                    ////////{
                    ////////    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange);
                    ////////}
                    //////wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange);
                    //////wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange);

                    #endregion

                    #region Added by vinod : For English and spanish videos
                    // modified by shravan

                    wt.WriteMedicalVideos(objPres, objPresSet, chkMedcheckFinal, objSlides, objShapes, txtFrame, txtRange, ddllanguage);


                    wt.WriteDentalVideos(objPres, objPresSet, chkDentalVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    // wt.WriteVisionVideos(objPres, objPresSet, chkVisionVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteHRAVideos(objPres, objPresSet, chkHRAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteHSAVideos(objPres, objPresSet, chkHSAVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteSTDLTDVideos(objPres, objPresSet, chkSTDLTDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteLifeADnDVideos(objPres, objPresSet, chkLifeADnDVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    // wt.WriteVoluntaryVideos(objPres, objPresSet, chkVoluntaryVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);



                    wt.WriteAdditionalProductsVideos(objPres, objPresSet, chkAdditionalProductsVideo, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    wt.WriteHrGeneralEducationVideos(objPres, objPresSet, chkHrGeneralEducationVideos, objSlides, objShapes, txtFrame, txtRange, ddllanguage);

                    #endregion

                    if (Convert.ToInt32(ddlMobileSelection.SelectedValue) == 1)
                    {
                        wt.WriteMobileVideos(objPres, objPresSet, chkMobileVideo, objSlides, objShapes, txtFrame, txtRange);

                    }

                    objCommFun.DeleteUnwantedColumnsFromTable(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.ShowUniqueCarrierNames(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ProductDS, PlanTable);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate4(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    #region Added by vinod : storing the activity logs
                    string AdditionalCrtieriaOption_1 = ddlSummaryStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                    //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreateSummaryPowerPoint4_ColorfulDots();
                        #region Added by Shravan
                        CreateSummaryPowerPoint_SpringField(AccountDS, AccountTeamMemberDS);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());

        }
        #endregion

        #region Created by Amogh For Word BayView Plan Writing

        protected string CreateSummaryTemplate_BayView(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRCData> BRCList = new List<BRCData>();
            bool isBRCSelected = false;
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            WriteTemplate_BayView wr = new WriteTemplate_BayView();
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/BayView")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/BayView"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_BayView_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/BayView/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();
                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                //STD and LTD
                List<int> LTDList = new List<int>();
                List<int> STDList = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();
                List<int> ADDPlans = new List<int>();
                bool STDSelected = false;

                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }


                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID) && (ContributionID > 0 || ContributionId_2 > 0))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }
                    ///LTD && STD
                    else if (dr["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        STDList.Add(Convert.ToInt32(dr["productID"]));
                    }
                    else if (dr["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        LTDList.Add(Convert.ToInt32(dr["productID"]));
                    }

                    /// lIFE AND aDD
                    if (dr["ProductTypeDescription"].ToString().Trim().ToLower() == "Life and AD&D".ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(dr["productID"]));
                    }
                    else if (dr["ProductTypeDescription"].ToString().Trim().ToLower() == "Group Term Life".ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(dr["productID"]));
                    }
                    else if (dr["ProductTypeDescription"].ToString().Trim().ToLower() == "AD&D".ToLower())
                    {
                        ADDPlans.Add(Convert.ToInt32(dr["productID"]));
                    }

                }

                #region GET BRC DETAILS

                if (!string.IsNullOrEmpty(Account_Office))
                {

                    BRCList = bp.GetBRCDetails(Account_Office);

                    if (BRCList.Count <= 0)
                    {
                        BRCData brcData = new BRCData();
                        brcData.BRCId = 0;
                        brcData.BRCName = "";
                        brcData.BRCLocation = "";
                        brcData.BRCEmail = "";
                        brcData.BRCPhone = "";
                        brcData.BRCFax = "";
                        brcData.BRCTimezone = "";
                        brcData.BRCDayHours = "";
                        BRCList.Add(brcData);
                    }
                }
                #endregion

                if (ddlBRC.SelectedValue == "YES")
                {
                    isBRCSelected = true;
                }
                string selectedClient = Convert.ToString(ddlClient.SelectedItem.Text.Trim());
                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToTabs(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);

                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    STDSelected = true;
                }

                wr.Write_CommonFieldToBayView(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, ProductDS, EligibilityDS, Emp, selectedClient, ddlOffice, ddlHRContact, ContactList, AccountDS, arrAcctContact, STDSelected, BRCList);

                wr.WriteMedicalSectionToTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProductMap["Medical"]);
                if (dictProductMap.ContainsKey("Dental"))
                    wr.WriteDentalSectionToTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProductMap["Dental"]);
                if (dictProductMap.ContainsKey("Vision"))
                    wr.WriteVisionSectionToTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["Vision"]);
                ////if (dictProductMap.ContainsKey("Life and AD&D"))
                ////    wr.WriteSectionToTemplateADandD(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"]);
                if (dictProductMap.ContainsKey("STD"))
                    wr.WriteSectionToTemplateSTD(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], STDList);
                if (dictProductMap.ContainsKey("LTD"))
                    wr.WriteSectionToTemplateLTD(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], LTDList);
                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteSectionToTemplateEAP(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, dictProductMap["EAP"]);
                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteSectionToTemplateFSA(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);

                ////Created by AAarti Dube 
                if (dictProductMap.ContainsKey("HSA"))
                    wr.WritHSASectionToTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HSA"]);
                if (dictProductMap.ContainsKey("HRA"))
                    wr.WritHRASectionToTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HRA"]);
                if (dictProductMap.ContainsKey("Voluntary Life"))
                    wr.WriteVoluntaryLifeTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, RateDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, dictProductMap["Voluntary Life"]);

                if (dictProductMap.ContainsKey("Life and AD&D"))
                {
                    if (LifeAndADnDPlans.Count > 0)
                    {
                        wr.WriteLifeADDToTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans);
                    }
                    if (GroupTermLife.Count > 0)
                    {
                        wr.WriteGroupLifeADDTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                    }
                    if (ADDPlans.Count > 0)
                    {
                        wr.WriteSectionToTemplateADandD(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADDPlans);
                    }
                }


                string color = "";
                wr.WriteMonthlyPremiumSectionToBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ContributionDS, PlanTable, color, dictProductMap["Medical"], dictContributionMap);

                ////Loading Contact details 
                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                DataTable dtblContact = Session["PlanContactTable"] as DataTable;
                wr.WriteContactinformationToTemplateBayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtblContact, CarrierSpecific, selectedColor, dtPlanContactDetails);


                /************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToBayView(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }
                if (ddlLTDNoOfPlan.SelectedIndex == 0 && ddlSTDNoOfPlan.SelectedIndex == 0)
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "DisabilityInsurance");
                }

                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected);
                wobj.office.oWordDoc.TablesOfContents[1].Update(); /***** update table of Contact ************/
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                /// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        #endregion

        #region Created by shravan --- Mosaic Summary
        protected string CreateSummaryTemplate_Mosaic(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRCData> BRCList = new List<BRCData>();
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            WriteTemplate_Mosaic wr = new WriteTemplate_Mosaic();
            bool isBRCSelected = false;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Mosaic")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Mosaic"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Mosaic_Template_V1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Mosaic/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();
                objCommFun.LoadPlanTypeIds();
                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }

                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }
                }

                #region List of Plans of voluntary
                //Life and AD&D
                List<int> ADnDPlans = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> VoluntaryLifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();

                //Voluntary Life
                List<int> VoluntaryLife = new List<int>();
                List<int> VoluntaryADnD = new List<int>();

                //STD and LTD
                List<int> LTD = new List<int>();
                List<int> STD = new List<int>();
                List<int> VoluntarySTD = new List<int>();
                List<int> VoluntaryLTD = new List<int>();

                foreach (DataRow row in PlanTable.Rows)
                {
                    if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        ADnDPlans.Add(Convert.ToInt32(row["productID"]));
                    }

                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        VoluntaryLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower())
                    {
                        VoluntaryADnD.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntarySTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            STD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            LTD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                }
                #endregion

                #region GET BRC DETAILS

                if (!string.IsNullOrEmpty(Account_Office))
                {

                    BRCList = bp.GetBRCDetails(Account_Office);

                    if (BRCList.Count <= 0)
                    {
                        BRCData brcData = new BRCData();
                        brcData.BRCId = 0;
                        brcData.BRCName = "";
                        brcData.BRCLocation = "";
                        brcData.BRCEmail = "";
                        brcData.BRCPhone = "";
                        brcData.BRCFax = "";
                        brcData.BRCTimezone = "";
                        brcData.BRCDayHours = "";
                        BRCList.Add(brcData);
                    }
                }
                #endregion

                if (ddlBRC.SelectedValue == "YES")
                {
                    isBRCSelected = true;
                }

                string selectedClient = Convert.ToString(ddlClient.SelectedItem.Text.Trim());
                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                string color = "";

                wr.Write_CommonFieldToMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, ProductDS, EligibilityDS, Emp, selectedClient, ddlOffice, ddlHRContact, ContactList, AccountDS, arrAcctContact, BRCList);

                wr.WriteMedicalSectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProducts["Medical"], dictContributionMap, ContributionDS);

                if (dictProducts.ContainsKey("Dental"))
                {
                    wr.WriteDentalSectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProducts["Dental"], dictContributionMap, ContributionDS);
                }

                if (dictProductMap.ContainsKey("Vision"))
                {
                    wr.WriteVisionSectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProducts["Vision"], dictContributionMap, ContributionDS);
                }


                if (dictProductMap.ContainsKey("Life and AD&D"))
                {
                    if (ADnDPlans.Count > 0)
                        wr.WriteADandDSectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADnDPlans);
                    if (LifeAndADnDPlans.Count > 0)
                        wr.WriteLifeADDToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans, VoluntaryLifeAndADnDPlans);
                    if (GroupTermLife.Count > 0)
                        wr.WriteGroupLifeADDTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                }
                if (dictProductMap.ContainsKey("HSA"))
                    wr.WritHSASectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HSA"]);

                if (dictProductMap.ContainsKey("HRA"))
                    wr.WritHRASectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HRA"]);

                if (dictProductMap.ContainsKey("STD"))
                    wr.WriteSTDSectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], STD, VoluntarySTD);

                if (dictProductMap.ContainsKey("LTD"))
                    wr.WriteLTDSectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], LTD, VoluntaryLTD);

                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteFSASectionToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);

                if (dictProductMap.ContainsKey("Voluntary Life"))
                    wr.WriteVoluntaryLifeTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, RateDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, dictProductMap["Voluntary Life"], VoluntaryLife, VoluntaryADnD);

                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wr.WriteAdditionalProductToTemplateMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanInfoTable);
                ////Loading Contact details 
                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                DataTable dtblContact = Session["PlanContactTable"] as DataTable;
                wr.WriteContactinformationToMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, dtblContact, CarrierSpecific, dictProductMap);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected, STD, LTD, VoluntarySTD, VoluntaryLTD, VoluntaryLifeAndADnDPlans, VoluntaryLife, VoluntaryADnD);

                /************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToMosaic(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);


                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        #endregion

        #region Created by Vaibhav - for Tabs
        protected string CreateSummaryTemplate_Tabs(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            WriteTemplate_Tabs wr = new WriteTemplate_Tabs();
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();

            SessionId = Session["SessionId"].ToString();

            bool isBRCSelected = false;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Tabs")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Tabs"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/TabsGuide_V1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Tabs/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();
                objCommFun.LoadPlanTypeIds();
                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }

                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }
                }

                #region List of Plans of voluntary
                //Life and AD&D
                List<int> ADnDPlans = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> VoluntaryLifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();

                //Voluntary Life
                List<int> VoluntaryLife = new List<int>();
                List<int> VoluntaryADnD = new List<int>();

                //STD and LTD
                List<int> LTD = new List<int>();
                List<int> STD = new List<int>();
                List<int> VoluntarySTD = new List<int>();
                List<int> VoluntaryLTD = new List<int>();

                foreach (DataRow row in PlanTable.Rows)
                {
                    if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        ADnDPlans.Add(Convert.ToInt32(row["productID"]));
                    }

                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        VoluntaryLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower())
                    {
                        VoluntaryADnD.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntarySTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            STD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            LTD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                }
                #endregion

                if (ddlBRC.SelectedValue == "YES")
                {
                    isBRCSelected = true;
                }

                string selectedClient = Convert.ToString(ddlClient.SelectedItem.Text.Trim());
                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                string color = "";
                wr.getBookmarks();
                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToTabs(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//
                wr.Write_CommonFieldToTabs(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, ProductDS, EligibilityDS, Emp, selectedClient, ddlOffice, ddlHRContact, ContactList, AccountDS, arrAcctContact, BRCDataList);
                if (dictProductMap.ContainsKey("Life and AD&D"))
                {
                    if (ADnDPlans.Count > 0)
                        wr.WriteADandDSectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADnDPlans);
                    if (LifeAndADnDPlans.Count > 0)
                        wr.WriteLifeADDToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans, VoluntaryLifeAndADnDPlans);
                    if (GroupTermLife.Count > 0)
                        wr.WriteGroupLifeADDTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                }

                if (dictProductMap.ContainsKey("Voluntary Life"))
                    wr.WriteVoluntaryLifeTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, RateDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, dictProductMap["Voluntary Life"], VoluntaryLife, VoluntaryADnD);

                if (dictProductMap.ContainsKey("STD"))
                    wr.WriteSTDSectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], STD, VoluntarySTD);

                if (dictProductMap.ContainsKey("LTD"))
                    wr.WriteLTDSectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], LTD, VoluntaryLTD);

                if (dictProductMap.ContainsKey("HSA"))
                    wr.WritHSASectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HSA"]);

                if (dictProductMap.ContainsKey("HRA"))
                    wr.WritHRASectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HRA"]);

                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteFSASectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);


                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToTabs(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);

                wr.WriteAdditionalProductToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanInfoTable);

                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                DataTable dtblContact = Session["PlanContactTable"] as DataTable;
                wr.WriteContactinformationToTabs(wobj.office.oWordDoc, wobj.office.oWordApp, dtblContact, CarrierSpecific, dictProductMap);

                wr.WriteNoticeSectionToTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }


                //Sections having tables dynamically generated are kept in bottom to manage table index
                if (dictProductMap.ContainsKey("Vision"))
                {
                    wr.WriteVisionSectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProducts["Vision"], dictContributionMap, ContributionDS);
                }
                if (dictProducts.ContainsKey("Dental"))
                {
                    wr.WriteDentalSectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProducts["Dental"], dictContributionMap, ContributionDS);
                }
                wr.WriteMedicalSectionToTemplateTabs(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProducts["Medical"], dictContributionMap, ContributionDS);
                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected, STD, LTD, VoluntarySTD, VoluntaryLTD, VoluntaryLifeAndADnDPlans, VoluntaryLife, VoluntaryADnD);

                /************************************ADDED BY AMOGH FOR TOC ************/
                bool isAllPlansSelected = false;
                if (ddlLifeADDPlanName1.SelectedIndex > 0 && ddlLifeADDPlanName2.SelectedIndex > 0 && ddlSTDPlanName1.SelectedIndex > 0 && ddlSTDPlanName2.SelectedIndex > 0 && ddlLTDPlanName1.SelectedIndex > 0 && ddlLTDPlanName2.SelectedIndex > 0)
                {
                    isAllPlansSelected = true;
                }

                wobj.office.oWordDoc.Save();
                wr.WriteTableOfContant(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ddlAnnualLegalNotice, ddlChipNotice, BRCDataList, ddlBRCSelectedValue, PlanInfoTable, isAllPlansSelected);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);


                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        #endregion

        #region Created by Amogh - For Mountain Guide Summery
        protected string CreateSummaryTemplate_Mountain(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRCData> BRCList = new List<BRCData>();
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            WriteTemplate_MountainGuide wr = new WriteTemplate_MountainGuide();
            bool isBRCSelected = false;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Mountain")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Mountain"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_Mountain_Guide.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Mountain/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();
                objCommFun.LoadPlanTypeIds();
                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();

                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }

                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }
                }

                #region List of Plans of voluntary
                //Life and AD&D
                List<int> ADnDPlans = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> VoluntaryLifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();

                //Voluntary Life
                List<int> VoluntaryLife = new List<int>();
                List<int> VoluntaryADnD = new List<int>();

                //STD and LTD
                List<int> LTD = new List<int>();
                List<int> STD = new List<int>();
                List<int> VoluntarySTD = new List<int>();
                List<int> VoluntaryLTD = new List<int>();

                foreach (DataRow row in PlanTable.Rows)
                {
                    if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        ADnDPlans.Add(Convert.ToInt32(row["productID"]));
                    }

                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        VoluntaryLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower())
                    {
                        VoluntaryADnD.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntarySTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            STD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            LTD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                }
                #endregion

                #region GET BRC DETAILS

                if (!string.IsNullOrEmpty(Account_Office))
                {

                    BRCList = bp.GetBRCDetails(Account_Office);

                    if (BRCList.Count <= 0)
                    {
                        BRCData brcData = new BRCData();
                        brcData.BRCId = 0;
                        brcData.BRCName = "";
                        brcData.BRCLocation = "";
                        brcData.BRCEmail = "";
                        brcData.BRCPhone = "";
                        brcData.BRCFax = "";
                        brcData.BRCTimezone = "";
                        brcData.BRCDayHours = "";
                        BRCList.Add(brcData);
                    }
                }
                #endregion

                if (ddlBRC.SelectedValue == "YES")
                {
                    isBRCSelected = true;
                }

                string selectedClient = Convert.ToString(ddlClient.SelectedItem.Text.Trim());
                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToMountain(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                string color = "";

                wr.Write_CommonFieldToBayView(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, ProductDS, EligibilityDS, Emp, selectedClient, ddlOffice, ddlHRContact, ContactList, AccountDS, arrAcctContact, BRCList);

                wr.WriteMedicalSectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProducts["Medical"], dictContributionMap, ContributionDS);

                if (dictProducts.ContainsKey("Dental"))
                {
                    wr.WriteDentalSectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProducts["Dental"], dictContributionMap, ContributionDS);
                }

                if (dictProductMap.ContainsKey("Vision"))
                {
                    wr.WriteVisionSectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProducts["Vision"], dictContributionMap, ContributionDS);
                }

                if (dictProductMap.ContainsKey("HSA"))
                    wr.WritHSASectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HSA"]);
                if (dictProductMap.ContainsKey("HRA"))
                    wr.WritHRASectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HRA"]);

                if (dictProductMap.ContainsKey("Life and AD&D"))
                {
                    if (ADnDPlans.Count > 0)
                        wr.WriteADandDSectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADnDPlans);
                    if (LifeAndADnDPlans.Count > 0)
                        wr.WriteLifeADDToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans, VoluntaryLifeAndADnDPlans);
                    if (GroupTermLife.Count > 0)
                        wr.WriteGroupLifeADDTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                }

                if (dictProductMap.ContainsKey("STD"))
                    wr.WriteSTDSectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], STD, VoluntarySTD);

                if (dictProductMap.ContainsKey("LTD"))
                    wr.WriteLTDSectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], LTD, VoluntaryLTD);

                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteFSASectionToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);

                if (dictProductMap.ContainsKey("Voluntary Life"))
                    wr.WriteVoluntaryLifeTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, RateDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, dictProductMap["Voluntary Life"], VoluntaryLife, VoluntaryADnD);

                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToMountain(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wr.WriteAdditionalProductToTemplateMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanInfoTable);

                ////******************** Loading Contact Details ***************////
                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                DataTable dtblContact = Session["PlanContactTable"] as DataTable;
                wr.WriteContactinformationToMountain(wobj.office.oWordDoc, wobj.office.oWordApp, dtblContact, CarrierSpecific, dictProductMap);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }

                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected, STD, LTD, VoluntarySTD, VoluntaryLTD, VoluntaryLifeAndADnDPlans, VoluntaryLife, VoluntaryADnD);

                ///************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToMountain(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        #endregion

        #region Created by Aarti - For Spot Light
        protected string CreateSummaryTemplate_SpotLight(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            WriteTemplate_SpotLight wr = new WriteTemplate_SpotLight();
            bool isBRCSelected = false;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/SpotLight")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/SpotLight"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_SpotLight_Guide_V1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/SpotLight/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();
                objCommFun.LoadPlanTypeIds();
                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();
                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }


                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }

                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }
                }

                #region List of Plans of voluntary
                //Life and AD&D
                List<int> ADnDPlans = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> VoluntaryLifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();

                //Voluntary Life
                List<int> VoluntaryLife = new List<int>();
                List<int> VoluntaryADnD = new List<int>();

                //STD and LTD
                List<int> LTD = new List<int>();
                List<int> STD = new List<int>();
                List<int> VoluntarySTD = new List<int>();
                List<int> VoluntaryLTD = new List<int>();

                foreach (DataRow row in PlanTable.Rows)
                {
                    if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        ADnDPlans.Add(Convert.ToInt32(row["productID"]));
                    }

                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        VoluntaryLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower())
                    {
                        VoluntaryADnD.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntarySTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            STD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            LTD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                }
                #endregion

                if (ddlBRC.SelectedValue == "YES")
                    isBRCSelected = true;
                else if (ddlBRC.SelectedValue == "NO")
                    isBRCSelected = false;

                string selectedClient = Convert.ToString(ddlClient.SelectedItem.Text.Trim());
                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }


                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                string color = "";

                wr.Write_CommonFieldToSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, ProductDS, EligibilityDS, Emp, selectedClient, ddlOffice, ddlHRContact, ContactList, AccountDS, arrAcctContact, BRCDataList);
                wr.WriteMedicalSectionToTemplateSpotLight_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProducts["Medical"], dictContributionMap, ContributionDS);
                if (dictProducts.ContainsKey("Dental"))
                {
                    wr.WriteDentalSectionToTemplateSpotLight_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProducts["Dental"], dictContributionMap, ContributionDS);
                }
                if (dictProducts.ContainsKey("Vision"))
                {
                    wr.WriteVisionSectionToTemplateSpotLight_v1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProducts["Vision"], dictContributionMap, ContributionDS);
                }
                if (dictProductMap.ContainsKey("Life and AD&D"))
                {

                    if (ADnDPlans.Count > 0)
                        wr.WriteADandDSectionToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADnDPlans);
                    if (LifeAndADnDPlans.Count > 0)
                        wr.WriteLifeADDToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans, VoluntaryLifeAndADnDPlans);
                    if (GroupTermLife.Count > 0)
                        wr.WriteGroupLifeADDTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                }
                if (dictProductMap.ContainsKey("HSA"))
                    wr.WritHSASectionToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HSA"]);

                if (dictProductMap.ContainsKey("HRA"))
                    wr.WritHRASectionToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HRA"]);



                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteFSASectionToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);


                if (dictProductMap.ContainsKey("STD"))
                    wr.WriteSTDSectionToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], STD, VoluntarySTD);

                if (dictProductMap.ContainsKey("LTD"))
                    wr.WriteLTDSectionToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], LTD, VoluntaryLTD);


                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);

                if (dictProductMap.ContainsKey("Voluntary Life"))
                    wr.WriteVoluntaryLifeTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, RateDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, dictProductMap["Voluntary Life"], VoluntaryLife, VoluntaryADnD);


                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wr.WriteAdditionalProductToTemplateSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanInfoTable);
                ////Loading Contact details 
                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                DataTable dtblContact = Session["PlanContactTable"] as DataTable;
                wr.WriteContactinformationToSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, dtblContact, CarrierSpecific, dictProductMap);

                /************* CALLING FOR ADDING ANNUL LEGAL NOTICE / CHIP NOTICE  **********/
                wr.WriteNoticeSectionToSpotLight(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }
                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected, STD, LTD, VoluntarySTD, VoluntaryLTD, VoluntaryLifeAndADnDPlans, VoluntaryLife, VoluntaryADnD);

                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);


                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        #endregion

        #region Created by Aarti - for Spring Field
        protected string CreateSummaryTemplate_SpringField(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            WriteTemplate_SpringField wr = new WriteTemplate_SpringField();
            List<BRCData> BRCDataList = new List<BRCData>();
            BRCDataList = (List<BRCData>)Session["BRCData"];
            string ddlBRCSelectedValue = ddlBRC.SelectedItem.Value.Trim();
            bool isBRCSelected = false;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/SpringField")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/SpringField"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Springfield.docm";



                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/SpringField/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                LoadColumnIdArrayList();
                objCommFun.LoadPlanTypeIds();
                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }

                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }
                }

                #region List of Plans of voluntary
                //Life and AD&D
                List<int> ADnDPlans = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> VoluntaryLifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();

                //Voluntary Life
                List<int> VoluntaryLife = new List<int>();
                List<int> VoluntaryADnD = new List<int>();

                //STD and LTD
                List<int> LTD = new List<int>();
                List<int> STD = new List<int>();
                List<int> VoluntarySTD = new List<int>();
                List<int> VoluntaryLTD = new List<int>();

                foreach (DataRow row in PlanTable.Rows)
                {
                    if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        ADnDPlans.Add(Convert.ToInt32(row["productID"]));
                    }

                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        VoluntaryLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower())
                    {
                        VoluntaryADnD.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntarySTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            STD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (wr.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLTD.Add(Convert.ToInt32(row["productID"]));
                        }
                        else
                        {
                            LTD.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                }
                #endregion

                if (ddlBRC.SelectedValue == "YES")
                {
                    isBRCSelected = true;
                }

                string selectedClient = Convert.ToString(ddlClient.SelectedItem.Text.Trim());
                DataTable Emp = new DataTable();
                if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Value))
                {
                    Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                }

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wr.WriteEligibilityToSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                wr.getBookmarks();
                if (dictProductMap.ContainsKey("Life and AD&D"))
                {
                    if (ADnDPlans.Count > 0)
                        wr.WriteADandDSectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADnDPlans);
                    if (LifeAndADnDPlans.Count > 0)
                        wr.WriteLifeADDToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans, VoluntaryLifeAndADnDPlans);
                    if (GroupTermLife.Count > 0)
                        wr.WriteGroupLifeADDTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                }

                if (dictProductMap.ContainsKey("Voluntary Life"))
                    wr.WriteVoluntaryLifeTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, RateDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, dictProductMap["Voluntary Life"], VoluntaryLife, VoluntaryADnD);

                if (dictProductMap.ContainsKey("STD"))
                    wr.WriteSTDSectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, dictProductMap["STD"], STD, VoluntarySTD);

                if (dictProductMap.ContainsKey("LTD"))
                    wr.WriteLTDSectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, dictProductMap["LTD"], LTD, VoluntaryLTD);


                wr.Write_CommonFieldToSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, ProductDS, EligibilityDS, Emp, selectedClient, ddlOffice, ddlHRContact, ContactList, AccountDS, arrAcctContact, BRCDataList);
                if (dictProductMap.ContainsKey("HSA"))
                    wr.WritHSASectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HSA"]);

                if (dictProductMap.ContainsKey("HRA"))
                    wr.WritHRASectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HRA"]);

                if (dictProductMap.ContainsKey("FSA"))
                    wr.WriteFSASectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);

                if (dictProductMap.ContainsKey("EAP"))
                    wr.WriteEAPSectionToSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);

                wr.WriteAdditionalProductToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanInfoTable);

                DataTable dtPlanContactDetails = new DataTable();
                dtPlanContactDetails = objCommFun.GetDataTableFromGridView_ForContactDetails(dvPlanContacts, PlanTable, (DataTable)Session["DataTable_PlanContactInfo"]);
                DataTable dtblContact = Session["PlanContactTable"] as DataTable;
                wr.WriteContactinformationToSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, dtblContact, CarrierSpecific, dictProductMap);
                string color = "";
                wr.WriteNoticeSectionToSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);

                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included") //&& ddlCreditableCoverage.SelectedValue =="Not Included"
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }
                if (dictProductMap.ContainsKey("Vision"))
                {
                    wr.WriteVisionSectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProducts["Vision"], dictContributionMap, ContributionDS);
                }
                if (dictProducts.ContainsKey("Dental"))
                {
                    wr.WriteDentalSectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, dictProducts["Dental"], dictContributionMap, ContributionDS);
                }

                wr.WriteMedicalSectionToTemplateSpringField(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, ddlClient, PlanTable, ProductDS, BenefitDS, EligibilityDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, dictProducts["Medical"], dictContributionMap, ContributionDS);
                wr.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected, STD, LTD, VoluntarySTD, VoluntaryLTD, VoluntaryLifeAndADnDPlans, VoluntaryLife, VoluntaryADnD);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        #endregion

        #region Created by Shravan   -- FAQv2
        protected string CreateSummary_FAQv2(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRCData> BRCList = new List<BRCData>();
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            bool isBRCSelected = false;
            string color = "";

            #region GET BRC DETAILS
            if (!string.IsNullOrEmpty(Account_Office))
            {

                BRCList = bp.GetBRCDetails(Account_Office);

                if (BRCList.Count <= 0)
                {
                    BRCData brcData = new BRCData();
                    brcData.BRCId = 0;
                    brcData.BRCName = "";
                    brcData.BRCLocation = "";
                    brcData.BRCEmail = "";
                    brcData.BRCPhone = "";
                    brcData.BRCFax = "";
                    brcData.BRCTimezone = "";
                    brcData.BRCDayHours = "";
                    BRCList.Add(brcData);
                }
            }
            #endregion

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report2")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report2"));
                }

                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary_FAQ_v2_Template.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report2/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();

                Dictionary<string, Dictionary<int, List<int>>> dictProductMap = new Dictionary<string, Dictionary<int, List<int>>>();
                Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>> dictProducts = new Dictionary<string, Dictionary<string, Dictionary<int, List<int>>>>();
                Dictionary<int, List<int>> dictContributionMap = new Dictionary<int, List<int>>();
                foreach (DataRow dr in PlanTable.Rows)
                {
                    string ProductType = dr["PlanType"].ToString();
                    string ProductTypeDescription = dr["ProductTypeDescription"].ToString();
                    int ProductId = int.Parse(dr["ProductId"].ToString());
                    int BenefitSummaryID = int.Parse(dr["SummaryId"].ToString());
                    int ContributionID = int.Parse(dr["ContributionId"].ToString());
                    int ContributionId_2 = int.Parse(dr["ContributionId_2"].ToString());

                    if (!dictProducts.ContainsKey(ProductType))
                    {
                        dictProducts[ProductType] = new Dictionary<string, Dictionary<int, List<int>>>();
                    }
                    if (!dictProducts[ProductType].ContainsKey(ProductTypeDescription))
                    {
                        dictProducts[ProductType][ProductTypeDescription] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription].ContainsKey(ProductId))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId] = new List<int>();
                    }
                    if (!dictProducts[ProductType][ProductTypeDescription][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProducts[ProductType][ProductTypeDescription][ProductId].Add(BenefitSummaryID);
                    }

                    if (!dictProductMap.ContainsKey(ProductType))
                    {
                        dictProductMap[ProductType] = new Dictionary<int, List<int>>();
                    }
                    if (!dictProductMap[ProductType].ContainsKey(ProductId))
                    {
                        dictProductMap[ProductType][ProductId] = new List<int>();
                    }
                    if (!dictProductMap[ProductType][ProductId].Contains(BenefitSummaryID))
                    {
                        dictProductMap[ProductType][ProductId].Add(BenefitSummaryID);
                    }

                    ////Added by Amogh For Contribution
                    if (!dictContributionMap.ContainsKey(BenefitSummaryID))
                    {
                        dictContributionMap[BenefitSummaryID] = new List<int>();
                    }
                    if (ContributionID > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionID))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionID);
                    }
                    if (ContributionId_2 > 0 && !dictContributionMap[BenefitSummaryID].Contains(ContributionId_2))
                    {
                        dictContributionMap[BenefitSummaryID].Add(ContributionId_2);
                    }
                }

                if (ddlBRC.SelectedValue == "YES")
                {
                    isBRCSelected = true;
                }

                WriteTemplate_FAQSummaryV2 wt = new WriteTemplate_FAQSummaryV2();

                #region List of Plans of voluntary
                //Life and AD&D
                List<int> ADnDPlans = new List<int>();
                List<int> LifeAndADnDPlans = new List<int>();
                List<int> VoluntaryLifeAndADnDPlans = new List<int>();
                List<int> GroupTermLife = new List<int>();

                //Voluntary Life
                List<int> VoluntaryLife = new List<int>();
                List<int> VoluntaryADnD = new List<int>();

                //STD and LTD
                List<int> LTD = new List<int>();
                List<int> STD = new List<int>();
                List<int> VoluntarySTD = new List<int>();
                List<int> VoluntaryLTD = new List<int>();

                foreach (DataRow row in PlanTable.Rows)
                {
                    if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        if (wt.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLifeAndADnDPlans.Add(Convert.ToInt32(row["productID"]));
                        }
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        ADnDPlans.Add(Convert.ToInt32(row["productID"]));
                    }

                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        VoluntaryLife.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower())
                    {
                        VoluntaryADnD.Add(Convert.ToInt32(row["productID"]));
                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {

                        STD.Add(Convert.ToInt32(row["productID"]));
                        if (wt.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntarySTD.Add(Convert.ToInt32(row["productID"]));
                        }

                    }
                    else if (row["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        LTD.Add(Convert.ToInt32(row["productID"]));
                        if (wt.IsProductVoluntary(Convert.ToInt32(row["productID"]), SessionId))
                        {
                            VoluntaryLTD.Add(Convert.ToInt32(row["productID"]));
                        }

                    }
                }
                #endregion

                //************* START Elibibility Change ********************************//
                int EleigibilityRuleId = 0;
                if (ddlEligibility.SelectedIndex > 0)
                    EleigibilityRuleId = Convert.ToInt32(ddlEligibility.SelectedValue);
                wt.WriteEligibilityToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Convert.ToInt32(ddlClient.SelectedValue), EleigibilityRuleId, SessionId);
                //************* END Elibibility Change ********************************//

                wt.WriteFieldToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList);
                wt.WriteMedicalSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, ddlMedicalNoOfPlan.SelectedItem.Text, CarrierSpecific);
                wt.WritePrescriptionDrugsSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList);
                if (dictProductMap.ContainsKey("HSA"))
                    wt.WritHSASectionToTemplateFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HSA"]);

                if (dictProductMap.ContainsKey("HRA"))
                    wt.WritHRASectionToTemplateFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, dictProductMap["HRA"]);
                wt.WriteDentalSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, CarrierSpecific, PlanTypeSpecific);
                wt.WriteVisionSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific, VisionBenefitColumnIdOutNetworkList);
                if (dictProductMap.ContainsKey("Life and AD&D"))
                {
                    if (ADnDPlans.Count > 0)
                        wt.WriteADandDSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, dictProductMap["Life and AD&D"], ADnDPlans);
                    if (LifeAndADnDPlans.Count > 0)
                        wt.WriteLifeADDToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, dictProductMap["Life and AD&D"], LifeAndADnDPlans, VoluntaryLifeAndADnDPlans);
                    if (GroupTermLife.Count > 0)
                        wt.WriteGroupLifeADDtoFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList, dictProductMap["Life and AD&D"], GroupTermLife);
                }
                wt.WriteSTDSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlSTDNoOfPlan, ddlLTDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteLTDSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlSTDNoOfPlan, ddlLTDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteVoluntaryLifeToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, VoluntaryLife, VoluntaryADnD);
                if (dictProductMap.ContainsKey("FSA"))
                    wt.WriteFSASectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, dictProductMap["FSA"]);
                if (dictProductMap.ContainsKey("EAP"))
                    wt.WriteEAPSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                //wt.WriteMonthlyPremiumSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ContributionDS);
                wt.WriteContribution(wobj.office.oWordDoc, wobj.office.oWordApp, dictContributionMap, ContributionDS, PlanTable);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, VoluntaryLife, VoluntaryADnD);
                wt.WriteVoluntarySTDandLTDMonthlyPremiumSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteContactInformationToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable);



                if (ddlChipNotice.SelectedValue == "Not Included" && ddlAnnualLegalNotice.SelectedValue == "Not Included" && ddlMarketplaceCoverage.SelectedValue == "Not Included") // && ddlCreditableCoverage.SelectedValue =="Not Included")
                {
                    wt.DeleteIndivialBookmark(wobj.office.oWordDoc, "LegalNoticeSectionT6");
                }
                else
                {
                    wt.WriteNoticeSectionToFAQv2(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                }

                wt.DeleteEmptyRows(wobj.office.oWordDoc, dictProductMap);
                wt.DeleteBookmarks(wobj.office.oWordDoc, wobj.office.oWordApp, dictProductMap, PlanInfoTable, isBRCSelected, STD, LTD, VoluntarySTD, VoluntaryLTD);
                wt.DeleteRemainingFields(wobj.office.oWordDoc);
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                ////#region Storing the activity logs

                ////string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text.Trim();
                ////string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_3 = ddlMedicalPlanName1.SelectedItem.Text;
                ////string AdditionalCrtieriaOption_4 = ddlMedicalBenefitSummary1.SelectedItem.Text;
                ////DicActivityLog.Clear();
                ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                ////bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                ////#endregion

                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }

            return (wobj.Save_File);
        }
        #endregion

        public bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }
    }
}
