﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.Common.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using BenefitPointSummaryPortal.BAL.RFPReports;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace BenefitPointSummaryPortal.View
{
    public partial class RFPReport : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();

        string SessionId = "";
        List<int> ApplicablePlanTypeIds = new List<int>();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        Dictionary<string, string> dictOrientationOption = new Dictionary<string, string>();
        List<string> lstAnalysisLOCOptions = new List<string>() { "Dental", "Vision", "Life and AD&D", "Short Term Disability", "Long Term Disability", "Absence Management", "EAP" };
        List<int> lstMedicalPlans = new List<int>() { 100, 110, 120, 130, 140, 150, 160, 170, 233, 420, 173, 235 };

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                DateTime dtCurrentDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                DateTime MinDate = dtCurrentDate;
                int cnt = 0;
                while (cnt <= 4)
                {
                    cnt++;
                    MinDate = MinDate.AddDays(1);
                    if (MinDate.DayOfWeek == DayOfWeek.Saturday || MinDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        cnt--;
                    }
                }


                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate(" + (MinDate.Month - 1).ToString() + "," + MinDate.Day.ToString() + "," + MinDate.Year.ToString() + ");</Script>", false);
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                LoadOrientationOptions();
                if (!IsPostBack)
                {
                    BindState();
                    ddlcontents.SelectedValue = "Ancillary_Intake_Form_REP";
                    ddlcontents_SelectedIndexChanged(null, null);
                    mvRFPReport.ActiveViewIndex = 0;
                    btnSummary.OnClientClick = "javascript:return ValidateCriteriaPage1();";
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    objCommFun.GetUserDetails();
                    txtsearch.Focus();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            }
        }
        #region functions
        private void Handle_ClientChange()
        {
            if (ddlcontents.SelectedValue == "0")
            {
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                txtEffectiveRenewalDate.Text = "";
                txtMeetingDate.Text = "";
                txtRFPDueDate.Text = "";
                ddlAdditionalLOC.SelectedValue = "0";
            }
            if (ddlcontents.SelectedValue == "Ancillary_Intake_Form_REP")
            {
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                txtEffectiveRenewalDate.Text = "";
                txtMeetingDate.Text = "";
                txtRFPDueDate.Text = "";
                ddlAdditionalLOC.SelectedValue = "0";
                rdlPlanSection.SelectedIndex = 0;
            }
        }
        private void LoadOrientationOptions()
        {
            dictOrientationOption["Ancillary_Analysis"] = "Landscape";
            dictOrientationOption["Ancillary_Intake_Form_REP"] = "Portrait";
        }
        private void BindState()
        {
            //USI State
            DataTable dtOfficeState = new DataTable();
            dtOfficeState = bp.GetOfficeStateList();
            ddlUSI_State.DataSource = dtOfficeState;
            ddlUSI_State.DataBind();
            ddlUSI_State.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlUSI_State.SelectedIndex = 0;
            ddlUSI_State_SelectedIndexChanged(null, null);
        }
        private void LoadPlanTypeIds()
        {
            if (ddlcontents.SelectedValue == "Ancillary_Intake_Form_REP")
            {
                ApplicablePlanTypeIds.Add(180);//Dental
                ApplicablePlanTypeIds.Add(210);//Dental
                ApplicablePlanTypeIds.Add(190);//Dental
                ApplicablePlanTypeIds.Add(200);//Dental
                ApplicablePlanTypeIds.Add(230);//Dental
                ApplicablePlanTypeIds.Add(250);//Group Term
                ApplicablePlanTypeIds.Add(1150);
                ApplicablePlanTypeIds.Add(240);
                ApplicablePlanTypeIds.Add(1230);
                ApplicablePlanTypeIds.Add(270);
                ApplicablePlanTypeIds.Add(260);
                ApplicablePlanTypeIds.Add(280);
                ApplicablePlanTypeIds.Add(290);
                ApplicablePlanTypeIds.Add(294);
                ApplicablePlanTypeIds.Add(297);
                ApplicablePlanTypeIds.Add(295);
                ApplicablePlanTypeIds.Add(293);
                ApplicablePlanTypeIds.Add(1190);
                ApplicablePlanTypeIds.Add(292);
                ApplicablePlanTypeIds.Add(300);
                ApplicablePlanTypeIds.Add(1180);
                ApplicablePlanTypeIds.Add(5330);
                ApplicablePlanTypeIds.Add(310);
                ApplicablePlanTypeIds.Add(1400);
                ApplicablePlanTypeIds.Add(5060);
                ApplicablePlanTypeIds.Add(1160);
                ApplicablePlanTypeIds.Add(5500);

                //Medical Plan Types

                ApplicablePlanTypeIds.Add(100);
                ApplicablePlanTypeIds.Add(110);
                ApplicablePlanTypeIds.Add(120);
                ApplicablePlanTypeIds.Add(130);
                ApplicablePlanTypeIds.Add(140);
                ApplicablePlanTypeIds.Add(150);
                ApplicablePlanTypeIds.Add(160);
                ApplicablePlanTypeIds.Add(170);
                ApplicablePlanTypeIds.Add(173);
                ApplicablePlanTypeIds.Add(233);
                ApplicablePlanTypeIds.Add(235);
                ApplicablePlanTypeIds.Add(420);


            }
            if (ddlcontents.SelectedValue == "Ancillary_Analysis")
            {
                ApplicablePlanTypeIds.Add(180);
                ApplicablePlanTypeIds.Add(190);
                ApplicablePlanTypeIds.Add(200);
                ApplicablePlanTypeIds.Add(210);
                ApplicablePlanTypeIds.Add(230);
                ApplicablePlanTypeIds.Add(240);
                ApplicablePlanTypeIds.Add(250);
                ApplicablePlanTypeIds.Add(260);
                ApplicablePlanTypeIds.Add(270);
                ApplicablePlanTypeIds.Add(280);
                ApplicablePlanTypeIds.Add(290);
                ApplicablePlanTypeIds.Add(292);
                ApplicablePlanTypeIds.Add(293);
                ApplicablePlanTypeIds.Add(294);
                ApplicablePlanTypeIds.Add(295);
                ApplicablePlanTypeIds.Add(297);
                ApplicablePlanTypeIds.Add(300);
                ApplicablePlanTypeIds.Add(310);
                ApplicablePlanTypeIds.Add(1150);
                ApplicablePlanTypeIds.Add(1230);
                ApplicablePlanTypeIds.Add(5330);

            }


        }
        private void LoadPlans()
        {
            List<Plan> PlanList = new List<Plan>();
            DataTable dtblPlan = CreatePlanInfoTable();
            if (Convert.ToString(Session["Summary"]) == "RFPReport")
            {
                LoadPlanTypeIds();
                List<Plan> TempPlan = new List<Plan>();
                Session["PlanList"] = TempPlan;
                SessionId = Session["SessionId"].ToString();
                if (ddlClient.SelectedIndex > 0)
                {
                    TempPlan = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId, "RFPReport");

                    foreach (Plan objPlan in TempPlan)
                    {
                        if (ApplicablePlanTypeIds.Contains(objPlan.ProductTypeId))
                        {
                            PlanList.Add(objPlan);
                            DataRow drNewRow = dtblPlan.NewRow();
                            drNewRow["Carrier"] = objPlan.CarrierName;
                            drNewRow["Name"] = objPlan.ProductName;
                            drNewRow["Effective"] = objPlan.EffectiveDate.ToString("MM/dd/yy");
                            drNewRow["Renewal"] = objPlan.RenewalDate.ToString("MM/dd/yy"); ;
                            drNewRow["PolicyNumber"] = objPlan.PolicyNumber;
                            drNewRow["ProductId"] = objPlan.ProductId;
                            drNewRow["ProductName"] = objPlan.ProductName;
                            drNewRow["ProductTypeId"] = objPlan.ProductTypeId;
                            drNewRow["PlanType"] = objPlan.ProductTypeDescription;
                            drNewRow["SummaryName"] = objPlan.SummaryName;
                            drNewRow["SummaryID"] = objPlan.SummaryID;
                            drNewRow["PlanNumber"] = objPlan.PolicyNumber;
                            dtblPlan.Rows.Add(drNewRow);
                        }
                    }
                }
            }
            Session["PlanList"] = PlanList;
        }
        private DataTable CreateLOCDataTable()
        {
            DataTable dtLOCData = new DataTable();
            dtLOCData.Columns.Add(new DataColumn("LOCName"));
            dtLOCData.Columns.Add(new DataColumn("SelectedPlan"));
            dtLOCData.Columns.Add(new DataColumn("CarrierName"));
            dtLOCData.Columns.Add(new DataColumn("ProductID"));
            dtLOCData.Columns.Add(new DataColumn("FundingType"));
            dtLOCData.Columns.Add(new DataColumn("Contribution"));
            dtLOCData.Columns.Add(new DataColumn("ApplicablePlanTypeIds"));
            dtLOCData.Columns.Add(new DataColumn("IsVoluntaryProduct"));
            dtLOCData.Columns.Add(new DataColumn("BidSpecifications"));
            dtLOCData.Columns.Add(new DataColumn("IsMultipleLOC"));

            DataRow drDental = dtLOCData.NewRow();
            drDental["LOCName"] = "Dental";
            drDental["SelectedPlan"] = "";
            drDental["ApplicablePlanTypeIds"] = "180,190,200,210";
            drDental["IsVoluntaryProduct"] = false;
            drDental["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drDental);

            DataRow drVision = dtLOCData.NewRow();
            drVision["LOCName"] = "Vision";
            drVision["SelectedPlan"] = "";
            drVision["ApplicablePlanTypeIds"] = "230";
            drVision["IsVoluntaryProduct"] = false;
            drVision["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drVision);

            DataRow drLifeADD = dtLOCData.NewRow();
            drLifeADD["LOCName"] = "Life / AD&D";
            drLifeADD["SelectedPlan"] = "";
            drLifeADD["ApplicablePlanTypeIds"] = "250,1150,240,1230,270";
            drLifeADD["IsVoluntaryProduct"] = false;
            drLifeADD["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drLifeADD);

            DataRow drVoluntaryLifeADD = dtLOCData.NewRow();
            drVoluntaryLifeADD["LOCName"] = "Voluntary Life / AD&D";
            drVoluntaryLifeADD["SelectedPlan"] = "";
            drVoluntaryLifeADD["ApplicablePlanTypeIds"] = "260,280";
            drVoluntaryLifeADD["IsVoluntaryProduct"] = false;
            drVoluntaryLifeADD["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drVoluntaryLifeADD);

            DataRow drShortTermDisability = dtLOCData.NewRow();
            drShortTermDisability["LOCName"] = "Short Term Disability";
            drShortTermDisability["SelectedPlan"] = "";
            drShortTermDisability["ApplicablePlanTypeIds"] = "290,294,297,295,293,292";
            drShortTermDisability["IsVoluntaryProduct"] = false;
            drShortTermDisability["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drShortTermDisability);

            DataRow drVoluntarySTD = dtLOCData.NewRow();
            drVoluntarySTD["LOCName"] = "Voluntary STD";
            drVoluntarySTD["SelectedPlan"] = "";
            drVoluntarySTD["ApplicablePlanTypeIds"] = "290";
            drVoluntarySTD["IsVoluntaryProduct"] = true;
            drVoluntarySTD["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drVoluntarySTD);

            DataRow drLongTermDisability = dtLOCData.NewRow();
            drLongTermDisability["LOCName"] = "Long Term Disability";
            drLongTermDisability["SelectedPlan"] = "";
            drLongTermDisability["ApplicablePlanTypeIds"] = "300";
            drLongTermDisability["IsVoluntaryProduct"] = false;
            drLongTermDisability["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drLongTermDisability);

            DataRow drVoluntaryLTD = dtLOCData.NewRow();
            drVoluntaryLTD["LOCName"] = "Voluntary LTD";
            drVoluntaryLTD["SelectedPlan"] = "";
            drVoluntaryLTD["ApplicablePlanTypeIds"] = "300";
            drVoluntaryLTD["IsVoluntaryProduct"] = true;
            drVoluntaryLTD["IsMultipleLOC"] = true;
            dtLOCData.Rows.Add(drVoluntaryLTD);

            DataRow drAbsenceManagement = dtLOCData.NewRow();
            drAbsenceManagement["LOCName"] = "Absence Management";
            drAbsenceManagement["SelectedPlan"] = "";
            drAbsenceManagement["ApplicablePlanTypeIds"] = "5330";
            drAbsenceManagement["IsVoluntaryProduct"] = false;
            drAbsenceManagement["IsMultipleLOC"] = false;
            dtLOCData.Rows.Add(drAbsenceManagement);

            DataRow drEAPAdministration = dtLOCData.NewRow();
            drEAPAdministration["LOCName"] = "EAP Administration";
            drEAPAdministration["SelectedPlan"] = "";
            drEAPAdministration["ApplicablePlanTypeIds"] = "310";
            drEAPAdministration["IsVoluntaryProduct"] = false;
            drEAPAdministration["IsMultipleLOC"] = false;
            dtLOCData.Rows.Add(drEAPAdministration);

            DataRow drCancer = dtLOCData.NewRow();
            drCancer["LOCName"] = "Cancer";
            drCancer["SelectedPlan"] = "";
            drCancer["ApplicablePlanTypeIds"] = "1400";
            drCancer["IsVoluntaryProduct"] = false;
            drCancer["IsMultipleLOC"] = false;
            dtLOCData.Rows.Add(drCancer);

            DataRow drHospital = dtLOCData.NewRow();
            drHospital["LOCName"] = "Hospital";
            drHospital["SelectedPlan"] = "";
            drHospital["ApplicablePlanTypeIds"] = "5060";
            drHospital["IsVoluntaryProduct"] = false;
            drHospital["IsMultipleLOC"] = false;
            dtLOCData.Rows.Add(drHospital);

            DataRow drCriticalIllness = dtLOCData.NewRow();
            drCriticalIllness["LOCName"] = "Critical Illness";
            drCriticalIllness["SelectedPlan"] = "";
            drCriticalIllness["ApplicablePlanTypeIds"] = "1160";
            drCriticalIllness["IsVoluntaryProduct"] = false;
            drCriticalIllness["IsMultipleLOC"] = false;
            dtLOCData.Rows.Add(drCriticalIllness);

            DataRow drAccident = dtLOCData.NewRow();
            drAccident["LOCName"] = "Accident";
            drAccident["SelectedPlan"] = "";
            drAccident["ApplicablePlanTypeIds"] = "5500";
            drAccident["IsVoluntaryProduct"] = false;
            drAccident["IsMultipleLOC"] = false;
            dtLOCData.Rows.Add(drAccident);

            return dtLOCData;
        }
        private DataTable CreateLOCDataTable_AnalysisTemplate()
        {
            DataTable dtLOCData = new DataTable();
            dtLOCData.Columns.Add(new DataColumn("LOCName"));
            dtLOCData.Columns.Add(new DataColumn("PlanType"));
            dtLOCData.Columns.Add(new DataColumn("AnalysisType"));
            dtLOCData.Columns.Add(new DataColumn("PlanName"));
            dtLOCData.Columns.Add(new DataColumn("ProductID"));
            dtLOCData.Columns.Add(new DataColumn("SelectedBenefitSummary"));
            dtLOCData.Columns.Add(new DataColumn("CarrierName"));
            return dtLOCData;
        }
        private string GetFundingType(string FundingType)
        {
            switch (FundingType.ToUpper())
            {
                case "FI":
                    FundingType = "Fully Insured";
                    break;
                case "SF":
                    FundingType = "Self Funded";
                    break;
            }
            return FundingType;
        }
        private string GetContributionsPlanName(string PlanName)
        {
            switch (PlanName.ToUpper())
            {
                case "ER PAID":
                    PlanName = "100% ER Paid";
                    break;
                case "EE PAID":
                    PlanName = "100% EE Paid";
                    break;
            }
            return PlanName;
        }
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private bool IsValidDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }
        protected void CreateAncillaryTemplate(string SessionId, DataSet AccountTeamMemberDS, DataSet AccountDS, string AccountOffice)
        {
            WriteAncillaryIntakeFormRFP wr = new WriteAncillaryIntakeFormRFP();
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            DataTable dtblPlansSelected = CreateLOCDataTable();
            List<Plan> lstTempPlan = Session["PlanList"] as List<Plan>;
            string BPUser_Name = string.Empty;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryIntakeFormRFPTemplate_06_25_19.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryRFPReport/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryRFPReport/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/RFPReports/Documents/Templates/AncillaryRFPReport/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                for (int i = 0; i < grdPlans.Rows.Count; i++)
                {
                    DropDownList ddlPlans = grdPlans.Rows[i].FindControl("ddlPlans") as DropDownList;
                    DropDownList ddlPlans_1 = grdPlans.Rows[i].FindControl("ddlPlans_1") as DropDownList;
                    DropDownList ddlPlans_2 = grdPlans.Rows[i].FindControl("ddlPlans_2") as DropDownList;

                    DropDownList ddlBidSpecifications = grdPlans.Rows[i].FindControl("ddlBidSpecifications") as DropDownList;
                    DropDownList ddlBidSpecifications_1 = grdPlans.Rows[i].FindControl("ddlBidSpecifications_1") as DropDownList;
                    DropDownList ddlBidSpecifications_2 = grdPlans.Rows[i].FindControl("ddlBidSpecifications_2") as DropDownList;

                    HiddenField hdnLOCName = grdPlans.Rows[i].FindControl("hdnLOCName") as HiddenField;
                    if (ddlPlans != null && hdnLOCName != null)
                    {
                        int PlanCount = 1;
                        string LOCName = hdnLOCName.Value;
                        DataRow dtLoc = dtblPlansSelected.Select("LOCName = '" + LOCName + "'").First();


                        DataRow dtLoc1 = dtblPlansSelected.NewRow();
                        dtLoc1["LOCName"] = dtLoc["LOCName"].ToString();
                        dtLoc1["SelectedPlan"] = dtLoc["SelectedPlan"].ToString();
                        dtLoc1["CarrierName"] = dtLoc["CarrierName"].ToString();
                        dtLoc1["ProductID"] = dtLoc["ProductID"].ToString();
                        dtLoc1["FundingType"] = dtLoc["FundingType"].ToString();
                        dtLoc1["Contribution"] = dtLoc["Contribution"].ToString();
                        dtLoc1["ApplicablePlanTypeIds"] = dtLoc["ApplicablePlanTypeIds"].ToString();
                        dtLoc1["IsVoluntaryProduct"] = dtLoc["IsVoluntaryProduct"].ToString();

                        DataRow dtLoc2 = dtblPlansSelected.NewRow();
                        dtLoc2["LOCName"] = dtLoc["LOCName"].ToString();
                        dtLoc2["SelectedPlan"] = dtLoc["SelectedPlan"].ToString();
                        dtLoc2["CarrierName"] = dtLoc["CarrierName"].ToString();
                        dtLoc2["ProductID"] = dtLoc["ProductID"].ToString();
                        dtLoc2["FundingType"] = dtLoc["FundingType"].ToString();
                        dtLoc2["Contribution"] = dtLoc["Contribution"].ToString();
                        dtLoc2["ApplicablePlanTypeIds"] = dtLoc["ApplicablePlanTypeIds"].ToString();
                        dtLoc2["IsVoluntaryProduct"] = dtLoc["IsVoluntaryProduct"].ToString();

                        if (ddlPlans.SelectedValue != "0" || ddlPlans_1.SelectedValue != "0" || ddlPlans_2.SelectedValue != "0")
                        {
                            Plan selectedPlan = lstTempPlan.Where(p => p.ProductId == int.Parse(ddlPlans.SelectedValue)).FirstOrDefault();
                            Plan selectedPlan_1 = lstTempPlan.Where(p => p.ProductId == int.Parse(ddlPlans_1.SelectedValue)).FirstOrDefault();
                            Plan selectedPlan_2 = lstTempPlan.Where(p => p.ProductId == int.Parse(ddlPlans_2.SelectedValue)).FirstOrDefault();

                            #region Plan #1

                            if (selectedPlan != null)
                            {
                                dtLoc["SelectedPlan"] = ddlPlans.SelectedItem.Text;
                                dtLoc["ProductID"] = ddlPlans.SelectedValue;
                                dtLoc["CarrierName"] = selectedPlan.CarrierName;
                                dtLoc["BidSpecifications"] = ddlBidSpecifications.SelectedValue;

                                if (selectedPlan.ProductTypeId.ToString().Length <= 3)
                                {
                                    string[] CustomplanNamePart = selectedPlan.ProductName.Split('|');
                                    string PlanName = CustomplanNamePart[0];
                                    string[] PlanNameParts = PlanName.Split('/');
                                    if (PlanNameParts.Count() > 0)
                                    {
                                        Dictionary<string, string> dictCustomField = wr.GetProductCustomValue(selectedPlan.ProductId, SessionId);
                                        dtLoc["FundingType"] = dictCustomField["FundingMethod"]; //GetFundingType(PlanNameParts[0].Trim());
                                        if (PlanNameParts.Count() > 2)
                                        {
                                            dtLoc["Contribution"] = GetContributionsPlanName(PlanNameParts[2].Trim());
                                        }
                                    }

                                }
                                else
                                {
                                    string[] CustomplanNamePart = selectedPlan.ProductName.Split('|');
                                    string PlanName = CustomplanNamePart[0];
                                    string[] PlanNameParts = PlanName.Split('/');
                                    if (PlanNameParts.Count() > 0)
                                    {
                                        dtLoc["Contribution"] = GetContributionsPlanName(PlanNameParts[0].Trim());
                                    }
                                }
                            }
                            else
                            {
                                if (ddlBidSpecifications.SelectedValue == "New Line of Coverage")
                                {
                                    dtLoc["SelectedPlan"] = "";
                                    dtLoc["ProductID"] = ddlPlans.SelectedValue;
                                    dtLoc["CarrierName"] = "";
                                    dtLoc["BidSpecifications"] = ddlBidSpecifications.SelectedValue;
                                    dtLoc["FundingType"] = "";
                                    dtLoc["Contribution"] = "";
                                }
                            }

                            #endregion
                            #region Plan #2

                            if (selectedPlan_1 != null)
                            {
                                dtLoc1["SelectedPlan"] = ddlPlans_1.SelectedItem.Text;
                                dtLoc1["ProductID"] = ddlPlans_1.SelectedValue;
                                dtLoc1["CarrierName"] = selectedPlan_1.CarrierName;
                                dtLoc1["BidSpecifications"] = ddlBidSpecifications_1.SelectedValue;

                                if (selectedPlan_1.ProductTypeId.ToString().Length <= 3)
                                {
                                    string[] CustomplanNamePart = selectedPlan_1.ProductName.Split('|');
                                    string PlanName = CustomplanNamePart[0];
                                    string[] PlanNameParts = PlanName.Split('/');
                                    if (PlanNameParts.Count() > 0)
                                    {
                                        Dictionary<string, string> dictCustomField = wr.GetProductCustomValue(selectedPlan_1.ProductId, SessionId);
                                        dtLoc1["FundingType"] = dictCustomField["FundingMethod"]; //GetFundingType(PlanNameParts[0].Trim());
                                        if (PlanNameParts.Count() > 2)
                                        {
                                            dtLoc1["Contribution"] = GetContributionsPlanName(PlanNameParts[2].Trim());
                                        }
                                    }

                                }
                                else
                                {
                                    string[] CustomplanNamePart = selectedPlan_1.ProductName.Split('|');
                                    string PlanName = CustomplanNamePart[0];
                                    string[] PlanNameParts = PlanName.Split('/');
                                    if (PlanNameParts.Count() > 0)
                                    {
                                        dtLoc1["Contribution"] = GetContributionsPlanName(PlanNameParts[0].Trim());
                                    }
                                }

                                dtblPlansSelected.Rows.Add(dtLoc1);
                            }

                            #endregion
                            #region Plan #3

                            if (selectedPlan_2 != null)
                            {
                                dtLoc2["SelectedPlan"] = ddlPlans_2.SelectedItem.Text;
                                dtLoc2["ProductID"] = ddlPlans_2.SelectedValue;
                                dtLoc2["CarrierName"] = selectedPlan_2.CarrierName;
                                dtLoc2["BidSpecifications"] = ddlBidSpecifications_1.SelectedValue;

                                if (selectedPlan_2.ProductTypeId.ToString().Length <= 3)
                                {
                                    string[] CustomplanNamePart = selectedPlan_2.ProductName.Split('|');
                                    string PlanName = CustomplanNamePart[0];
                                    string[] PlanNameParts = PlanName.Split('/');
                                    if (PlanNameParts.Count() > 0)
                                    {
                                        Dictionary<string, string> dictCustomField = wr.GetProductCustomValue(selectedPlan_2.ProductId, SessionId);
                                        dtLoc2["FundingType"] = dictCustomField["FundingMethod"]; //GetFundingType(PlanNameParts[0].Trim());
                                        if (PlanNameParts.Count() > 2)
                                        {
                                            dtLoc2["Contribution"] = GetContributionsPlanName(PlanNameParts[2].Trim());
                                        }
                                    }

                                }
                                else
                                {
                                    string[] CustomplanNamePart = selectedPlan_2.ProductName.Split('|');
                                    string PlanName = CustomplanNamePart[0];
                                    string[] PlanNameParts = PlanName.Split('/');
                                    if (PlanNameParts.Count() > 0)
                                    {
                                        dtLoc2["Contribution"] = GetContributionsPlanName(PlanNameParts[0].Trim());
                                    }
                                }

                                dtblPlansSelected.Rows.Add(dtLoc2);
                            }

                            #endregion
                            dtblPlansSelected.AcceptChanges();
                        }
                        else
                        {
                            dtLoc["SelectedPlan"] = "";
                            dtLoc["ProductID"] = "0";
                            dtblPlansSelected.AcceptChanges();
                        }

                    }

                }




                string SummaryName_SheetName = string.Empty;
                DataTable dtOfficeAddress = new DataTable();

                string MainAddress = string.Empty;


                SummaryDetail sd = new SummaryDetail();
                MainAddress = sd.GetFormattedAddress(AccountDS, "").Trim();
                MainAddress = MainAddress.Replace("\n", "; ");
                int x = MainAddress.LastIndexOf(";");
                MainAddress = MainAddress.Remove(x);


                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }
                SummaryName_SheetName = "RFP Submission";
                myWorksheet = myWorkbook.Worksheets[1];
                DateTime dtEffectiveRenewalDate = GetDate(txtEffectiveRenewalDate.Text.Trim());
                DateTime dtRFPDueDate = GetDate(txtRFPDueDate.Text.Trim());
                DateTime dtMeetingDate = GetDate(txtMeetingDate.Text.Trim());
                string MEdicalCarrierName = GetMedicalCarrierNames();
                int AdditionalLOCCount = int.Parse(ddlAdditionalLOC.SelectedValue);
                int MaxLOCCount = 4;
                BPUser_Name = Session["UserName"].ToString();
                wr.WriteRFPDetails(myExcelApp, ddlClient, SummaryName_SheetName, MainAddress, AccountDS, AccountTeamMemberDS, Account_Region, Account_Office, dtOfficeAddress, dtEffectiveRenewalDate, dtRFPDueDate, dtMeetingDate, BPUser_Name, MEdicalCarrierName);
                wr.WritePlanTo_AncillaryIntakeForm(myExcelApp, SummaryName_SheetName, dtblPlansSelected, AdditionalLOCCount, MaxLOCCount);
                myWorksheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SummaryName_SheetName];
                Excel.Range r = myWorksheet.Cells[1, 1];
                r.Select();
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
        private bool IsValidAncillaryDates()
        {
            if (txtEffectiveRenewalDate.Text.Trim() == string.Empty)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Effective / Renewal Date.')</script>", false);
                txtEffectiveRenewalDate.Focus();
                return false;
            }
            if (!IsValidDate(txtEffectiveRenewalDate.Text.Trim()))
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Effective / Renewal Date. Date format should be MM/DD/YYYY')</script>", false);
                txtEffectiveRenewalDate.Focus();
                return false;
            }

            if (txtRFPDueDate.Text.Trim() == string.Empty)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select RFP Sent Date.')</script>", false);
                txtRFPDueDate.Focus();
                return false;
            }
            if (!IsValidDate(txtRFPDueDate.Text.Trim()))
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid RFP Sent Date. Date format should be MM/DD/YYYY')</script>", false);
                txtRFPDueDate.Focus();
                return false;
            }
            if (IsValidDate(txtRFPDueDate.Text.Trim()))
            {
                DateTime dtCurrentDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                DateTime MinDate = dtCurrentDate;
                int cnt = 0;
                while (cnt <= 4)
                {
                    cnt++;
                    MinDate = MinDate.AddDays(1);
                    if (MinDate.DayOfWeek == DayOfWeek.Saturday || MinDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        cnt--;
                    }
                }
                DateTime dtRFPDueDate = GetDate(txtRFPDueDate.Text.Trim());
                if (dtRFPDueDate < MinDate)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid RFP Sent Date. A minimum of 5 business days is required. If needed sooner, please contact Ancillary Lead.')</script>", false);
                    txtRFPDueDate.Text = "";
                    txtRFPDueDate.Focus();
                    return false;
                }
            }
            if (txtMeetingDate.Text.Trim() == string.Empty)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client Renewal Meeting Date.')</script>", false);
                txtMeetingDate.Focus();
                return false;
            }

            if (!IsValidDate(txtMeetingDate.Text.Trim()))
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Client Renewal Meeting Date. Date format should be MM/DD/YYYY')</script>", false);
                txtMeetingDate.Focus();
                return false;
            }
            return true;
        }
        #endregion
        #region Event Handlers

        protected void grdPlans_PlanChanged(object sender, EventArgs e)
        {
            DropDownList ddlSender = sender as DropDownList;
            if (ddlSender != null)
            {
                string ddlSenderClientID = ddlSender.ClientID;
                string[] IdParts = ddlSenderClientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
                string ddlBidSpecificationsId = "";

                if (ddlSender.CssClass == "ddlPlans")
                {
                    ddlBidSpecificationsId = "ddlBidSpecifications";
                }
                else if (ddlSender.CssClass == "ddlPlans1")
                {
                    ddlBidSpecificationsId = "ddlBidSpecifications_1";
                }
                else
                {
                    ddlBidSpecificationsId = "ddlBidSpecifications_2";
                }
                DropDownList ddlBidSpecifications = grdPlans.Rows[RowIndex].FindControl(ddlBidSpecificationsId) as DropDownList;
                if (ddlBidSpecifications != null)
                {
                    if (ddlSender.SelectedValue == "0")
                    {
                        // ddlSender.Visible = false;
                        ddlBidSpecifications.SelectedValue = "Match Current";
                        // ddlBidSpecifications.Visible = false;
                    }
                    else
                    {
                        // ddlSender.Visible = true;
                        ddlBidSpecifications.SelectedValue = "Match Current";
                        //ddlBidSpecifications.Visible = true;
                    }
                }

            }
        }
        protected void ddlUSI_State_SelectedIndexChanged(object sender, EventArgs e)
        {
            //USI State
            DataTable dtOfficeCity = new DataTable();
            ddlUSI_City.Items.Clear();
            if (ddlUSI_State.SelectedIndex > 0)
            {
                dtOfficeCity = bp.GetOfficeCityList(ddlUSI_State.SelectedValue);
                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            else
            {
                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            ddlUSI_City.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlUSI_City.SelectedIndex = 0;
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(Session["Summary"]) == "RFPReport")
            {
                if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                    return;
                }


                SessionId = Session["SessionId"].ToString();
                SummaryDetail sd = new SummaryDetail();
                DataSet AccountDS = new DataSet();
                DataSet AccountTeamMemberDS = new DataSet();
                sd.BuildAccountTable();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                // Get the Account Office and Account Region for the selected client

                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                if (ddlcontents.SelectedValue == "Ancillary_Intake_Form_REP")
                {
                    if (IsValidAncillaryDates())
                        CreateAncillaryTemplate(SessionId, AccountTeamMemberDS, AccountDS, Account_Office);
                }
            }
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToString(Session["Summary"]) == "RFPReport")
            {
                Session["PlanList"] = new List<Plan>();
                Session["ProductDS"] = null;
                ddlUSI_State.SelectedIndex = 0;
                if (Session["SessionId"] != null)
                {
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        DataSet AccountDS1 = new DataSet();
                        SummaryDetail sd1 = new SummaryDetail();
                        sd1.BuildAccountTable();
                        AccountDS1 = sd1.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        BindState(AccountDS1);
                    }
                }
                ddlUSI_State_SelectedIndexChanged(null, null);
                Handle_ClientChange();
            }
        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            if (IsValidAncillaryDates())
            {
                List<Plan> PlanList = new List<Plan>();
                LoadPlans();
                DataTable dtbl = CreateLOCDataTable();
                grdPlans.DataSource = dtbl;
                grdPlans.DataBind();
            }
        }
        protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            WriteAncillaryIntakeFormRFP wr = new WriteAncillaryIntakeFormRFP();
            SessionId = Session["SessionId"].ToString();
            DropDownList ddlPlans = e.Row.FindControl("ddlPlans") as DropDownList;
            DropDownList ddlPlans_1 = e.Row.FindControl("ddlPlans_1") as DropDownList;
            DropDownList ddlPlans_2 = e.Row.FindControl("ddlPlans_2") as DropDownList;

            HiddenField hdnApplicationPlanTypeIds = e.Row.FindControl("hdnApplicationPlanTypeIds") as HiddenField;
            HiddenField hdnIsVoluntaryProduct = e.Row.FindControl("hdnIsVoluntaryProduct") as HiddenField;
            HiddenField hdnLOCName = e.Row.FindControl("hdnLOCName") as HiddenField;
            HiddenField HdnIsMultipleLOC = e.Row.FindControl("HdnIsMultipleLOC") as HiddenField;

            DropDownList ddlBidSpecifications = e.Row.FindControl("ddlBidSpecifications") as DropDownList;
            DropDownList ddlBidSpecifications_1 = e.Row.FindControl("ddlBidSpecifications_1") as DropDownList;
            DropDownList ddlBidSpecifications_2 = e.Row.FindControl("ddlBidSpecifications_2") as DropDownList;

            if (ddlPlans != null && hdnApplicationPlanTypeIds != null && hdnIsVoluntaryProduct != null)
            {
                List<Plan> lstAvailablePlans = new List<Plan>();
                List<Plan> tempList = Session["PlanList"] as List<Plan>;
                ddlPlans.Items.Clear();
                string strPlanTypeIds = hdnApplicationPlanTypeIds.Value;
                if (strPlanTypeIds != string.Empty)
                {
                    strPlanTypeIds = strPlanTypeIds.TrimStart(',').TrimEnd(',');
                    string[] Typeids = strPlanTypeIds.Split(',');
                    List<int> lstTypeIds = new List<int>();
                    foreach (string ptID in Typeids)
                    {
                        int temp = 0;
                        int.TryParse(ptID, out temp);
                        if (temp != 0)
                        {
                            lstTypeIds.Add(temp);
                        }
                    }

                    if (tempList != null)
                    {
                        foreach (Plan objPlan in tempList)
                        {
                            if (lstTypeIds.Contains(objPlan.ProductTypeId))
                            {
                                if (rdlPlanSection.SelectedIndex == 0)
                                {
                                    if (objPlan.RenewalDate > System.DateTime.Now && objPlan.ProductStatus == objPlan.ProductStatusCurrent)
                                    {
                                        if (hdnLOCName.Value == "Voluntary STD" || hdnLOCName.Value == "Voluntary LTD")
                                        {
                                            bool IsVoluntaryProduct = wr.IsProductVoluntary(objPlan.ProductId, SessionId);
                                            if (IsVoluntaryProduct)
                                            {
                                                lstAvailablePlans.Add(objPlan);
                                            }
                                        }
                                        else if (hdnLOCName.Value == "Short Term Disability" || hdnLOCName.Value == "Long Term Disability")
                                        {
                                            bool IsVoluntaryProduct = wr.IsProductVoluntary(objPlan.ProductId, SessionId);
                                            if (!IsVoluntaryProduct)
                                            {
                                                lstAvailablePlans.Add(objPlan);
                                            }
                                        }
                                        else
                                        {
                                            lstAvailablePlans.Add(objPlan);
                                        }

                                    }
                                }
                                else
                                {
                                    if (hdnLOCName.Value == "Voluntary STD" || hdnLOCName.Value == "Voluntary LTD")
                                    {
                                        bool IsVoluntaryProduct = wr.IsProductVoluntary(objPlan.ProductId, SessionId);
                                        if (IsVoluntaryProduct)
                                        {
                                            lstAvailablePlans.Add(objPlan);
                                        }
                                    }
                                    else if (hdnLOCName.Value == "Short Term Disability" || hdnLOCName.Value == "Long Term Disability")
                                    {
                                        bool IsVoluntaryProduct = wr.IsProductVoluntary(objPlan.ProductId, SessionId);
                                        if (!IsVoluntaryProduct)
                                        {
                                            lstAvailablePlans.Add(objPlan);
                                        }
                                    }
                                    else
                                    {
                                        lstAvailablePlans.Add(objPlan);
                                    }
                                }

                            }
                        }
                    }

                }
                lstAvailablePlans = (from l in lstAvailablePlans
                                     orderby l.ProductName, l.CarrierName, l.RenewalDate ascending
                                     select l).ToList();
                ddlPlans.DataSource = lstAvailablePlans;
                ddlPlans.DataBind();

                ddlPlans_1.DataSource = lstAvailablePlans;
                ddlPlans_1.DataBind();

                ddlPlans_2.DataSource = lstAvailablePlans;
                ddlPlans_2.DataBind();

                ddlPlans.Items.Insert(0, new ListItem("Select", "0"));
                ddlPlans_1.Items.Insert(0, new ListItem("Select", "0"));
                ddlPlans_2.Items.Insert(0, new ListItem("Select", "0"));

                if (lstAvailablePlans.Count == 0)
                {
                    ddlPlans.Items[0].Value = "-1";
                    ddlPlans.Items[0].Text = "No Plan Available";
                    ddlPlans_1.Visible = false;
                    ddlPlans_2.Visible = false;

                    ddlBidSpecifications_1.Visible = false;
                    ddlBidSpecifications_2.Visible = false;
                }
                else if (lstAvailablePlans.Count == 1)
                {
                    ddlPlans.SelectedValue = lstAvailablePlans.First().ProductId.ToString();
                    ddlPlans_1.Visible = false;
                    ddlPlans_2.Visible = false;
                    ddlBidSpecifications_1.Visible = false;
                    ddlBidSpecifications_2.Visible = false;
                }
                else
                {
                    ddlPlans.SelectedValue = lstAvailablePlans.First().ProductId.ToString();
                    Plan secndPlan = lstAvailablePlans.Skip(1).FirstOrDefault();
                    if (secndPlan != null)
                        ddlPlans_1.SelectedValue = secndPlan.ProductId.ToString();
                    else
                    {
                        ddlPlans_1.Visible = false;
                        ddlBidSpecifications_1.Visible = false;
                    }
                    Plan thirdPlan = lstAvailablePlans.Skip(2).FirstOrDefault();
                    if (thirdPlan != null)
                    {
                        ddlPlans_2.SelectedValue = thirdPlan.ProductId.ToString();
                        ddlPlans_2.Visible = true;
                        ddlBidSpecifications_2.Visible = true;
                    }
                    else
                    {
                        ddlPlans_2.Visible = false;
                        ddlBidSpecifications_2.Visible = false;
                    }

                }

                if (HdnIsMultipleLOC.Value != null && HdnIsMultipleLOC.Value.ToLower() != "true")
                {
                    if (ddlPlans.Items.Count == 2)
                        ddlPlans.SelectedIndex = 1;
                    else
                        ddlPlans.SelectedIndex = 0;

                    ddlPlans_1.Visible = false;
                    ddlPlans_2.Visible = false;
                    ddlBidSpecifications_1.Visible = false;
                    ddlBidSpecifications_2.Visible = false;

                    ddlPlans_1.SelectedValue = "0";
                    ddlPlans_2.SelectedValue = "0";

                    ddlBidSpecifications_1.SelectedValue = "Match Current";
                    ddlBidSpecifications_2.SelectedValue = "Match Current";
                }


            }

        }
        protected void ddlcontents_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetForm();
            string OrientationOption = "";
            if (dictOrientationOption.ContainsKey(ddlcontents.SelectedValue))
            {
                OrientationOption = dictOrientationOption[ddlcontents.SelectedValue].ToLower();
            }
            switch (OrientationOption)
            {
                case "portrait":
                    ddlOrientation.SelectedValue = "Portrait";
                    ddlOrientation.Enabled = false;
                    break;
                case "landscape":
                    ddlOrientation.SelectedValue = "Landscape";
                    ddlOrientation.Enabled = false;
                    break;
                case "all":
                    ddlOrientation.SelectedValue = "0";
                    ddlOrientation.Enabled = true;
                    break;
                default:
                    ddlOrientation.SelectedValue = "0";
                    ddlOrientation.Enabled = true;
                    break;
            }

            switch (ddlcontents.SelectedValue)
            {
                case "Ancillary_Intake_Form_REP":
                    txtLetterDecription.Text = "Ancillary Intake Form REP";
                    tblRFPDetails.Style.Add("display", "");
                    tblCurrentPlans.Style.Add("display", "");
                    spnClientDescription.InnerText = "Indicate which BenefitPoint client you would like to create an RFP for.";
                    break;
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ddlcontents.SelectedValue = "Ancillary_Intake_Form_REP";
            ddlcontents_SelectedIndexChanged(null, null);

        }
        protected void rdlPlanSection_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }
        #endregion


        private void ResetForm()
        {
            #region common
            spnClientDescription.InnerText = "";
            ddlOrientation.SelectedValue = "0";
            ddlOrientation.Enabled = true;
            txtLetterDecription.Text = "";
            txtLetterDecription.Visible = false;
            Session["PlanList"] = new List<Plan>();
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            rdlClient.SelectedIndex = 0;
            ddlClient_SelectedIndexChanged(null, null);
            // ddlUSI_State.SelectedIndex = 0;
            //ddlUSI_State_SelectedIndexChanged(null, null);
            #endregion
            #region Ancillary Intake Report
            tblRFPDetails.Style.Add("display", "none");
            tblCurrentPlans.Style.Add("display", "none");
            ddlAdditionalLOC.SelectedValue = "0";
            txtEffectiveRenewalDate.Text = "";
            txtRFPDueDate.Text = "";
            txtMeetingDate.Text = "";
            rdlPlanSection.SelectedIndex = 0;
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            #endregion
        }
        public void BindState(DataSet AccountDS)
        {
            string State = string.Empty;

            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"])))
            {

                State = Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"]);
                State = State.Replace("_", " ");
                ddlUSI_State.SelectedValue = State;
            }
        }
        public string GetMedicalCarrierNames()
        {
            string MedicalCarrierName = string.Empty;
            char[] arrChar = { ',' };
            List<string> lstMEdicalCarrier = new List<string>();
            List<Plan> PlanList = Session["PlanList"] as List<Plan>;
            if (PlanList != null && PlanList.Count() > 0)
            {
                foreach (Plan item in PlanList)
                {
                    if (lstMedicalPlans.Contains(item.ProductTypeId))
                    {
                        if (!lstMEdicalCarrier.Contains(item.CarrierName))
                            lstMEdicalCarrier.Add(item.CarrierName);
                    }
                }
            }

            if (lstMEdicalCarrier.Count > 0)
                MedicalCarrierName = string.Join(", ", lstMEdicalCarrier);

            return MedicalCarrierName.TrimEnd(arrChar);
        }
    }
}