﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.Tools;
using System.Collections;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.Tools;

using BenefitPointSummaryPortal.Common.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.ServiceCalendar;
using BenefitPointSummaryPortal.Common.OpenCloseWord;

namespace BenefitPointSummaryPortal.View
{
    public partial class Tools_ClientContact : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        List<UserDetails> lstUserDetails = new List<UserDetails>();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        static DataTable PlanInfoTable = new DataTable();
        static DataTable dtPlanContactInfo = new DataTable();
        static DataTable dtPlanContact;
        int rowvalue = 0;

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btnSummary);
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();
                    DictDepartment = sd.getDepartmentDetails();
                    mvClientContact.ActiveViewIndex = 0;
                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                    {
                        TitleSpan.InnerText = "Client Contact Sheet";
                        spanCriteriaPage1.InnerText = "General Information – Criteria Page 1 of 2";
                        spanCriteriaPage2.InnerText = "Additional Options – Criteria Page 2 of 2";
                        btnPrevious.Visible = false;
                        btnNext.Visible = true;
                        btnSummary.Visible = false;
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    GetData();
                    txtsearch.Focus();
                    //Activity = lblHeading.Text;
                    ////Activity = TitleSpan.InnerText;
                    Activity_Group = "Tools";
                    Activity = "Client Contact Sheet-Basic";
                    //dtPlanContact = new DataTable();
                    //dtPlanContact = CreateContactTable();

                    ///** Office Dropdown Enabled=False by Amogh*/
                    ddlOffice.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                //ddlActivity.Items.Clear();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                pnlPlans.Visible = false;
                // rdlActivity.SelectedIndex = 0;
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

                //cblistAccountContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            //ddlActivity.SelectedIndex = 0;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //ddlActivity.Items.Clear();
                // rdlActivity.SelectedIndex = 0;
                if (ddlOffice.Items.Count > 1)
                {
                    ddlOffice.SelectedIndex = 2;
                }
                ddlBRC.SelectedIndex = 0;
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                ddlPlanContacts.SelectedIndex = 1;
                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;

                // cblistAccountContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Bind data to office dropdown and BRC dropdown.
        /// </summary>
        protected void GetData()
        {
            try
            {
                //Office.
                Session["OffieceTable"] = null;
                Session["BRCList"] = null;
                BPBusiness bp = new BPBusiness();
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();
                dt = bp.GetOfficeList();
                Session["OffieceTable"] = dt;
                ddlOffice.DataSource = dt;
                ddlOffice.DataBind();
                ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlOffice.SelectedIndex = 2;
                //USI State
                DataTable dtOfficeState = new DataTable();
                dtOfficeState = bp.GetOfficeStateList();
                Session["OffieceTable"] = dtOfficeState;
                ddlUSI_State.DataSource = dtOfficeState;
                ddlUSI_State.DataBind();
                ddlUSI_State.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlUSI_State.SelectedIndex = 0;

                // BRC
                List<BRC> BRCList = new List<BRC>();
                BRCList = bp.GetBRC_Region();
                Session["BRCList"] = BRCList;
                ddlBRC.DataSource = BRCList;
                ddlBRC.DataBind();
                ddlBRC.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlBRC.Items.Insert(1, new ListItem("None", "-1"));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void ddlUSI_State_SelectedIndexChanged(object sender, EventArgs e)
        {
            //USI State
            DataTable dtOfficeCity = new DataTable();
            if (ddlUSI_State.SelectedIndex > 0)
            {
                dtOfficeCity = bp.GetOfficeCityList(ddlUSI_State.SelectedValue);


                //string CityDetails = String.Format("{0}, {1}", LastName, FirstName);

                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            else
            {
                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            ddlUSI_City.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlUSI_City.SelectedIndex = 0;

        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlActivity.Items.Clear();
            pnlPlans.Visible = false;
            if (Convert.ToString(Session["Summary"]) == "Tools1")
            {
                // GetActivity_List(rdlActivity.SelectedItem.Text, tc.Tools1_SubjectID);
            }
            else if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
            {

                lblMessage.Visible = false;
                grdAccountTeam.DataSource = null;
                grdAccountTeam.DataBind();
                SessionId = Session["SessionId"].ToString();
                List<string> lstUser = new List<string>();
                DataSet AccountTeamMemberDS = new DataSet();

                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                UserDetails objUserDetails = new UserDetails();

                if (AccountTeamMemberDS.Tables.Count > 0)
                {
                    if (AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < AccountTeamMemberDS.Tables[0].Rows.Count; i++)
                        {
                            lstUser = sd.GetUserDetails(Convert.ToInt32(AccountTeamMemberDS.Tables[0].Rows[i]["UserId"].ToString()), SessionId);

                            objUserDetails = new UserDetails();

                            objUserDetails.UserId = Convert.ToInt32(AccountTeamMemberDS.Tables[0].Rows[i]["UserId"]);
                            objUserDetails.First_Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]);
                            objUserDetails.Last_Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]);
                            objUserDetails.Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]);
                            //objUserDetails.Role = Convert.ToString(lstUser[0]);
                            objUserDetails.Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["role"]);
                            objUserDetails.WorkPhone = Convert.ToString(lstUser[1]);
                            objUserDetails.Email = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["Email"]);

                            lstUserDetails.Add(objUserDetails);
                        }
                    }
                }

                lblAccountContact.Visible = true;
                lblAccountContactHeadermsg.Visible = true;
                grdAccountTeam.Visible = true;
                pnlGrdAccounTeam.Visible = true;

                if (lstUserDetails.Count > 0)
                {
                    pnlGrdAccounTeam.Height = 150;
                    Session["lstUserDetails"] = lstUserDetails;

                    grdAccountTeam.DataSource = lstUserDetails;
                    grdAccountTeam.DataBind();
                    grdAccountTeam.Height = 130;

                    pnlHeader.Visible = true;
                    GridView1.DataSource = lstUserDetails;
                    GridView1.DataBind();

                    //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdAccountTeam');</script>", false);
                }
                else
                {
                    lblMessage.Visible = true;
                    pnlGrdAccounTeam.Height = 50;
                }


            }

        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                dtPlanContact = new DataTable();
                dtPlanContact = CreateContactTable();
                dtPlanContact.Clear();
                PlanInfoTable = GetPlanInfoTable();

                TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;


                if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                {
                    if (PlanInfoTable != null)
                    {
                        if (PlanInfoTable.Rows.Count > 0)
                        {
                            foreach (GridViewRow oItem in grdPlans.Rows)
                            {
                                CheckBox chkSelect = oItem.Cells[8].FindControl("chkItemSelect") as CheckBox;
                                Label lblProductType = oItem.Cells[7].FindControl("ProductTypeId") as Label;

                                if (chkSelect.Checked)
                                {
                                    //var planTYpe = GetPlanName(Convert.ToInt16(lblProductType));
                                    flag = true;
                                    break;
                                }
                            }
                            //foreach (DataRow dr in PlanInfoTable.Rows)
                            //{
                            //    string planName = GetPlanName(Convert.ToInt16(dr["ProductTypeId"]));
                            //    if (planName == "Medical")
                            //    {
                            //        flag = true;
                            //        break;
                            //    }
                            //}
                        }
                        else
                        {
                            if (grdPlans.Rows.Count > 0)
                            {
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            flag = false;
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                        }
                    }
                }

                if (flag == true)
                {
                    string mynewfile = "";
                    int count = 0;
                    List<DataRow> rowDeleteList = new List<DataRow>();

                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    if (PlanInfoTable.Rows.Count > 0)
                    {
                        foreach (DataRow r in PlanInfoTable.Rows)
                        {
                            DataRow dr = dtPlanContact.NewRow();
                            dr["CarrierName"] = r["Carrier"].ToString();
                            dr["ProductId"] = r["ProductId"].ToString();
                            dtPlanContact.Rows.Add(dr);
                        }
                        //if (ddlPlanContacts.SelectedIndex == 1)
                        //{
                        //var distinctValues = dtPlanContact.AsEnumerable().Select(row => new
                        //                        {
                        //                            attribute1_name = row.Field<string>("CarrierName")
                        //                        })
                        //                        .Distinct();

                        //DataView view = new DataView(dtPlanContact);
                        //dtPlanContact = view.ToTable(true, "ContactId", "ContactName", "ContactEmail", "ContactWorkPhone", "Contact_FirstName", "Contact_LastName", "Contact_Address", "CarrierName");
                        //dtPlanContact.AcceptChanges();
                        //}
                        //else if (ddlPlanContacts.SelectedIndex == 0)
                        //{
                        foreach (GridViewRow oItem in dvPlanContacts.Rows)
                        {
                            DropDownList dropdwn = oItem.Cells[1].FindControl("ddlItemPlanContact") as DropDownList;
                            Label lblProductID = oItem.Cells[2].FindControl("lblProductID") as Label;

                            foreach (DataRow r in dtPlanContactInfo.Rows)
                            {
                                foreach (DataRow rowContact in dtPlanContact.Rows)
                                {
                                    //if (dropdwn.SelectedIndex == 1)
                                    //{
                                    //    if (dropdwn.SelectedValue == r["ContactId"].ToString() && lblProductID.Text == r["ProductId"].ToString())
                                    //    {
                                    //        string productId = r["ProductId"].ToString();
                                    //        if (dtPlanContact.AsEnumerable().Any(row => productId == row.Field<String>("ProductId")))
                                    //        {
                                    //            //DataRow rowno = dtPlanContact.AsEnumerable().Where(x => x["ProductId"].ToString() == productId).First();
                                    //            var matchingRows = from row in dtPlanContact.AsEnumerable()
                                    //                               where row.Field<string>("ProductId") == productId
                                    //                               select row;

                                    //            DataRow rowno = matchingRows.FirstOrDefault();
                                    //            if (rowno != null)
                                    //            {
                                    //                rowno["ContactId"] = r["ContactId"].ToString();
                                    //                rowno["ContactName"] = "";
                                    //                rowno["ContactWorkPhone"] = "";
                                    //                rowno["ContactEmail"] = "";
                                    //            }
                                    //        }
                                    //    }
                                    //}
                                    if (dropdwn.SelectedIndex > 1)
                                    {
                                        if (dropdwn.SelectedValue == r["ContactId"].ToString() && lblProductID.Text == r["ProductId"].ToString())
                                        {
                                            string productId = r["ProductId"].ToString();
                                            if (dtPlanContact.AsEnumerable().Any(row => productId == row.Field<String>("ProductId")))
                                            {
                                                //DataRow rowno = dtPlanContact.AsEnumerable().Where(x => x["ProductId"].ToString() == productId).First();
                                                var matchingRows = from row in dtPlanContact.AsEnumerable()
                                                                   where row.Field<string>("ProductId") == productId
                                                                   select row;

                                                DataRow rowno = matchingRows.FirstOrDefault();
                                                if (rowno != null)
                                                {
                                                    rowno["ContactId"] = r["ContactId"].ToString();
                                                    rowno["ContactName"] = r["ContactName"].ToString();
                                                    rowno["ContactWorkPhone"] = r["ContactWorkPhone"].ToString();
                                                    rowno["ContactEmail"] = r["ContactEmail"].ToString();
                                                }
                                            }
                                            else
                                            {
                                                dtPlanContact.ImportRow(r);
                                            }
                                            break;
                                            //rowDeleteList.Add(r);
                                            //r["ContactName"] = "";
                                            //r["ContactWorkPhone"] = "";
                                            //r["ContactEmail"] = "";
                                        }
                                    }

                                }
                            }
                            //}
                            //}
                            //count++;
                        }
                        DataView view = new DataView(dtPlanContact);
                        dtPlanContact = view.ToTable(true, "ContactId", "ContactName", "ContactEmail", "ContactWorkPhone", "Contact_FirstName", "Contact_LastName", "Contact_Address", "CarrierName");
                        dtPlanContact.AcceptChanges();
                        //}

                    }

                    //foreach (DataRow row in rowDeleteList)
                    //{
                    //    dtPlanContactInfo.Rows.Remove(row);
                    //}

                    if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                    {
                        mynewfile = CreateClientContact(SessionId);
                    }

                    DownloadFileNew(mynewfile);

                    // DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        //protected void btnSummary_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        dtPlanContact.Clear(); 
        //        PlanInfoTable = GetPlanInfoTable();

        //        TimelineDetail timeD = new TimelineDetail();
        //        SessionId = Session["SessionId"].ToString();
        //        bool flag = true;


        //        if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
        //        {
        //            if (PlanInfoTable != null)
        //            {
        //                if (PlanInfoTable.Rows.Count > 0)
        //                {
        //                    foreach (GridViewRow oItem in grdPlans.Rows)
        //                    {
        //                        CheckBox chkSelect = oItem.Cells[8].FindControl("chkItemSelect") as CheckBox;
        //                        Label lblProductType = oItem.Cells[7].FindControl("ProductTypeId") as Label;

        //                        if (chkSelect.Checked)
        //                        {
        //                            //var planTYpe = GetPlanName(Convert.ToInt16(lblProductType));
        //                            flag = true;
        //                            break;
        //                        }
        //                    }
        //                    //foreach (DataRow dr in PlanInfoTable.Rows)
        //                    //{
        //                    //    string planName = GetPlanName(Convert.ToInt16(dr["ProductTypeId"]));
        //                    //    if (planName == "Medical")
        //                    //    {
        //                    //        flag = true;
        //                    //        break;
        //                    //    }
        //                    //}
        //                }
        //                else
        //                {
        //                    if (grdPlans.Rows.Count > 0)
        //                    {
        //                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        //                    }
        //                    flag = false;
        //                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
        //                }
        //            }
        //        }

        //        if (flag == true)
        //        {
        //            string mynewfile = "";
        //            int count = 0;
        //            List<DataRow> rowDeleteList = new List<DataRow>();

        //            // Get the Account Office and Account Region for the selected client
        //            Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

        //            foreach (GridViewRow oItem in dvPlanContacts.Rows)
        //            {
        //                DropDownList dropdwn = oItem.Cells[1].FindControl("ddlItemPlanContact") as DropDownList;
        //                //Label lblContractID = oItem.Cells[2].FindControl("lblContractID") as Label;

        //                if (dropdwn != null)
        //                {
        //                    if (dropdwn.SelectedIndex == 1)
        //                    {
        //                        DataRow dr = dtPlanContactInfo.Rows[count];
        //                        dtPlanContact.ImportRow(dr);
        //                        DataRow drnew = dtPlanContact.Rows[count];
        //                        drnew["ContactName"] = "";
        //                        drnew["ContactWorkPhone"] = "";
        //                        drnew["ContactEmail"] = "";
        //                    }
        //                    else if (dropdwn.SelectedIndex != 1 || dropdwn.SelectedIndex != 0)
        //                    {
        //                        //DataRow dr = dtPlanContactInfo.Rows[count];
        //                        //dtPlanContact.ImportRow(dr);
        //                        foreach (DataRow r in dtPlanContactInfo.Rows)
        //                        {
        //                            if (dropdwn.SelectedValue == r["ContactId"].ToString())
        //                            {
        //                                dtPlanContact.ImportRow(r);
        //                                break;
        //                                //rowDeleteList.Add(r);
        //                                //r["ContactName"] = "";
        //                                //r["ContactWorkPhone"] = "";
        //                                //r["ContactEmail"] = "";
        //                            }
        //                        }
        //                    }
        //                }
        //                count++;
        //            }

        //            //foreach (DataRow row in rowDeleteList)
        //            //{
        //            //    dtPlanContactInfo.Rows.Remove(row);
        //            //}

        //            if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
        //            {
        //                mynewfile = CreateClientContact(SessionId);
        //            }



        //            DownloadFileNew(mynewfile);

        //            // DownloadFileNew(mynewfile);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}
        /// <summary>
        /// Create Summary Template2
        /// </summary>
        protected string CreateClientContact(string SessionId)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];

            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            string strFileName = string.Empty;
            string strReportName = string.Empty;

            if (ddlReportFormat.SelectedItem.Value == "1") // Landscape Format
            {
                strFileName = "Client Contact Sheet - Basic Landscape";
                strReportName = "Report5 - Landscape";
            }
            else if (ddlReportFormat.SelectedItem.Value == "2") // Portrait Format
            {
                strFileName = "Client Contact Sheet - Basic Portrait";
                strReportName = "Report5 - Portrait";
            }

            Object fileName = Server.MapPath("~/Files/Tools/Documents/Templates/" + strFileName + ".docm");

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();
            DataSet ActivityDS = new DataSet();
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            DataTable dtOfficeAddress = new DataTable();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName)))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                WriteTool5_ClientContact wt = new WriteTool5_ClientContact();



                //dtOfficeAddress = null;
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                //Code Added for Insert Activty Log 
                List<Contact> ContactList = new List<Contact>();
                DataSet AccountDS = new DataSet();
                DataSet AccountTeamMemberDS = new DataSet();

                sd.BuildAccountTable();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }

                string RenewalDate = string.Empty;
                if (ddlReportFormat.SelectedItem.Value == "1") // Landscape Format
                {
                    wt.WriteFieldToClientContact_Landscape(oWordDoc, oWordApp, ddlOffice, ddlClient, grdAccountTeam, BRCList, ddlBRC, dtPlanContact, PlanInfoTable, dtOfficeAddress);
                }
                else if (ddlReportFormat.SelectedItem.Value == "2") // Portrait Format
                {
                    wt.WriteFieldToClientContact_Portrait(oWordDoc, oWordApp, ddlOffice, ddlClient, grdAccountTeam, BRCList, ddlBRC, dtPlanContact, PlanInfoTable, dtOfficeAddress);
                }
                RunMacro(oWordApp, new Object[] { "CleanContactSheetDocument" });
                //temperror = temperror + " postmacro";
                oWordDoc.Save();
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 = ddlReportFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(ddlClient.SelectedItem.Text), Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {

                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void ddlPlanContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    PlanInfoTable = GetPlanInfoTable();
                    BindPlanContactGrid();
                }
                else
                {
                    lblPlanContactMessage.Text = "";
                    dvPlanContacts.DataSource = null;
                    dvPlanContacts.DataBind();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void BindPlanContactGrid()
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    List<int> lstProductIds = new List<int>();
                    //List<int> sessionProductIdList = new List<int>();
                    //sessionProductIdList = (List<int>)Session["ProductIdList"];

                    foreach (GridViewRow oItem in grdPlans.Rows)
                    {
                        CheckBox chkSelect = oItem.Cells[8].FindControl("chkItemSelect") as CheckBox;
                        if (chkSelect != null)
                        {
                            if (chkSelect.Checked)
                            {
                                lstProductIds.Add(Convert.ToInt32(oItem.Cells[5].Text));
                            }
                        }
                    }

                    try
                    {
                        //        //if (sessionProductIdList == null)
                        //        //{
                        //        //    Session["ProductIdList"] = lstProductIds;
                        dtPlanContactInfo.Clear();
                        dtPlanContactInfo = sd.GetPlanContactInformation(lstProductIds, Session["SessionId"].ToString());
                        dtPlanContactInfo.Columns.Add("CarrierName", typeof(string));
                        //        //}
                        //        //else if (sessionProductIdList.Count != lstProductIds.Count)
                        //        //{
                        //        //    Session["ProductIdList"] = lstProductIds;
                        //        //    dtPlanContactInfo = sd.GetPlanContactInformation(lstProductIds, Session["SessionId"].ToString());
                        //        //}
                        Session["DataTable_PlanContactInfo"] = dtPlanContactInfo;
                    }
                    catch (Exception ex)
                    {
                        dtPlanContactInfo.Clear();
                        Session["DataTable_PlanContactInfo"] = null;
                    }

                    if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                    {
                        string[] TobeDistinct = { "ProductId" };
                        //dt = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct);

                        dvPlanContacts.DataSource = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct); ;
                        dvPlanContacts.DataBind();
                    }
                    else
                    {
                        lblPlanContactMessage.Text = "No contacts found for the selected Plans/Products.";
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void dvPlanContacts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblProductID = (e.Row.FindControl("lblProductID") as Label);
                Label lblName = (e.Row.FindControl("lblName") as Label);
                DropDownList ddlItemPlanContact = (e.Row.FindControl("ddlItemPlanContact") as DropDownList);

                var name = (from a in PlanInfoTable.AsEnumerable()
                            where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                            select a.Field<string>("Name")).FirstOrDefault();

                var carrier = (from a in PlanInfoTable.AsEnumerable()
                               where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                               select a.Field<string>("Carrier")).FirstOrDefault();

                foreach (DataRow row in dtPlanContactInfo.Rows)
                {
                    DataRow dr = dtPlanContactInfo.Rows[rowvalue];
                    dr["CarrierName"] = carrier;
                    if (dr["ProductId"].ToString() == row["ProductId"].ToString())
                    {
                        row["CarrierName"] = carrier;
                    }
                }

                lblName.Text = name;

                var planContact = (from n in dtPlanContactInfo.AsEnumerable()
                                   where n.Field<int>("ProductId") == Convert.ToInt32(lblProductID.Text)
                                   select new { ContactId = (n.Field<int>("ContactId")), ContactName = (n.Field<string>("ContactName")), ContactPhoneNumber = (n.Field<string>("ContactWorkPhone")), ContactEmail = (n.Field<string>("ContactEmail")) });

                foreach (var item in planContact.ToList())
                {
                    ListItem li = new ListItem();
                    li.Text = item.ContactName + " - " + carrier;
                    li.Value = Convert.ToString(item.ContactId);
                    //li.Attributes.Add("ContactPhoneNumber", Convert.ToString(item.ContactPhoneNumber));
                    ddlItemPlanContact.Items.Add(li);
                }

                //Add Default Item in the DropDownList
                ddlItemPlanContact.Items.Insert(0, new ListItem("Select"));
                ddlItemPlanContact.Items.Insert(1, new ListItem("None"));
                rowvalue++;

                //foreach (GridViewRow oItem in dvPlanContacts.Rows)
                //{
                //    DropDownList dropdwn = oItem.Cells[8].FindControl("ddlItemPlanContact") as DropDownList;
                //    if (dropdwn != null)
                //    {
                //        if (dropdwn.SelectedIndex == 1)
                //        {
                //            foreach (DataRow row in dtPlanContactInfo.Rows)
                //            {
                //                DataRow dr = dtPlanContactInfo.Rows[rowvalue];
                //                dr["CarrierName"] = carrier;
                //            }
                //        }
                //    }
                //}
            }
        }


        private DataTable GetDataTableFromGridView(GridView dtg)
        {
            DataTable dt = new DataTable();
            DataRow dr;

            // add the columns to the datatable            
            dt.Columns.Add(new System.Data.DataColumn("PlanName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactId", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactPhoneNumber", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ProductId", typeof(String)));

            //  add each of the data rows to the table
            foreach (GridViewRow row in dtg.Rows)
            {
                Label lblName = (Label)row.FindControl("lblName");
                DropDownList ddlItemPlanContact = (DropDownList)row.FindControl("ddlItemPlanContact");
                DropDownList ddlItemPlanContactPhoneNumber = (DropDownList)row.FindControl("ddlItemPlanContactPhoneNumber");
                Label lblProductID = (Label)row.FindControl("lblProductID");

                if (ddlItemPlanContact.SelectedItem.Text != "Select")
                {
                    dr = dt.NewRow();
                    dr[0] = Convert.ToString(lblName.Text).Replace(" ", "");
                    dr[1] = Convert.ToString(ddlItemPlanContact.SelectedItem.Value);
                    dr[2] = Convert.ToString(ddlItemPlanContact.SelectedItem.Text);
                    dr[4] = Convert.ToString(lblProductID.Text);

                    foreach (ListItem item in ddlItemPlanContactPhoneNumber.Items)
                    {
                        if (item.Value == Convert.ToString(ddlItemPlanContact.SelectedItem.Value))
                        {
                            dr[3] = Convert.ToString(item.Text);
                        }
                    }

                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                if (Convert.ToString(Session["Summary"]) == "Tools1")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        flag = false;
                        //Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                    }
                }

                if (Convert.ToString(Session["Summary"]) == "Tools2")
                {
                    //int cnt = 0;
                    //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                    //{
                    //    if (cblistAccountContact.Items[i].Selected == true)
                    //    {
                    //        cnt++;
                    //    }
                    //}

                    //if (cnt > 3)
                    //{
                    //    string script = "alert(\"Please select max 3 Account Contacts.\");";
                    //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    //    flag = false;
                    //}

                    grdPlans.DataSource = null;
                    grdPlans.DataBind();

                    flag = CheckAccountContactsSelected();
                }

                if (flag == true)
                {
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                                if (Convert.ToString(Session["Summary"]) == "Tools1")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                else
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    commonPlanList.Add(item);
                                }
                            }

                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();

                            lstPlanList = (from l in commonPlanList
                                           orderby l.ProductTypeId, l.CarrierName ascending
                                           select l).ToList();

                            grdPlans.DataSource = lstPlanList;
                            grdPlans.DataBind();

                            if (commonPlanList.Count > 0)
                            {
                                pnlPlans.Visible = true;
                                CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                                ChkBoxHeader.Checked = true;
                                foreach (GridViewRow row in grdPlans.Rows)
                                {
                                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                                    ChkBoxRows.Checked = true;
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            else
                            {
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        protected DataTable CreateContactTable()
        {
            try
            {
                dtPlanContact.Columns.Add("ProductId", typeof(string));
                dtPlanContact.Columns.Add("ContactId", typeof(string));
                dtPlanContact.Columns.Add("ContactName", typeof(string));
                dtPlanContact.Columns.Add("ContactEmail", typeof(string));
                dtPlanContact.Columns.Add("ContactWorkPhone", typeof(string));
                dtPlanContact.Columns.Add("Contact_FirstName", typeof(string));
                dtPlanContact.Columns.Add("Contact_LastName", typeof(string));
                dtPlanContact.Columns.Add("Contact_Address", typeof(string));
                dtPlanContact.Columns.Add("CarrierName", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return dtPlanContact;
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }

        private DataTable GetPlanInfoTable()
        {
            //  DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();

            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (chkItemSelect.Checked == true)
                        {
                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }

                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For ProductTypeId
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                            }

                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        //protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        if (e.Row.RowIndex == 0)
        //            e.Row.Style.Add("width", "8px");
        //    }
        //}

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }
        protected void chkHeaderSelectAccountCnt_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)GridView1.HeaderRow.FindControl("chkHeaderSelectAccountCnt");

            foreach (GridViewRow row in grdAccountTeam.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            // ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdAccountTeam');</script>", false);
        }
        private bool CheckAccountContactsSelected()
        {
            bool flag = true;
            try
            {
                int cnt = 0;

                foreach (GridViewRow row in grdAccountTeam.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chkRow = (row.Cells[4].FindControl("chkItemSelect") as CheckBox);
                        if (chkRow.Checked)
                        {
                            cnt++;
                        }
                    }
                }


                if (cnt == 0)
                {
                    string script = "alert(\"Please select Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return flag;
        }
        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (mvClientContact.ActiveViewIndex == 1)
                {
                    mvClientContact.ActiveViewIndex = 0;
                    btnPrevious.Visible = false;
                    btnNext.Visible = true;
                    btnSummary.Visible = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnNext_Click(object sender, EventArgs e)
        {
            List<Eligibility> EligibilityList = new List<Eligibility>();
            Eligibility eligibilityItem = new Eligibility();
            string _PlanName = string.Empty;
            string selected_Value = string.Empty;
            bool flag = true;


            try
            {
                if (mvClientContact.ActiveViewIndex == 0)
                {
                    if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                    {
                        if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                            ddlClient.Focus();
                            flag = false;
                        }


                        else if (ddlReportFormat.SelectedItem.Value == "0")
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Layout Option.')</script>", false);
                            if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                            {
                                ddlReportFormat.Focus();
                                flag = false;
                            }

                        }


                        else if (ddlOffice.SelectedIndex == 0) // Legal Name
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Legal Name.')</script>", false);
                            if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                            {
                                ddlOffice.Focus();
                                flag = false;
                            }

                        }

                        else if (ddlUSI_State.SelectedIndex == 0) // USI State
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select State.')</script>", false);
                            if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                            {
                                ddlUSI_State.Focus();
                                flag = false;
                            }

                        }

                        else if (ddlUSI_City.SelectedIndex == 0) //  USI Office
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select USI Office.')</script>", false);
                            if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                            {
                                ddlUSI_City.Focus();
                                flag = false;
                            }
                        }
                        else if (ddlBRC.SelectedIndex == 0) // BRC
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select BRC.')</script>", false);
                            if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                            {
                                ddlBRC.Focus();
                                flag = false;
                            }

                        }
                        else
                        {
                            flag = CheckAccountContactsSelected();
                        }
                        if (flag == true)
                        {

                            mvClientContact.ActiveViewIndex = 1;
                            btnPrevious.Visible = true;
                            btnNext.Visible = false;
                            btnSummary.Visible = true;
                            ddlPlanContacts.SelectedIndex = 1;
                            dvPlanContacts.DataSource = null;
                            dvPlanContacts.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #region Move Account Contact GridView Rows
        protected void MoveGridViewRows(object sender, EventArgs e)
        {

            List<UserDetails> TempUserList = (List<UserDetails>)Session["lstUserDetails"];

            Button btnUp = (Button)sender;
            GridViewRow row = (GridViewRow)btnUp.NamingContainer;
            //ViewState["IsCheckedAll"] = ((CheckBox)sender).Checked;

            switch (btnUp.CommandName)
            {
                case "Up":
                    //If First Item, insert at end (rotating positions)  
                    if (row.RowIndex.Equals(0))
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('This is First Record.')</script>", false);
                    }
                    else
                    {
                        UserDetails PrevRec = TempUserList.ElementAt(row.RowIndex - 1);
                        UserDetails CurrRec = TempUserList.ElementAt(row.RowIndex);

                        TempUserList.RemoveAt(row.RowIndex);
                        TempUserList.Insert(row.RowIndex, PrevRec);

                        TempUserList.RemoveAt(row.RowIndex - 1);
                        TempUserList.Insert(row.RowIndex - 1, CurrRec);
                    }
                    break;
                case "Down":
                    //if last item, insert at beginning (rotating positions)  
                    if (row.RowIndex.Equals(grdAccountTeam.Rows.Count - 1))
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('This is Last Record.')</script>", false);
                    }
                    else
                    {
                        UserDetails PrevRec = TempUserList.ElementAt(row.RowIndex + 1);
                        UserDetails CurrRec = TempUserList.ElementAt(row.RowIndex);

                        TempUserList.RemoveAt(row.RowIndex);
                        TempUserList.Insert(row.RowIndex, PrevRec);

                        TempUserList.RemoveAt(row.RowIndex + 1);
                        TempUserList.Insert(row.RowIndex + 1, CurrRec);
                    }
                    break;
            }

            grdAccountTeam.DataSource = TempUserList;
            grdAccountTeam.DataBind();

            //for (int i = 0; i < grdAccountTeam.Rows.Count; i++)
            //{
            //    CheckBox chkbox = (CheckBox)grdAccountTeam.Rows[i].FindControl("chkItemSelect");
            //    if (chkbox.Checked == true)
            //    {
            //        chkbox.Checked = true;
            //    }
            //}
        }
        #endregion

        protected void btnSummary_Click1(object sender, EventArgs e)
        {
            try
            {
                dtPlanContact.Clear();
                PlanInfoTable = GetPlanInfoTable();

                TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;


                if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                {
                    if (PlanInfoTable != null)
                    {
                        if (PlanInfoTable.Rows.Count > 0)
                        {
                            foreach (GridViewRow oItem in grdPlans.Rows)
                            {
                                CheckBox chkSelect = oItem.Cells[8].FindControl("chkItemSelect") as CheckBox;
                                Label lblProductType = oItem.Cells[7].FindControl("ProductTypeId") as Label;

                                if (chkSelect.Checked)
                                {
                                    //var planTYpe = GetPlanName(Convert.ToInt16(lblProductType));
                                    flag = true;
                                    break;
                                }
                            }
                            //foreach (DataRow dr in PlanInfoTable.Rows)
                            //{
                            //    string planName = GetPlanName(Convert.ToInt16(dr["ProductTypeId"]));
                            //    if (planName == "Medical")
                            //    {
                            //        flag = true;
                            //        break;
                            //    }
                            //}
                        }
                        else
                        {
                            if (grdPlans.Rows.Count > 0)
                            {
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            flag = false;
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                        }
                    }
                }

                if (flag == true)
                {
                    string mynewfile = "";
                    int count = 0;
                    List<DataRow> rowDeleteList = new List<DataRow>();

                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    foreach (GridViewRow oItem in dvPlanContacts.Rows)
                    {
                        DropDownList dropdwn = oItem.Cells[1].FindControl("ddlItemPlanContact") as DropDownList;
                        //Label lblContractID = oItem.Cells[2].FindControl("lblContractID") as Label;

                        if (dropdwn != null)
                        {
                            if (dropdwn.SelectedIndex == 1)
                            {
                                DataRow dr = dtPlanContactInfo.Rows[count];
                                dtPlanContact.ImportRow(dr);
                                DataRow drnew = dtPlanContact.Rows[count];
                                drnew["ContactName"] = "";
                                drnew["ContactWorkPhone"] = "";
                                drnew["ContactEmail"] = "";
                            }
                            else if (dropdwn.SelectedIndex != 1 || dropdwn.SelectedIndex != 0)
                            {
                                //DataRow dr = dtPlanContactInfo.Rows[count];
                                //dtPlanContact.ImportRow(dr);
                                foreach (DataRow r in dtPlanContactInfo.Rows)
                                {
                                    if (dropdwn.SelectedValue == r["ContactId"].ToString())
                                    {
                                        dtPlanContact.ImportRow(r);
                                        break;
                                        //rowDeleteList.Add(r);
                                        //r["ContactName"] = "";
                                        //r["ContactWorkPhone"] = "";
                                        //r["ContactEmail"] = "";
                                    }
                                }
                            }
                        }
                        count++;
                    }

                    //foreach (DataRow row in rowDeleteList)
                    //{
                    //    dtPlanContactInfo.Rows.Remove(row);
                    //}

                    if (Convert.ToString(Session["Summary"]) == "Tools_ClientContact")
                    {
                        mynewfile = CreateClientContact(SessionId);
                    }



                    DownloadFileNew(mynewfile);

                    // DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}