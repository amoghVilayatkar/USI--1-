﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class Word_Office
    {
        private Word.Document _oworddoc;
        private Word.ApplicationClass _oWordApp;

        public Word.Document oWordDoc
        {
            get
            {
                return _oworddoc;
            }
            set
            {
                _oworddoc = value;
            }
        }

        public Word.ApplicationClass oWordApp
        {
            get
            {
                return _oWordApp;
            }
            set
            {
                _oWordApp = value;
            }
        }
    }
}