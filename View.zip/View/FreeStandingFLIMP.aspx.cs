﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using BenefitPointSummaryPortal.BAL.Reports;

namespace BenefitPointSummaryPortal.View
{
    public partial class FreeStandingFLIMP : System.Web.UI.Page
    {
        #region  Global Variable
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        static string SessionId;
        private static string Activity = "";
        private static string Activity_Group = "";

        //For Activity Log
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        static DataSet AccountDS = new DataSet();
        static DataSet AccountTeamMemberDS = new DataSet();
        static List<Contact> ContactList = new List<Contact>();
        SummaryDetail sd = new SummaryDetail();
        static string Account_Region = string.Empty;
        static string Account_Office = string.Empty;
        static string VideosSelected = string.Empty;

        //Dictionary for Video Merge Fields
        private static Dictionary<string, string> DictVideos = new Dictionary<string, string>();

        //Dictionary for Video Merge Fields of Videos Selected
        public static Dictionary<string, string> DictVideosSelected;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //Session["Summary"] = "FreeStandingFLIMP";

                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    if (Convert.ToString(Session["Summary"]) == "FreeStandingFLIMP")
                    {
                        TitleSpan.InnerText = "Free Standing Flimp";
                    }

                    Session["DeliverableCategory"] = "Employee Communications";
                    DictDepartment = sd.getDepartmentDetails();

                    txtsearch.Focus();
                    Activity_Group = "Communications";
                    Activity = TitleSpan.InnerText;

                    //Loading data to dictVideos 
                    GetDictonaryVideos();


                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                ddlLanguage.SelectedIndex = 0;
                rdlClient.SelectedIndex = 0;
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {

                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                ddlLanguage.SelectedIndex = 0;
                ddlClient.Items.Clear();

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                string mynewfile = string.Empty;

                //Creating a copy of DictVideos 
                DictVideosSelected = new Dictionary<string, string>(DictVideos);

                //Creating List of CheckListBoxes
                List<CheckBoxList> ListChk = new List<CheckBoxList>();
                ListChk.Add(chkMedicalVideo);
                ListChk.Add(ChkPrescriptionDrugs);
                ListChk.Add(chkHRAVideo);
                ListChk.Add(chkDisability);
                ListChk.Add(chkDental);
                ListChk.Add(chkVision);
                ListChk.Add(chkLife);
                ListChk.Add(ChkVoluntary);
                ListChk.Add(chkAdditional);
                ListChk.Add(chkHrGeneral);

                //Looping through List such that "DictVideosSelected" only contains selected videos MERGEFIELDS
                foreach (CheckBoxList checkboxlist in ListChk)
                {
                    foreach (ListItem listitem in checkboxlist.Items)
                    {
                        string value = listitem.Value.ToString();
                        if (listitem.Selected == false)
                        {
                            if (DictVideosSelected.ContainsKey(value))
                            {
                                DictVideosSelected.Remove(value);
                            }
                        }

                    }
                }

                if (DictVideosSelected.Count > 0)
                {
                    VideosSelected = "Videos Selected : " + DictVideosSelected.Count.ToString();
                    mynewfile = CreateTemplate_FLIMPVideos();
                }
                else
                {
                    // Commented and Handled on Client Side.
                    //ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select atleast one FLIMP video')</script>", false);
                    return;
                }

                if (mynewfile != "")
                {
                    DownloadFileNew(mynewfile);
                }

                //Insering Log 
                InsertLog("Language : " + ddlLanguage.SelectedItem.Text, VideosSelected);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //Creates and returns a Dictonary of  <EnglishMergeField, SpanishMergeField>
        protected Dictionary<string, string> GetDictonaryVideos()
        {
            DictVideos.Clear();
            //-----------------------------------------------------------------
            // For better performance - Add Videos in same order as in Powerpoint Base Template i.e Section wise and video wise 
            //-------------------------------------------------------------------

            #region Section-1 : Medical Videos
            DictVideos.Add("MedVideo1", "MedVideo1_Spanish");
            DictVideos.Add("MedVideo2", "MedVideo2_Spanish");
            DictVideos.Add("MedVideo3", "MedVideo3_Spanish");
            DictVideos.Add("MedVideo4", "MedVideo4_Spanish");
            DictVideos.Add("MedVideo5", "MedVideo5_Spanish");
            DictVideos.Add("MedVideo6", "MedVideo6_Spanish");
            DictVideos.Add("MedVideo7", "MedVideo7_Spanish");
            DictVideos.Add("MedVideo8", "MedVideo8_Spanish");
            DictVideos.Add("MedVideo9", "MedVideo9_Spanish");
            DictVideos.Add("MedVideo10", "MedVideo10_Spanish");
            DictVideos.Add("MedVideo11", "MedVideo11_Spanish");
            DictVideos.Add("MedVideo12", "MedVideo12_Spanish");
            DictVideos.Add("MedVideo13", "MedVideo13_Spanish");
            DictVideos.Add("MedVideo14", "MedVideo14_Spanish");
            #endregion

            #region Section-2 : Prescription Drugs  *Newly Added

            DictVideos.Add("PrescriptionDrugs1", "PrescriptionDrugs1_Spanish");
            DictVideos.Add("PrescriptionDrugs2", "PrescriptionDrugs2_Spanish");
            #endregion

            #region Section-3 : HRA/HSA

            DictVideos.Add("HRAVideo1", "HRAVideo1_Spanish");
            DictVideos.Add("HRAVideo2", "HRAVideo2_Spanish");
            DictVideos.Add("HRAVideo3", "HRAVideo3_Spanish");
            DictVideos.Add("HRAVideo4", "HRAVideo4_Spanish");
            DictVideos.Add("HRAVideo5", "HRAVideo5_Spanish");
            #endregion

            #region Section-4 : Disability Video

            DictVideos.Add("DisabilityVideo1", "DisabilityVideo1_Spanish");
            #endregion

            #region Section-5 : Dental Videos

            DictVideos.Add("DentalVideo1", "DentalVideo1_Spanish");
            #endregion

            #region Section-6 : Vision Videos

            DictVideos.Add("VisionVideo1", "VisionVideo1_Spanish");
            #endregion

            #region Section-7 : Life and AD&D

            DictVideos.Add("LifeVideo1", "LifeVideo1_Spanish");
            DictVideos.Add("LifeVideo2", "LifeVideo2_Spanish");
            DictVideos.Add("LifeVideo3", "LifeVideo3_Spanish");
            DictVideos.Add("LifeVideo4", "LifeVideo4_Spanish");
            #endregion

            #region Section-8 : Voluntary Video

            DictVideos.Add("VoluntaryVideo1", "VoluntaryVideo1_Spanish");
            DictVideos.Add("VoluntaryVideo2", "VoluntaryVideo2_Spanish");
            DictVideos.Add("VoluntaryVideo3", "VoluntaryVideo3_Spanish");
            DictVideos.Add("VoluntaryVideo4", "VoluntaryVideo4_Spanish");
            DictVideos.Add("VoluntaryVideo5", "VoluntaryVideo5_Spanish");
            DictVideos.Add("VoluntaryVideo6", "VoluntaryVideo6_Spanish");
            #endregion

            #region Section-9 : Additional Products Video

            DictVideos.Add("AdditionalVideo1", "AdditionalVideo1_Spanish");
            DictVideos.Add("AdditionalVideo2", "AdditionalVideo2_Spanish");
            DictVideos.Add("AdditionalVideo3", "AdditionalVideo3_Spanish");
            DictVideos.Add("AdditionalVideo4", "AdditionalVideo4_Spanish");
            #endregion

            #region Section-10 : Hr and General Vidoes

            DictVideos.Add("HRVideo1", "HRVideo1_Spanish");
            DictVideos.Add("HRVideo2", "HRVideo2_Spanish");
            DictVideos.Add("HRVideo3", "HRVideo3_Spanish");
            DictVideos.Add("HRVideo4", "HRVideo4_Spanish");
            DictVideos.Add("HRVideo5", "HRVideo5_Spanish");
            DictVideos.Add("HRVideo6", "HRVideo6_Spanish");
            DictVideos.Add("HRVideo7", "HRVideo7_Spanish");
            DictVideos.Add("HRVideo8", "HRVideo8_Spanish");
            #endregion



            return DictVideos;
        }

        [STAThread]
        protected string CreateTemplate_FLIMPVideos()
        {

            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;
            bool bAssistantOn;

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/FreeStandingFLIMPVideos.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/FreeStandardFLIMP/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/FreeStandardFLIMP")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/FreeStandardFLIMP"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    WritePowerPoint_FreeStandingFLIMP wt = new WritePowerPoint_FreeStandingFLIMP();
                    wt.Write_FLIMPVideos(objPres, objPresSet, DictVideosSelected, objSlides, objShapes, txtFrame, txtRange, ddlLanguage);


                    objPres.Save();
                }

                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {

                        CreateTemplate_FLIMPVideos();
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return savefilename.ToString();
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {

            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);

            sd.BuildAccountTable();
            AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            if (ddlClient.SelectedValue != "")
            {
                AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            }

            Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);


        }

        protected void InsertLog(string Criteria1 = "", string Criteria2 = "", string Criteria3 = "", string Criteria4 = "")
        {
            DicActivityLog.Clear();
            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Criteria1, Criteria2, Criteria3, Criteria4);

        }

    }
}