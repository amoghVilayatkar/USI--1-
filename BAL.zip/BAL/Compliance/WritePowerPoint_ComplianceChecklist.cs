﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.Compliance
{
    public class WritePowerPoint_ComplianceChecklist
    {
        //Write data on SlideMaster and Custom layouts
        internal void WriteSlideMaster(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            Microsoft.Office.Interop.PowerPoint.Master sliedmaster1 = objPres.SlideMaster;
            Microsoft.Office.Interop.PowerPoint.Master sliedmaster2 = objPres.Slides[1].Design.SlideMaster;

            #region Writing Year in SlideMaster-1 Footer
            for (int i = 1; i <= sliedmaster1.Shapes.Count; i++)
            {
                if (sliedmaster1.Shapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                {
                    if (sliedmaster1.Shapes[i].Name == "Textdate")
                    {
                        txtFrame = sliedmaster1.Shapes[i].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<Current Year>>"))
                        {
                            txtRange.Replace("<<Current Year>>", DateTime.Today.Year.ToString());
                            break;
                        }
                    }
                }
            }
            #endregion

            #region Writing Year in SlideMaster-2 Footer
            for (int i = 1; i <= sliedmaster2.Shapes.Count; i++)
            {
                if (sliedmaster2.Shapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                {
                    if (sliedmaster2.Shapes[i].Name == "Textdate")
                    {
                        txtFrame = sliedmaster2.Shapes[i].TextFrame;
                        txtRange = txtFrame.TextRange;

                        if (txtRange.Text.Contains("<<Current Year>>"))
                        {
                            txtRange.Replace("<<Current Year>>", DateTime.Today.Year.ToString());
                            break;
                        }
                    }
                }
            }
            #endregion

            #region Writing Year in Footer of Custom Slides of SlideMaster-2
            for (int i = 1; i <= sliedmaster2.CustomLayouts.Count; i++)
            {
                for (int j = 1; j < sliedmaster2.CustomLayouts[i].Shapes.Count; j++)
                {
                    if (sliedmaster2.CustomLayouts[i].Shapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        if (sliedmaster2.CustomLayouts[i].Shapes[j].Name == "Textdate")
                        {
                            txtFrame = sliedmaster2.CustomLayouts[i].Shapes[j].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Current Year>>"))
                            {
                                txtRange.Replace("<<Current Year>>", DateTime.Today.Year.ToString());
                                break;
                            }
                        }
                    }
                }


            }
            #endregion

        }

        //Write data on slides in shapes
        internal void WriteCommonFields(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddlClient, DateTime MeetingDate)
        {
            Microsoft.Office.Interop.PowerPoint.Slide slide = objPres.Slides[1];

            for (int i = 1; i <= slide.Shapes.Count; i++)
            {
                if (slide.Shapes[i].HasTextFrame == Microsoft.Office.Core.MsoTriState.msoTrue)
                {
                    txtFrame = slide.Shapes[i].TextFrame;
                    txtRange = txtFrame.TextRange;

                    if (txtRange.Text.Contains("<<Client Name>>"))
                    {
                        txtRange.Replace("<<Client Name>>", ddlClient.SelectedItem.Text.ToString());
                    }

                    if (txtRange.Text.Contains("<<Meeting date>>"))
                    {
                        txtRange.Replace("<<Meeting date>>", MeetingDate.ToString("MMMM dd, yyyy"));
                    }
                }
            }
        }

    }
}