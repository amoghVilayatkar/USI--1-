﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using BenefitPointSummaryPortal.BAL.Tools;

namespace BenefitPointSummaryPortal.View
{
    public partial class CensusRequestTemplate : System.Web.UI.Page
    {

        #region  Global Variable
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        static string SessionId;
        private static string Activity = "";
        private static string Activity_Group = "";

        //For Activity Log
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        static DataSet AccountDS = new DataSet();
        static DataSet AccountTeamMemberDS = new DataSet();
        static List<Contact> ContactList = new List<Contact>();
        SummaryDetail sd = new SummaryDetail();
        static string Account_Region = string.Empty;
        static string Account_Office = string.Empty;


        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //Session["Summary"] = "CensusRequestTemplate";

                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                   // if (Convert.ToString(Session["Summary"]) == "CensusRequestTemplate")
                   // {
                        TitleSpan.InnerText = "Census Request Template";
                  //  }

                    Session["DeliverableCategory"] = "Client Management Tools";
                    DictDepartment = sd.getDepartmentDetails();

                    txtsearch.Focus();
                    Activity_Group = "Tools";
                    Activity = TitleSpan.InnerText;

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {

                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                ddlLayout.SelectedIndex = 0;
                ddlClient.Items.Clear();

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                sd.BuildAccountTable();
                
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }



                // AccountDS.Tables[1].Rows[0]["groupAccountInfo_SICCode"]
                switch (ddlLayout.SelectedValue)
                {
                    case "Over50Employees":
                        Create_Census_Over50_Template();
                        break;
                    case "Under50Employees":
                        Create_Census_Under50_Template();
                        break;
                    default: return;
                }

                //Insering Log 
               InsertLog(ddlLayout.SelectedItem.Text);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {

            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);

            sd.BuildAccountTable();
            AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            if (ddlClient.SelectedValue != "")
            {
                AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            }

            Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);


        }

        //Census Over 50 Employees
        protected void Create_Census_Over50_Template()
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            string BPUser_Name = string.Empty;
            string SICCode = string.Empty;

            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Tools/Documents/Templates/Census_Over50_Template.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/Census_Over50_Template/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/Census_Over50_Template/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/Census_Over50_Template/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                SICCode = AccountDS.Tables[1].Rows[0]["groupAccountInfo_SICCode"].ToString();
               // WriteAncillaryIntakeFormRFP wr = new WriteAncillaryIntakeFormRFP();
                WriteCensusRequestTemplate wr = new WriteCensusRequestTemplate();
                wr.Write_CensusOver50_Template(myExcelApp, ddlClient.SelectedItem.Text, SICCode);
                //string SummaryName_SheetName = string.Empty;

                //wr.WriteRFPDetails(myExcelApp, ddlClient, SummaryName_SheetName, MainAddress, AccountDS, AccountTeamMemberDS, Account_Region, Account_Office, dtOfficeAddress, dtEffectiveRenewalDate, dtRFPDueDate, dtMeetingDate, BPUser_Name);
               // wr.WritePlanTo_AncillaryIntakeForm(myExcelApp, SummaryName_SheetName, dtblPlansSelected, AdditionalLOCCount, MaxLOCCount);
                

                //myWorksheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SummaryName_SheetName];
                //Excel.Range r = myWorksheet.Cells[1, 1];
                //r.Select();
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        //Census Under 50 Employees
        protected void Create_Census_Under50_Template()
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            string BPUser_Name = string.Empty;
            string SICCode = string.Empty;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Tools/Documents/Templates/Census_Under50_Template.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/Census_Under50_Template/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/Census_Under50_Template/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/Census_Under50_Template/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);



                SICCode = AccountDS.Tables[1].Rows[0]["groupAccountInfo_SICCode"].ToString();
                // WriteAncillaryIntakeFormRFP wr = new WriteAncillaryIntakeFormRFP();
                WriteCensusRequestTemplate wr = new WriteCensusRequestTemplate();
                wr.Write_CensusUnder50_Template(myExcelApp, ddlClient.SelectedItem.Text, SICCode);
               // string SummaryName_SheetName = string.Empty;


                //SummaryName_SheetName = "RFP Submission";
                //myWorksheet = myWorkbook.Worksheets[1];


                //wr.WriteRFPDetails(myExcelApp, ddlClient, SummaryName_SheetName, MainAddress, AccountDS, AccountTeamMemberDS, Account_Region, Account_Office, dtOfficeAddress, dtEffectiveRenewalDate, dtRFPDueDate, dtMeetingDate, BPUser_Name);
                // wr.WritePlanTo_AncillaryIntakeForm(myExcelApp, SummaryName_SheetName, dtblPlansSelected, AdditionalLOCCount, MaxLOCCount);
                //myWorksheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SummaryName_SheetName];
               // Excel.Range r = myWorksheet.Cells[1, 1];
               // r.Select();
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void InsertLog(string Criteria1 = "", string Criteria2 = "", string Criteria3 = "", string Criteria4 = "")
        {
            DicActivityLog.Clear();
            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Criteria1, Criteria2, Criteria3, Criteria4);

        }
    }
}